"use client";

import { Icon } from "@iconify/react/dist/iconify.js";
import { Button } from "@nextui-org/react";
import clsx from "clsx";
import Link from "next/link";
import React from "react";
import data from "../../common/data/contactData.json";
import Text from "@/components/Text";
import { twMerge } from "tailwind-merge";

type Props = {
   langText: any;
   className?: string;
};

const CareerSection = ({ className, langText }: Props) => {
   return (
      <div className={twMerge(clsx(className))}>
         <div className="md:px-[80px] pb-[40px] border-b border-[#262626] flex flex-col lg:flex-row justify-between items-start gap-y-[20px]">
            <div>
               {" "}
               <Text className="inter text-[12px] leading-[24px] tracking-[1.2px] md:text-[14px] md:tracking-[1.4px] uppercase text-[#Ababab] text-start">
                  {langText.subTitle}
               </Text>
               <h3 className=" text-[25px] md:text-[45px] leading-[30px] md:leading-[60px]  w-[294px] md:w-[528px] poppins">
                  {langText.title}
               </h3>
            </div>

            <Link
               href={langText.btnLink}
               data-aos="zoom-in-up"
               data-aos-duration={500}
               data-aos-delay={500}
               data-aos-anchor-placement="top-bottom"
            >
               <Button
                  className={twMerge(
                     clsx(
                        " text-[14px] text-center !bg-[#1463fd] !border-[#1463fd] rounded-full font-bold inter leading-[24px] text-[#ffffff] hover:border-[#1463fd] after:bg-white hover:text-[#1463fd] px-[30px] py-[15px] btn"
                     )
                  )}
               >
                  {langText.btnText}
                  <Icon
                     icon={langText.btnIcon}
                     className="text-[18px] mt-[2px] "
                  />
               </Button>
            </Link>
         </div>
         <div className="md:px-[80px]">
            <p className="inter max-w-[379px]   md:max-w-[530px] text-[14px] leading-[24px] text-[#f5f5f5]">
               {langText.text}
            </p>
         </div>
      </div>
   );
};

export default CareerSection;
