"use client";
import clsx from "clsx";
import Link from "next/link";
import { twMerge } from "tailwind-merge";
import data from "../../common/data/contactData.json";
import SectionTitle from "../SectionTitle";
import Text from "@/components/Text";

type Props = {
   langText: any;
   className?: string;
};

const AddressSection = ({ className, langText }: Props) => {
   const googleMapsLink = `https://www.google.com/maps?q=${encodeURIComponent(
      langText.officeAddress.address
   )}`;
   return (
      <div className={twMerge(clsx(className))}>
         <div className="grid gap-y-[40px] xl:grid-cols-11">
            <div className=" space-y-[10px] col-span-3">
               <SectionTitle
                  className="text-start"
                  animationVariant="fadeRight"
               >
                  {langText.title}
               </SectionTitle>
               <Text className="text-start" animationVariant="fadeRight">
                  {langText.text}
               </Text>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-[40px] md:gap-[50px] col-span-8 pt-[10px] ">
               {/* NOTE: Address */}
               <div
                  className="grid gap-[5px] md:gap-[10px] w-[296px]"
                  data-aos="fade-left"
                  data-aos-duration="600"
                  data-aos-delay="150"
                  data-aos-anchor-placement="top-bottom"
               >
                  <h3 className=" poppins text-[20px] font-bold leading-[40px]">
                     {langText.officeAddress.title}
                  </h3>
                  <a
                     href={googleMapsLink}
                     target="_blank"
                     rel="noopener noreferrer"
                     className="text-[14px] md:text-[16px] mt-[5px] md:mt-0 leading-[24px] md:leading-[28px] text-[#f5f5f5] inter"
                  >
                     {langText.officeAddress.address}
                  </a>

                  <p className="  text-[14px] md:text-[16px]  md:mt-[10px] leading-[24px] md:leading-[28px] text-[#f5f5f5] inter">
                     <span className="font-semibold text-[#fff]">
                        {langText.officeAddress.assisDays}
                     </span>{" "}
                     {langText.officeAddress.assisTime}
                  </p>
               </div>

               {/* NOTE: Phone Number */}
               <div
                  className="grid gap-[5px] md:gap-[10px] w-[296px]"
                  data-aos="fade-left"
                  data-aos-duration="600"
                  data-aos-delay="450"
                  data-aos-anchor-placement="top-bottom"
               >
                  <h3 className=" poppins text-[20px] font-bold leading-[40px]">
                     {langText.contactNumber.title}
                  </h3>
                  <div className="text-[14px] md:text-[16px] mt-[5px] md:mt-0 leading-[24px] md:leading-[28px] text-[#f5f5f5] inter">
                     <Link
                        href={`tel:${langText.contactNumber.phoneOne}`}
                        className="text-[#f5f5f5] hover:text-[#fff] inter"
                     >
                        {langText.contactNumber.phoneOne}
                     </Link>
                     <br />
                     <Link
                        href={`tel:${langText.contactNumber.phoneTwo}`}
                        className="text-[#f5f5f5] hover:text-[#fff] inter"
                     >
                        {langText.contactNumber.phoneTwo}
                     </Link>
                  </div>
                  <p className="  text-[14px] md:text-[16px]  md:mt-[10px] leading-[24px] md:leading-[28px] text-[#f5f5f5] inter">
                     <span className="font-semibold text-[#fff]">
                        {langText.contactNumber.assisHours}
                     </span>{" "}
                     {langText.contactNumber.assisTime}
                  </p>
               </div>

               {/* NOTE: Mail */}
               <div
                  className="grid gap-[5px] md:gap-[10px] md:w-[241px]"
                  data-aos="fade-left"
                  data-aos-duration="600"
                  data-aos-delay="650"
                  data-aos-anchor-placement="top-bottom"
               >
                  <h3 className=" poppins text-[20px] font-bold leading-[40px]">
                     {langText.mailAddress.title}
                  </h3>
                  <div className="text-[14px] md:text-[16px] mt-[5px] md:mt-0 leading-[24px] md:leading-[28px] text-[#f5f5f5] inter">
                     <Link
                        href="mailto:support@bytescrum.com"
                        className="text-[#f5f5f5] hover:text-[#fff] inter"
                     >
                        {langText.mailAddress.emailOne}
                     </Link>
                     <br />
                     <Link
                        href="mailto:info@bytescrum.com"
                        className="text-[#f5f5f5] hover:text-[#fff] inter"
                     >
                        {langText.mailAddress.emailTwo}
                     </Link>
                  </div>
                  <p className="  text-[14px] md:text-[16px]  md:mt-[10px] leading-[24px] md:leading-[28px] text-[#f5f5f5] inter">
                     <span className="font-semibold text-[#fff]">
                        {langText.mailAddress.assisHours}
                     </span>{" "}
                     {langText.mailAddress.assisTime}
                  </p>
               </div>
            </div>
         </div>
      </div>
   );
};

export default AddressSection;
