"use client";

import clsx from "clsx";
import { useState } from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import { twMerge } from "tailwind-merge";
import * as Yup from "yup";
import NextUIModal from "../nextUI/Modal";
import SectionTitle from "../SectionTitle";
import Text from "@/components/Text";
import axios from "axios";
import ContactUsApi from "@/common/apis/contactus.api";
import { EContactFormTypes } from "@/utils/enums";
import API_CONFIG from "@/config";
import { cn } from "@nextui-org/react";

interface IProps {
   className?: string;
   langText?: any;
}

interface FormValues {
   firstName: string;
   lastName: string;
   email: string;
   phoneNumber: string;
   subject: string;
   budget: string;
   message: string;
}

const validationSchema = Yup.object({
   firstName: Yup.string().required("First Name is required"),
   lastName: Yup.string().required("Last Name is required"),
   email: Yup.string()
      .email("Invalid email address")
      .required("Email is required"),
   phoneNumber: Yup.string().required("Phone Number is required"),
   subject: Yup.string().required("Subject is required"),
   budget: Yup.string(),
   message: Yup.string().required("Message is required"),
});

const ConnectForm = ({ className, langText }: IProps) => {
   const [isModalOpen, setIsModalOpen] = useState(false);
   const [massege, setMassege] = useState<string | undefined>();
   const [referenceNo, setReferenceNo] = useState<string | null>(null);

   const generateReferenceNo = () => {
      const date = new Date();

      const year = String(date.getFullYear()).padStart(4, "0");

      return `REF-${year}-${Math.floor(100000 + Math.random() * 900000)}`;
   };

   const fieldStyle =
      "w-full px-[30px] py-[20px] bg-[#262626]/35 rounded-[16px] border border-[#262626] text-[#b0b0b0] outline-none";

   return (
      <>
         <div
            className={twMerge(
               clsx(
                  "flex flex-col items-center justify-center px-6  bg-black text-white overflow-hidden",
                  className
               )
            )}
         >
            <div className="space-y-[10px] mb-6">
               <SectionTitle>{langText.title}</SectionTitle>

               <Text className="lg:max-w-4xl ">{langText.subTitle}</Text>
            </div>

            <Formik<FormValues>
               initialValues={{
                  firstName: "",
                  lastName: "",
                  email: "",
                  phoneNumber: "",
                  subject: "",
                  budget: "",
                  message: "",
               }}
               validationSchema={validationSchema}
               onSubmit={async (values, { setSubmitting, resetForm }) => {
                  try {
                     const ref = generateReferenceNo();
                     setReferenceNo(ref);

                     const payload = {
                        ...values,
                        formTypes: [EContactFormTypes.CONTACT_US],
                     };

                     const response = await axios.post(
                        `${API_CONFIG.BASE_URL}${ContactUsApi.base}`,
                        payload
                     );
                     if (response.data.statusCode === 400) {
                        setMassege("Email  already exists");

                        return;
                     } else {
                        setMassege("");
                     }
                     setMassege(
                        " Hey there, Your form has been posted successfully, we will get back to  you as soon as possible."
                     );
                  } catch (error: any) {
                  } finally {
                     setIsModalOpen(true);
                     setSubmitting(false);
                  }
               }}
            >
               {({ isSubmitting }) => (
                  <>
                     {" "}
                     <Form className="w-full max-w-4xl">
                        <div className="grid grid-cols-1 gap-4">
                           <div className="grid grid-cols-2 gap-4">
                              <div>
                                 <Field
                                    name={langText.form.firstName.name}
                                    type="text"
                                    placeholder={
                                       langText.form.firstName.placeholder
                                    }
                                    className={fieldStyle}
                                    data-aos="fade-right"
                                    data-aos-easing="ease-out-cubic"
                                    data-aos-anchor-placement="top-bottom"
                                 />
                                 <ErrorMessage
                                    name={langText.form.firstName.name}
                                    component="div"
                                    className="text-red-500 text-sm"
                                 />
                              </div>
                              <div>
                                 <Field
                                    name={langText.form.lastName.name}
                                    type="text"
                                    placeholder={
                                       langText.form.lastName.placeholder
                                    }
                                    className={fieldStyle}
                                    data-aos="fade-left"
                                    data-aos-easing="ease-out-cubic"
                                    data-aos-anchor-placement="top-bottom"
                                 />
                                 <ErrorMessage
                                    name={langText.form.lastName.name}
                                    component="div"
                                    className="text-red-500 text-sm"
                                 />
                              </div>
                           </div>
                           <div>
                              <Field
                                 name={langText.form.email.name}
                                 type="email"
                                 placeholder={langText.form.email.placeholder}
                                 className={fieldStyle}
                                 data-aos="fade-up"
                                 data-aos-easing="ease-out-cubic"
                                 data-aos-delay={100}
                                 data-aos-anchor-placement="top-bottom"
                              />
                              <ErrorMessage
                                 name={langText.form.email.name}
                                 component="div"
                                 className="text-red-500 text-sm"
                              />
                           </div>
                           <div>
                              <Field
                                 name={langText.form.phone.name}
                                 type="text"
                                 placeholder={langText.form.phone.placeholder}
                                 className={fieldStyle}
                                 data-aos="fade-up"
                                 data-aos-easing="ease-out-cubic"
                                 data-aos-delay={200}
                                 data-aos-anchor-placement="top-bottom"
                              />
                              <ErrorMessage
                                 name={langText.form.phone.name}
                                 component="div"
                                 className="text-red-500 text-sm"
                              />
                           </div>
                           <div>
                              <Field
                                 name={langText.form.subject.name}
                                 type="text"
                                 placeholder={langText.form.subject.placeholder}
                                 className={fieldStyle}
                                 data-aos="fade-up"
                                 data-aos-easing="ease-out-cubic"
                                 data-aos-delay={300}
                                 data-aos-anchor-placement="top-bottom"
                              />
                              <ErrorMessage
                                 name={langText.form.subject.name}
                                 component="div"
                                 className="text-red-500 text-sm"
                              />
                           </div>
                           <div>
                              <Field
                                 name={langText.form.budget.name}
                                 type="text"
                                 placeholder={langText.form.budget.placeholder}
                                 className={fieldStyle}
                                 data-aos="fade-up"
                                 data-aos-easing="ease-out-cubic"
                                 data-aos-delay={400}
                                 data-aos-anchor-placement="top-bottom"
                              />
                           </div>
                           <div>
                              <Field
                                 as="textarea"
                                 name={langText.form.message.name}
                                 placeholder={langText.form.message.placeholder}
                                 className={clsx(
                                    " resize-none h-[200px]",
                                    fieldStyle
                                 )}
                                 data-aos="fade-up"
                                 data-aos-easing="ease-out-cubic"
                                 data-aos-delay={500}
                                 data-aos-anchor-placement="top-bottom"
                              />
                              <ErrorMessage
                                 name={langText.form.message.name}
                                 component="div"
                                 className="text-red-500 text-sm"
                              />
                           </div>
                           <div
                              data-aos="fade-up"
                              data-aos-easing="ease-out-cubic"
                              data-aos-delay={600}
                              data-aos-anchor-placement="top-bottom"
                           >
                              <div className="flex justify-center mt-[31px] md:mt-[30px]">
                                 <button
                                    type="submit"
                                    disabled={isSubmitting}
                                    className="disabled:opacity-50 disabled:cursor-not-allowed py-[20px] text-[16px] border !bg-[#262626]/35 after:bg-white btn"
                                 >
                                    {isSubmitting
                                       ? "Submitting..."
                                       : langText.btnText}
                                 </button>
                              </div>
                           </div>
                        </div>
                     </Form>
                  </>
               )}
            </Formik>

            <NextUIModal
               open={isModalOpen}
               headerClass={cn({
                  " text-yellow-600": massege === "Email  already exists",
               })}
               titleIcon={
                  massege === "Email  already exists"
                     ? "typcn:warning"
                     : "fluent-emoji:thumbs-up"
               }
               title={
                  massege === "Email  already exists"
                     ? "Oopsss.."
                     : "Submitted "
               }
               onClose={() => setIsModalOpen(false)}
               size="full"
               color="black"
            >
               {" "}
               <p className="text-center inter text-[#f5f5f5] text-[12px] md:text-lg leading-[24px] md:leading-[28px] poppins md:px-16 ">
                  {massege}
               </p>
            </NextUIModal>
         </div>
      </>
   );
};

export default ConnectForm;