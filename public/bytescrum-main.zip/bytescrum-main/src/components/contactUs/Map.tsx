import React from "react";
import { GoogleMap, LoadScript, Marker } from "@react-google-maps/api";

const containerStyle = {
   width: "100%",
   height: "400px",
};

const center = {
   lat: 26.8467,
   lng: 80.9462,
};

const Map = () => {
   return (
      // <LoadScript
      //    googleMapsApiKey={
      //       process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY as string
      //    }
      // >
      //    <GoogleMap
      //       mapContainerStyle={containerStyle}
      //       center={center}
      //       zoom={14}
      //    >
      //       <Marker position={center} />
      //    </GoogleMap>
      //    hello
      // </LoadScript>
      <div className="bytes-map">
         <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3559.249295032224!2d80.99578187606505!3d26.863819562188812!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399be2bfaaaaaaad%3A0x8d25ef8108d63c47!2sByteScrum%20Technologies%20Pvt.%20Ltd.!5e0!3m2!1sen!2sin!4v1682313564602!5m2!1sen!2sin"
            width="100%"
            height="450"
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
         ></iframe>
      </div>
   );
};

export default Map;
