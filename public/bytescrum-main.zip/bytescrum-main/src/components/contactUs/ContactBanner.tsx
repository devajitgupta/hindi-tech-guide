"use client";

import PageBanner from "@/components/PageBanner";
import contactData from "../../common/data/contactData.json";
import clsx from "clsx";
import { usePathname } from "next/navigation";

type Props = {
   langText: any;
};

const ContactBanner = ({ langText }: Props) => {
   const pathName = usePathname();
   return (
      <PageBanner bgPath="/contactBanner.png">
         <div className="grid place-items-center md:gap-[10px]">
            <h1
               className="text-[35px] md:text-[70px] md:leading-[80px] font-light  poppins text-center"
               data-aos="zoom-in"
               data-aos-easing="ease-out-cubic"
               data-aos-anchor-placement="top-bottom"
            >
               {langText.pageTitleLineOne}
               <br />
               <span className="font-bold">{langText.pageTitleLineTwo}</span>
            </h1>
            <p
               className="poppins text-[#b7b7b7] text-[14px] md:text-[18px]"
               data-aos="zoom-in"
               data-aos-easing="ease-out-cubic"
               data-aos-delay={500}
               data-aos-anchor-placement="top-bottom"
            >
               {langText.links.map((link: any, index: any) => (
                  <span
                     className={clsx(
                        " text-white first:border-r first:px-3 px-2",
                        {
                           "first:text-[#b7b7b7]": pathName !== `/${pathName}`,
                        }
                     )}
                     key={index}
                  >
                     {link}
                  </span>
               ))}
            </p>
         </div>
      </PageBanner>
   );
};

export default ContactBanner;
