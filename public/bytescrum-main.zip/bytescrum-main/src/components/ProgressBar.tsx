import { motion } from "framer-motion";
import clsx from "clsx";

interface IProps {
   name: string;
   level: number;
}

const ProgressBar = ({ name, level }: IProps) => {
   return (
      <div>
         <div className="flex justify-between text-sm mb-1">
            <span className="text-[16px]  inter leading-[28px] mb-5">
               {name}
            </span>
            <span>{level}%</span>
         </div>
         <div className="w-full bg-[#595959] rounded-full h-2 relative">
            <motion.div
               className="absolute top-0 left-0 h-2 bg-white rounded-full"
               style={{ width: `${level}%` }}
               initial={{ width: "0%" }}
               animate={{ width: `${level}%` }}
               transition={{ duration: 1.2, ease: "easeInOut" }}
            />
         </div>
      </div>
      // <div className="w-full lg:max-w-md lg:mx-auto">
      //    <div className="text-[16px]  inter leading-[28px] mb-5">
      //       <span>{label}</span>
      //    </div>
      //    <div className="relative h-[5px] bg-[#595959] rounded-full">
      //       <div
      //          className={clsx("absolute h-full bg-white rounded", {
      //             "transition-all": true,
      //          })}
      //          style={{ width: `${percentage}%` }}
      //       />
      //    </div>
      //    <div className="flex justify-end mb-2 text-white  px-[10px]">
      //       <span className="text-[16px]  inter leading-[28px]">
      //          {percentage}%
      //       </span>
      //    </div>
      // </div>
   );
};

export default ProgressBar;
