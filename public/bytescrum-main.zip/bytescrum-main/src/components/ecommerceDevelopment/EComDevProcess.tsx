import { Button } from "@nextui-org/react";
import React from "react";
import SectionTitle from "../SectionTitle";
import SectionSubtitle from "../SectionSubtitle";

const EComDevProcess = () => {
   return (
      <div className="px-5 md:px-[40px] pb-[60px]   md:pb-[80px] gap-[40px] bg-[#000000] relative z-50 w-full">
         {" "}
         <div className="mt-16 max-w-7xl m-auto">

            <SectionTitle
               animationVariant="fadeUp"
               className="section-title text-center"
            >
               Our E-commerce Development Process
            </SectionTitle>
            <div className="mt-8  grid lg:grid-cols-2 gap-x-12">
               <div className="flex flex-col md:flex-row items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#1463fd] flex items-center justify-center text-white font-bold">

                     1
                  </div>
                  <div>
                     <SectionSubtitle className="text-start font-semibold ">
                        Discovery & Strategy
                     </SectionSubtitle>
                     <p className="text-[#fafafa] mb-6 ">
                        We analyze your business goals, target audience, and
                        competition to develop a comprehensive e-commerce
                        strategy.
                     </p>
                  </div>
               </div>

               <div className="flex flex-col md:flex-row items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#1463fd] flex items-center justify-center text-white font-bold">

                     2
                  </div>
                  <div>
                     <SectionSubtitle className="text-start font-semibold ">
                        UX/UI Design
                     </SectionSubtitle>
                     <p className="text-[#fafafa] mb-6 ">
                        Our designers create intuitive, conversion-focused
                        interfaces that enhance the shopping experience and
                        reflect your brand identity.
                     </p>
                  </div>
               </div>

               <div className="flex flex-col md:flex-row items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#1463fd] flex items-center justify-center text-white font-bold">

                     3
                  </div>
                  <div>
                     <SectionSubtitle className="text-start font-semibold ">
                        Development & Integration
                     </SectionSubtitle>
                     <p className="text-[#fafafa] mb-6 ">
                        We build your e-commerce platform with clean code and
                        integrate essential features like payment gateways,
                        shipping calculators, and inventory management.
                     </p>
                  </div>
               </div>

               <div className="flex flex-col md:flex-row items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#1463fd] flex items-center justify-center text-white font-bold">

                     4
                  </div>
                  <div>
                     <SectionSubtitle className="text-start font-semibold ">
                        Testing & Quality Assurance
                     </SectionSubtitle>
                     <p className="text-[#fafafa] mb-6 ">
                        We conduct thorough testing across devices and browsers
                        to ensure your store functions flawlessly and provides a
                        seamless shopping experience.
                     </p>
                  </div>
               </div>

               <div className="flex flex-col md:flex-row items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#1463fd] flex items-center justify-center text-white font-bold">

                     5
                  </div>
                  <div>
                     <SectionSubtitle className="text-start font-semibold ">
                        Launch & Optimization
                     </SectionSubtitle>
                     <p className="text-[#fafafa] mb-6 ">
                        We handle the deployment process and provide ongoing
                        optimization to improve conversion rates and enhance
                        performance.
                     </p>
                  </div>
               </div>
            </div>
         </div>
         <div className="mt-16 text-center  m-auto">
            <Button className="bg-[#1463fd] hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105">

               Launch Your Online Store
            </Button>
         </div>
      </div>
   );
};

export default EComDevProcess;
