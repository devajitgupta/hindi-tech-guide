import React from "react";
import SectionTitle from "../SectionTitle";
import Text from "../Text";
type Props = {
   langText: any;
};
const EComShopping = ({ langText }: Props) => {
   return (
      <div className="px-5 md:px-[40px] pb-[60px]   md:pb-[80px] gap-[40px] bg-[#000000] relative z-50 w-full">
         {" "}
         <div>
            <div className="space-y-5">
               <SectionTitle className="max-w-3xl m-auto">
                  {langText.title}
               </SectionTitle>
               <Text
                  className="text-[#fafafa] mt-2 mb-12 m-auto text-center lg:max-w-5xl"
                  data-aos="fade-up"
                  data-aos-delay={600}
                  data-aos-easing="ease-out-cubic"
                  data-aos-anchor-placement="top-bottom"
               >
                 {langText.ecomDescription}
               </Text>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
               <div className="service-card bg-gradient-to-br from-black to-pink-950/20">
                  <div className="w-12 h-12 bg-pink-500/20 rounded-lg flex items-center justify-center mb-4">
                     <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-pink-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                     >
                        <path
                           strokeLinecap="round"
                           strokeLinejoin="round"
                           strokeWidth={2}
                           d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
                        />
                     </svg>
                  </div>
                  <h4 className="text-xl font-semibold mb-3">
                     {langText.customerTitle}
                  </h4>
                  <p className="text-gray-400">
                     {langText.customerDescr}
                  </p>
               </div>

               <div className="service-card bg-gradient-to-br from-black to-blue-950/20">
                  <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mb-4">
                     <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-blue-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                     >
                        <path
                           strokeLinecap="round"
                           strokeLinejoin="round"
                           strokeWidth={2}
                           d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"
                        />
                     </svg>
                  </div>
                  <h4 className="text-xl font-semibold mb-3">
                     {langText.paymentTitle}
                  </h4>
                  <p className="text-gray-400">
                    {langText.paymentDescr}
                  </p>
               </div>

               <div className="service-card bg-gradient-to-br from-black to-purple-950/20">
                  <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mb-4">
                     <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-purple-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                     >
                        <path
                           strokeLinecap="round"
                           strokeLinejoin="round"
                           strokeWidth={2}
                           d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                        />
                     </svg>
                  </div>
                  <h4 className="text-xl font-semibold mb-3">
                     {langText.analysisTitle}
                  </h4>
                  <p className="text-gray-400">
                     {langText.analysisDescr}
                  </p>
               </div>

               <div className="service-card bg-gradient-to-br from-black to-amber-950/20">
                  <div className="w-12 h-12 bg-amber-500/20 rounded-lg flex items-center justify-center mb-4">
                     <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-amber-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                     >
                        <path
                           strokeLinecap="round"
                           strokeLinejoin="round"
                           strokeWidth={2}
                           d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"
                        />
                     </svg>
                  </div>
                  <h4 className="text-xl font-semibold mb-3">
                     {langText.mobileTitle}
                  </h4>
                  <p className="text-gray-400">
                     {langText.mobileDescr}
                  </p>
               </div>

               <div className="service-card bg-gradient-to-br from-black to-green-950/20">
                  <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mb-4">
                     <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-green-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                     >
                        <path
                           strokeLinecap="round"
                           strokeLinejoin="round"
                           strokeWidth={2}
                           d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z"
                        />
                     </svg>
                  </div>
                  <h4 className="text-xl font-semibold mb-3">
                     {langText.supportTitle}
                  </h4>
                  <p className="text-gray-400">
                     {langText.supportDescr}
                  </p>
               </div>

               <div className="service-card bg-gradient-to-br from-black to-teal-950/20">
                  <div className="w-12 h-12 bg-teal-500/20 rounded-lg flex items-center justify-center mb-4">
                     <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-teal-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                     >
                        <path
                           strokeLinecap="round"
                           strokeLinejoin="round"
                           strokeWidth={2}
                           d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"
                        />
                     </svg>
                  </div>
                  <h4 className="text-xl font-semibold mb-3">
                     {langText.inventoryTitle}
                  </h4>
                  <p className="text-gray-400">
                     {langText.inventoryDescr}
                  </p>
               </div>
            </div>
         </div>
      </div>
   );
};

export default EComShopping;
