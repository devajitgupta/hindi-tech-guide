import React from "react";
import SectionTitle from "../SectionTitle";
import SectionSubtitle from "../SectionSubtitle";
type Props = {
   langText: any;
};
const EComPlatform = ({ langText }: Props) => {
   return (
      <div className="px-5 md:px-[40px] pb-[60px]   md:pb-[80px] gap-[40px] bg-[#000000] relative z-50 w-full">
         <div className="mt-16 max-w-7xl m-auto">
            <div className=" overflow-hidden">
               <SectionTitle
                  animationVariant="fadeUp"
                  className=" max-w-2xl m-auto"
               >
                  {langText.secTitle}
               </SectionTitle>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8">
               {/* <div className="bg-gradient-to-br from-black to-blue-950/10 p-6 rounded-lg border border-blue-900/20 text-center"> */}
               <div className="bg-gradient-to-br from-[#0f0f0f] to-[#303030]/70 p-6 rounded-lg border border-[#2F2F2F] text-center">
                  <SectionSubtitle className="text-lg font-semibold mb-2 ">
                     {langText.shopifyTitle}
                  </SectionSubtitle>
                  <p className="text-[#fafafa]  text-center text-sm">
                     {langText.shopifyDescr}
                  </p>
               </div>

               <div className="bg-gradient-to-br from-[#0f0f0f] to-[#303030]/70 p-6 rounded-lg border border-[#2F2F2F] text-center">
                  <SectionSubtitle className="text-lg font-semibold mb-2 ">
                     {langText.WoComTitle}

                  </SectionSubtitle>
                  <p className="text-[#fafafa]  text-center text-sm">
                     {langText.WoComSubtitle}

                  </p>
               </div>

               <div className="bg-gradient-to-br from-[#0f0f0f] to-[#303030]/70 p-6 rounded-lg border border-[#2F2F2F] text-center">
                  <SectionSubtitle className="text-lg font-semibold mb-2 ">
                     {langText.magentoTitle}
                  </SectionSubtitle>
                  <p className="text-[#fafafa]  text-center text-sm">
                     {langText.magentoDescr}
                  </p>
               </div>

               <div className="bg-gradient-to-br from-[#0f0f0f] to-[#303030]/70 p-6 rounded-lg border border-[#2F2F2F] text-center">
                  <SectionSubtitle className="text-lg font-semibold mb-2 ">
                     {langText.customSolTitle}
                  </SectionSubtitle>
                  <p className="text-[#fafafa]  text-center text-sm">
                     {langText.customSolDescr}
                  </p>
               </div>
            </div>
         </div>
      </div>
   );
};

export default EComPlatform;
