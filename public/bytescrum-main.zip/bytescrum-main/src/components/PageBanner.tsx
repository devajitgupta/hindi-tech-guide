import clsx from "clsx";
import { ReactNode } from "react";
import { twMerge } from "tailwind-merge";

interface IProps {
   // pageTitle: string;
   bgPath?: any;
   className?: string;
   children: ReactNode;
   bannerHeight?: string;
   gradient?: string;
}

const PageBanner = ({
   children,
   className,
   bgPath,
   gradient,
   bannerHeight = "h-[26vh] md:h-[43vh]",
}: IProps) => {
   return (
      <div
         className={twMerge(
            clsx(
               "max-w-[1728px] m-auto bg-[#000000] inter text-[#fafafa]",
               gradient
            )
         )}
      >
         <div
            className={twMerge(
               clsx(
                  " bg-cover bg-center",
                  // bannerHeight,

                  className
               )
            )}
            style={{ backgroundImage: `url(${bgPath})` }}
         >
            <div
               className={twMerge(
                  clsx("w-full h-full grid items-center  py-24", gradient)
               )}
            >
               {children}
            </div>
         </div>
      </div>
   );
};

export default PageBanner;
