"use client";

import { Icon } from "@iconify/react";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";

interface IProps {
   variant: "prev" | "next";
   text: string;
   className?: string;
   onClick?: () => void;
}

const PrevNextBtn = ({ className, variant, text, onClick }: IProps) => {
   return (
      <button
         onClick={onClick}
         className={twMerge(
            clsx(
               "flex items-center  text-white text-[12px] md:text-[16px] leading-[28px] md:px-4 py-2 bg-transparent hover:text-gray-400",
               className
            )
         )}
         data-aos={variant === "prev" ? "fade-right" : "fade-left"}
         data-aos-easing="ease-out-cubic"
         data-aos-anchor-placement="top-bottom"
      >
         {variant === "prev" && (
            <Icon
               icon="uim:angle-left"
               className=" text-[24px] md:text-[28px] leading-[28px]"
            />
         )}
         <span>{text}</span>
         {variant === "next" && (
            <Icon
               icon="uim:angle-right"
               className="text-[24px] md:text-[28px]leading-[28px]"
            />
         )}
      </button>
   );
};

export default PrevNextBtn;
