// "use client";
// import React, { useState, useEffect } from "react";
// import { motion } from "framer-motion";

// const BackgroundGradient = ({ children }: { children?: React.ReactNode }) => {
//    const [randomColors, setRandomColors] = useState(["#ff6b6b", "#4ecdc4"]);
//    const [smokeColors, setSmokeColors] = useState([
//       "#2d3748",
//       "#4a5568",
//       "#718096",
//       "#a0aec0",
//    ]);

//    // Comprehensive array of vibrant color combinations
//    const colorSets = [
//       // Red spectrum
//       ["#ff6b6b", "#4ecdc4"], // Red to Teal
//       ["#ff4757", "#3742fa"], // Red to Blue
//       ["#ff3838", "#ff9ff3"], // Red to Pink
//       ["#ff6348", "#f0932b"], // Red to Orange
//       ["#eb4d4b", "#6c5ce7"], // Red to Purple

//       // Pink spectrum
//       ["#a8e6cf", "#ff8b94"], // Mint to Pink
//       ["#fa709a", "#fee140"], // Pink to Yellow
//       ["#f093fb", "#f5576c"], // Pink to Red
//       ["#ff9ff3", "#54a0ff"], // Pink to Blue
//       ["#ff6b9d", "#c44569"], // Pink variations

//       // Purple spectrum
//       ["#667eea", "#764ba2"], // Purple gradient
//       ["#9c88ff", "#ffeaa7"], // Purple to Yellow
//       ["#6c5ce7", "#00b894"], // Purple to Green
//       ["#a29bfe", "#fd79a8"], // Light Purple to Pink
//       ["#8e44ad", "#3498db"], // Purple to Blue

//       // Blue spectrum
//       ["#4facfe", "#00f2fe"], // Blue gradient
//       ["#54a0ff", "#2ed573"], // Blue to Green
//       ["#3742fa", "#ffa502"], // Blue to Orange
//       ["#2f3542", "#57606f"], // Dark Blue to Gray-Blue
//       ["#70a1ff", "#5352ed"], // Light Blue variations

//       // Green spectrum
//       ["#43e97b", "#38f9d7"], // Green to Mint
//       ["#2ed573", "#ffa502"], // Green to Orange
//       ["#00b894", "#fdcb6e"], // Teal to Yellow
//       ["#6c5ce7", "#00cec9"], // Purple to Cyan
//       ["#55efc4", "#fd79a8"], // Mint to Pink

//       // Yellow/Orange spectrum
//       ["#ffd93d", "#6bcf7f"], // Yellow to Green
//       ["#ffecd2", "#fcb69f"], // Peach gradient
//       ["#fdcb6e", "#e17055"], // Yellow to Orange-Red
//       ["#f39c12", "#8e44ad"], // Orange to Purple
//       ["#ffa726", "#42a5f5"], // Orange to Blue

//       // Teal/Cyan spectrum
//       ["#17a2b8", "#fd7e14"], // Teal to Orange
//       ["#20bf6b", "#fa8231"], // Teal to Orange
//       ["#0abde3", "#ee5a52"], // Cyan to Red
//       ["#00cec9", "#6c5ce7"], // Teal to Purple
//       ["#1dd1a1", "#feca57"], // Green-Teal to Yellow

//       // Multi-color combinations
//       ["#ff7675", "#74b9ff"], // Coral to Sky Blue
//       ["#fd79a8", "#fdcb6e"], // Pink to Yellow
//       ["#e84393", "#00b894"], // Magenta to Teal
//       ["#00cec9", "#ff7675"], // Teal to Coral
//       ["#a29bfe", "#fd79a8"], // Lavender to Pink

//       // Vibrant combinations
//       ["#ff6b35", "#f7931e"], // Orange spectrum
//       ["#c44569", "#f8b500"], // Burgundy to Gold
//       ["#3c6382", "#40739e"], // Steel Blue variations
//       ["#e55039", "#fa983a"], // Red-Orange spectrum
//       ["#b71540", "#0c2461"], // Deep Red to Navy

//       // Tropical combinations
//       ["#ff9a9e", "#fecfef"], // Pink gradient
//       ["#a8edea", "#fed6e3"], // Mint to Pink
//       ["#ffecd2", "#fcb69f"], // Cream to Peach
//       ["#ff9a8b", "#a8e6cf"], // Coral to Mint
//       ["#fad0c4", "#ffd1ff"], // Peach to Lavender

//       // Sunset combinations
//       ["#ff8a80", "#ff80ab"], // Coral to Pink
//       ["#ffab91", "#ffcc02"], // Peach to Gold
//       ["#ff8a65", "#ffb74d"], // Orange spectrum
//       ["#f48fb1", "#ce93d8"], // Pink to Lavender
//       ["#ffcc02", "#ff6f00"], // Gold to Deep Orange

//       // Ocean combinations
//       ["#4fc3f7", "#29b6f6"], // Light Blue spectrum
//       ["#26c6da", "#00acc1"], // Cyan spectrum
//       ["#42a5f5", "#1e88e5"], // Blue spectrum
//       ["#66bb6a", "#26a69a"], // Green to Teal
//       ["#5c6bc0", "#3f51b5"], // Indigo spectrum

//       // Forest combinations
//       ["#81c784", "#66bb6a"], // Green spectrum
//       ["#aed581", "#9ccc65"], // Light Green spectrum
//       ["#4caf50", "#388e3c"], // Green variations
//       ["#8bc34a", "#689f38"], // Lime Green spectrum
//       ["#cddc39", "#afb42b"], // Yellow-Green spectrum
//    ];

//    // Colorful smoke colors (avoiding black/white)
//    const smokeColorSets = [
//       ["#2d3748", "#4a5568", "#718096", "#a0aec0"], // Blue-gray
//       ["#744210", "#975a16", "#ca8a04", "#eab308"], // Golden-brown
//       ["#7c2d12", "#dc2626", "#f87171", "#fca5a5"], // Red-brown
//       ["#581c87", "#7c3aed", "#a78bfa", "#c4b5fd"], // Purple
//       ["#14532d", "#16a34a", "#4ade80", "#86efac"], // Green
//       ["#0c4a6e", "#0284c7", "#38bdf8", "#7dd3fc"], // Blue
//       ["#9a3412", "#ea580c", "#fb923c", "#fdba74"], // Orange
//       ["#86198f", "#c026d3", "#e879f9", "#f0abfc"], // Magenta
//       ["#365314", "#65a30d", "#a3e635", "#d9f99d"], // Lime
//       ["#0f766e", "#0d9488", "#2dd4bf", "#7dd3fc"], // Teal
//    ];

//    // Change random colors every 3 seconds
//    useEffect(() => {
//       const interval = setInterval(() => {
//          const randomColorIndex = Math.floor(Math.random() * colorSets.length);
//          const randomSmokeIndex = Math.floor(
//             Math.random() * smokeColorSets.length
//          );
//          setRandomColors(colorSets[randomColorIndex]);
//          setSmokeColors(smokeColorSets[randomSmokeIndex]);
//       }, 3000);

//       return () => clearInterval(interval);
//    }, []);

//    return (
//       <div
//          className="relative w-full  overflow-hidden"
//          style={{ background: "linear-gradient(135deg, #1a1a2e, #16213e)" }}
//       >
//          {/* Smoky Background Layer */}
//          <div className="absolute inset-0">
//             {/* Large flowing smoke clouds */}
//             <motion.div
//                className="absolute w-96 h-96 rounded-full opacity-30 blur-3xl"
//                style={{
//                   background: `radial-gradient(circle, ${smokeColors[0]}, ${smokeColors[1]}, transparent)`,
//                }}
//                animate={{
//                   x: [-100, 100, -50, 150, -100],
//                   y: [-50, 100, 50, -100, -50],
//                   scale: [1, 1.2, 0.8, 1.1, 1],
//                }}
//                transition={{
//                   duration: 20,
//                   repeat: Infinity,
//                   ease: "easeInOut",
//                }}
//                initial={{ x: -25, y: -10 }}
//             />

//             <motion.div
//                className="absolute w-80 h-80 rounded-full opacity-25 blur-2xl"
//                style={{
//                   background: `radial-gradient(circle, ${smokeColors[1]}, ${smokeColors[2]}, transparent)`,
//                }}
//                animate={{
//                   x: [300, 100, 400, 50, 300],
//                   y: [200, 50, 300, 150, 200],
//                   scale: [0.8, 1.3, 1, 0.9, 0.8],
//                }}
//                transition={{
//                   duration: 25,
//                   repeat: Infinity,
//                   ease: "easeInOut",
//                }}
//                initial={{ x: 300, y: 200 }}
//             />

//             <motion.div
//                className="absolute w-72 h-72 rounded-full opacity-20 blur-xl"
//                style={{
//                   background: `radial-gradient(circle, ${smokeColors[2]}, ${smokeColors[3]}, transparent)`,
//                }}
//                animate={{
//                   x: [500, 200, 600, 300, 500],
//                   y: [100, 300, 50, 250, 100],
//                   scale: [1.1, 0.7, 1.4, 1, 1.1],
//                }}
//                transition={{
//                   duration: 18,
//                   repeat: Infinity,
//                   ease: "easeInOut",
//                }}
//                initial={{ x: 500, y: 100 }}
//             />

//             {/* Additional smaller smoke particles */}
//             {[...Array(8)].map((_, i) => (
//                <motion.div
//                   key={i}
//                   className="absolute w-32 h-32 rounded-full opacity-15 blur-lg"
//                   style={{
//                      background: `radial-gradient(circle, ${
//                         smokeColors[i % smokeColors.length]
//                      }, transparent)`,
//                      left: `${Math.random() * 100}%`,
//                      top: `${Math.random() * 100}%`,
//                   }}
//                   animate={{
//                      x: [
//                         0,
//                         Math.random() * 200 - 100,
//                         Math.random() * 100 - 50,
//                         0,
//                      ],
//                      y: [
//                         0,
//                         Math.random() * 200 - 100,
//                         Math.random() * 100 - 50,
//                         0,
//                      ],
//                      scale: [0.5, 1, 0.7, 0.5],
//                      opacity: [0.1, 0.3, 0.15, 0.1],
//                   }}
//                   transition={{
//                      duration: 15 + Math.random() * 10,
//                      repeat: Infinity,
//                      ease: "easeInOut",
//                      delay: i * 0.5,
//                   }}
//                />
//             ))}
//          </div>

//          {/* Dynamic Color Layer */}
//          <div className="absolute inset-0">
//             {/* Main color orbs */}
//             <motion.div
//                className="absolute w-96 h-96 rounded-full opacity-40 blur-3xl"
//                style={{
//                   background: `radial-gradient(circle, ${randomColors[0]}, transparent)`,
//                }}
//                animate={{
//                   x: [200, 600, 100, 500, 200],
//                   y: [300, 100, 400, 200, 300],
//                   scale: [1, 1.5, 0.8, 1.2, 1],
//                }}
//                transition={{
//                   duration: 22,
//                   repeat: Infinity,
//                   ease: "easeInOut",
//                }}
//                initial={{ x: 200, y: 300 }}
//             />

//             <motion.div
//                className="absolute w-80 h-80 rounded-full opacity-35 blur-2xl"
//                style={{
//                   background: `radial-gradient(circle, ${randomColors[1]}, transparent)`,
//                }}
//                animate={{
//                   x: [400, 50, 450, 150, 400],
//                   y: [150, 350, 80, 280, 150],
//                   scale: [0.9, 1.3, 1.1, 0.7, 0.9],
//                }}
//                transition={{
//                   duration: 20,
//                   repeat: Infinity,
//                   ease: "easeInOut",
//                }}
//                initial={{ x: 400, y: 150 }}
//             />

//             {/* Medium color orbs */}
//             <motion.div
//                className="absolute w-64 h-64 rounded-full opacity-30 blur-2xl"
//                style={{
//                   background: `radial-gradient(circle, ${randomColors[0]}, ${randomColors[1]}, transparent)`,
//                }}
//                animate={{
//                   x: [100, 300, 50, 250, 100],
//                   y: [400, 200, 350, 100, 400],
//                   scale: [0.8, 1.2, 1, 0.9, 0.8],
//                }}
//                transition={{
//                   duration: 18,
//                   repeat: Infinity,
//                   ease: "easeInOut",
//                }}
//                initial={{ x: 100, y: 400 }}
//             />

//             {/* Smaller dynamic color particles */}
//             {[...Array(12)].map((_, i) => (
//                <motion.div
//                   key={`color-${i}`}
//                   className="absolute w-40 h-40 rounded-full opacity-25 blur-xl"
//                   style={{
//                      background: `radial-gradient(circle, ${
//                         randomColors[i % 2]
//                      }, transparent)`,
//                      left: `${(i * 12) % 90}%`,
//                      top: `${(i * 15) % 80}%`,
//                   }}
//                   animate={{
//                      x: [
//                         0,
//                         Math.random() * 150 - 75,
//                         Math.random() * 100 - 50,
//                         0,
//                      ],
//                      y: [
//                         0,
//                         Math.random() * 150 - 75,
//                         Math.random() * 100 - 50,
//                         0,
//                      ],
//                      scale: [0.6, 1.2, 0.8, 0.6],
//                      opacity: [0.2, 0.4, 0.25, 0.2],
//                   }}
//                   transition={{
//                      duration: 12 + Math.random() * 8,
//                      repeat: Infinity,
//                      ease: "easeInOut",
//                      delay: i * 0.3,
//                   }}
//                />
//             ))}
//          </div>

//          {/* Overlay gradient for depth */}
//          <div className="absolute inset-0 bg-gradient-to-br from-transparent via-purple-900/10 to-blue-900/20" />

//          {/* Content overlay */}
//          <div className="relative z-10 flex items-center justify-center h-full">
//             <motion.div
//                className="text-center text-slate-100"
//                initial={{ opacity: 0, y: 20 }}
//                animate={{ opacity: 1, y: 0 }}
//                transition={{ duration: 1, delay: 0.5 }}
//             >
//                {children}
//             </motion.div>
//          </div>
//       </div>
//    );
// };

// export default BackgroundGradient;

"use client";
import { motion } from "framer-motion";
import { cn } from "@/libs/cn";

const gradientOptions = [
   [
      "radial-gradient(circle_farthest-side_at_0_100%,#E13930,transparent)",
      "radial-gradient(circle_farthest-side_at_100%_0,#7c55f4,transparent)",
      "radial-gradient(circle_farthest-side_at_100%_100%,#e9b784,transparent)",
      "radial-gradient(circle_farthest-side_at_0_0,#1ca0fb,#141316)",
   ],
   [
      "radial-gradient(circle_farthest-side_at_0_100%,#00ccb1,transparent)",
      "radial-gradient(circle_farthest-side_at_100%_0,#7b61ff,transparent)",
      "radial-gradient(circle_farthest-side_at_100%_100%,#ffc414,transparent)",
      "radial-gradient(circle_farthest-side_at_0_0,#1ca0fb,#141316)",
   ],
   [
      "radial-gradient(circle_farthest-side_at_0_100%,#f43f5e,transparent)",
      "radial-gradient(circle_farthest-side_at_100%_0,#3b82f6,transparent)",
      "radial-gradient(circle_farthest-side_at_100%_100%,#f59e0b,transparent)",
      "radial-gradient(circle_farthest-side_at_0_0,#10b981,#a855f7)",
   ],
   [
      "radial-gradient(circle_farthest-side_at_0_100%,#ef4444,transparent)",
      "radial-gradient(circle_farthest-side_at_100%_0,#8b5cf6,transparent)",
      "radial-gradient(circle_farthest-side_at_100%_100%,#f97316,transparent)",
      "radial-gradient(circle_farthest-side_at_0_0,#06b6d4,#22c55e)",
   ],
   [
      "radial-gradient(circle_farthest-side_at_0_100%,#fb923c,transparent)",
      "radial-gradient(circle_farthest-side_at_100%_0,#a78bfa,transparent)",
      "radial-gradient(circle_farthest-side_at_100%_100%,#34d399,transparent)",
      "radial-gradient(circle_farthest-side_at_0_0,#60a5fa,#f43f5e)",
   ],
];

export const BackgroundGradient = ({
   children,
   className,
   containerClassName,
   animate = true,
   index,
}: {
   children?: React.ReactNode;
   className?: string;
   containerClassName?: string;
   animate?: boolean;
   index: number;
}) => {
   const variants = {
      initial: {
         backgroundPosition: "0 50%",
      },
      animate: {
         backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
      },
   };

   // Randomize gradients once per render

   const random = () =>
      gradientOptions[Math.floor(Math.random() * gradientOptions.length)];

   return (
      <div className={cn("relative p-[4px] group", containerClassName)}>
         <motion.div
            variants={animate ? variants : undefined}
            initial={animate ? "initial" : undefined}
            animate={animate ? "animate" : undefined}
            transition={
               animate
                  ? {
                       duration: 5,
                       repeat: Infinity,
                       repeatType: "reverse",
                    }
                  : undefined
            }
            style={{
               backgroundSize: animate ? "400% 400%" : undefined,
            }}
            className={cn(
               "absolute inset-0 rounded-3xl z-[1] opacity-60 group-hover:opacity-100 blur-xl transition duration-500 will-change-transform",
               `bg-[${gradientOptions[index]}]`
            )}
         />
         <motion.div
            variants={animate ? variants : undefined}
            initial={animate ? "initial" : undefined}
            animate={animate ? "animate" : undefined}
            transition={
               animate
                  ? {
                       duration: 5,
                       repeat: Infinity,
                       repeatType: "reverse",
                    }
                  : undefined
            }
            style={{
               backgroundSize: animate ? "400% 400%" : undefined,
            }}
            className={cn(
               "absolute inset-0 rounded-3xl z-[1] will-change-transform",
               `bg-[${gradientOptions[index]}]`
            )}
         />
         <div className={cn("relative z-10", className)}>{children}</div>
      </div>
   );
};
