import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardHeader } from "@nextui-org/react";
import SectionSubtitle from "../SectionSubtitle";
import { Icon } from "@iconify/react/dist/iconify.js";
import { DjangoBackground } from "./CardBackground/DjangoBackground";
import { CardBackground } from "./CardBackground";
type Props = {
   title: string;
   description: string;
   icon?: string;
};

const PerspectiveCard = ({ title, description, icon }: Props) => {
   const [rotateX, setRotateX] = useState(0);
   const [rotateY, setRotateY] = useState(0);

   const handleMouseMove = (e: any) => {
      const card = e.currentTarget;
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 5;
      const centerY = rect.height / 5;

      const rotateXValue = (y - centerY) / 8;
      const rotateYValue = (centerX - x) / 8;

      setRotateX(rotateXValue);
      setRotateY(rotateYValue);
   };

   const handleMouseLeave = () => {
      setRotateX(0);
      setRotateY(0);
   };

   return (
      <motion.div
         className="perspective-card"
         onMouseMove={handleMouseMove}
         onMouseLeave={handleMouseLeave}
         style={{
            perspective: "1000px",
            transformStyle: "preserve-3d",
         }}
      >
         <motion.div
            animate={{
               rotateX: rotateX,
               rotateY: rotateY,
            }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
            style={{
               transformStyle: "preserve-3d",
            }}
         >
            {/* <Card className="h-[160px] bg-gradient-to-br from-[#0f0f0f] to-[#303030] p-6 rounded-lg border border-[#2F2F2F] shadow-xl "> */}
            <Card className="h-[160px] bg-transparent relative p-6 rounded-lg border border-[#2F2F2F] shadow-xl ">
               <CardBackground title={title} />
               <CardHeader>
                  {icon && (
                     <motion.div
                        className=" hidden items-center justify-center w-16 h-16 rounded-full bg-orange-100 dark:bg-orange-900 mb-4"
                        style={{
                           transform: "translateZ(20px)",
                        }}
                     >
                        <Icon icon={icon} width="24" height="24" />
                     </motion.div>
                  )}
                  <SectionSubtitle
                     className="text-lg font-semibold mb-2 text-center m-auto text-[#1463fd]"
                     transform="translateZ(10px)"
                  >
                     {title}
                  </SectionSubtitle>
               </CardHeader>
               <div>
                  <p
                     className="text-[#fafafa] text-center text-sm"
                     style={{ transform: "translateZ(5px)" }}
                  >
                     {description}
                  </p>
               </div>
            </Card>
         </motion.div>
      </motion.div>
   );
};

export default PerspectiveCard;
