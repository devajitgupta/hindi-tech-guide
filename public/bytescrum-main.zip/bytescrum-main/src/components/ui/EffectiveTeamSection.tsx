import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";

type Props = {
   className?: string;
   langText: any
   data: any;
};

const EffectiveTeamSection = ({ className, langText, data }: Props) => {
   return (
      <div className={twMerge(clsx(className))}>
         {" "}
         <div className="space-y-[60px] lg:px-[40px]">
            <div className="space-y-[20px]">
               <SectionTitle className="m-auto max-w-2xl">{langText.title}</SectionTitle>
               <Text
                  className="max-w-[491px] lg:max-w-3xl m-auto"
                  variant="primary"
               >
                  {langText.subtitle}
               </Text>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5 ">
               {data.map((item: any, index: number) => (
                  <div
                     key={index}
                     className="space-y-[5px] bg-[#1a1a1a] px-[48px] py-[42px] rounded-[16px] relative"
                  >
                     <span className="block bg-[#1463FD] w-1 h-[60%] absolute top-1/2 left-[-1.5px] rounded-full transform -translate-y-1/2"></span>
                     <h3 className="poppins text-[20px] text-[#fff] font-bold">
                        {item.title}
                     </h3>
                     <Text className="text-start" variant="primary">
                        {item.description}
                     </Text>
                  </div>
               ))}
            </div>
         </div>
      </div>
   );
};

export default EffectiveTeamSection;
