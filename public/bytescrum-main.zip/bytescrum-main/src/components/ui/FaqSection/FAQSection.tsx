"use client";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import { Accordion, AccordionItem } from "@nextui-org/react";
import "./faqStyle.css";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";

interface IProps {
   header?: any;
   className?: string;
   data: any;
   showTitle?: boolean;
}

const FAQSection = ({ className, data, header, showTitle = true }: IProps) => {
   return (
      <div className={twMerge(clsx(className))}>
         <div className="space-y-[40px]">
            {showTitle && (
               <div className="space-y-[10px]">
                  <SectionTitle className="max-w-3xl m-auto">
                     {header.title}
                  </SectionTitle>
                  <SectionSubtitle className="m-auto">
                     {header.subtitle}
                  </SectionSubtitle>
               </div>
            )}

            <div className="m-auto w-11/12 md:w-9/12 lg:w-7/12 ">
               <Accordion
                  variant="splitted"
                  fullWidth={true}
                  defaultExpandedKeys={[0]}
                  itemClasses={{
                     base: "border border-[#262626] !bg-[#0a0a0a] px-5 rounded-lg ",
                  }}
               >
                  {data.map((accordion: any, index: number) => (
                     <AccordionItem
                        key={index}
                        aria-label={accordion.question}
                        title={accordion.question}
                        indicator={({ isOpen }) => (
                           <label className="accordionContainer group rotate-90">
                              <input
                                 type="checkbox"
                                 checked={isOpen}
                                 readOnly
                              />
                              <div className="line "></div>
                              <div className="line line-indicator"></div>
                           </label>
                        )}
                        classNames={{
                           content: " px-3  flex justify-between  ",
                           heading: " relative  flex justify-between  ",
                           title: "poppins text-[16px] md:text-[18px] font-medium md:font-semibold text-[#ffffff] pe-5  ",
                           indicator: "text-[#ffffff] absolute  right-0",
                        }}
                        data-aos="fade-up"
                        data-aos-easing="ease-out-cubic"
                        data-aos-delay={index * 50}
                        data-aos-anchor-placement="top-bottom"
                     >
                        {accordion.answer}
                     </AccordionItem>
                  ))}
               </Accordion>
            </div>
         </div>
      </div>
   );
};

export default FAQSection;
