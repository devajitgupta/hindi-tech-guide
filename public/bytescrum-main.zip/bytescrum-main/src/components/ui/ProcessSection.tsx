"use client";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import SectionTitle from "../SectionTitle";
import Text from "../Text";
import Image from "next/image";
import { Line } from "../Icons";
import { useState } from "react";
import { Icon } from "@iconify/react/dist/iconify.js";

type StepData = {
   icon: string;
   title: string;
   text: string;
   srcOne: string;
   srcTwo: string;
};

type Props = {
   className?: string;
  
   steps: StepData[];
   data:any;
};

const ProcessSection = ({
   className = "",
    steps,
   data
}: Props) => {
   const [isSelected, setIsSelected] = useState<number>(0);

   const handleSelect = (index: number) => {
      setIsSelected(index);
   };

   const selectedData = steps[isSelected];

   return (
      <div className={twMerge(clsx(className))}>
         <div className="space-y-[60px]">
            <div className="space-y-[20px]">
               <SectionTitle className="text-start">{data.title}</SectionTitle>
               <Text className="max-w-full lg:max-w-[1170px] text-start leading-[28px]">
                  {data.description}
               </Text>
            </div>
            <div className="grid xl:grid-cols-6 gap-5 xl:gap-0">
               <div className="xl:col-span-2 md:grid items-center w-[90dvw] md:w-full overflow-auto xl:overflow-hidden">
                  <ul className="xl:ps-5 xl:space-y-[50px] flex justify-between xl:grid gap-5 list-decimal ">
                     {steps.map((item, index) => (
                        <li
                           key={index}
                           className={twMerge(
                              clsx(
                                 "list-decimal text-[20px] font-bold cursor-pointer  flex items-center w-full mb-2",
                                 {
                                    "text-[#1463FD]": isSelected === index,
                                 }
                              )
                           )}
                           onClick={() => handleSelect(index)}
                        >
                           <span className=" text-nowrap  w-fit">
                              {index + 1}. {item.title}
                           </span>
                           {isSelected === index && (
                              <span className="hidden xl:block mt-1  w-full">
                                 <Line trigger={isSelected} />
                              </span>
                           )}
                        </li>
                     ))}
                  </ul>
               </div>
               <div className="xl:col-span-4 grid xl:grid-cols-2 gap-5">
                  <div className="border border-[#262626] bg-[#090909] px-[42px] py-[38px] rounded-[16px]">
                     <div className="space-y-[20px]">
                        <Icon icon={selectedData.icon} width="50" height="50" />
                        <SectionTitle className="text-start text-[#1463FD] max-w-[200px] md:max-w-full">
                           {selectedData.title}
                        </SectionTitle>
                        <Text className="text-start max-w-full xl:max-w-[356px] leading-[28px]">
                           {selectedData.text}
                        </Text>
                     </div>
                  </div>
                  <div className="grid grid-cols-2 gap-5">
                     <Image
                        src={selectedData.srcOne}
                        width={440}
                        height={200}
                        alt="Process Step Image 1"
                        className="col-span-2 w-full h-full"
                     />
                     <Image
                        src={selectedData.srcTwo}
                        width={210}
                        height={200}
                        alt="Process Step Image 2"
                        className="w-full h-full"
                     />
                     <div className="bg-[#1463FD] rounded-[16px] grid place-items-center">
                        <div className="grid place-items-center">
                           <span className="text-[45px] text-white font-semibold poppins">
                              200+
                           </span>
                           <span>{data.successTitle}</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   );
};

export default ProcessSection;
