export { default as PortfolioBackgroundAnimation } from "./PortfolioBackgroundAnimation";
export { default as ImplementationStep } from "./implementationStep";
export { default as DevExpertiseSection } from "./DevExpertiseSection";
export { default as EffectiveTeamSection } from "./EffectiveTeamSection";
export { default as OverviewSection } from "./OverviewSection";
export { default as ProcessSection } from "./ProcessSection";
export { default as ServiceSection } from "./ServiceSection";
