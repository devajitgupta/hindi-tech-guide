"use client";

import { motion } from "framer-motion";
import SectionTitle from "../SectionTitle";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import SectionSubtitle from "../SectionSubtitle";
import Text from "../Text";
import ProgressBar from "../ProgressBar";

interface IProps {
   className?: string;

   skills: any;
}

const DevExpertiseSection = ({
   className,
   skills,

}: IProps) => {
   const langText= skills.skills
   return (
      <div className={twMerge(clsx(className))}>
         <div className="space-y-[30px] md:space-y-[60px]  xl:px-[153px]">
            <div className="space-y-[20px] overflow-hidden ">
               <SectionTitle
                  animationVariant="fadeUp"
                  className="max-w-3xl m-auto"
               >
                  {skills.DevExpertSec.title}
               </SectionTitle>
            </div>

            <div>
               <div className="grid  md:grid-cols-2 items-center gap-y-10 gap-x-[30px] lg:gap-x-[60px]">
                  <motion.div
                     className="space-y-5 lg:max-w-[554px]"
                     initial={{ opacity: 0, x: -30 }}
                     animate={{ opacity: 1, x: 0 }}
                     transition={{ duration: 0.8 }}
                  >
                     <SectionSubtitle
                        animationVariant="fadeUp"
                        textSize="lg"
                        className="text-start font-bold poppins w-full max-w-[350px] "
                     >
                        {skills.DevExpertSec.subTitle}
                     </SectionSubtitle>
                     <Text className="text-start">{skills.DevExpertSec.descriptionOne}</Text>
                     {skills.DevExpertSec.descriptionTwo && (
                        <Text className="text-start"> {skills.DevExpertSec.descriptionTwo}</Text>
                     )}

                     <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-all"
                     >
                        {skills.DevExpertSec.devexTitle}
                     </motion.button>
                  </motion.div>

                  {/* Right Section: Progress Bars */}
                  <motion.div
                     className="space-y-6"
                     initial={{ opacity: 0, x: 30 }}
                     animate={{ opacity: 1, x: 0 }}
                     transition={{ duration: 0.8 }}
                  >
                     {langText.map((skill: any, index: number) => (
                        <ProgressBar
                           key={index}
                           name={skill.name}
                           level={skill.level}
                        />
                     ))}
                  </motion.div>
                  {/* <motion.div
                  className="space-y-6"
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8 }}
               >
                  {skills.map((skill, index) => (
                     <div key={index}>
                        <div className="flex justify-between text-sm mb-1">
                           <span>{skill.name}</span>
                           <span>{skill.level}%</span>
                        </div>
                        <div className="w-full bg-gray-800 rounded-full h-2 relative">
                           <motion.div
                              className="absolute top-0 left-0 h-2 bg-blue-500 rounded-full"
                              style={{ width: `${skill.level}%` }}
                              initial={{ width: "0%" }}
                              animate={{ width: `${skill.level}%` }}
                              transition={{ duration: 1.2, ease: "easeInOut" }}
                           />
                        </div>
                     </div>
                  ))}
               </motion.div> */}
               </div>
            </div>
         </div>
      </div>
   );
};

export default DevExpertiseSection;
