"use client";
import { Icon } from "@iconify/react/dist/iconify.js";
import { motion, useScroll, useTransform, useInView } from "framer-motion";
import { useRef, useState } from "react";

interface IProps {
   data: any;
}

const PortfolioBackgroundAnimation = ({ data }: IProps) => {
   const [activeTab, setActiveTab] = useState("overview");

   const colorScheme =
      data.id === "/cmd-forward"
         ? {
              primary: "from-blue-500 to-cyan-400",
              secondary: "blue",
              accent: "cyan",
           }
         : data.id === "ecommerce-platform"
         ? {
              primary: "from-pink-500 to-purple-600",
              secondary: "pink",
              accent: "purple",
           }
         : data.id === "healthcare-platform"
         ? {
              primary: "from-green-500 to-emerald-400",
              secondary: "green",
              accent: "emerald",
           }
         : {
              primary: "from-orange-500 to-red-500",
              secondary: "orange",
              accent: "red",
           };

   const containerRef = useRef(null);

   const { scrollYProgress } = useScroll({
      target: containerRef,
      offset: ["start start", "end end"],
   });

   const backgroundY = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
   const opacity = useTransform(
      scrollYProgress,
      [0, 0.2, 0.3, 1],
      [1, 0.8, 0.6, 0]
   );

   return (
      <div className=" absolute  inset-0 z-0 overflow-hidden bg-black">
         <motion.div
            className=" absolute  inset-0 z-0 overflow-hidden bg-black"
            style={{ y: backgroundY, opacity }}
         >
            <div className="absolute inset-0 overflow-hidden">
               <div
                  className={`absolute inset-0 bg-gradient-to-b from-${colorScheme.secondary}-900/20 to-${colorScheme.accent}-900/10`}
               ></div>

               {/* Floating elements */}
               {Array.from({ length: 15 }).map((_, i) => (
                  <motion.div
                     key={`block-${i}`}
                     className="absolute rounded-md border border-blue-500/50 bg-blue-500/10 backdrop-blur-xl"
                     style={{
                        width: Math.random() * 60 + 40,
                        height: Math.random() * 60 + 40,
                        left: `${Math.random() * 100}%`,
                        top: `${Math.random() * 100}%`,
                        // borderRadius: `${Math.random() * 100}%`,
                        // borderTopLeftRadius: `${Math.random() * 100}%`,
                        // borderTopRightRadius: `${Math.random() * 100}%`,
                        // borderBottomLeftRadius: `${Math.random() * 100}%`,
                        // borderBottomRightRadius: `${Math.random() * 100}%`,
                     }}
                     initial={{ opacity: 0 }}
                     animate={{
                        opacity: [0, 0.3, 0],
                        x: [0, Math.random() * 100 - 50],
                        y: [0, Math.random() * 100 - 50],
                        scale: [0, 2, 0],
                        rotate: [0, Math.random() * 360],
                     }}
                     transition={{
                        duration: Math.random() * 20 + 10,
                        delay: i * 0.5,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "loop",
                     }}
                  />
               ))}
            </div>
         </motion.div>
      </div>
   );
};

export default PortfolioBackgroundAnimation;
