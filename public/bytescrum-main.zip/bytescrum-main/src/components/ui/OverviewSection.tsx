"use client";
import SectionTitle from "@/components/SectionTitle";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import Text from "@/components/Text";
import { StatsCountUp } from "@/components/home";
import Image from "next/image";
import { Button } from "@nextui-org/react";
import Link from "next/link";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import OverViewBanner from "@/components/ui/OverViewBanner";
import { usePathname } from "next/navigation";

interface IProps {
  data:any;
  className?: string;
  countUpData: any;
}

const OverviewSection = ({ className, countUpData, data }: IProps) => {
  const pathName = usePathname();

  return (
    <div
      className={twMerge(clsx("relative h-full  w-full z-20  mt-2", className))}
    >
      <div
        className={twMerge(
          clsx("grid lg:grid-cols-2", {
            "pb-10": pathName !== "/recover-hacked-website",
          })
        )}
      >
        <div className="order-2 lg:order-1 ">
          <div className="space-y-[20px]  pt-[60px]  mt-8 lg:mt-0 ">
            <SectionTitle className="text-start"> {data.title}</SectionTitle>
            <div className="space-y-[10px]">
              <Text className="text-start  max-w-full md:max-w-[622px] lg:max-w-full ">
                {data.descriptionOne}
              </Text>
              <Text className="text-start  max-w-full md:max-w-[622px] lg:max-w-full hidden xl:block">
                {data.descriptionTwo}
              </Text>
            </div>
          </div>
          <StatsCountUp
            langText={countUpData}
            className="lg:flex justify-between hidden  md:gap-[0px] py-0 lg:pt-[5px] gap-0 lg:max-w-[670px] overflow-hidden "
            wrapper={clsx(
              "  px-0 md:px-0 w-fit [&:nth-child(1)]:hidden  [&:nth-child(2)]:hidden [&:nth-child(2)]:border-r [&:nth-child(2)]:border-[#262626] [&:nth-child(2)]:rounded-none w-[300px]"
            )}
            countUpClass=" text-start text-[28px] md:text-[45px] px-0 md:px-0 py-0 md:py-0 "
            symbolClass="text-[20px] md:[42px]"
            textClass="font-normal text-start text-[14px]  md:text-[20px]"
          />
        </div>

        <OverViewBanner className="order-1  lg:order-2" />
      </div>
    </div>
  );
};

export default OverviewSection;
