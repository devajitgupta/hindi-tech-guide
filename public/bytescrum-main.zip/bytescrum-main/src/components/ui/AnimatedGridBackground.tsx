"use client";

import { useEffect, useState, useMemo } from "react";
import { motion } from "framer-motion";

type GridLine = {
   id: number;
   position: number;
   isHorizontal: boolean;
   thickness: number;
   opacity: number;
   delay: number;
   duration: number;
   glow: boolean;
};

export default function AnimatedGridBackground() {
   const [gridLines, setGridLines] = useState<GridLine[]>([]);
   const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

   // Memoize colors based on theme
   const primaryColor = "#656565";
   //  "rgba(165, 180, 252, 0.3)

   const glowColor = "rgba(99, 102, 241, 0.8)";
   // "rgba(165, 180, 252, 0.8)",

   // Handle window resize and initial dimensions
   useEffect(() => {
      const updateDimensions = () => {
         setDimensions({
            width: window.innerWidth,
            height: window.innerHeight,
         });
      };

      // Set initial dimensions
      updateDimensions();

      window.addEventListener("resize", updateDimensions);
      return () => window.removeEventListener("resize", updateDimensions);
   }, []);

   // Generate grid lines when dimensions change
   useEffect(() => {
      if (dimensions.width === 0 || dimensions.height === 0) return;

      const lines: GridLine[] = [];
      const baseSpacing = dimensions.width < 768 ? 10 : 40;

      // Create horizontal lines
      const horizontalCount = Math.ceil(dimensions.height / baseSpacing) + 1;
      for (let i = 0; i < horizontalCount; i++) {
         const isSpecial = i % 2 === 0; // Every 4th line is special (glowing)
         lines.push({
            id: i,
            position: i * baseSpacing,
            isHorizontal: true,
            thickness: isSpecial ? 2 : 2,
            opacity: isSpecial ? 0.6 : 0.6,
            delay: i * 0.1,
            duration: Math.random() * 3 + 4, // 4-7 seconds
            glow: isSpecial,
         });
      }

      // Create vertical lines
      const verticalCount = Math.ceil(dimensions.width / baseSpacing) + 1;
      for (let i = 0; i < verticalCount; i++) {
         const isSpecial = i % 2 === 0; // Every 4th line is special (glowing)
         lines.push({
            id: horizontalCount + i,
            position: i * baseSpacing,
            isHorizontal: false,
            thickness: isSpecial ? 2 : 2,
            opacity: isSpecial ? 0.6 : 0.6,
            delay: i * 0.1,
            duration: Math.random() * 3 + 4, // 4-7 seconds
            glow: isSpecial,
         });
      }

      setGridLines(lines);
   }, [dimensions.width, dimensions.height]);

   return (
      <div className="ansolute inset-0 -z-10 overflow-hidden opacity-30">
         {gridLines.map((line) => (
            <motion.div
               key={line.id}
               className="absolute"
               style={{
                  left: line.isHorizontal ? 0 : line.position,
                  top: line.isHorizontal ? line.position : 0,
                  width: line.isHorizontal ? "100%" : `${line.thickness}px`,
                  height: line.isHorizontal ? `${line.thickness}px` : "100%",
                  backgroundColor: line.glow ? glowColor : primaryColor,
                  boxShadow: line.glow ? `0 0 8px ${glowColor}` : "none",
               }}
               initial={{
                  opacity: 0,
                  scale: line.isHorizontal ? 1 : 0.8,
               }}
               animate={{
                  opacity: [0, line.opacity, line.opacity * 0.7, line.opacity],
                  scale: line.isHorizontal ? [1, 1] : [0.95, 1, 0.98, 1],
               }}
               transition={{
                  duration: line.duration,
                  delay: line.delay,
                  repeat: Number.POSITIVE_INFINITY,
                  repeatType: "reverse",
               }}
            />
         ))}

         {/* Animated intersections for added visual interest */}
         {gridLines
            .filter((line) => line.glow && !line.isHorizontal)
            .map((vLine) =>
               gridLines
                  .filter((line) => line.glow && line.isHorizontal)
                  .map((hLine) => (
                     <motion.div
                        key={`intersection-${vLine.id}-${hLine.id}`}
                        className="absolute rounded-full bg-purple-500"
                        style={{
                           left: vLine.position - 2,
                           top: hLine.position - 2.5,
                           width: "6px",
                           height: "6px",
                           //    backgroundColor: glowColor,
                           boxShadow: `0 0 10px #a855f7, 0 0 20px #a855f7`,
                        }}
                        animate={{
                           opacity: [0.2, 0.8, 0.2],
                           scale: [0.8, 1.2, 0.8],
                        }}
                        transition={{
                           duration: 4,
                           delay: (vLine.delay + hLine.delay) / 2,
                           repeat: Number.POSITIVE_INFINITY,
                        }}
                     />
                  ))
            )}
      </div>
   );
}
