import { motion, useInView } from "framer-motion";
import SectionTitle from "../SectionTitle";
import Text from "../Text";
import { cn } from "@nextui-org/react";

const ImplementationStep = ({
   number,
   title,
   description,
   index,
   className,
}: {
   number: number;
   title: string;
   description: string;
   index: number;
   className?: string;
}) => {
   const variants = {
      hidden: {
         opacity: 0,
         y: 50,
         rotateY: 30,
      },
      visible: {
         opacity: 1,
         y: 0,
         rotateY: 0,
         transition: {
            type: "spring",
            stiffness: 100,
            damping: 15,
            delay: index * 0.1,
         },
      },
   };

   return (
      <motion.div
         className={cn(
            "bg-gradient-to-tl from-[#0a0a0a] to-[#626262]/20 backdrop-blur-lg rounded-xl p-4 md:p-6 border border-white/20  group",
            className
         )}
         variants={variants}
         whileHover={{
            scale: 1.05,
            boxShadow: "0 10px 30px rgba(0, 0, 0, 0.2)",
            backgroundColor: "rgba(255, 255, 255, 0.15)",
         }}
         transition={{ type: "keyframes", duration: 0.3 }}
      >
         <div className="flex items-center gap-3">
            <motion.div
               className="min-w-9 h-9 md:min-w-12 md:h-12 rounded-full border primaryBorder bg-gradient-radial from-[#000] via-[#000] to-[#676767] flex items-center justify-center md:text-lg font-bold   group-hover:rotate-[360deg] duration-3000 transition-all ease-in-out"
               whileHover={{
                  backgroundColor: "#676767",
                  transition: { duration: 0.5 },
               }}
            >
               {number}
            </motion.div>
            <SectionTitle
               useAs="h3"
               className="inter !text-xl md:!text-2xl text-start"
            >
               {title}
            </SectionTitle>
         </div>
         <Text className="text-start mt-3 lg:max-w-full ">{description}</Text>
      </motion.div>
   );
};

export default ImplementationStep;
