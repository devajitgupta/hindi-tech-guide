import Link from "next/link";
import React from "react";
import SectionTitle from "../SectionTitle";
import Text from "../Text";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";

type Props = {
   data: { title: string; subtitle: string; descriptions?: [] }[];
   className: string;
};

const PoliciesAndConditions = ({ data, className }: Props) => {
   return (
      <div className={twMerge(clsx(className))}>
         {/* Privacy Policy Content */}

         <div className="container mx-auto px-4 md:px-6">
            <div className=" mx-auto w-sm p-6 md:p-8 space-y-8">
               {data.map((item, index) => (
                  <div key={index}>
                     <SectionTitle className="!text-2xl font-semibold text-start  mb-1">
                        {item.title}
                     </SectionTitle>
                     <Text className=" mb-3 lg:max-w-full w-full text-start">
                        {item.subtitle}
                     </Text>
                  </div>
               ))}
            </div>
         </div>
      </div>
   );
};

export default PoliciesAndConditions;
