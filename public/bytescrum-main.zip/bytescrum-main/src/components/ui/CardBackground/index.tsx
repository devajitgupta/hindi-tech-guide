"use client";

import { DjangoBackground } from "./DjangoBackground";
import { FlaskBackground } from "./FlaskBackground";
import { TensorFlowBackground } from "./TensorFlowBackground";
import { PyTorchBackground } from "./PyTorchBackground";
import { NumPyBackground } from "./NumPyBackground";
import { ScikitLearnBackground } from "./ScikitLearnBackground";
import { FastAPIBackground } from "./FastAPIBackground";
import { PandasBackground } from "./PandasBackground";
type Props = {
   title: string;
};

export function CardBackground({ title }: Props) {
   switch (title) {
      case "Django":
         return <DjangoBackground />;
      case "Flask":
         return <FlaskBackground />;
      case "TensorFlow":
         return <TensorFlowBackground />;
      case "PyTorch":
         return <PyTorchBackground />;
      case "NumPy":
         return <NumPyBackground />;
      case "Scikit-learn":
         return <ScikitLearnBackground />;
      case "FastAPI":
         return <FastAPIBackground />;
      case "Pandas":
         return <PandasBackground />;
   }
}
