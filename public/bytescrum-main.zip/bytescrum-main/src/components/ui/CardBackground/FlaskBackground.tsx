"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";

type Bubble = {
   x: number;
   y: number;
   radius: number;
   speed: number;
   opacity: number;
};

export function FlaskBackground() {
   const canvasRef = useRef<HTMLCanvasElement>(null);

   useEffect(() => {
      if (!canvasRef.current) return;

      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      // Set canvas dimensions
      const handleResize = () => {
         canvas.width = window.innerWidth;
         canvas.height = window.innerHeight;
      };

      handleResize();
      window.addEventListener("resize", handleResize);

      // Create bubbles
      const bubbles: Bubble[] = [];
      const bubbleCount = 50;

      for (let i = 0; i < bubbleCount; i++) {
         bubbles.push({
            x: Math.random() * canvas.width,
            y: canvas.height + Math.random() * 100,
            radius: Math.random() * 20 + 5,
            speed: Math.random() * 1 + 0.5,
            opacity: Math.random() * 0.5 + 0.1,
         });
      }

      // Draw flask shape
      const drawFlask = () => {
         const flaskWidth = canvas.width * 0.3;
         const flaskHeight = canvas.height * 0.6;
         const neckWidth = flaskWidth * 0.3;
         const neckHeight = flaskHeight * 0.4;

         const centerX = canvas.width / 2;
         const bottomY = canvas.height * 0.8;

         ctx.strokeStyle = "rgba(255, 255, 255, 0.1)";
         ctx.lineWidth = 2;
         ctx.beginPath();

         // Flask neck
         ctx.moveTo(centerX - neckWidth / 2, bottomY - flaskHeight);
         ctx.lineTo(
            centerX - neckWidth / 2,
            bottomY - flaskHeight + neckHeight
         );

         // Flask left side
         ctx.lineTo(
            centerX - flaskWidth / 2,
            bottomY - flaskHeight + neckHeight
         );
         ctx.lineTo(centerX - flaskWidth / 2, bottomY);

         // Flask bottom
         ctx.lineTo(centerX + flaskWidth / 2, bottomY);

         // Flask right side
         ctx.lineTo(
            centerX + flaskWidth / 2,
            bottomY - flaskHeight + neckHeight
         );

         // Flask neck right side
         ctx.lineTo(
            centerX + neckWidth / 2,
            bottomY - flaskHeight + neckHeight
         );
         ctx.lineTo(centerX + neckWidth / 2, bottomY - flaskHeight);

         ctx.stroke();
      };

      // Animation loop
      let animationId: number;

      const animate = () => {
         ctx.clearRect(0, 0, canvas.width, canvas.height);

         // Draw flask outline
         drawFlask();

         // Update and draw bubbles
         bubbles.forEach((bubble) => {
            bubble.y -= bubble.speed;

            // Reset bubble when it goes off screen
            if (bubble.y < -bubble.radius * 2) {
               bubble.y = canvas.height + bubble.radius;
               bubble.x = Math.random() * canvas.width;
            }

            // Draw bubble
            ctx.beginPath();
            ctx.arc(bubble.x, bubble.y, bubble.radius, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(255, 255, 255, ${bubble.opacity})`;
            ctx.fill();
         });

         animationId = requestAnimationFrame(animate);
      };

      animate();

      return () => {
         window.removeEventListener("resize", handleResize);
         cancelAnimationFrame(animationId);
      };
   }, []);

   return (
      <div className=" absolute inset-0 -z-30 overflow-hidden bg-[#000]">
         <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.3 }}
            transition={{ duration: 1 }}
            className="absolute inset-0"
         >
            <canvas
               ref={canvasRef}
               className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 inset-0 md:w-[800px]"
            />
         </motion.div>
      </div>
   );
}
