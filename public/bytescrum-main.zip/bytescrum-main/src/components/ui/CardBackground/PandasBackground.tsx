"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";

export function PandasBackground() {
   const canvasRef = useRef<HTMLCanvasElement>(null);

   useEffect(() => {
      if (!canvasRef.current) return;

      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      // Set canvas dimensions
      const handleResize = () => {
         canvas.width = window.innerWidth;
         canvas.height = window.innerHeight;
      };

      handleResize();
      window.addEventListener("resize", handleResize);

      // DataFrame animation
      const cellWidth = 80;
      const cellHeight = 30;
      const headerHeight = 40;

      // Create dataframe structure
      const columns = ["Date", "Open", "High", "Low", "Close", "Volume"];
      const rows = 15;

      // Generate random data
      const data: string[][] = [];

      for (let i = 0; i < rows; i++) {
         const row: string[] = [];

         // Date
         const date = new Date(2023, 0, i + 1);
         row.push(date.toLocaleDateString());

         // Price data
         const basePrice = 100 + Math.random() * 50;
         row.push(basePrice.toFixed(2));
         row.push((basePrice + Math.random() * 10).toFixed(2));
         row.push((basePrice - Math.random() * 10).toFixed(2));
         row.push((basePrice + (Math.random() - 0.5) * 15).toFixed(2));

         // Volume
         row.push(Math.floor(Math.random() * 10000).toString());

         data.push(row);
      }

      // Animation parameters
      let scrollOffset = 0;
      let targetScrollOffset = 0;
      const maxScroll =
         rows * cellHeight - (canvas.height - headerHeight - 100);

      // Highlight cells
      const highlights: { row: number; col: number; duration: number }[] = [];

      // Animation loop
      let animationId: number;
      let frame = 0;

      const animate = () => {
         ctx.clearRect(0, 0, canvas.width, canvas.height);
         frame++;

         // Smooth scrolling
         scrollOffset += (targetScrollOffset - scrollOffset) * 0.1;

         // Randomly change scroll target
         if (frame % 120 === 0) {
            targetScrollOffset = Math.random() * maxScroll;
         }

         // Randomly highlight cells
         if (Math.random() < 0.02) {
            highlights.push({
               row: Math.floor(Math.random() * rows),
               col: Math.floor(Math.random() * columns.length),
               duration: 60 + Math.floor(Math.random() * 60),
            });
         }

         // Update highlights
         for (let i = highlights.length - 1; i >= 0; i--) {
            highlights[i].duration--;
            if (highlights[i].duration <= 0) {
               highlights.splice(i, 1);
            }
         }

         // Calculate dataframe position
         const dfWidth = columns.length * cellWidth;
         const dfX = (canvas.width - dfWidth) / 2;
         const dfY = 100 - scrollOffset;

         // Draw dataframe

         // Draw header
         for (let j = 0; j < columns.length; j++) {
            const x = dfX + j * cellWidth;
            const y = dfY;

            // Header cell background
            ctx.fillStyle = "#1463fd"; // Pandas pink
            ctx.fillRect(x, y, cellWidth, headerHeight);

            // Header text
            ctx.font = "bold 12px sans-serif";
            ctx.fillStyle = "white";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.fillText(columns[j], x + cellWidth / 2, y + headerHeight / 2);
         }

         // Draw data cells
         for (let i = 0; i < rows; i++) {
            for (let j = 0; j < columns.length; j++) {
               const x = dfX + j * cellWidth;
               const y = dfY + headerHeight + i * cellHeight;

               // Skip if out of view
               if (y + cellHeight < 0 || y > canvas.height) continue;

               // Check if cell is highlighted
               const isHighlighted = highlights.some(
                  (h) => h.row === i && h.col === j
               );

               // Cell background
               if (isHighlighted) {
                  ctx.fillStyle = "rgba(231, 4, 136, 0.3)"; // Pandas pink with transparency
               } else {
                  ctx.fillStyle =
                     i % 2 === 0
                        ? "rgba(19, 6, 84, 0.7)"
                        : "rgba(19, 6, 84, 0.5)"; // Pandas dark blue
               }

               ctx.fillRect(x, y, cellWidth, cellHeight);

               // Cell border
               ctx.strokeStyle = "rgba(255, 255, 255, 0.1)";
               ctx.lineWidth = 1;
               ctx.strokeRect(x, y, cellWidth, cellHeight);

               // Cell text
               ctx.font = "11px monospace";
               ctx.fillStyle = "white";
               ctx.textAlign = "center";
               ctx.textBaseline = "middle";
               ctx.fillText(data[i][j], x + cellWidth / 2, y + cellHeight / 2);
            }
         }

         animationId = requestAnimationFrame(animate);
      };

      animate();

      return () => {
         window.removeEventListener("resize", handleResize);
         cancelAnimationFrame(animationId);
      };
   }, []);

   return (
      <div className="fixed inset-0 -z-10 overflow-hidden bg-[#000]">
         <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.3 }}
            transition={{ duration: 1 }}
            className="absolute inset-0"
         >
            <canvas
               ref={canvasRef}
               className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 inset-0 md:w-[800px]"
            />
         </motion.div>
      </div>
   );
}
