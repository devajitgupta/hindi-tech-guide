"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";

export function NumPyBackground() {
   const canvasRef = useRef<HTMLCanvasElement>(null);

   useEffect(() => {
      if (!canvasRef.current) return;

      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      // Set canvas dimensions
      const handleResize = () => {
         canvas.width = window.innerWidth;
         canvas.height = window.innerHeight;
      };

      handleResize();
      window.addEventListener("resize", handleResize);

      // Matrix animation parameters
      const cellSize = 40;
      const cols = Math.ceil(canvas.width / cellSize);
      const rows = Math.ceil(canvas.height / cellSize);

      // Create matrix cells
      const cells: { value: number; opacity: number; highlight: boolean }[][] =
         [];

      for (let i = 0; i < rows; i++) {
         cells[i] = [];
         for (let j = 0; j < cols; j++) {
            cells[i][j] = {
               value: Math.floor(Math.random() * 10),
               opacity: Math.random() * 0.5 + 0.1,
               highlight: false,
            };
         }
      }

      // Animation loop
      let animationId: number;
      let frame = 0;

      const animate = () => {
         ctx.clearRect(0, 0, canvas.width, canvas.height);
         frame++;

         // Every 30 frames, highlight a random row or column
         if (frame % 30 === 0) {
            // Reset previous highlights
            for (let i = 0; i < rows; i++) {
               for (let j = 0; j < cols; j++) {
                  cells[i][j].highlight = false;
               }
            }

            // Randomly highlight a row or column
            if (Math.random() < 0.5) {
               // Highlight row
               const row = Math.floor(Math.random() * rows);
               for (let j = 0; j < cols; j++) {
                  cells[row][j].highlight = true;
               }
            } else {
               // Highlight column
               const col = Math.floor(Math.random() * cols);
               for (let i = 0; i < rows; i++) {
                  cells[i][col].highlight = true;
               }
            }
         }

         // Every 10 frames, update some random values
         if (frame % 10 === 0) {
            const updateCount = Math.floor(rows * cols * 0.05); // Update 5% of cells

            for (let i = 0; i < updateCount; i++) {
               const row = Math.floor(Math.random() * rows);
               const col = Math.floor(Math.random() * cols);

               cells[row][col].value = Math.floor(Math.random() * 10);
            }
         }

         // Draw matrix
         for (let i = 0; i < rows; i++) {
            for (let j = 0; j < cols; j++) {
               const cell = cells[i][j];
               const x = j * cellSize;
               const y = i * cellSize;

               // Draw cell value
               ctx.font = "16px monospace";
               ctx.textAlign = "center";
               ctx.textBaseline = "middle";

               if (cell.highlight) {
                  ctx.fillStyle = "rgba(77, 171, 207, 0.8)"; // NumPy blue
               } else {
                  ctx.fillStyle = `rgba(77, 171, 207, ${cell.opacity})`;
               }

               ctx.fillText(
                  cell.value.toString(),
                  x + cellSize / 2,
                  y + cellSize / 2
               );
            }
         }

         animationId = requestAnimationFrame(animate);
      };

      animate();

      return () => {
         window.removeEventListener("resize", handleResize);
         cancelAnimationFrame(animationId);
      };
   }, []);

   return (
      <div className="fixed inset-0 -z-10 overflow-hidden bg-[#000]">
         <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.7 }}
            transition={{ duration: 1 }}
            className="absolute inset-0"
         >
            <canvas
               ref={canvasRef}
               className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 inset-0 md:w-[800px]"
            />
         </motion.div>
      </div>
   );
}
