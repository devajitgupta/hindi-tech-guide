"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";

type ApiRequest = {
   startX: number;
   startY: number;
   endX: number;
   endY: number;
   progress: number;
   speed: number;
   size: number;
   method: string;
   color: string;
};

export function FastAPIBackground() {
   const canvasRef = useRef<HTMLCanvasElement>(null);

   useEffect(() => {
      if (!canvasRef.current) return;

      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      // Set canvas dimensions
      const handleResize = () => {
         canvas.width = window.innerWidth;
         canvas.height = window.innerHeight;
      };

      handleResize();
      window.addEventListener("resize", handleResize);

      // API request animation
      const requests: ApiRequest[] = [];
      const apiMethods = ["GET", "POST", "PUT", "DELETE"];
      const methodColors = {
         GET: "#009688", // FastAPI teal
         POST: "#05998b", // Lighter teal
         PUT: "#00796b", // Darker teal
         DELETE: "#b71c1c", // Red for delete
      };

      // Create server nodes
      const serverCount = 5;
      const servers: { x: number; y: number }[] = [];

      for (let i = 0; i < serverCount; i++) {
         servers.push({
            x: (canvas.width * (i + 1)) / (serverCount + 1),
            y: canvas.height * 0.3,
         });
      }

      // Create client nodes
      const clientCount = 8;
      const clients: { x: number; y: number }[] = [];

      for (let i = 0; i < clientCount; i++) {
         clients.push({
            x: (canvas.width * (i + 1)) / (clientCount + 1),
            y: canvas.height * 0.7,
         });
      }

      // Draw nodes
      const drawNodes = () => {
         // Draw servers
         servers.forEach((server) => {
            ctx.beginPath();
            ctx.arc(server.x, server.y, 10, 0, Math.PI * 2);
            ctx.fillStyle = "#009688"; // FastAPI teal
            ctx.fill();

            ctx.beginPath();
            ctx.arc(server.x, server.y, 15, 0, Math.PI * 2);
            ctx.strokeStyle = "rgba(0, 150, 136, 0.3)";
            ctx.lineWidth = 2;
            ctx.stroke();
         });

         // Draw clients
         clients.forEach((client) => {
            ctx.beginPath();
            ctx.arc(client.x, client.y, 8, 0, Math.PI * 2);
            ctx.fillStyle = "rgba(255, 255, 255, 0.7)";
            ctx.fill();
         });
      };

      // Animation loop
      let animationId: number;

      const animate = () => {
         ctx.clearRect(0, 0, canvas.width, canvas.height);

         // Draw connection lines
         ctx.strokeStyle = "rgba(255, 255, 255, 0.1)";
         ctx.lineWidth = 1;

         servers.forEach((server) => {
            clients.forEach((client) => {
               ctx.beginPath();
               ctx.moveTo(server.x, server.y);
               ctx.lineTo(client.x, client.y);
               ctx.stroke();
            });
         });

         // Randomly create new requests
         if (Math.random() < 0.1) {
            const fromClient = Math.random() < 0.7; // 70% chance request starts from client

            const start = fromClient
               ? clients[Math.floor(Math.random() * clients.length)]
               : servers[Math.floor(Math.random() * servers.length)];

            const end = fromClient
               ? servers[Math.floor(Math.random() * servers.length)]
               : clients[Math.floor(Math.random() * clients.length)];

            const method =
               apiMethods[Math.floor(Math.random() * apiMethods.length)];

            requests.push({
               startX: start.x,
               startY: start.y,
               endX: end.x,
               endY: end.y,
               progress: 0,
               speed: Math.random() * 0.01 + 0.005,
               size: Math.random() * 4 + 3,
               method,
               color: methodColors[method as keyof typeof methodColors],
            });
         }

         // Update and draw requests
         for (let i = requests.length - 1; i >= 0; i--) {
            const req = requests[i];

            // Update progress
            req.progress += req.speed;

            if (req.progress >= 1) {
               // Remove completed request
               requests.splice(i, 1);
               continue;
            }

            // Calculate current position
            const x = req.startX + (req.endX - req.startX) * req.progress;
            const y = req.startY + (req.endY - req.startY) * req.progress;

            // Draw request
            ctx.beginPath();
            ctx.arc(x, y, req.size, 0, Math.PI * 2);
            ctx.fillStyle = req.color;
            ctx.fill();

            // Draw method text
            ctx.font = "10px monospace";
            ctx.fillStyle = "white";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.fillText(req.method, x, y);
         }

         // Draw nodes on top
         drawNodes();

         animationId = requestAnimationFrame(animate);
      };

      animate();

      return () => {
         window.removeEventListener("resize", handleResize);
         cancelAnimationFrame(animationId);
      };
   }, []);

   return (
      <div className="fixed inset-0 -z-10 overflow-hidden bg-[#000]">
         <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.3 }}
            transition={{ duration: 1 }}
            className="absolute inset-0"
         >
            <canvas
               ref={canvasRef}
               className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 inset-0 md:w-[600px]"
            />
         </motion.div>
      </div>
   );
}
