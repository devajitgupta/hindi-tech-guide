"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";

type Node = {
   x: number;
   y: number;
   children: Node[];
   depth: number;
   decision: string;
   highlight: boolean;
   highlightTime: number;
};

export function ScikitLearnBackground() {
   const canvasRef = useRef<HTMLCanvasElement>(null);

   useEffect(() => {
      if (!canvasRef.current) return;

      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      // Set canvas dimensions
      const handleResize = () => {
         canvas.width = window.innerWidth;
         canvas.height = window.innerHeight;
      };

      handleResize();
      window.addEventListener("resize", handleResize);

      // Create decision tree
      const createTree = (
         depth: number,
         x: number,
         y: number,
         angle: number,
         length: number
      ): Node => {
         const node: Node = {
            x,
            y,
            children: [],
            depth,
            decision: Math.random() < 0.5 ? "x > 0.5" : "y < 0.7",
            highlight: false,
            highlightTime: 0,
         };

         if (depth < 4) {
            const childCount = Math.random() < 0.7 ? 2 : 1;
            const childAngleSpread = Math.PI / 4;

            for (let i = 0; i < childCount; i++) {
               const childAngle =
                  angle + (i === 0 ? -childAngleSpread : childAngleSpread);
               const childLength = length * 0.7;
               const childX = x + Math.cos(childAngle) * childLength;
               const childY = y + Math.sin(childAngle) * childLength;

               node.children.push(
                  createTree(depth + 1, childX, childY, childAngle, childLength)
               );
            }
         }

         return node;
      };

      // Create multiple trees
      const trees: Node[] = [];
      const treeCount = 3;

      for (let i = 0; i < treeCount; i++) {
         const x = (canvas.width * (i + 1)) / (treeCount + 1);
         const y = canvas.height * 0.8;
         const angle = -Math.PI / 2; // Upward
         const length = canvas.height * 0.2;

         trees.push(createTree(0, x, y, angle, length));
      }

      // Recursively draw tree
      const drawTree = (node: Node, time: number) => {
         // Draw connections to children
         node.children.forEach((child) => {
            ctx.beginPath();
            ctx.moveTo(node.x, node.y);
            ctx.lineTo(child.x, child.y);

            if (node.highlight || child.highlight) {
               ctx.strokeStyle = "rgba(248, 153, 57, 0.8)"; // Scikit-learn orange
               ctx.lineWidth = 2;
            } else {
               ctx.strokeStyle = "rgba(248, 153, 57, 0.3)";
               ctx.lineWidth = 1;
            }

            ctx.stroke();

            // Recursively draw children
            drawTree(child, time);
         });

         // Draw node
         ctx.beginPath();
         ctx.arc(node.x, node.y, 5, 0, Math.PI * 2);

         if (node.highlight) {
            ctx.fillStyle = "#f89939"; // Scikit-learn orange
         } else {
            ctx.fillStyle = "rgba(52, 153, 205, 0.7)"; // Scikit-learn blue
         }

         ctx.fill();

         // Draw decision text for non-leaf nodes
         if (node.children.length > 0) {
            ctx.font = "10px monospace";
            ctx.fillStyle = "rgba(255, 255, 255, 0.7)";
            ctx.textAlign = "center";
            ctx.fillText(node.decision, node.x, node.y - 10);
         }

         // Update highlight state
         if (Math.random() < 0.001) {
            node.highlight = true;
            node.highlightTime = time + 100; // Highlight for 100 frames
         }

         if (node.highlight && time > node.highlightTime) {
            node.highlight = false;
         }
      };

      // Animation loop
      let animationId: number;
      let time = 0;

      const animate = () => {
         ctx.clearRect(0, 0, canvas.width, canvas.height);
         time++;

         // Draw all trees
         trees.forEach((tree) => {
            drawTree(tree, time);
         });

         animationId = requestAnimationFrame(animate);
      };

      animate();

      return () => {
         window.removeEventListener("resize", handleResize);
         cancelAnimationFrame(animationId);
      };
   }, []);

   return (
      <div className="fixed inset-0 -z-10 overflow-hidden bg-[#000]">
         <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.3 }}
            transition={{ duration: 1 }}
            className="absolute inset-0"
         >
            <canvas
               ref={canvasRef}
               className="absolute top-1 left-1/2 -translate-x-1/2 -translate-y-1/2 inset-0 md:w-[1000px]"
            />
         </motion.div>
      </div>
   );
}
