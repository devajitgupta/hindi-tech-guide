"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";

type Node = {
   x: number;
   y: number;
   radius: number;
   color: string;
   connections: number[];
   pulsePhase: number;
   pulseSpeed: number;
};

export function TensorFlowBackground() {
   const canvasRef = useRef<HTMLCanvasElement>(null);

   useEffect(() => {
      if (!canvasRef.current) return;

      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      // Set canvas dimensions
      const handleResize = () => {
         canvas.width = window.innerWidth;
         canvas.height = window.innerHeight;
      };

      handleResize();
      window.addEventListener("resize", handleResize);

      // Create neural network nodes
      const nodes: Node[] = [];
      const nodeCount = 30;
      const colors = ["#ff6f00", "#f89939", "#425066"];

      // Create nodes in layers
      const layers = 5;
      const nodesPerLayer = Math.ceil(nodeCount / layers);

      for (let layer = 0; layer < layers; layer++) {
         const layerX = (canvas.width * (layer + 1)) / (layers + 1);

         for (let i = 0; i < nodesPerLayer; i++) {
            const layerHeight = canvas.height * 0.7;
            const spacing = layerHeight / (nodesPerLayer + 1);
            const nodeY = (canvas.height - layerHeight) / 2 + spacing * (i + 1);

            nodes.push({
               x: layerX,
               y: nodeY,
               radius: Math.random() * 5 + 3,
               color: colors[Math.floor(Math.random() * colors.length)],
               connections: [],
               pulsePhase: Math.random() * Math.PI * 2,
               pulseSpeed: 0.02 + Math.random() * 0.03,
            });
         }
      }

      // Create connections between layers
      for (let layer = 0; layer < layers - 1; layer++) {
         const layerStartIdx = layer * nodesPerLayer;
         const nextLayerStartIdx = (layer + 1) * nodesPerLayer;

         for (let i = 0; i < nodesPerLayer; i++) {
            const nodeIdx = layerStartIdx + i;

            // Connect to 1-3 nodes in the next layer
            const connectionCount = Math.floor(Math.random() * 3) + 1;

            for (let c = 0; c < connectionCount; c++) {
               const targetIdx =
                  nextLayerStartIdx + Math.floor(Math.random() * nodesPerLayer);
               if (targetIdx < nodes.length) {
                  nodes[nodeIdx].connections.push(targetIdx);
               }
            }
         }
      }

      // Animation loop
      let animationId: number;
      let time = 0;

      const animate = () => {
         ctx.clearRect(0, 0, canvas.width, canvas.height);
         time += 0.01;

         // Draw connections first
         nodes.forEach((node, idx) => {
            node.connections.forEach((targetIdx) => {
               const target = nodes[targetIdx];

               // Calculate pulse position (0 to 1)
               const pulsePos = (Math.sin(time + node.pulsePhase) + 1) / 2;

               // Draw connection line
               ctx.beginPath();
               ctx.moveTo(node.x, node.y);
               ctx.lineTo(target.x, target.y);
               ctx.strokeStyle = "rgba(255, 111, 0, 0.15)";
               ctx.lineWidth = 1;
               ctx.stroke();

               // Draw pulse moving along the connection
               const pulseX = node.x + (target.x - node.x) * pulsePos;
               const pulseY = node.y + (target.y - node.y) * pulsePos;

               ctx.beginPath();
               ctx.arc(pulseX, pulseY, 2, 0, Math.PI * 2);
               ctx.fillStyle = "#ff6f00";
               ctx.fill();
            });
         });

         // Draw nodes
         nodes.forEach((node) => {
            // Node glow effect
            const glow = (Math.sin(time + node.pulsePhase) + 1) / 2;

            ctx.beginPath();
            ctx.arc(node.x, node.y, node.radius + glow * 3, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${hexToRgb(node.color)}, ${
               0.1 + glow * 0.2
            })`;
            ctx.fill();

            // Node core
            ctx.beginPath();
            ctx.arc(node.x, node.y, node.radius, 0, Math.PI * 2);
            ctx.fillStyle = node.color;
            ctx.fill();
         });

         animationId = requestAnimationFrame(animate);
      };

      animate();

      return () => {
         window.removeEventListener("resize", handleResize);
         cancelAnimationFrame(animationId);
      };
   }, []);

   return (
      <div className=" absolute inset-0 -z-10 overflow-hidden bg-[#000] ">
         <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.3 }}
            transition={{ duration: 1 }}
            className="absolute inset-0"
         >
            <canvas
               ref={canvasRef}
               className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 inset-0 md:w-[700px]"
            />
         </motion.div>
      </div>
   );
}

// Helper function to convert hex to rgb
function hexToRgb(hex: string): string {
   // Remove # if present
   hex = hex.replace("#", "");

   // Parse the hex values
   const r = Number.parseInt(hex.substring(0, 2), 16);
   const g = Number.parseInt(hex.substring(2, 4), 16);
   const b = Number.parseInt(hex.substring(4, 6), 16);

   return `${r}, ${g}, ${b}`;
}
