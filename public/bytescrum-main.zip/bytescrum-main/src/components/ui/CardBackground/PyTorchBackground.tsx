"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";

type Particle = {
   x: number;
   y: number;
   size: number;
   life: number;
   maxLife: number;
   vx: number;
   vy: number;
   color: string;
};

export function PyTorchBackground() {
   const canvasRef = useRef<HTMLCanvasElement>(null);

   useEffect(() => {
      if (!canvasRef.current) return;

      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      // Set canvas dimensions
      const handleResize = () => {
         canvas.width = window.innerWidth;
         canvas.height = window.innerHeight;
      };

      handleResize();
      window.addEventListener("resize", handleResize);

      // Torch flame particles
      const particles: Particle[] = [];
      const torchPositions = [
         { x: canvas.width * 0.25, y: canvas.height * 0.7 },
         { x: canvas.width * 0.75, y: canvas.height * 0.7 },
      ];

      // Colors for the flame
      const flameColors = [
         "#ee4c2c", // PyTorch red
         "#f89939", // PyTorch orange
         "#ffcc80", // Light orange
         "#ffb74d", // Medium orange
      ];

      // Draw torch base
      const drawTorch = (x: number, y: number) => {
         // Torch handle
         ctx.beginPath();
         ctx.moveTo(x, y);
         ctx.lineTo(x, y + 100);
         ctx.lineWidth = 10;
         ctx.strokeStyle = "#555";
         ctx.stroke();

         // Torch head
         ctx.beginPath();
         ctx.arc(x, y, 20, 0, Math.PI, true);
         ctx.fillStyle = "#777";
         ctx.fill();
      };

      // Animation loop
      let animationId: number;

      const animate = () => {
         ctx.clearRect(0, 0, canvas.width, canvas.height);

         // Draw torches
         torchPositions.forEach((pos) => {
            drawTorch(pos.x, pos.y);

            // Add new particles
            if (Math.random() < 0.3) {
               const particleCount = Math.floor(Math.random() * 3) + 1;

               for (let i = 0; i < particleCount; i++) {
                  particles.push({
                     x: pos.x + (Math.random() - 0.5) * 15,
                     y: pos.y - 10,
                     size: Math.random() * 15 + 5,
                     life: 0,
                     maxLife: Math.random() * 100 + 50,
                     vx: (Math.random() - 0.5) * 2,
                     vy: -Math.random() * 3 - 1,
                     color: flameColors[
                        Math.floor(Math.random() * flameColors.length)
                     ],
                  });
               }
            }
         });

         // Update and draw particles
         for (let i = particles.length - 1; i >= 0; i--) {
            const p = particles[i];

            // Update position
            p.x += p.vx;
            p.y += p.vy;

            // Update velocity (flame rises and spreads)
            p.vy -= 0.05;
            p.vx *= 0.99;

            // Update size and life
            p.life++;
            const lifeRatio = p.life / p.maxLife;
            const size = Math.max(p.size * (1 - lifeRatio), 0);

            // Draw particle
            ctx.beginPath();
            ctx.arc(p.x, p.y, size, 0, Math.PI * 2);

            // Gradient for more realistic flame
            const gradient = ctx.createRadialGradient(
               p.x,
               p.y,
               0,
               p.x,
               p.y,
               size
            );
            gradient.addColorStop(0, p.color);
            gradient.addColorStop(1, "rgba(239, 76, 44, 0)");

            ctx.fillStyle = gradient;
            ctx.fill();

            // Remove dead particles
            if (p.life >= p.maxLife) {
               particles.splice(i, 1);
            }
         }

         animationId = requestAnimationFrame(animate);
      };

      animate();

      return () => {
         window.removeEventListener("resize", handleResize);
         cancelAnimationFrame(animationId);
      };
   }, []);

   return (
      <div className="absolute inset-0 -z-10 overflow-hidden bg-[#000]">
         <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.3 }}
            transition={{ duration: 1 }}
            className="absolute inset-0"
         >
            <canvas
               ref={canvasRef}
               className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 inset-0 md:w-[600px]"
            />
         </motion.div>
      </div>
   );
}
