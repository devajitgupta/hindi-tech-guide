"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";

export function DjangoBackground() {
   const canvasRef = useRef<HTMLCanvasElement>(null);

   useEffect(() => {
      if (!canvasRef.current) return;

      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      // Set canvas dimensions
      const handleResize = () => {
         canvas.width = window.innerWidth;
         canvas.height = window.innerHeight;
      };

      handleResize();
      window.addEventListener("resize", handleResize);

      // Django grid animation parameters
      const gridSize = 40;
      const blockSize = Math.max(canvas.width, canvas.height) / gridSize;
      const blocks: {
         x: number;
         y: number;
         opacity: number;
         targetOpacity: number;
         size: number;
      }[] = [];

      // Initialize grid blocks
      for (let x = 0; x < Math.ceil(canvas.width / blockSize) + 1; x++) {
         for (let y = 0; y < Math.ceil(canvas.height / blockSize) + 1; y++) {
            blocks.push({
               x: x * blockSize,
               y: y * blockSize,
               opacity: 0,
               targetOpacity: Math.random() * 0.3,
               size: blockSize * (0.5 + Math.random() * 0.5),
            });
         }
      }

      // Animation loop
      let animationId: number;

      const animate = () => {
         ctx.clearRect(0, 0, canvas.width, canvas.height);

         // Draw grid pattern
         ctx.strokeStyle = "rgba(68, 183, 139, 0.1)";
         ctx.lineWidth = 1;

         // Horizontal lines
         for (let y = 0; y <= canvas.height; y += blockSize) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(canvas.width, y);
            ctx.stroke();
         }

         // Vertical lines
         for (let x = 0; x <= canvas.width; x += blockSize) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, canvas.height);
            ctx.stroke();
         }

         // Draw blocks
         blocks.forEach((block) => {
            // Gradually change opacity
            block.opacity += (block.targetOpacity - block.opacity) * 0.05;

            // Randomly change target opacity
            if (Math.random() < 0.01) {
               block.targetOpacity = Math.random() * 0.3;
            }

            ctx.fillStyle = `rgba(68, 183, 139, ${block.opacity})`;
            ctx.fillRect(
               block.x - block.size / 2,
               block.y - block.size / 2,
               block.size,
               block.size
            );
         });

         animationId = requestAnimationFrame(animate);
      };

      animate();

      return () => {
         window.removeEventListener("resize", handleResize);
         cancelAnimationFrame(animationId);
      };
   }, []);

   return (
      <div className=" absolute inset-0 -z-50 1overflow-hidden bg-[#000]">
         <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.4 }}
            transition={{ duration: 1 }}
            className="absolute inset-0"
         >
            <canvas
               ref={canvasRef}
               className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 inset-0 md:w-[800px]"
            />
         </motion.div>
      </div>
   );
}
