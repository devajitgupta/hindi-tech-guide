"use client";
import { motion } from "framer-motion";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import SectionTitle from "../SectionTitle";
import Text from "../Text";
import { Button } from "@nextui-org/react";
import Link from "next/link";
import { Icon } from "@iconify/react/dist/iconify.js";

type Props = {
   className?: string;
   serviceSection: any;
   data: any;
};

const ServiceSection = ({
   className,
   serviceSection,
   data,
}: Props) => {
   return (
      <motion.div className={twMerge(clsx(className))}>
         <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            <div className="bg-[#1A1A1A]/35 rounded-[16px] sm:col-span-2 sm:row-span-2 grid items-center justify-start px-10 ">
               <div className=" space-y-[30px] md:space-y-[50px] grid items-center py-10">
                  <div className="space-y-3 md:space-y-5 ">
                     <SectionTitle className="  text-[22px] md:text-[45px] text-start md:text-start  ">
                        {serviceSection.sectionTitle}
                     </SectionTitle>
                     <Text className="max-w-full lg:max-w-[600px]  md:px-16 px-4 lg:px-0 text-start md:text-start ">
                        {serviceSection.sectionDescription}
                       </Text>
                  </div>
                  <div>
                     <Button
                        as={Link}
                        href="/contact-us"
                        className={twMerge(
                           clsx(
                              "btn !bg-[#1463FD] text-white after:bg-[#fff]  !w-fit after:text-white py-[10px] px-[30px] inter font-bold text-[14px] leading-[24px] m-auto"
                           )
                        )}
                     >
                        {serviceSection.title}
                     </Button>
                  </div>
               </div>
            </div>

            {data.map((item: any, index: number) => (
               <motion.div
                  key={index}
                  className="bg-[#090909] rounded-[16px] relative overflow-hidden group"
                  whileHover={{ scale: 1.02 }}
                  transition={{ ease: "easeInOut" }}
               >
                  <Icon
                     icon={item.icon}
                     width="200"
                     height="200"
                     className="opacity-70 absolute top-1/2 translate-x-1/2 right-5 text-white/10 group-hover:text-[#1463fd]/50 group-hover:opacity-50 transition-all duration-3000  "
                  />
                  <div
                     key={index}
                     className={twMerge(
                        clsx(
                           " bg-fit  bg-no-repeat bg-opacity-20 rounded-[8px] md:rounded-[16px] grid place-items-center px-4 md:px-[33px] min-h-[275px] md:min-h-[325px]"
                        )
                     )}
                     style={{ backgroundImage: `url(${item.bg})` }}
                  >
                     <div className="space-y-[40px] ">
                        {/* <Image
                           src={item.icon}
                           width={50}
                           height={50}
                           alt={item.icon}
                        /> */}
                        <Icon icon={item.icon} width="70" height="70" />
                        <div className="space-y-[10px] sm:max-w-[260px] ">
                           <h3 className="text-[20px] font-bold poppins">
                              {item.title}
                           </h3>
                           <Text className="text-start">
                              {item.description}
                           </Text>
                        </div>
                     </div>
                  </div>
               </motion.div>
            ))}
         </div>
      </motion.div>
   );
};

export default ServiceSection;
