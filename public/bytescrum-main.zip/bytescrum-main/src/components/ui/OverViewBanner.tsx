"use client";
import Image from "next/image";
import React from "react";
import Text from "../Text";
import { motion } from "framer-motion";
import Link from "next/link";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import { useRouter } from "next/navigation";
import SectionTitle from "../SectionTitle";
import { Button } from "@nextui-org/react";

type Props = {
   className?: string;
   deskTopImageSrc?: string;
   mobileImageSrc?: string;
   bannerTextOne?: string;
   bannerTextTwo?: string;
   buttonText?: string;
   buttonUrl?: string;
};

const OverViewBanner = ({
   className,
   deskTopImageSrc,
   mobileImageSrc,
   bannerTextOne,
   bannerTextTwo,
   buttonText,
   buttonUrl,
}: Props) => {
   const router = useRouter();
   return (
      <div className={twMerge(clsx(" w-full relative   ", className))}>
         <div className=" overflow-hidden  xl:w-fit ml-auto rounded-lg md:w-[375px] xl:max-h-[25rem] ">
            <Image
               src={
                  deskTopImageSrc
                     ? deskTopImageSrc
                     : "/service/webDev/overViewBanner.png"
               }
               width={440}
               height={0}
               alt={"overViewBanner.png"}
               className="ml-auto h-auto hidden md:block -mt-10"
            />
            <Image
               src={"/service/webDev/overViewBanner.png"}
               width={232}
               height={0}
               alt={mobileImageSrc ? mobileImageSrc : "overViewBanner.png"}
               className="ml-auto h-auto md:hidden"
            />
         </div>
         {/* <div className="relative  lg:-top-5 ml-auto">
            <div className=" absolute rounded-[16px] bg-[#1463fd] px-[15px] py-[20px]  md:py-[85px] lg:px-[27px]  grid place-items-center gap-5 lg:gap-[30px] max-w-[225px]  md:max-w-[360px] lg:max-h-[340px] -bottom-16 -md:bottom-10 md:left-40 lg:left-36">
               <div className="space-y-[10px]">
                  <Text
                     className="font-bold text-[20px]  poppins"
                     color="#fff"
                     textSize="lg"
                  >
                     {bannerTextOne ? bannerTextOne : "Be Part of the Tribe"}
                  </Text>
                  <Text className="max-w-[305px] inter" color="#fff">
                     {bannerTextTwo
                        ? bannerTextTwo
                        : "Drop your development requirements and join them as our pride."}
                  </Text>
               </div>

               <motion.button
                  whileHover={{
                     scale: 1.02,
                     transition: { duration: 0.5 },
                     shadow: "1px 100px 100px #000",
                  }}
                  whileTap={{ scale: 0.8 }}
                  onClick={() =>
                     router.push(buttonUrl ? buttonUrl : "/contact-us")
                  }
                  className={twMerge(
                     clsx(
                        "btn !bg-white text-black after:bg-[#1463fd] border !after:border-white m-auto !w-fit !after:text-white hover:text-white py-[10px] px-[30px]"
                     )
                  )}
               >
                  {buttonText ? buttonText : "Contact us now"}
               </motion.button>
            </div>
         </div> */}
         <div className="relative -top-[12rem] lg:-top-[14rem] xl:-top-[15rem]  md:left-20 lg:left-5 xl:left-28 ml-auto">
            <div className="py-6 lg:py-8 xl:py-12 absolute rounded-[16px] px-5 md:px-6 bg-[#1463fd]">
               <div className="grid place-items-center gap-3 md:gap-6">
                  <p className="font-bold text-lg m-auto">
                     {bannerTextOne ? bannerTextOne : "Be Part of the Tribe"}
                  </p>
                  <Text
                     className=" max-w-[12.5rem] md:!max-w-[305px] inter m-auto"
                     color="#fff"
                  >
                     {bannerTextTwo
                        ? bannerTextTwo
                        : "Drop your development requirements and join them as our pride."}
                  </Text>
                  {/* <motion.button
                     whileTap={{ scale: 0.8 }}
                     initial={{
                        scale: 1,
                        shadow: "1px 100px 100px #000",
                        backgroundColor: "#1463fd",
                     }}
                     onClick={() =>
                        router.push(buttonUrl ? buttonUrl : "/contact-us")
                     }
                     whileHover={{
                        scale: 1.02,
                        shadow: "1px 100px 100px #000",
                        backgroundColor: "white",
                     }}
                     transition={{ duration: 0.5, type: "spring" }}
                     className={twMerge(
                        // clsx(
                        //    "btn  !bg-white text-black after:bg-[#1463fd] border !after:border-white m-auto !w-fit !after:text-white hover:text-white py-[10px] px-[30px]"
                        // )
                        clsx(
                           "hover:text-black border text-white  m-auto rounded-full !w-fit py-[10px] px-[30px]"
                        )
                     )}
                  >
                     {buttonText ? buttonText : "Contact us now"}
                  </motion.button> */}
                  <Button className="border rounded-full text-black hover:text-white m-auto !w-fit py-[10px] px-[30px] hover:bg-[#1463fd] ">
                     {" "}
                     {buttonText ? buttonText : "Contact us now"}
                  </Button>
               </div>
            </div>
         </div>
      </div>
   );
};

export default OverViewBanner;
