import { twMerge } from "tailwind-merge";
import { TrustedCard } from "./home";
import clsx from "clsx";
interface IProps {
   className?: string;
   data?:any;
}
const TurstedMarquee = ({ className, data }:IProps) => {
   return (
      <div
         className={twMerge(
            clsx(
               "trustSection  pb-[180px] md:pb-[180px]   grid items-center gap-[72px] md:gap-[92px] relative overflow-hidden bg-gradient-to-b lg:bg-gradient-to-r from-[#0D0D0D]/50 to-[#2A2A2A]/50",
               className
            )
         )}
      >
         {data.trustedSection.trustedCardData.map((item:any) => (
            <div
               key={item._id}
               className="grid gap-[0px] md:gap-[20px]  item-center justify-center overflow-hidden w-5/12  "
            >
               <div className=" flex gap-[10px] md:gap-[20px] animate-[marqueRight_linear_15s_infinite]  md:animate-[marqueRight_linear_25s_infinite] absolute   overflow-x-hidden ">
                  {" "}
                  {item.lineOne &&
                     item.lineOne.map((logo:any, logoIndex:number) => (
                        <TrustedCard
                           logo={logo.logo}
                           width={logo.width}
                           height={logo.height}
                           key={logo._id}
                        />
                     ))}
                  {item.lineOne &&
                     item.lineOne.map((logo:any, logoIndex:number) => (
                        <TrustedCard
                           logo={logo.logo}
                           width={logo.width}
                           height={logo.height}
                           // key={`${logoIndex}-1st_row`}
                           key={logo._id}
                        />
                     ))}
               </div>
               <div className=" flex gap-[10px] md:gap-[20px] animate-[marqueLeft_linear_20s_infinite]  md:animate-[marqueLeft_linear_30s_infinite] absolute overflow-x-hidden ">
                  {item.lineTwo &&
                     item.lineTwo.map((logo:any, logoIndex:number) => (
                        <TrustedCard
                           logo={logo.logo}
                           width={logo.width}
                           height={logo.height}
                           // key={`${logoIndex}-2nd_row`}
                           key={logo._id}
                        />
                     ))}
                  {item.lineTwo &&
                     item.lineTwo.map((logo:any, logoIndex:number) => (
                        <TrustedCard
                           logo={logo.logo}
                           width={logo.width}
                           height={logo.height}
                           // key={`${logoIndex}-2nd_row`}
                           key={logo._id}
                        />
                     ))}
               </div>

               <div className=" flex gap-[10px] md:gap-[20px] animate-[marqueRight_linear_15s_infinite]  md:animate-[marqueRight_linear_25s_infinite] bottom-12 absolute   overflow-x-hidden md:hidden ">
                  {item.lineOne &&
                     item.lineOne.map((logo:any, logoIndex:number) => (
                        <TrustedCard
                           logo={logo.logo}
                           width={logo.width}
                           height={logo.height}
                           // key={`${logoIndex}-1st_row`}
                           key={logo._id}
                        />
                     ))}

                  {item.lineOne &&
                     item.lineOne.map((logo:any, logoIndex:number) => (
                        <TrustedCard
                           logo={logo.logo}
                           width={logo.width}
                           height={logo.height}
                           // key={`${logoIndex}-1st_row`}
                           key={logo._id}
                        />
                     ))}
               </div>
            </div>
         ))}
      </div>
   );
};

export default TurstedMarquee;
