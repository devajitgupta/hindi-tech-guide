import React from "react";
import SectionTitle from "../SectionTitle";
import { Button } from "@nextui-org/react";
import SectionSubtitle from "../SectionSubtitle";

const BlockChainDevProcess = () => {
   return (
      <div className="px-5 md:px-[40px] pb-[60px]   md:pb-[80px] gap-[40px] bg-[#000000] relative z-50 w-full max-w-6xl m-auto">
         <div className="mt-16">
            <SectionTitle className="section-subtitle text-center">
               Our Blockchain Development Process
            </SectionTitle>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
               <div className="bg-gradient-to-br from-black to-blue-950/20 p-6 rounded-lg border border-blue-900/30">
                  <div className="text-blue-400 text-xl font-bold mb-2">01</div>
                  <SectionSubtitle className="text-lg font-semibold mb-2">
                     Requirement Analysis
                  </SectionSubtitle>
                  <p className="text-[#fafafa] text-sm">
                     We analyze your business needs and identify how blockchain
                     technology can solve your specific challenges.
                  </p>
               </div>

               <div className="bg-gradient-to-br from-black to-blue-950/20 p-6 rounded-lg border border-blue-900/30">
                  <div className="text-blue-400 text-xl font-bold mb-2">02</div>
                  <h4 className="text-lg font-semibold mb-2">
                     Architecture Design
                  </h4>
                  <p className="text-[#fafafa] text-sm">
                     Our experts design a robust blockchain architecture
                     tailored to your specific requirements and scalability
                     needs.
                  </p>
               </div>

               <div className="bg-gradient-to-br from-black to-blue-950/20 p-6 rounded-lg border border-blue-900/30">
                  <div className="text-blue-400 text-xl font-bold mb-2">03</div>
                  <h4 className="text-lg font-semibold mb-2">
                     Smart Contract Development
                  </h4>
                  <p className="text-[#fafafa] text-sm">
                     We develop secure, efficient smart contracts that automate
                     business processes and enforce agreements.
                  </p>
               </div>

               <div className="bg-gradient-to-br from-black to-blue-950/20 p-6 rounded-lg border border-blue-900/30">
                  <div className="text-blue-400 text-xl font-bold mb-2">04</div>
                  <h4 className="text-lg font-semibold mb-2">
                     Frontend Integration
                  </h4>
                  <p className="text-[#fafafa] text-sm">
                     Our team creates intuitive user interfaces that interact
                     seamlessly with your blockchain backend.
                  </p>
               </div>

               <div className="bg-gradient-to-br from-black to-blue-950/20 p-6 rounded-lg border border-blue-900/30">
                  <div className="text-blue-400 text-xl font-bold mb-2">05</div>
                  <h4 className="text-lg font-semibold mb-2">
                     Testing & Auditing
                  </h4>
                  <p className="text-[#fafafa] text-sm">
                     We conduct comprehensive testing and security audits to
                     ensure your blockchain solution is secure and reliable.
                  </p>
               </div>

               <div className="bg-gradient-to-br from-black to-blue-950/20 p-6 rounded-lg border border-blue-900/30">
                  <div className="text-blue-400 text-xl font-bold mb-2">06</div>
                  <h3 className="text-lg font-semibold mb-2">
                     Deployment & Support
                  </h3>
                  <p className="text-[#fafafa] text-sm">
                     We handle the deployment process and provide ongoing
                     support and maintenance for your blockchain solution.
                  </p>
               </div>
            </div>
         </div>
         <div className="mt-16">
            <SectionSubtitle className="section-subtitle text-center m-auto">
               Blockchain Technologies We Work With
            </SectionSubtitle>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
               {[
                  "Ethereum",
                  "Hyperledger",
                  "Solana",
                  "Polkadot",
                  "Binance Smart Chain",
                  "Polygon",
                  "Avalanche",
                  "Cardano",
               ].map((tech, index) => (
                  <div
                     key={index}
                     className="bg-gradient-to-br from-black to-blue-950/10 p-4 rounded-lg border border-blue-900/20 text-center"
                  >
                     <span className="text-white">{tech}</span>
                  </div>
               ))}
            </div>
         </div>

         <div className="mt-16 text-center">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105">
               Start Your Blockchain Project
            </Button>
         </div>
      </div>
   );
};

export default BlockChainDevProcess;
