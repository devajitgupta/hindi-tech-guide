import React from "react";
import SectionTitle from "../SectionTitle";
import Text from "../Text";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import { StatsCountUp } from "../home";
import BlockChainInnovationSection from "./BlockChainInnovationSection";
import OverViewBanner from "../ui/OverViewBanner";

interface IProps {
   className?: string;
}

const BlockChainOverview = ({ className }: IProps) => {
   return (
      <div className={twMerge(clsx("relative h-full  w-full z-20", className))}>
         <div className="grid lg:grid-cols-2 lg:pb-32 ">
            <div className="order-2 lg:order-1 ">
               <div className="space-y-[20px]  pt-[60px]  mt-8 lg:mt-0 ">
                  <SectionTitle className="text-start">Overview</SectionTitle>
                  <div className="space-y-[10px]">
                     <Text className="text-start  max-w-full md:max-w-[622px] lg:max-w-full">
                        Blockchain development encompasses scalability,
                        interoperability, privacy, governance, and Blockchain as
                        a Service (BaaS). These elements enhance decentralized
                        technologies, facilitating efficient transactions,
                        seamless blockchain communication, data security,
                        informed decision-making, and streamlined development
                        and deployment processes for innovative solutions.
                     </Text>
                     <Text className="text-start  max-w-full md:max-w-[622px] lg:max-w-full">
                        Smart contracts enhance automation and trust, while
                        decentralized identity solutions empower users over
                        their data. Emerging technologies like layer-2 solutions
                        and cross-chain bridges will transform blockchain
                        interactions, fostering innovation and unlocking new
                        opportunities for a more transparent and equitable
                        digital economy.
                     </Text>
                  </div>
               </div>
               {/* <StatsCountUp
                  className="lg:flex justify-between hidden  md:gap-[0px] py-0 lg:pt-[5px] gap-0 lg:max-w-[670px] overflow-hidden "
                  wrapper={clsx(
                     "  px-0 md:px-0 w-fit [&:nth-child(1)]:hidden  [&:nth-child(2)]:hidden [&:nth-child(2)]:border-r [&:nth-child(2)]:border-[#262626] [&:nth-child(2)]:rounded-none w-[300px]"
                  )}
                  countUpClass=" text-start text-[28px] md:text-[45px] px-0 md:px-0 py-0 md:py-0 "
                  symbolClass="text-[20px] md:[42px]"
                  textClass="font-normal text-start text-[14px]  md:text-[20px]"
               /> */}
            </div>
            <OverViewBanner className="order-1  lg:order-2" />
         </div>
         <BlockChainInnovationSection />
      </div>
   );
};

export default BlockChainOverview;
