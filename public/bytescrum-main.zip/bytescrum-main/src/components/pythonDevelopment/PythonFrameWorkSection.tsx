"use client";
import React from "react";
import SectionTitle from "../SectionTitle";
import PerspectiveCard from "../ui/PerspectiveCard";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";

type Props = {
   className?: string;
   libraries: any;
   data:any;
};

const PythonFrameWorkSection = ({ className,data, libraries }: Props) => {
   return (
      <div
         className={twMerge(
            clsx(
               "px-5 md:px-[40px] pb-[60px]   md:pb-[80px] gap-[40px] bg-[#000000] relative z-50 w-full",
               className
            )
         )}
      >
         {" "}
         <div className="md:mt-5  m-auto">
            <div className=" overflow-hidden">
               <SectionTitle
                  animationVariant="fadeUp"
                  className=" max-w-2xl m-auto"
               >
{data.title}               </SectionTitle>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-8">
               {libraries.map((item: any, index: number) => (
                  <PerspectiveCard
                     key={index}
                     title={item.title}
                     description={item.description}
                     icon={item.icon}
                  />
               ))}
            </div>
         </div>
      </div>
   );
};

export default PythonFrameWorkSection;
