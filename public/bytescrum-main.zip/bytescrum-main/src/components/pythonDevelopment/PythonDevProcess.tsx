import React from "react";
import SectionTitle from "../SectionTitle";

const PythonDevProcess = () => {
   return (
      <div className="px-5 md:px-[40px] pb-[60px]   md:pb-[80px] gap-[40px] bg-[#000000] relative z-50 w-full">
         {" "}
         <div className="mt-16 max-w-6xl m-auto">
            <div className=" overflow-hidden">
               <SectionTitle
                  animationVariant="fadeUp"
                  className="section-title text-center  "
               >
                  Our Python Development Process
               </SectionTitle>
            </div>
            <div className="relative mt-12">
               {/* Timeline */}
               <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-gradient-to-b from-blue-600/50 to-purple-600/50"></div>

               {/* Timeline Items */}
               <div className="space-y-16">
                  <div className="relative">
                     <div className="absolute left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-blue-600 border-4 border-black"></div>
                     <div className="ml-auto mr-8 md:mr-auto md:ml-8 md:pl-10 w-full md:w-1/2 p-4 rounded-lg bg-gradient-to-br from-black to-blue-950/20 border border-blue-900/30">
                        <h4 className="text-lg font-semibold mb-2">
                           Requirements Analysis
                        </h4>
                        <p className="text-[#fafafa] text-sm">
                           We work closely with you to understand your business
                           needs and define the scope and requirements of your
                           Python project.
                        </p>
                     </div>
                  </div>

                  <div className="relative">
                     <div className="absolute left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-indigo-600 border-4 border-black"></div>
                     <div className="mr-auto ml-8 md:ml-auto md:mr-8 md:pr-10 w-full md:w-1/2 p-4 rounded-lg bg-gradient-to-br from-black to-indigo-950/20 border border-indigo-900/30">
                        <h4 className="text-lg font-semibold mb-2">
                           Architecture & Design
                        </h4>
                        <p className="text-[#fafafa] text-sm">
                           Our architects design a robust application structure
                           optimized for performance, scalability, and
                           maintainability.
                        </p>
                     </div>
                  </div>

                  <div className="relative">
                     <div className="absolute left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-purple-600 border-4 border-black"></div>
                     <div className="ml-auto mr-8 md:mr-auto md:ml-8 md:pl-10 w-full md:w-1/2 p-4 rounded-lg bg-gradient-to-br from-black to-purple-950/20 border border-purple-900/30">
                        <h4 className="text-lg font-semibold mb-2">
                           Development & Testing
                        </h4>
                        <p className="text-[#fafafa] text-sm">
                           We follow agile methodologies to develop your Python
                           application with continuous testing and quality
                           assurance.
                        </p>
                     </div>
                  </div>

                  <div className="relative">
                     <div className="absolute left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-blue-600 border-4 border-black"></div>
                     <div className="mr-auto ml-8 md:ml-auto md:mr-8 md:pr-10 w-full md:w-1/2 p-4 rounded-lg bg-gradient-to-br from-black to-blue-950/20 border border-blue-900/30">
                        <h4 className="text-lg font-semibold mb-2">
                           Deployment & Documentation
                        </h4>
                        <p className="text-[#fafafa] text-sm">
                           We handle the deployment process and provide
                           comprehensive documentation to ensure your team can
                           effectively manage the application.
                        </p>
                     </div>
                  </div>

                  <div className="relative">
                     <div className="absolute left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-purple-600 border-4 border-black"></div>
                     <div className="ml-auto mr-8 md:mr-auto md:ml-8 md:pl-10 w-full md:w-1/2 p-4 rounded-lg bg-gradient-to-br from-black to-purple-950/20 border border-purple-900/30">
                        <h4 className="text-lg font-semibold mb-2">
                           Maintenance & Support
                        </h4>
                        <p className="text-[#fafafa] text-sm">
                           We provide ongoing maintenance, support, and updates
                           to ensure your Python application continues to meet
                           your evolving business needs.
                        </p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div className="mt-16 text-center">
            <button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105">
               Explore Python Solutions
            </button>
         </div>
      </div>
   );
};

export default PythonDevProcess;
