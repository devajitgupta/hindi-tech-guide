import React from "react";
import SectionTitle from "../SectionTitle";
import Text from "../Text";

const VersatileSolutions = ({data}:any) => {
   return (
      <div className="px-5 md:px-[40px] pb-[60px]   md:pb-[80px] gap-[40px] bg-[#000000] relative z-50 w-full">
         <div className="mt-16  m-auto">
            {" "}
            <div className=" overflow-hidden">
               <SectionTitle
                  animationVariant="fadeUp"
                  className=" max-w-3xl m-auto"
               >
                  {data.sectionTitle}
               </SectionTitle>
            </div>
            <Text className="text-[#fafafa] mb-12 text-center lg:max-w-5xl m-auto">
              {data.description}
            </Text>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8 mt-12">
               <div className="service-card bg-gradient-to-br from-black to-blue-950/20">
                  <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mb-4">
                     <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-blue-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                     >
                        <path
                           strokeLinecap="round"
                           strokeLinejoin="round"
                           strokeWidth={2}
                           d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                        />
                     </svg>
                  </div>
                  <h4 className="text-xl font-semibold mb-3">
                     {data.service1_title}
                  </h4>
                  <p className="text-[#fafafa] mb-12 ">
                
                {data.service1_description} </p>
               </div>

               <div className="service-card bg-gradient-to-br from-black to-green-950/20">
                  <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mb-4">
                     <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-green-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                     >
                        <path
                           strokeLinecap="round"
                           strokeLinejoin="round"
                           strokeWidth={2}
                           d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                        />
                     </svg>
                  </div>
                  <h4 className="text-xl font-semibold mb-3">

{data.service2_title}                  </h4>
                  <p className="text-[#fafafa] mb-12 ">
              
              {data.service2_description}  </p>
               </div>

               <div className="service-card bg-gradient-to-br from-black to-purple-950/20">
                  <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mb-4">
                     <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-purple-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                     >
                        <path
                           strokeLinecap="round"
                           strokeLinejoin="round"
                           strokeWidth={2}
                           d="M13 10V3L4 14h7v7l9-11h-7z"
                        />
                     </svg>
                  </div>
                  <h4 className="text-xl font-semibold mb-3">
{data.service3_title}                  </h4>
                  <p className="text-[#fafafa] mb-12 ">
             {data.service3_description}   </p>
               </div>

               <div className="service-card bg-gradient-to-br from-black to-teal-950/20">
                  <div className="w-12 h-12 bg-teal-500/20 rounded-lg flex items-center justify-center mb-4">
                     <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-6 w-6 text-teal-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                     >
                        <path
                           strokeLinecap="round"
                           strokeLinejoin="round"
                           strokeWidth={2}
                           d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                        />
                     </svg>
                  </div>
                  <h4 className="text-xl font-semibold mb-3">
{data.service4_title}                  </h4>
                  <p className="text-[#fafafa] mb-12 ">
               {data.service4_description}   </p>
               </div>
            </div>
         </div>
      </div>
   );
};

export default VersatileSolutions;
