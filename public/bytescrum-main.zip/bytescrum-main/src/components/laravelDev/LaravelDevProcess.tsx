import React from "react";

const LaravelDevProcess = () => {
   return (
      <div>
         {" "}
         <div className="mt-16 max-w-6xl m-auto ">
            <h3 className="section-subtitle text-center">
               Our Laravel Development Process
            </h3>
            <div className="mt-8 grid grid-cols-2 gap-y-4 gap-x-12">
               <div className="flex flex-col md:flex-row items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#1463fd] flex items-center justify-center text-white font-bold">
                     1
                  </div>
                  <div>
                     <h4 className="text-lg font-semibold mb-2">
                        Requirements Analysis
                     </h4>
                     <p className="text-[#fafafa]">
                        We work closely with you to understand your business
                        needs and define the scope and requirements of your
                        Laravel project.
                     </p>
                  </div>
               </div>

               <div className="flex flex-col md:flex-row items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#1463fd] flex items-center justify-center text-white font-bold">
                     2
                  </div>
                  <div>
                     <h4 className="text-lg font-semibold mb-2">
                        Architecture & Database Design
                     </h4>
                     <p className="text-[#fafafa]">
                        Our architects design a robust application structure and
                        database schema optimized for performance and
                        scalability.
                     </p>
                  </div>
               </div>

               <div className="flex flex-col md:flex-row items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#1463fd] flex items-center justify-center text-white font-bold">
                     3
                  </div>
                  <div>
                     <h4 className="text-lg font-semibold mb-2">
                        Development & Testing
                     </h4>
                     <p className="text-[#fafafa]">
                        We follow agile methodologies to develop your Laravel
                        application with continuous testing and quality
                        assurance.
                     </p>
                  </div>
               </div>

               <div className="flex flex-col md:flex-row items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#1463fd] flex items-center justify-center text-white font-bold">
                     4
                  </div>
                  <div>
                     <h4 className="text-lg font-semibold mb-2">
                        Deployment & Training
                     </h4>
                     <p className="text-[#fafafa]">
                        We handle the deployment process and provide
                        comprehensive training to ensure your team can
                        effectively manage the application.
                     </p>
                  </div>
               </div>

               <div className="flex flex-col md:flex-row items-start gap-4">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#1463fd] flex items-center justify-center text-white font-bold">
                     5
                  </div>
                  <div>
                     <h4 className="text-lg font-semibold mb-2">
                        Maintenance & Support
                     </h4>
                     <p className="text-[#fafafa]">
                        We provide ongoing maintenance, support, and updates to
                        ensure your Laravel application continues to meet your
                        evolving business needs.
                     </p>
                  </div>
               </div>
            </div>
         </div>
         <div className="mt-16 text-center">
            <button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105">
               Start Your Laravel Project
            </button>
         </div>
      </div>
   );
};

export default LaravelDevProcess;
