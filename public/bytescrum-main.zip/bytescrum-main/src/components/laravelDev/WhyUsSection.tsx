import React from "react";
import SectionTitle from "../SectionTitle";

const WhyUsSection = ({ data }: any) => {
  const section = data;
  return (
    <div className="px-5  md:px-[40px] pb-[60px]   md:py-[80px] gap-[40px] bg-[#000000] relative z-50 w-full">
      <div className=" m-auto">
        <div className=" overflow-hidden">
          <SectionTitle
            animationVariant="fadeUp"
            className="section-title text-center"
          >
            {section.sectionTitle}
          </SectionTitle>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <div className="bg-gradient-to-br from-black to-[#2a2a2a]/50 p-6 rounded-lg border border-[#262626]">
            <div className="w-12 h-12 bg-[#2a2a2a] rounded-lg flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-[#fff]"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>
            <h4 className="text-lg font-semibold mb-2">
              {section.featureOne.title}
            </h4>
            <p className="text-[#fafafa] text-sm">
              {section.featureOne.description}
            </p>
          </div>

          <div className="bg-gradient-to-br from-black to-[#2a2a2a]/50 p-6 rounded-lg border border-[#262626]">
            <div className="w-12 h-12 bg-[#2a2a2a] rounded-lg flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-[#fff]"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                />
              </svg>
            </div>
            <h4 className="text-lg font-semibold mb-2">
              {section.featureTwo.title}
            </h4>
            <p className="text-[#fafafa] text-sm">
              {section.featureTwo.description}
            </p>
          </div>

          <div className="bg-gradient-to-br from-black to-[#2a2a2a]/50 p-6 rounded-lg border border-[#262626]">
            <div className="w-12 h-12 bg-[#2a2a2a] rounded-lg flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-[#fff]"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M13 10V3L4 14h7v7l9-11h-7z"
                />
              </svg>
            </div>
            <h4 className="text-lg font-semibold mb-2">
              {section.featureThree.title}{" "}
            </h4>
            <p className="text-[#fafafa] text-sm">
             {section.featureThree.description}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WhyUsSection;
