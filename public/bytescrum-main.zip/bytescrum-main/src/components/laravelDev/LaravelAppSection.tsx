import React from "react";
import SectionTitle from "../SectionTitle";
import Text from "../Text";

const LaravelAppSection = ({ data }: any) => {
  const section = data;
  return (
    <div className="px-5 md:px-[40px] pb-[60px]   md:pb-[60px] gap-[40px] bg-[#000000] relative z-50 w-full">
      <div className=" ">
        <div className=" overflow-hidden space-y-4">
          <SectionTitle className="max-w-2xl m-auto  ">
            {section.title}{" "}
          </SectionTitle>
          <Text className=" text-center lg:max-w-5xl m-auto">
            {section.subtitle}
          </Text>
        </div>
        <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-8 mt-12">
          <div className="service-card bg-gradient-to-br from-black to-pink-950/20">
            <div className="w-12 h-12 bg-pink-500/20 rounded-lg flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-pink-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"
                />
              </svg>
            </div>
            <h4 className="text-xl font-semibold mb-3">
              {section.serviceOne.title}
            </h4>
            <p className="text-[#fafafa]">{section.serviceOne.description}</p>
          </div>

          <div className="service-card bg-gradient-to-br from-black to-blue-950/20">
            <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-blue-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4"
                />
              </svg>
            </div>
            <h4 className="text-xl font-semibold mb-3">
              {" "}
              {section.serviceTwo.title}
            </h4>
            <p className="text-[#fafafa]">{section.serviceTwo.description}</p>
          </div>

          <div className="service-card bg-gradient-to-br from-black to-purple-950/20">
            <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-purple-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                />
              </svg>
            </div>
            <h4 className="text-xl font-semibold mb-3">
              {" "}
              {section.serviceThree.title}
            </h4>
            <p className="text-[#fafafa]">{section.serviceThree.description}</p>
          </div>

          <div className="service-card bg-gradient-to-br from-black to-amber-950/20">
            <div className="w-12 h-12 bg-amber-500/20 rounded-lg flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-amber-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                />
              </svg>
            </div>
            <h4 className="text-xl font-semibold mb-3">
              {" "}
              {section.serviceFour.title}
            </h4>
            <p className="text-[#fafafa]">{section.serviceFour.description}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LaravelAppSection;
