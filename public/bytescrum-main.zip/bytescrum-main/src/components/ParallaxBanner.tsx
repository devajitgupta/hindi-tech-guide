// "use client";

// import clsx from "clsx";
// import { twMerge } from "tailwind-merge";
// import Connect from "./connectSection/Connect";
// import { ReactNode, useRef } from "react";
// import { motion, useScroll, useTransform, useSpring } from "framer-motion";
// import useBreakpoints from "@/common/hooks/useBreakpoints ";

// interface IProps {
//    desktopBgImage?: string;
//    mobileBgImage?: string;
//    sectionStyle?: string;
//    className?: string;
//    children?: ReactNode;
// }

// const ParallaxBanner = ({
//    desktopBgImage = "/aboutUs/banner_two.png",
//    mobileBgImage = "/aboutUs/banner_two_mobile.png",
//    sectionStyle,
//    className,
//    children,
// }: IProps) => {
//    const { screenWidth } = useBreakpoints();
//    const matches = screenWidth <= 1024;
//    const desktopRef = useRef(null);
//    const mobileRef = useRef(null);

//    const { scrollYProgress: desktopScrollYProgress } = useScroll({
//       target: desktopRef,
//       offset: ["start end", "end start"],
//    });

//    const { scrollYProgress: mobileScrollYProgress } = useScroll({
//       target: mobileRef,
//       offset: ["start end", "end start"],
//    });

//    const smoothDesktopScrollYProgress = useSpring(desktopScrollYProgress, {
//       damping: 30,
//       stiffness: 350,
//       mass: 0.5,
//    });

//    const smoothMobileScrollYProgress = useSpring(mobileScrollYProgress, {
//       damping: 30,
//       stiffness: 350,
//       mass: 0.5,
//    });

//    const desktopY = useTransform(
//       smoothDesktopScrollYProgress,
//       [0, 1],
//       ["-10%", "75%"]
//    );
//    const mobileY = useTransform(
//       smoothMobileScrollYProgress,
//       [0, 1],
//       ["0%", "60%"]
//    );

//    return (
//       <section className={twMerge(clsx(className))}>
//          {/* NOTE: For DeskTop */}
//          <div
//             className={clsx(
//                "w-full h-[519px] bg-fixed rounded-xl bg-cover bg-no-repeat bg-center lg:block hidden    ",
//                sectionStyle
//             )}
//             style={{ backgroundImage: `url(${desktopBgImage})` }}
//          >
//             <div
//                className="bg-black/60 h-full scroll-smooth overflow-hidden"
//                ref={desktopRef}
//             >
//                {!children && (
//                   <motion.div
//                      className=" grid place-items-center max-h-[75vh]"
//                      style={{ y: desktopY }}
//                   >
//                      <Connect
//                         isParallaxVarient={true}
//                         className="bg-transparent border-none p-5 "
//                         animation={false}
//                      />
//                   </motion.div>
//                )}
//                {children}
//             </div>
//          </div>
//          {/* NOTE: For Mobile */}

//          <div
//             className={clsx(
//                "w-full h-[519px] bg-fixed rounded-xl bg-cover bg-no-repeat bg-center lg:hidden",
//                sectionStyle
//             )}
//             style={{ backgroundImage: `url(${mobileBgImage})` }}
//          >
//             {!children && (
//                <div
//                   className="bg-black/60 h-full scroll-smooth overflow-hidden"
//                   ref={mobileRef}
//                >
//                   <motion.div
//                      className=" grid place-items-center "
//                      style={{ y: mobileY }}
//                   >
//                      <Connect
//                         isParallaxVarient={true}
//                         className="bg-transparent border-none p-5 "
//                         animation={false}
//                      />
//                   </motion.div>
//                </div>
//             )}
//             {children}
//          </div>
//       </section>
//    );
// };

// export default ParallaxBanner;

"use client";

import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import { ReactNode, useRef } from "react";
import { motion, useScroll, useTransform, useSpring } from "framer-motion";
// import useBreakpoints from "@/common/hooks/useBreakpoints";
import Connect from "./connectSection/Connect";
import useBreakpoints from "@/common/hooks/useBreakpoints ";

interface IProps {
  sData:any;
  href: string;
  buttonText?: string;
  onButtonClick?: () => void;
  desktopBgImage?: string;
  mobileBgImage?: string;
  sectionStyle?: string;
  className?: string;
  contantClass?: string;
  children?: ReactNode;
}

const ParallaxBanner = ({
  buttonText,
  href,
  sData,
  onButtonClick,
  desktopBgImage = "/aboutUs/banner_two.png",
  mobileBgImage = "/aboutUs/banner_two_mobile.png",
  sectionStyle,
  className,
  children,
  contantClass,
}: IProps) => {
  const { screenWidth } = useBreakpoints();
  const desktopRef = useRef(null);
  const mobileRef = useRef(null);

  const { scrollYProgress: desktopScrollYProgress } = useScroll({
    target: desktopRef,
    offset: ["start end", "end start"],
  });

  const { scrollYProgress: mobileScrollYProgress } = useScroll({
    target: mobileRef,
    offset: ["start end", "end start"],
  });

  const smoothDesktopScrollYProgress = useSpring(desktopScrollYProgress, {
    damping: 30,
    stiffness: 350,
    mass: 0.5,
  });

  const smoothMobileScrollYProgress = useSpring(mobileScrollYProgress, {
    damping: 30,
    stiffness: 350,
    mass: 0.5,
  });

  const desktopY = useTransform(
    smoothDesktopScrollYProgress,
    [0, 1],
    ["-10%", "75%"]
    // ["-10%", "100%"]
  );
  const mobileY = useTransform(
    smoothMobileScrollYProgress,
    [0, 1],
    ["0%", "60%"]
  );
  console.log(desktopBgImage);
  return (
    <section className={twMerge(clsx(className))}>
      {/* Desktop view */}
      <div
        className={twMerge(
          clsx(
            "w-full h-[519px] bg-fixed rounded-xl bg-cover bg-no-repeat bg-center lg:block hidden",
            sectionStyle
          )
        )}
        style={{ backgroundImage: `url(${desktopBgImage})` }}
      >
        <div className="bg-black/60 h-full overflow-hidden" ref={desktopRef}>
          <motion.div
            className={twMerge(
              clsx(
                "grid items-center justify-center max-h-[75vh]",
                contantClass
              )
            )}
            style={{ y: desktopY }}
          >
            {children ? (
              children
            ) : (
              <Connect
                title={sData.securitySection.title}
                text={sData.securitySection.text}
                subTitle={sData.securitySection.subTitle}
                buttonText={sData.securitySection.buttonText}
                onButtonClick={onButtonClick}
                isParallaxVarient={true}
                className="bg-transparent border-none p-5"
                animation={false}
                href={href}
              />
            )}
          </motion.div>
        </div>
      </div>

      {/* Mobile view */}
      <div
        className={twMerge(
          clsx(
            "w-full h-[519px] bg-fixed rounded-xl bg-cover bg-no-repeat bg-center lg:hidden",
            sectionStyle
          )
        )}
        style={{ backgroundImage: `url(${mobileBgImage})` }}
      >
        <div className="bg-black/60 h-full overflow-hidden" ref={mobileRef}>
          <motion.div
            className="grid place-items-center"
            style={{ y: mobileY }}
          >
            {children ? (
              children
            ) : (
              <Connect
                title={sData.securitySection.title}
                subTitle={sData.securitySection.subTitle}
                text={sData.securitySection.text}
                buttonText={sData.securitySection.buttonText}
                onButtonClick={onButtonClick}
                isParallaxVarient={true}
                className="bg-transparent border-none  p-5"
                animation={false}
                href={href}
              />
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default ParallaxBanner;
