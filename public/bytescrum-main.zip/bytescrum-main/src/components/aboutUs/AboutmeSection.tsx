"use client";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import VerticleLineIcon from "../Icons/VerticleLineIcon";
import { useRef } from "react";
import { motion, useScroll, useTransform, useSpring } from "framer-motion";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import SectionTitle from "../SectionTitle";

interface IProps {
   className: string;
   langText?: any;
}

const AboutmeSection = ({ className, langText }: IProps) => {
   const ref = useRef(null);
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth <= 430;

   const { scrollYProgress } = useScroll({
      target: ref,
      offset: ["center end", "end start"],
   });

   const smoothScrollYProgress = useSpring(scrollYProgress, {
      damping: 20,
      stiffness: 100,
   });

   const titleY = useTransform(scrollYProgress, [0, 1], ["0%", "40%"]);
   const colY = useTransform(smoothScrollYProgress, [0, 1], ["20%", "-30%"]);
   return (
      <div className={twMerge(clsx(className, " mb-20"))}>
         <div
            className="grid lg:grid-cols-11 mt-10 md:mt-20 lg:mt-0 md:gap-10 items-center justify-center "
            ref={ref}
         >
            <motion.div
               className="m-auto   md:pe-40 lg:col-span-5"
               style={{ y: titleY }}
            >
               <div className="relative transition-all duration-[50s]">
                  <SectionTitle className="m-auto  group relative h-[174px] w-[174px]  md:h-[200px] md:w-[320px] flex md:justify-end items-center  transition-all duration-[50s] group-hover:transition-all group-hover:duration-[50s] rounded-[90px]">
                     {" "}
                     <span className="relative z-30 !text-start">
                        {langText.titleOne}
                     </span>
                     <span className=" transition-all duration-50 delay-300  absolute h-[124px] w-[124px] md:w-[200px] md:h-[200px] bg-[#262626] rounded-full flex justify-center items-center overflow-hidden transform rotate-0 group-hover:rotate-[160deg] -left-20 md:-left-[6px] group-hover:left-12 group-hover:md:left-[196px] shadow shadow-white ">
                        <span className="h-[14px] w-[144px] md:w-[200px] md:h-[24px] group-hover:bg-gradient-to-l  from-[#fff] absolute top-0  "></span>
                        <span className="h-[14px] w-[144px] md:w-[200px] md:h-[24px] group-hover:bg-gradient-to-r  from-[#fff] absolute bottom-0 "></span>
                        <span className="w-[195px] h-[195px] bg-[#000] rounded-full z-20"></span>
                     </span>
                  </SectionTitle>
               </div>
            </motion.div>
            <div className="overflow-hidden mt-16 lg:mt-0  lg:col-span-6">
               <motion.div
                  className=" space-y-5  "
                  style={!matches ? { y: colY } : {}}
               >
                  <SectionTitle className="group text-start flex justify-start items-center max-w-[346px] md:max-w-[712px] ">
                     {" "}
                     {langText.titleTwo}
                  </SectionTitle>
                  <p className="py-5 px-10 border border-[#1b1b1b] bg-[#090909] max-w-[620px] flex items-center rounded-[8px]">
                     <VerticleLineIcon />
                     <span className="inter text-[12px] md:text-[16px] lg:leading-[28px]  ps-5 flex  md:max-w-full ">
                        {langText.subTitle}
                     </span>
                  </p>
                  <div className="space-y-[30px] mt-[10px]">
                     {langText.text.map((para: any, index: number) => (
                        <p key={index}>{para}</p>
                     ))}
                  </div>
               </motion.div>
            </div>
         </div>
      </div>
   );
};

export default AboutmeSection;
