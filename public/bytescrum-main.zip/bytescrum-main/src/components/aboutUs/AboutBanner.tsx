"use client";

import clsx from "clsx";
import PageBanner from "../PageBanner";
import { usePathname } from "next/navigation";
import { twMerge } from "tailwind-merge";
import Image from "next/image";
import BannerElement from "./BannerElement";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import MobileBannerElement from "./MobileBannerElement";

type Props = {
   langText?: any;
};

const AboutBanner = ({ langText }: Props) => {
   
   const pathName = usePathname();
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth <= 430;
   return (
      <PageBanner
         bgPath={"/aboutUs/banner.png"}
         bannerHeight={"h-[32vh ] md:h-[55vh]"}
         className={twMerge(
            clsx(
               "relative overflow-hidden px-[22px] md:px-[54px]  items-center justify-normal "
            )
         )}
      >
         <div className="grid lg:grid-cols-2 gap-16 ">
            <div className="grid items-center md:gap-10">
               <div>
                  <p
                     className="poppins text-[#b7b7b7] text-[14px] md:text-[18px]"
                     data-aos="fade-up"
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     {langText.links.map((link:any, index:any) => (
                        <span
                           className={clsx(
                              " text-white first:border-r  first:pe-3 last:ps-3 cursor-pointer",
                              {
                                 "first:text-[#b7b7b7]":
                                    pathName !== `/${pathName}`,
                              }
                           )}
                           key={index}
                        >
                           {link}
                        </span>
                     ))}
                  </p>
                  <h1
                     className="text-[35px] md:text-[70px] md:leading-[80px] font-light  poppins text-start"
                     data-aos="fade-up"
                     data-aos-delay={300}
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     {langText.pageTitleLineOne}
                     <br />
                     <span className="font-bold">{langText.pageTitleLineTwo}</span>
                  </h1>
                  <p
                     className="max-w-[609px] mt-8 text-[16px] leading-[28px]"
                     data-aos="fade-up"
                     data-aos-delay={500}
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     {langText.bannerText}
                  </p>
               </div>
            </div>
            <div className="grid place-items-center lg:justify-end  m-auto w-[375px] h-[348px]  sm:min-w-[467px] sm:min-h-[448px]  relative">
               <Image
                  src={
                     matches
                        ? "/aboutUs/mobileBnnerImg.png"
                        : "/aboutUs/bannerImg.png"
                  }
                  width={matches ? 351 : 467}
                  height={matches ? 337 : 448}
                  alt="BannerImage"
                  data-aos="zoom-in-left"
                  data-aos-delay={300}
                  data-aos-easing="ease-out-cubic"
                  data-aos-anchor-placement="top-bottom"
               />

               <div className="absolute bottom-0 right-0 hidden  sm:block   ">
                  <BannerElement />
               </div>
               <div className="absolute  sm:hidden -bottom-8  right-[6px]">
                  <MobileBannerElement />
               </div>
            </div>
         </div>
      </PageBanner>
   );
};

export default AboutBanner;
