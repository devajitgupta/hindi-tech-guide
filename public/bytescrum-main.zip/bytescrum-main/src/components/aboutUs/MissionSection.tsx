"use client";
import { Accordion, AccordionItem } from "@nextui-org/react";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import "./aboutUs.css";
import data from "../../common/data/aboutData.json";
import SectionTitle from "../SectionTitle";
import SectionSubtitle from "../SectionSubtitle";
interface IProps {
   className: string;
   langText: any;
}

const MissionSection = ({ className, langText }: IProps) => {
   return (
      <div className={twMerge(clsx(className))}>
         <div className="space-y-[60px]">
            <div className="   space-y-[10px] overflow-hidden">
               <SectionTitle> {langText.title}</SectionTitle>
               <SectionSubtitle className="m-auto">
                  Our mission is to deliver innovative solutions that transform
                  businesses and exceed client expectations through cutting-edge
                  technology and exceptional service.
               </SectionSubtitle>
            </div>
            <div className="m-auto w-11/12 md:w-9/12 lg:w-7/12 ">
               <Accordion
                  variant="splitted"
                  fullWidth={true}
                  defaultExpandedKeys={[1]}
                  itemClasses={{
                     base: "border border-[#262626] !bg-[#0a0a0a] px-5 rounded-lg ",
                  }}
               >
                  {langText.accordions.map((accordion: any, index: any) => (
                     <AccordionItem
                        key={accordion._id}
                        aria-label={accordion.title}
                        title={accordion.title}
                        indicator={({ isOpen }) => (
                           <label className="container group rotate-90">
                              <input
                                 type="checkbox"
                                 checked={isOpen}
                                 readOnly
                              />
                              <div className="line"></div>
                              <div className="line line-indicator"></div>
                           </label>
                        )}
                        classNames={{
                           content: " px-3  flex justify-between  ",
                           heading: " relative  flex justify-between  ",
                           title: "poppins text-[18px] font-bold text-[#ffffff] ",
                           indicator: "text-[#ffffff] absolute  right-0",
                        }}
                        data-aos="fade-up"
                        data-aos-easing="ease-out-cubic"
                        data-aos-delay={index * 150}
                        data-aos-anchor-placement="top-bottom"
                     >
                        {accordion.text}
                     </AccordionItem>
                  ))}
               </Accordion>
            </div>
         </div>
      </div>
   );
};

export default MissionSection;
