import useBreakpoints from "@/common/hooks/useBreakpoints ";
import React from "react";

const MobileBannerElement = () => {
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth <= 360;
   return (
      <svg
         width={matches ? "388" : "388"}
         height={matches ? "227" : "277"}
         viewBox="0 0 388 227"
         fill="none"
         xmlns="http://www.w3.org/2000/svg"
      >
         <path
            d="M311.154 63.0352H349.578C370.798 63.0352 388.001 80.2379 388.001 101.458C388.001 122.679 370.798 139.882 349.578 139.882H311.154V63.0352Z"
            fill="url(#paint0_linear_490_72)"
            data-aos="zoom-in-right"
            data-aos-delay={500}
            data-aos-easing="ease-out-cubic"
            data-aos-anchor-placement="top-bottom"
         />
         <path
            d="M181.383 184.522L217.732 148.922V226.522H139.379L181.383 184.522Z"
            fill="url(#paint1_linear_490_72)"
            data-aos="zoom-out-up"
            data-aos-delay={700}
            data-aos-easing="ease-out-cubic"
            data-aos-anchor-placement="top-bottom"
         />
         <path
            opacity="0.25"
            d="M175.542 190.359L139.379 226.522V148.922H217.732L175.542 190.359Z"
            fill="#88CBFF"
            data-aos="zoom-in-down"
            data-aos-delay={700}
            data-aos-easing="ease-out-cubic"
            data-aos-anchor-placement="top-bottom"
         />
         <path
            opacity="0.25"
            d="M311.154 226.522C311.154 184.081 345.56 148.922 388.001 148.922V226.522H311.154Z"
            fill="#04D7FF"
            data-aos="zoom-in-left"
            data-aos-delay={1000}
            data-aos-easing="ease-out-cubic"
            data-aos-anchor-placement="top-bottom"
         />
         <g style={{ mixBlendMode: "hard-light" }} opacity="0.5">
            <path
               d="M76.8457 0.503006C76.8457 42.9442 42.4403 77.3496 -0.000900269 77.3496V0.503006H76.8457Z"
               fill="#04D7FF"
               data-aos="zoom-out-up"
               data-aos-delay={1300}
               data-aos-easing="ease-out-cubic"
               data-aos-anchor-placement="top-bottom"
            />
         </g>
         <defs>
            <linearGradient
               id="paint0_linear_490_72"
               x1="364.792"
               y1="63.0352"
               x2="400.849"
               y2="190.083"
               gradientUnits="userSpaceOnUse"
            >
               <stop stopColor="#2363E1" />
               <stop offset="0.502725" stopColor="#6E94DD" />
               <stop offset="1" stopColor="#2363E1" />
            </linearGradient>
            <linearGradient
               id="paint1_linear_490_72"
               x1="194.069"
               y1="148.922"
               x2="230.181"
               y2="277.398"
               gradientUnits="userSpaceOnUse"
            >
               <stop stopColor="#2363E1" />
               <stop offset="0.502725" stopColor="#6E94DD" />
               <stop offset="1" stopColor="#2363E1" />
            </linearGradient>
         </defs>
      </svg>
   );
};

export default MobileBannerElement;
