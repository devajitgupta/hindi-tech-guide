import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import { StatsCountUp } from "../home";
import homeData from "../../common/data/homeData.json";
import aboutData from "../../common/data/aboutData.json";
import SectionSubtitle from "../SectionSubtitle";
import SectionTitle from "../SectionTitle";

interface IProps {
   className: string;
   langText?: any;
   langTextStartUpcount?: any;
}

const FunSection = ({ className, langText, langTextStartUpcount }: IProps) => {
   return (
      <section className={twMerge(clsx(className))}>
         <div
            className=" grid lg:grid-cols-2 border items-center  border-[#262626] bg-[#090909] px-[30px] py-[40px] md:p-[60px] rounded-[16px] gap-y-20"
            data-aos="zoom-in-up"
            data-aos-easing="ease-out-cubic"
            data-aos-anchor-placement="top-bottom"
         >
            <div className="space-y-[20px]">
               <SectionTitle className="text-start">
                  <span className="text-[#a4a4a4]"> {langText.titleOne} </span>
                  {langText.titleTwo}
               </SectionTitle>
               <SectionSubtitle className="text-start" textSize="sm">
                  {langText.text}
               </SectionSubtitle>
            </div>
            <StatsCountUp
               className="xl:grid-cols-2 p-0  gap-0"
               countUpClass="text-start text-[20px] md:text-[45px]  poppins font-semibold leading-[25px] mb-[10px]"
               textClass="text-start text-[14px] md:ext-[25px] inter leading-[24px] md:leading-[25px]"
               symbolClass="text-[14px] md:text-[35px]"
               wrapper="p-0 mt-5 md:mt-0"
               langText={langTextStartUpcount}
            />
         </div>
      </section>
   );
};

export default FunSection;
