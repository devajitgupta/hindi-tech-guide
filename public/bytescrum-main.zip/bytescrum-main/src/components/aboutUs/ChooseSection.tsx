"use client";

import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import {
   ExperiencedIcon,
   ClientApproachIcon,
   Innovation,
   SalutionIcon,
} from "../Icons";
import { useRef } from "react";
import { motion, useScroll, useTransform, useSpring } from "framer-motion";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import { TLocale } from "@/i18n-config";

interface IProps {
   className: string;
}

interface Iprops {
   langText: any;
   className?: string;
   lang: TLocale;
}

const ChooseSection = ({ langText, lang, className }: Iprops) => {
      const data = langText.chooseSection;
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth <= 1024;
   const tablet = screenWidth >= 567 && screenWidth <= 1024;
   const ref = useRef(null);
   const { scrollYProgress } = useScroll({
      target: ref,
      offset: ["start end", "center start"],
   });

   const smoothScrollYProgress = useSpring(scrollYProgress, {
      damping: 30,
      stiffness: 150,
   });

   const titleY = useTransform(
      scrollYProgress,
      [0, 1],
      tablet ? ["200%", "-400%"] : ["-20%", "200%"]
   );

   const colOneY = useTransform(
      smoothScrollYProgress,
      [0, 1],
      matches ? ["0%", "0%"] : ["50%", "-50%"]
   );
   const colTwoY = useTransform(
      smoothScrollYProgress,
      [0, 1],
      matches ? ["0%", "0%"] : ["-50%", "50%"]
   );

   function getIconById(id: any) {
      switch (id) {
         case 1:
            return <ExperiencedIcon />;
         case 2:
            return <Innovation />;
         case 3:
            return <ClientApproachIcon />;
         case 4:
            return <SalutionIcon varient="rightSide" />;
         default:
            return null;
      }
   }

   return (
      <section className={twMerge(clsx(className, "pt-20 mb-20"))}>
         <div className=" scroll-smooth" ref={ref}>
            <motion.h2
               className="poppins absolute text-[#fff]   z-20 py-10 text-[24px] md:text-[45px] leading-[30px] md:leading-[60px] indicator scroll-smooth mb-10 lg:mb-0 bg-black xl:bg-transparent w-[90%] lg:w-fit"
               style={!matches ? { y: titleY } : {}}
            >
               {data.titleOne} <br />
               {data.titleTwo}
            </motion.h2>
            <div className=" overflow-hidden  pt-20  md:overflow-visible">
               <motion.div className="grid lg:grid-cols-5  gap-x-10">
                  <span className="hidden lg:block ">
                     {/* NOTE: Don't remove this. It's left-side  Empty Area */}
                  </span>
                  <div className="col-span-full xl:col-span-4 mt-36 md:mt-56 m-auto xl:mt-0  grid md:grid-cols-2 items-center lg:m-0 justify-end w-fit lg:ml-auto gap-10 md:gap-10 ">
                     {data.chooseCard.map((item: any, index: number) => (
                        <motion.div
                           className="space-y-[10px]   grid xl:odd:pl-20 xl:odd:mt-16 xl:even:mb-16 xl:even:justify-end scroll-smooth"
                           key={index}
                           style={
                              index === 0 || index === 2
                                 ? { y: colOneY }
                                 : { y: colTwoY }
                           }
                        >
                           {getIconById(item._Id)}
                           <h3 className=" poppins text-[16px] md:text-[20px] max-w-[265px]  font-bold">
                              {item.title}
                           </h3>
                           <p className="md:max-w-[359px] text-[14px] md:text-[16px] leading-[24px]  md:leading-[28px] text-[#f5f5f5]">
                              {item.text}
                           </p>
                        </motion.div>
                     ))}
                  </div>
               </motion.div>
            </div>
         </div>
      </section>
   );
};

export default ChooseSection;
