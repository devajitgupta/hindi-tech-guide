"use client";

import useBreakpoints from "@/common/hooks/useBreakpoints ";
import clsx from "clsx";
import Image from "next/image";
import { twMerge } from "tailwind-merge";
import aboutData from "../../common/data/aboutData.json";
import SectionTitle from "../SectionTitle";
import SectionSubtitle from "../SectionSubtitle";

interface IProps {
   className: string;
}

const ValueSection = ({ className }: IProps) => {
   const data = aboutData.valueSection;
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth <= 430;

   return (
      <div className={twMerge(clsx(className))}>
         <div className="md:px-[55px] space-y-[60px]">
            <div className="   space-y-[10px] overflow-hidden">
               <SectionTitle> {data.title}</SectionTitle>

               <SectionSubtitle className="m-auto">
                  {" "}
                  {data.subTitle}
               </SectionSubtitle>
            </div>
            <div className="grid lg:grid-cols-2 items-center justify-center lg:gap-[18px] gap-y-[74px]  ">
               <div className="space-y-[110px] ps-8 order-2 lg:order-1">
                  {data.valueCard.map((item: any, index) => (
                     <div key={index}>
                        <h3 className="text-[18px] md:text-[20px] font-bold poppins relative ">
                           <span
                              className="relative z-30 block"
                              data-aos="fade-left"
                              data-aos-easing="ease-out-cubic"
                              data-aos-delay={index * 100}
                              data-aos-anchor-placement="top-bottom"
                           >
                              {item.title}
                           </span>
                           <span
                              className="absolute text-[70px] font-bold leading-[72px] -z-0 text-[#141414] -top-8 -left-8"
                              data-aos="fade-right"
                              data-aos-easing="ease-out-cubic"
                              data-aos-delay={index * 150}
                              data-aos-anchor-placement="top-bottom"
                           >
                              {item._Id <= 9 ? `0${item._Id}` : item._Id}
                           </span>
                        </h3>
                        <p
                           className="max-w-[415px] text-[14] md:text-[16px] leadding-[24px] md:leadding-[28px] text-[#f5f5f5]"
                           data-aos="fade-left"
                           data-aos-easing="ease-out-cubic"
                           data-aos-delay={index * 200}
                           data-aos-anchor-placement="top-bottom"
                        >
                           {item.text}
                        </p>
                     </div>
                  ))}
               </div>

               <div
                  className={clsx(
                     "relative  max-w-[679px]  order-1 lg:order-2"
                  )}
               >
                  <Image
                     src={matches ? data.mobileImg : data.deskTopImg}
                     width={matches ? 390 : 679}
                     height={matches ? 311 : 543}
                     alt="Value Img"
                     data-aos={matches ? "zoom-in-up" : "zoom-in-left"}
                     data-aos-easing="ease-out-cubic"
                     data-aos-delay={matches ? 0 : 150}
                     data-aos-anchor-placement="top-bottom"
                  />
               </div>
            </div>
         </div>
      </div>
   );
};

export default ValueSection;
