import useBreakpoints from "@/common/hooks/useBreakpoints ";

const BannerElement = () => {
   return (
      <svg
         width="515"
         height="300"
         viewBox="0 0 515 300"
         fill="none"
         xmlns="http://www.w3.org/2000/svg"
      >
         <path
            d="M413 83H464C492.167 83 515 105.833 515 134C515 162.167 492.167 185 464 185H413V83Z"
            fill="url(#paint0_linear_364_1261)"
            data-aos="zoom-in-right"
            data-aos-delay={500}
            data-aos-easing="ease-out-cubic"
            data-aos-anchor-placement="top-bottom"
         />
         <path
            d="M240.753 244.253L289 197V300H185L240.753 244.253Z"
            fill="url(#paint1_linear_364_1261)"
            data-aos="zoom-out-up"
            data-aos-delay={700}
            data-aos-easing="ease-out-cubic"
            data-aos-anchor-placement="top-bottom"
         />
         <path
            opacity="0.25"
            d="M233 252L185 300V197H289L233 252Z"
            fill="#88CBFF"
            data-aos="zoom-in-down"
            data-aos-delay={700}
            data-aos-easing="ease-out-cubic"
            data-aos-anchor-placement="top-bottom"
         />
         <path
            opacity="0.25"
            d="M413 300C413 243.667 458.667 197 515 197V300H413Z"
            fill="#04D7FF"
            data-aos="zoom-in-left"
            data-aos-delay={1000}
            data-aos-easing="ease-out-cubic"
            data-aos-anchor-placement="top-bottom"
         />
         <g style={{ mixBlendMode: "hard-light" }} opacity="0.5">
            {" "}
            <path
               d="M102 0C102 56.333 56.333 102 0 102V0H102Z"
               fill="#04D7FF"
               data-aos="zoom-out-up"
               data-aos-delay={1300}
               data-aos-easing="ease-out-cubic"
               data-aos-anchor-placement="top-bottom"
            />
         </g>
         <defs>
            <linearGradient
               id="paint0_linear_364_1261"
               x1="484.195"
               y1="83"
               x2="532.054"
               y2="251.633"
               gradientUnits="userSpaceOnUse"
            >
               <stop stopColor="#2363E1" />
               <stop offset="0.502725" stopColor="#6E94DD" />
               <stop offset="1" stopColor="#2363E1" />
            </linearGradient>
            <linearGradient
               id="paint1_linear_364_1261"
               x1="257.591"
               y1="197"
               x2="305.523"
               y2="367.529"
               gradientUnits="userSpaceOnUse"
            >
               <stop stopColor="#2363E1" />
               <stop offset="0.502725" stopColor="#6E94DD" />
               <stop offset="1" stopColor="#2363E1" />
            </linearGradient>
         </defs>
      </svg>
   );
};

export default BannerElement;
