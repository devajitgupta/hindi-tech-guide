"use client";

import { i18n, TLocale } from "@/i18n-config";
import { useRouter, usePathname } from "next/navigation";
import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/libs/cn";

interface LanguageSwitcherProps {
   currentLang: TLocale;
   className?: string;
   onClick?: (lang: TLocale) => void; // <-- Added prop
}

export default function LanguageSwitcher({
   currentLang,
   className,
   onClick,
}: LanguageSwitcherProps) {
   const router = useRouter();
   const pathname = usePathname();
   const [isOpen, setIsOpen] = useState(false);
   const dropdownRef = useRef<HTMLDivElement>(null);

   const handleLanguageChange = (newLang: TLocale) => {
      if (newLang === currentLang) return;

      // Remove leading/trailing slashes and split into segments
      const pathWithoutSlashes = pathname.replace(/^\/|\/$/g, "");
      const segments = pathWithoutSlashes.split("/");

      // Check if the first segment is a valid locale
      const isFirstSegmentLocale = i18n.locales.includes(
         segments[0] as TLocale
      );

      let newSegments: string[];

      if (isFirstSegmentLocale) {
         // Replace the existing locale
         newSegments = [newLang, ...segments.slice(1)];
      } else {
         // Add new locale at the beginning
         newSegments =
            newLang === i18n.defaultLocale ? segments : [newLang, ...segments];
      }

      const newPath = `/${newSegments.join("/")}`;
      router.push(newPath || "/");
      setIsOpen(false);

      // Call onClick if provided
      if (onClick) onClick(newLang);
   };

   const langLabels: Record<TLocale, string> = {
      en: "EN",
      es: "ES",
      nl: "NL",
      fr: "FR",
   };

   useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
         if (
            dropdownRef.current &&
            !dropdownRef.current.contains(event.target as Node)
         ) {
            setIsOpen(false);
         }
      };

      document.addEventListener("mousedown", handleClickOutside);
      return () =>
         document.removeEventListener("mousedown", handleClickOutside);
   }, []);

   return (
      <div
         ref={dropdownRef}
         className={`relative ${className}`}
         onMouseEnter={() => setIsOpen(true)}
         onMouseLeave={() => setIsOpen(false)}
      >
         <AnimatePresence>
            {isOpen && (
               <motion.div
                  initial={{ opacity: 0, y: -5, rotate: 45 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  className="absolute h-3 w-3 bg-[#0d0d0d] left-[1.4rem] rotate-45 top-[2rem] !z-[9999999999] border-white/20 border-l border-t"
               ></motion.div>
            )}
         </AnimatePresence>

         <button
            className={cn(
               "flex items-center justify-between w-full appearance-none text-start ps-3 pe-6 py-[6px] text-sm rounded-md hover:bg-[#0d0d0d] backdrop-blur-3xl text-white border border-white/20 focus:outline-none cursor-pointer transition-colors",
               { "bg-[#0d0d0d]": isOpen }
            )}
            onClick={() => setIsOpen(!isOpen)}
            aria-haspopup="true"
            aria-expanded={isOpen}
         >
            {langLabels[currentLang]}
            <div
               className={`absolute top-1/2 -translate-y-1/2 right-2 w-0 h-0 border-l-[4px] border-l-transparent border-r-[4px] border-r-transparent transition-transform duration-200 ${
                  isOpen
                     ? "border-t-[9px] border-t-white -rotate-180"
                     : "border-t-[9px] border-t-white"
               }`}
            />
         </button>

         <AnimatePresence>
            {isOpen && (
               <motion.div
                  key="dropdown-menu"
                  initial={{ opacity: 0, y: -10, height: 0 }}
                  animate={{ opacity: 1, y: 0, height: "auto" }}
                  exit={{ opacity: 0, y: -10, height: 0 }}
                  transition={{ duration: 0.2 }}
                  className="absolute z-10 w-full mt-1 rounded-md shadow-lg bg-[#0d0d0d] border border-white/20 overflow-hidden"
               >
                  <div className="py-1">
                     {i18n.locales.map((lang) => (
                        <button
                           key={lang}
                           onClick={() => handleLanguageChange(lang as TLocale)}
                           className={`block w-full text-start px-4 py-2 text-sm hover:bg-white/20 ${
                              lang === currentLang
                                 ? "text-white font-medium"
                                 : "text-white/70"
                           }`}
                        >
                           {langLabels[lang as TLocale]}
                        </button>
                     ))}
                  </div>
               </motion.div>
            )}
         </AnimatePresence>
      </div>
   );
}
