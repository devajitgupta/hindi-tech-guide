"use client";
import { ReactNode, useEffect } from "react";
import {
  Modal,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  useDisclosure,
  Divider,
  Button,
  cn,
} from "@nextui-org/react";
import Confetti from "react-confetti";
import { Icon } from "@iconify/react/dist/iconify.js";

type Size =
  | "sm"
  | "md"
  | "lg"
  | "xs"
  | "xl"
  | "2xl"
  | "3xl"
  | "4xl"
  | "5xl"
  | "full"
  | undefined;

type Props = {
  open: boolean;
  onClose: () => void;
  title?: string;
  color?: string;
  headerClass?: string;
  titleIcon?: string;
  children: ReactNode;
  footer?: ReactNode;
  size?: Size;
  isDismissable?: boolean;
  isKeyboardDismissDisabled?: boolean;
  showConfetti?: boolean;
  modalType?: "success" | "warning" | "error"; // Add this prop to control confetti
};

const NextUIModal = ({
  open,
  onClose: handleClose,
  title,
  titleIcon,
  children,
  headerClass,
  color = "transparent",
  footer,
  size = "lg",
  isDismissable = false,
  isKeyboardDismissDisabled = false,
  showConfetti = false,
  modalType = "success", // Default to success
}: Props) => {
  const { isOpen, onOpen, onOpenChange, onClose } = useDisclosure();

  useEffect(() => {
    if (open) {
      onOpen();
    } else {
      onClose();
    }
  }, [open]);

  // Determine icon color based on modal type
  const getIconColor = () => {
    switch (modalType) {
      case "success":
        return "text-green-500";
      case "warning":
        return "text-yellow-500";
      case "error":
        return "text-red-500";
      default:
        return "text-green-500";
    }
  };

  return (
    <Modal
      backdrop="blur"
      isOpen={isOpen}
      onOpenChange={() => {
        onOpenChange();
        handleClose();
      }}
      motionProps={{
        variants: {
          enter: {
            y: 0,
            opacity: 1,
            transition: {
              duration: 0.3,
              ease: "easeOut",
            },
          },
          exit: {
            y: -30,
            opacity: 0,
            transition: {
              duration: 0.2,
              ease: "easeIn",
            },
          },
        },
      }}
      placement="center"
      size={size}
      isDismissable={isDismissable}
      isKeyboardDismissDisabled={isKeyboardDismissDisabled}
      classNames={{
        wrapper: "z-[99999999]",
        closeButton: "hidden",
      }}
    >
      <ModalContent className="bg-transparent w-full h-full">
        {() => (
          <>
            {showConfetti && modalType === "success" && (
              <Confetti className="w-full h-full" />
            )}

            <div className=" w-11/12 sm:w-7/12 md:w-6/12 lg:w-5/12 grid place-items-center m-auto   py-10 border border-[#262626] rounded-2xl relative bg-[#000000]">
              <Button
                isIconOnly
                className=" absolute rounded top-5 right-5 bg-red-900/20 border border-red-500/30"
                onPress={handleClose}
              >
                <Icon
                  icon="line-md:close-small"
                  width="24"
                  height="24"
                  className="text-red-500"
                />
              </Button>
              <ModalHeader
                className={cn(
                  "text-center z-[2000] text-4xl md:text-5xl flex- flex-col items-center justify-center gap-1",
                  headerClass, // This will now properly override the default
                  getIconColor() // Apply the appropriate color based on modalType
                )}
              >
                {titleIcon && (
                  <Icon
                    icon={titleIcon ?? ""}
                    className={cn("text-4xl md:text-7xl ", getIconColor())}
                  />
                )}
                {title}
                <div
                  className={cn(
                    "h-0.5 mt-1 w-full bg-gradient-to-l from-transparent to-transparent"
                  )}
                ></div>
              </ModalHeader>
              <Divider />
              <ModalBody className="p-4 overflow-y-auto  z-[2000] ">
                {children}
              </ModalBody>
              {footer && <ModalFooter>{footer}</ModalFooter>}
            </div>
          </>
        )}
      </ModalContent>
    </Modal>
  );
};

export default NextUIModal;
