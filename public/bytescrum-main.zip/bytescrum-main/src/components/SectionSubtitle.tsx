import clsx from "clsx";
import React from "react";
import { twMerge } from "tailwind-merge";

interface IProps {
   className?: string;
   children: React.ReactNode;
   color?: string;
   variant?: "default" | "primary";
   animationVariant?:
      | "default"
      | "fadeRight"
      | "fadeLeft"
      | "fadeUp"
      | "fadeDown"
      | "zoomInUp";
   transform?: string;
   animationDelay?: string;
   animationDuration?: string;
   textSize?: "sm" | "md" | "lg" | "xl" | "xxl" | "xxxl";
}

const SectionSubtitle = ({
   className,
   children,
   color,
   variant = "default",
   animationVariant = "default",
   animationDelay = "0",
   animationDuration = "600",
   textSize = "md",
   transform,
}: IProps) => {
   const variantColors = {
      default: "#f5f5f5",
      primary: "#bcbcbc",
      secondary: "#000",
   };
   const aosVariants = {
      fadeRight: "fade-right",
      fadeLeft: "fade-left",
      fadeUp: "fade-up",
      fadeDown: "fade-down",
      zoomInUp: "zoom-in-up",
   };

   const textSizes = {
      sm: "text-[14px] md:text-[16px] leading-[24px] md:leading-[28px]",
      md: "text-[14px] md:text-[18px] leading-[18px] md:leading-[24px]",
      lg: "text-[16px] md:text-[20px] leading-[22px] md:leading-[28px]",
      xl: "text-[18px] md:text-[24px] leading-[28px] md:leading-[32px]",
      xxl: "text-[20px] md:text-[28px] leading-[32px] md:leading-[36px]",
      xxxl: "text-[22px] md:text-[32px] leading-[36px] md:leading-[42px]",
   };

   const appliedColor = color || variantColors[variant];
   const appliedAos =
      animationVariant !== "default" ? aosVariants[animationVariant] : null;

   const appliedTextSize = textSizes[textSize];

   return (
      <p
         className={twMerge(
            clsx(
               "max-w-[650px] text-center text-[14px] md:text-[18px] leading-[18px] md:leading-[24px] poppins ",
               className,
               appliedTextSize
            )
         )}
         style={{ color: appliedColor, transform: transform }}
         data-aos={appliedAos || undefined}
         data-aos-duration={animationDuration}
         data-aos-anchor-placement="top-bottom"
         data-aos-delay={animationDelay}
      >
         {children}
      </p>
   );
};

export default SectionSubtitle;
