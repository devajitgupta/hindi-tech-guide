import React from "react";

const TwitterIcon = () => {
   return (
      <svg
         xmlns="http://www.w3.org/2000/svg"
         width="40"
         height="41"
         viewBox="0 0 40 41"
         fill="none"
         className="transition-all duration-300 ease-in-out hover:text-black group"
      >
         <rect
            y="0.638672"
            width="39.1198"
            height="40"
            rx="19.5599"
            fill="#1A1A1A"
            className="transition-all duration-300 ease-in-out hover:fill-white"
         />
         <mask
            id="mask0_250_1297"
            // style="mask-type:luminance"
            maskUnits="userSpaceOnUse"
            x="12"
            y="12"
            width="16"
            height="17"
         >
            <path
               d="M27.6479 12.6387H12V28.6387H27.6479V12.6387Z"
               fill="white"
            />
         </mask>
         <g mask="url(#mask0_250_1297)">
            <path
               d="M21.3126 19.4101L27.1379 12.6387H25.7575L20.6994 18.5182L16.6595 12.6387H12L18.1091 21.5296L12 28.6305H13.3805L18.722 22.4215L22.9884 28.6305H27.6479L21.3123 19.4101H21.3126ZM19.4219 21.6079L18.8029 20.7226L13.8779 13.6779H15.9982L19.9728 19.3632L20.5918 20.2485L25.7582 27.6385H23.6378L19.4219 21.6082V21.6079Z"
               fill="#1A1A1A"
               className="transition-all duration-300 ease-in-out group-hover:fill-black fill-white"
            />
         </g>
      </svg>
   );
};

export default TwitterIcon;
