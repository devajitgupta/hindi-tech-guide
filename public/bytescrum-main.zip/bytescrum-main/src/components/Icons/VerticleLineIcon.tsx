import React from "react";

const VerticleLineIcon = () => {
   return (
      <svg
         xmlns="http://www.w3.org/2000/svg"
         width="4"
         height="53"
         viewBox="0 0 4 53"
         fill="none"
         className="animate-flip-down animate-infinite animate-duration-1000 animate-delay-[5000ms] animate-ease-in animate-normal animate-fill-both"
      >
         <path
            d="M2 2L2 51"
            stroke="url(#paint0_linear_438_2847)"
            strokeWidth="4"
            strokeLinecap="round"
         />
         <defs>
            <linearGradient
               id="paint0_linear_438_2847"
               x1="2"
               y1="26.5"
               x2="0.999999"
               y2="26.5"
               gradientUnits="userSpaceOnUse"
            >
               <stop stopColor="#0E7BDA" />
               <stop offset="1" stopColor="#04D7FF" />
            </linearGradient>
         </defs>
      </svg>
   );
};

export default VerticleLineIcon;
