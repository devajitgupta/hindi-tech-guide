import React from "react";

const FaceBookIcon = () => {
   return (
      <svg
         xmlns="http://www.w3.org/2000/svg"
         width="41"
         height="41"
         viewBox="0 0 41 41"
         fill="none"
         className="transition-all duration-300 ease-in-out hover:text-black group"
      >
         <rect
            x="0.119141"
            y="0.638672"
            width="40"
            height="40"
            rx="20"
            fill="#1A1A1A"
            className="transition-all duration-300 ease-in-out hover:fill-white"
         />
         <path
            d="M23.9476 21.5707L24.3883 18.6969H21.6311V16.832C21.6311 16.0458 22.0162 15.2795 23.2512 15.2795H24.5049V12.8329C24.5049 12.8329 23.3671 12.6387 22.2794 12.6387C20.0085 12.6387 18.5243 14.015 18.5243 16.5066V18.6969H16V21.5707H18.5243V28.5179C19.0304 28.5973 19.5492 28.6387 20.0777 28.6387C20.6062 28.6387 21.1249 28.5973 21.6311 28.5179V21.5707H23.9476Z"
            fill="none"
            className="transition-all duration-300 ease-in-out group-hover:fill-black fill-white"
         />
      </svg>
   );
};

export default FaceBookIcon;
