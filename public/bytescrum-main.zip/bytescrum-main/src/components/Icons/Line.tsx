import clsx from "clsx";
import { motion } from "framer-motion";
import { twMerge } from "tailwind-merge";
import { useEffect } from "react";

interface IProps {
   className?: string;
   trigger?: any; // Used to re-trigger animation when tab changes
}

const lineVariant = {
   hidden: { pathLength: 0 },
   visible: { pathLength: 1, transition: { duration: 0.8, ease: "easeInOut" } },
};

const Line = ({ className, trigger }: IProps) => {
   return (
      <motion.svg
         key={trigger} // This forces re-render on tab change
         width="330"
         height="2"
         viewBox="0 0 330 2"
         fill="none"
         xmlns="http://www.w3.org/2000/svg"
         className={twMerge(clsx(className))}
      >
         <motion.line
            y1="1"
            x2="330"
            y2="1"
            stroke="#1463fd"
            strokeWidth="2"
            variants={lineVariant}
            initial="hidden"
            animate="visible"
         />
      </motion.svg>
   );
};

export default Line;
