"use client";

import { useRef } from "react";
import { motion } from "framer-motion";

export default function AIBanner() {
   const containerRef = useRef<HTMLDivElement>(null);

   return (
      <div className="absolute inset-0 z-0 overflow-hidden bg-black">
         {/* AI Neural Grid */}
         <div className="absolute inset-0 perspective-1000">
            {/* Animated Neural Matrix Grid */}
            <div className="absolute inset-0 grid grid-cols-6 grid-rows-6 opacity-20">
               {Array.from({ length: 36 }).map((_, index) => (
                  <motion.div
                     key={`grid-${index}`}
                     className="border border-purple-700/20 relative"
                     initial={{ opacity: 0 }}
                     animate={{
                        opacity: [0, 0.4, 0],
                        backgroundColor: [
                           "rgba(147, 51, 234, 0)",
                           "rgba(147, 51, 234, 0.07)",
                           "rgba(147, 51, 234, 0)",
                        ],
                     }}
                     transition={{
                        duration: Math.random() * 5 + 5,
                        delay: Math.random() * 5,
                        repeat: Infinity,
                        repeatType: "loop",
                     }}
                  />
               ))}
            </div>

            {/* Floating AI Nodes (Blocks with Digital Signatures) */}
            {Array.from({ length: 15 }).map((_, index) => {
               const size = Math.random() * 80 + 40;
               const depth = Math.random() * 500 - 250;

               return (
                  <motion.div
                     key={`node-${index}`}
                     className="absolute rounded-lg border border-fuchsia-500/30 bg-gradient-to-br from-purple-900/10 to-pink-800/5 backdrop-blur-sm"
                     style={{
                        width: size,
                        height: size,
                        left: `calc(${Math.random() * 100}% - ${size / 2}px)`,
                        top: `calc(${Math.random() * 100}% - ${size / 2}px)`,
                        transform: `translateZ(${depth}px)`,
                     }}
                     initial={{ opacity: 0, rotateX: 0, rotateY: 0 }}
                     animate={{
                        opacity: [0, 0.6, 0],
                        rotateX: [0, Math.random() * 360],
                        rotateY: [0, Math.random() * 360],
                        z: [depth, depth + Math.random() * 200 - 100],
                     }}
                     transition={{
                        duration: Math.random() * 5 + 5,
                        repeat: Infinity,
                        repeatType: "loop",
                        ease: "easeInOut",
                     }}
                  >
                     <div className="absolute inset-0 flex items-center justify-center text-pink-400/70 text-xs font-mono overflow-hidden p-4">
                        AI-{Math.random().toString(36).substring(2, 6)}
                     </div>

                     {Math.random() > 0.5 && (
                        <motion.div
                           className="absolute w-[200px] h-px bg-gradient-to-r from-fuchsia-400/0 via-purple-400/50 to-pink-400/0"
                           style={{
                              left: "100%",
                              top: "50%",
                              transformOrigin: "left center",
                              transform: `rotate(${
                                 Math.random() * 60 - 30
                              }deg)`,
                           }}
                           animate={{ opacity: [0, 0.6, 0] }}
                           transition={{
                              duration: 3,
                              repeat: Infinity,
                              repeatType: "loop",
                           }}
                        />
                     )}
                  </motion.div>
               );
            })}

            {/* Glowing Neural Particles */}
            {Array.from({ length: 20 }).map((_, index) => {
               const size = Math.random() * 10 + 5;
               const colors = ["#A855F7", "#EC4899", "#6366F1"];
               const color = colors[Math.floor(Math.random() * colors.length)];

               return (
                  <motion.div
                     key={`neuron-${index}`}
                     className="absolute rounded-full"
                     style={{
                        width: size,
                        height: size,
                        backgroundColor: color,
                        boxShadow: `0 0 15px ${color}, 0 0 30px ${color}`,
                        left: `${Math.random() * 100}%`,
                        top: `${Math.random() * 100}%`,
                     }}
                     animate={{
                        scale: [1, 1.5, 1],
                        opacity: [0.3, 0.9, 0.3],
                        x: [
                           0,
                           Math.random() * 200 - 100,
                           Math.random() * 100 - 50,
                        ],
                        y: [
                           0,
                           Math.random() * 200 - 100,
                           Math.random() * 100 - 50,
                        ],
                     }}
                     transition={{
                        duration: Math.random() * 10 + 2,
                        repeat: Infinity,
                        repeatType: "mirror",
                        ease: "easeInOut",
                     }}
                  />
               );
            })}

            {/* AI Data Streams */}
            {Array.from({ length: 15 }).map((_, index) => {
               const isHorizontal = Math.random() > 0.5;
               const width = isHorizontal ? Math.random() * 300 + 100 : 2;
               const height = isHorizontal ? 2 : Math.random() * 300 + 100;

               return (
                  <motion.div
                     key={`stream-${index}`}
                     className="absolute bg-gradient-to-r from-pink-500/0 via-purple-400/50 to-pink-500/0"
                     style={{
                        width,
                        height,
                        left: `${Math.random() * 100}%`,
                        top: `${Math.random() * 100}%`,
                     }}
                     animate={{
                        opacity: [0, 0.8, 0],
                        x: isHorizontal ? [-width, width] : 0,
                        y: isHorizontal ? 0 : [-height, height],
                     }}
                     transition={{
                        duration: Math.random() * 1 + 5,
                        repeat: Infinity,
                        repeatType: "loop",
                        ease: "linear",
                     }}
                  />
               );
            })}
         </div>
      </div>
   );
}
