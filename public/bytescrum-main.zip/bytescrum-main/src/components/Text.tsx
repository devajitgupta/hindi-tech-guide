import clsx from "clsx";
import React from "react";
import { twMerge } from "tailwind-merge";

interface IProps {
   className?: string;
   children: React.ReactNode;
   color?: string;
   variant?: "default" | "primary";
   animationVariant?:
      | "default"
      | "fadeRight"
      | "fadeLeft"
      | "fadeUp"
      | "fadeDown"
      | "zoomInUp";
   transform?: string;
   animationDelay?: string;
   animationDuration?: string;
   textSize?: "xs" | "sm" | "md" | "lg" | "xl" | "xxl";
}

const Text = ({
   className,
   children,
   color,
   variant = "default",
   animationVariant = "default",
   animationDelay = "0",
   animationDuration = "600",
   textSize = "md",
   transform,
}: IProps) => {
   const variantColors = {
      default: "#f5f5f5",
      primary: "#bcbcbc",
   };
   const aosVariants = {
      fadeRight: "fade-right",
      fadeLeft: "fade-left",
      fadeUp: "fade-up",
      fadeDown: "fade-down",
      zoomInUp: "zoom-in-up",
   };

   const textSizes = {
      xs: "text-[10px] md:text-[12px] leading-[20px] md:leading-[24px] max-w-[481px]",
      sm: "text-[12px] md:text-[14px] leading-[24px] md:leading-[28px] max-w-[481px]",
      md: "text-[14px] md:text-[16px] leading-[24px] md:leading-[28px]",
      lg: "text-[16px] md:text-[18px] leading-[24px] md:leading-[28px]",
      xl: "text-[18px] md:text-[20px] leading-[24px] md:leading-[28px]",
      xxl: "text-[20px] md:text-[22px] leading-[24px] md:leading-[28px]",
   };

   const appliedColor = color ? color : variantColors[variant];
   const appliedAos =
      animationVariant !== "default" ? aosVariants[animationVariant] : null;

   const appliedTextSize = textSizes[textSize];

   return (
      <p
         className={twMerge(
            clsx(
               "inter text-[12px] md:text-[16px] leading-0 md:leading-[28px] text-center max-w-full lg:max-w-[743px]",
               className,
               appliedTextSize
            )
         )}
         style={{ color: appliedColor, transform: transform }}
         data-aos={appliedAos || undefined}
         data-aos-duration={animationDuration}
         data-aos-anchor-placement="top-bottom"
         data-aos-delay={animationDelay}
      >
         {children}
      </p>
   );
};

export default Text;
