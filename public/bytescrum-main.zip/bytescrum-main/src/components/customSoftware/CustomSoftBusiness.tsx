import React from "react";
import SectionTitle from "../SectionTitle";

import Text from "../Text";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";

const CustomSoftBusiness = ({ data }: any) => {
  return (
    <div
      className={twMerge(
        clsx(
          "px-5 md:px-[40px] pb-[60px]   md:pb-[80px] gap-[40px] bg-[#000000] relative z-50 w-full "
        )
      )}
    >
      <div>
        <SectionTitle className="max-w-3xl m-auto">
          {data.sectionTitle}{" "}
        </SectionTitle>
        <Text className="text-gray-300 mb-12 text-center lg:max-w-5xl max-w-full m-auto ">
          {data.description}
        </Text>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8 mt-12  w-full">
          <div className="service-card bg-gradient-to-br from-black to-red-950/20">
            <div className="w-12 h-12 bg-red-500/20 rounded-lg flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-red-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"
                />
              </svg>
            </div>
            <h4 className="text-xl font-semibold mb-3">{data.card1_title} </h4>
            <p className="text-gray-400">{data.card1_description}</p>
          </div>

          <div className="service-card bg-gradient-to-br from-black to-purple-950/20">
            <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-purple-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z"
                />
              </svg>
            </div>
            <h4 className="text-xl font-semibold mb-3">{data.card2_title} </h4>
            <p className="text-gray-400">{data.card2_description}</p>
          </div>

          <div className="service-card bg-gradient-to-br from-black to-amber-950/20">
            <div className="w-12 h-12 bg-amber-500/20 rounded-lg flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-amber-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"
                />
              </svg>
            </div>
            <h4 className="text-xl font-semibold mb-3"> {data.card3_title}</h4>
            <p className="text-gray-400">{data.card3_description}</p>
          </div>

          <div className="service-card bg-gradient-to-br from-black to-teal-950/20">
            <div className="w-12 h-12 bg-teal-500/20 rounded-lg flex items-center justify-center mb-4">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-teal-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01"
                />
              </svg>
            </div>
            <h4 className="text-xl font-semibold mb-3">{data.card4_title} </h4>
            <p className="text-gray-400">{data.card4_description}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomSoftBusiness;
