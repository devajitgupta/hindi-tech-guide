import React from "react";
import SectionSubtitle from "../SectionSubtitle";
import SectionTitle from "../SectionTitle";
import { Button } from "@nextui-org/react";

const CustomSoftIndustry = () => {
   return (
      <div className="px-5 md:px-[40px] pb-[60px]   md:pb-[80px] gap-[40px] bg-[#000000] relative z-50 w-full max-w-6xl m-auto">
         {" "}
         <div className="mt-16">
            <SectionTitle className="section-subtitle text-center m-auto">
               Industries We Serve
            </SectionTitle>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
               {[
                  "Healthcare",
                  "Finance",
                  "E-commerce",
                  "Education",
                  "Manufacturing",
                  "Logistics",
                  "Real Estate",
                  "Entertainment",
               ].map((industry, index) => (
                  <div
                     key={index}
                     className="bg-gradient-to-br from-black to-blue-950/10 p-4 rounded-lg border border-blue-900/20 text-center"
                  >
                     <span className="text-white">{industry}</span>
                  </div>
               ))}
            </div>
         </div>
         <div className="mt-16 text-center">
            <Button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105">
               Request Custom Software
            </Button>
         </div>
      </div>
   );
};

export default CustomSoftIndustry;
