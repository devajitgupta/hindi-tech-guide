"use client";

import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useInView } from "react-intersection-observer";
import SectionTitle from "../SectionTitle";
import useElementSize from "@/common/hooks/useElementSize";

const CustomSoftProcess = () => {
   const { ref: sizeRef, height } = useElementSize<HTMLDivElement>();
   const [activeStep, setActiveStep] = useState(-1);

   // Enable smooth scrolling in browser
   useEffect(() => {
      document.documentElement.style.scrollBehavior = "smooth";
   }, []);

   // Timeline Items Data
   const timelineItems = [
      {
         title: "Discovery & Analysis",
         description: "Understanding business objectives through research.",
         color: "blue",
      },
      {
         title: "Solution Architecture",
         description:
            "Designing a solution blueprint with architecture models.",
         color: "indigo",
      },
      {
         title: "Development & Testing",
         description: "Building software iteratively with quality checks.",
         color: "purple",
      },
      {
         title: "Deployment & Training",
         description: "Deploying software and training teams for usage.",
         color: "pink",
      },
      {
         title: "Maintenance & Support",
         description: "Providing updates and ongoing support for improvements.",
         color: "red",
      },
   ];

   // Generate refs dynamically
   const refs = timelineItems.map(() =>
      useInView({ threshold: 0.5, rootMargin: "-250px 0px 250px 0px" })
   );

   // Update active step based on which item is in view
   useEffect(() => {
      const activeIndex = refs.findIndex(([_, inView]) => inView);
      setActiveStep(activeIndex !== -1 ? activeIndex : -1);
   }, [refs.map(([_, inView]) => inView)]);

   // Calculate line height smoothly
   const getLineHeight = () => {
      if (activeStep === -1) return "0%";
      return `${(activeStep + 1) * (100 / timelineItems.length)}%`;
   };

   return (
      <div className="px-5 md:px-10 pb-16 bg-black relative z-50 w-full">
         <div className="mt-16 max-w-5xl m-auto ">
            <SectionTitle className=" max-w-3xl m-auto">
               Our Custom Software Development Approach
            </SectionTitle>
            <div className="relative mt-12 overflow-hidden">
               {/* Timeline Line */}
               <div className="absolute top-2 z-30 left-1/2 transform translate-x-[10px] h-full w-1 bg-gray-800">
                  <motion.div
                     className="absolute top-0  left-1/2 w-full -translate-x-1/2  bg-gradient-to-b from-blue-600 to-purple-600"
                     initial={{ height: "0%" }}
                     animate={{ height: getLineHeight() }}
                     transition={{
                        type: "spring",
                        stiffness: 120,
                        damping: 20,
                        mass: 0.7,
                     }}
                  />
               </div>

               {/* Timeline Items */}
               <div ref={sizeRef} className="py-4">
                  {timelineItems.map((item, index) => {
                     const [ref, inView] = refs[index];

                     return (
                        <motion.div
                           key={index}
                           className="relative    "
                           ref={ref}
                        >
                           {/* Timeline Dot */}
                           <motion.div
                              className="absolute z-40 left-1/2 transform translate-x-0 -translate-y-1/2 w-6 h-6 rounded-full border-4 border-black "
                              animate={{
                                 backgroundColor:
                                    activeStep >= index ? "#1463fd" : "#1f2937",
                                 // scale: activeStep === index ? 1 : 0.8,
                              }}
                              transition={{
                                 type: "spring",
                                 stiffness: 150,
                                 damping: 25,
                              }}
                           />

                           {/* Timeline Content */}
                           <motion.div
                              className={`w-full md:w-1/2 px-4 py-8 rounded-lg  ${
                                 index % 2 === 0
                                    ? "ml-auto md:pl-10"
                                    : "mr-auto md:pr-10"
                              } bg-gradient-to-br from-black to-${
                                 item.color
                              }-950/20 `}
                              animate={{
                                 opacity: activeStep >= index - 1 ? 1 : 0.5,
                                 y: activeStep >= index - 1 ? 0 : 20,
                                 scale: activeStep === index ? 1.03 : 1,
                                 // boxShadow:
                                 //    activeStep === index
                                 //       ? "0 0 15px #1462fd53"
                                 //       : "none",
                              }}
                              transition={{
                                 type: "spring",
                                 stiffness: 120,
                                 damping: 20,
                              }}
                           >
                              <h4 className="text-lg font-semibold mb-2">
                                 {item.title}
                              </h4>
                              <p className="text-gray-400 text-sm">
                                 {item.description}
                              </p>
                           </motion.div>
                        </motion.div>
                     );
                  })}
               </div>
            </div>
         </div>
      </div>
   );
};

export default CustomSoftProcess;
