import clsx from "clsx";
import React from "react";
import { twMerge } from "tailwind-merge";
import CustomSoftBanner from "./CustomSoftBanner";

const CustomSoftHeroSection = ({data}:any) => {
   return (
      <div
         className={twMerge(
            clsx(
               "relative overflow-hidden px-[22px]  md:px-[54px]  items-center justify-normal   z-20"
            )
         )}
      >
         <CustomSoftBanner />
         <div className="grid place-items-center py-10 md:py-16 md:gap-[10px]">
            <h1
               className="text-[35px] md:text-[70px] md:leading-[80px] font-light  poppins text-center "
               data-aos="zoom-in"
               data-aos-delay={300}
               data-aos-easing="ease-out-cubic"
               data-aos-anchor-placement="top-bottom"
            >
               <span className="font-bold ">{data.title}</span>
            </h1>
            <p
               className="max-w-[609px] text-[16px] leading-[28px]  text-center m-auto mt-2"
               data-aos="zoom-in"
               data-aos-delay={500}
               data-aos-easing="ease-out-cubic"
               data-aos-anchor-placement="top-bottom"
            >
               {data.titleOne}
            </p>
         </div>
      </div>
   );
};

export default CustomSoftHeroSection;
