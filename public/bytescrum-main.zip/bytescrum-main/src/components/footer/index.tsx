import React from "react";
import DeskTopFooter from "./DeskTopFooter";
type Props = {
   langText: any;
};
const Footer = ({ langText }: Props) => {
   return (
      <footer className="  bg-black z-50 relative">
         <DeskTopFooter langText={langText}  />
      </footer>
   );
};

export default Footer;
