"use client";

import { Icon } from "@iconify/react/dist/iconify.js";
import Image from "next/image";
import Link from "next/link";
import { Accordion, AccordionItem } from "@nextui-org/react";
import { useState } from "react";
import "./footer.css";
import homeData from "../../common/data/homeData.json";
import { EContactFormTypes } from "@/utils/enums";
import API_CONFIG from "@/config";
import ContactUsApi from "@/common/apis/contactus.api";
import axios from "axios";
import toast from "react-hot-toast";
type Props = {
   langText: any;
};
const DeskTopFooter = ({ langText }: Props) => {
  const footer = langText.footer;
  const [showFooterLogo, setShowFooterLogo] = useState(true);
  const [email, setEmail] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("Please enter a valid email address");
      return;
    }

    setIsSubmitting(true);

    try {
      const [username] = email.split("@");
      const firstName = username.charAt(0).toUpperCase() + username.slice(1);

      const response = await axios.post(
        `${API_CONFIG.BASE_URL}${ContactUsApi.base}`,
        {
          email,
          firstName,
          formTypes: [EContactFormTypes.NEWSLETTER],
          subject: [
            {
              title: "Subscribed to newsletter",
              form: EContactFormTypes.NEWSLETTER
            }
          ]
        },
        {
          headers: {
            "Content-Type": "application/json"
          }
        }
      );

      // Success only if no error is thrown
      setEmail("");
      toast.success(response?.data?.message || "Thank you for subscribing!");
    } catch (error: any) {
      const message =
        error?.response?.data?.message ||
        error?.response?.data?.error ||
        "Something went wrong. Please try again later.";

      toast.error(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const currentYear = new Date().getFullYear();
  return (
    <div
      id="footer"
      className={`grid px-4 md:px-[40px] pt-[60px] gap-[32px] inter border-t  border-[#2f2f2f] ${
        showFooterLogo ? "show" : "hide"
      }`}
    >
      <div className="grid lg:grid-cols-12  gap-[40px]  ">
        <div className="col-span-full  max-w-full lg:col-span-5 grid gap-[40px]">
          <div className="m-auto md:m-0 logo-container">
            <Image
              src={"/bytes_Logo_3.svg"}
              width={280}
              height={0}
              // width={325}
              // height={75}
              priority={true}
              alt="Barnd Logo"
              className="footer-logo w-auto h-auto"
            />
          </div>

          <div className="grid grid-cols-2 gap-[30px]  ">
            {footer.contact.map((item:any) => (
              <div key={item._id}>
                <h3 className="text-[14px] md:text-[16px] text-[#ffffff] inter font-bold leading-[28px]">
                  {item.title}
                </h3>
                <p className=" text-[12px] md:text-[16px] text-[#dedede] inter  leading-[18px] md:leading-[28px] ">
                  {item.textOne} <br /> {item.textTwo}
                </p>
              </div>
            ))}

            {/* NOTE: Follow us */}
            <div className="grid gap-[10px]">
              <h3 className="text-[14px] md:text-[16px] text-[#ffffff] inter font-bold leading-[28px]">
                {footer.follow.title}
              </h3>
              <div className="flex gap-[5px] md:gap-[10px]">
                {footer.follow.icon.map((item:any) => (
                  <Link href={item.href} target="blank" key={item._id}>
                    <Icon
                      icon={item.icon}
                      className="hover:text-[#1a1a1a] hover:bg-white bg-[#1a1a1a] px-[5px] md:p-[10px] text-[30px] md:text-[42px] rounded-full text-[#ffffff]"
                    />
                  </Link>
                ))}
              </div>
            </div>
          </div>

          {/* NOTE: Input */}
          <div className=" grid gap-[20px] ">
            <h3 className=" poppins text-[20px] font-bold uppercase text-[#ffffff]">
              {footer.subscribe.title}
            </h3>
            <div>
              <form
                className="bg-[#242424] border border-[#535353] rounded-full py-[8px] pe-[7px] ps-[28px] flex justify-between "
                onSubmit={handleSubmit}
              >
                <input
                  type="email"
                  placeholder={footer.subscribe.placeHolder}
                  onChange={(e) => setEmail(e.target.value)}
                  value={email}
                  className=" outline-none border-none bg-[#242424] placeholder:leading-[28px] placeholder:text-[16px] w-full placeholder:text-[#ffffff] placeholder:inter pe-[28px] "
                />

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`text-[#1a1a1a] text-center inter text-[14px] leading-[24px] uppercase bg-[#ffffff] px-[30px] py-[10px] rounded-full ${
                    isSubmitting ? "opacity-50 cursor-not-allowed" : ""
                  }`}
                >
                  {isSubmitting ? "Subscribing..." : footer.subscribe.btnText}
                </button>
              </form>
            </div>
          </div>
        </div>
        <div className=" grid-cols-3 mt-[20px] col-span-full lg:grid lg:col-span-7 hidden ">
          {footer.links.footerLinks.map((link:any) => (
            <div key={link.title} className=" grid  justify-center ">
              <div>
                <h3 className="text-[22px] font-bold poppins text-[#ffffff]">
                  {link.title}
                </h3>
                <div className="grid gap-[20px]  mt-[30px]">
                  {link.servicesLinks.map((serviceLink:any, index:any) => (
                    <Link
                      key={index}
                      href={serviceLink.href}
                      className=" inter  text-[#dedede] text-[14px] leading-[24px]"
                    >
                      {serviceLink.title}
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="col-span-full max-w-full lg:hidden">
          <Accordion
            variant="bordered"
            showDivider={true}
            fullWidth={true}
            defaultExpandedKeys={["1"]}
          >
            {footer.links.footerLinks.map((link:any) => (
              <AccordionItem
                key={link._id}
                aria-label={link.title}
                title={link.title}
                indicator={({ isOpen }) =>
                  isOpen ? (
                    <Icon icon={footer.links.minusIcon} className="text-xl" />
                  ) : (
                    <Icon icon={footer.links.plusIcon} className="text-xl" />
                  )
                }
                classNames={{
                  content: "border-b border-[#262626] flex justify-between  ",
                  heading:
                    "border-b relative active:border-none border-[#262626]  flex justify-between ",
                  title: "poppins text-[18px] font-bold text-[#ffffff] ",
                  indicator: "text-[#ffffff] absolute  right-0"
                }}
              >
                <div className="grid sm:grid-cols-2  w-full  gap-5">
                  {link.servicesLinks.map((serviceLink:any, index:any) => (
                    <Link
                      key={index}
                      href={serviceLink.href}
                      className=" inter  text-[#dedede] leading-[24px]"
                    >
                      {serviceLink.title}
                    </Link>
                  ))}
                </div>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
      <div className="grid gap-[20px] ">
        <div className="grid place-items-center grid-cols-4 md:grid-cols-5 gap-[40px] px-[10px] md:px-[150px] pb-[30px] md:py-[50px] border-b md:border-y border-[#2f2f2f]">
          {footer.links.techLogos.map((logo: any, index: number) => (
            <Link
              key={index}
              href={"#"}
              className="first:col-span-full md:first:col-span-1 "
            >
              <Image
                src={logo.src}
                width={logo.width}
                height={0}
                alt="Tech Logo"
                className="h-auto w-auto"
              />
            </Link>
          ))}
        </div>
        <div className="grid items-center lg:grid-cols-5 py-[20px] gap-y-[20px]">
          <span className="lg:col-span-3 text-[12px] order-2 lg:order-1 text-center lg:text-start inter text-[#ffffff]">
            {/* {footer.copyright.text} */}© bytescrum {currentYear} — All
            Rights Reserved.
          </span>
          <ul className="flex   justify-evenly xl:grid md:grid-cols-3 col-span-full lg:col-span-2 place-items-center list-disc  text-[12px] md:text-[14px] text-[#dedede] inter order-1 lg:order-2  ">
            {footer.copyright.links.map((link:any, index:any) => (
              <li key={index}>
                {" "}
                <Link href={link.href} key={link._id}>
                  {link.title}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default DeskTopFooter;
