"use client";
import Link from "next/link";
import SectionTitle from "../SectionTitle";
import SectionSubtitle from "../SectionSubtitle";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import "./style.css";
import Text from "../Text";
import { motion } from "framer-motion";

interface IConnectProps {
   title?: string;
   subTitle?: string;
   text?: string;
   href?: string;
   buttonText?: string;
   onButtonClick?: () => void;
   className?: string;
   titleClass?: string;
   subtitleClass?: string;
   colorVarient?: string;
   animation?: boolean;
   isParallaxVarient?: boolean;
}


const Connect = ({
   title,
   text ,
   buttonText ,
   href = "/contact-us",
   subTitle,
   onButtonClick,
   className,
   titleClass,
   subtitleClass,
   colorVarient,
   animation = true,
   isParallaxVarient = false,
}: IConnectProps) => {
   return (
      <div
         className={twMerge(
            clsx(
               "md:px-[20px]  border-t border-[#262626] xl:px-[40px] pt-[60px] pb-[30px] px-4 grid place-items-center gap-[30px] bg-black relative overflow-hidden",
               className
            )
         )}
      >
         {/* <div className="absolute inset-0 z-0">
            <motion.div
              
               className="absolute top-0 left-0 w-full h-full bg-transparent"
               animate={{
                  backgroundPosition: ["0% 0%", "100% 100%", "0% 0%"],
               }}
               transition={{
                  duration: 20,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "linear",
               }}
            />

            
            {Array.from({ length: 5 }).map((_, index) => (
               <motion.div
                  key={`line-${index}`}
                  className="absolute h-px bg-gradient-to-r from-blue-500/0 via-blue-500/30 to-blue-500/0"
                  style={{
                     width: "100%",
                     top: `${index * 20}%`,
                     left: 0,
                  }}
                  animate={{
                     x: ["-100%", "100%"],
                     opacity: [0, 1, 0],
                  }}
                  transition={{
                     duration: 8 + index * 2,
                     repeat: Number.POSITIVE_INFINITY,
                     ease: "linear",
                     delay: index * 0.5,
                  }}
               />
            ))}
         </div> */}
         <div
            className={twMerge(
               clsx("grid gap-[17px] max-w-[750px]", {
                  "max-w-6xl": isParallaxVarient,
               })
            )}
         >
            <SectionTitle
               animationVariant={animation ? "zoomInUp" : undefined}
               className={twMerge(clsx(titleClass))}
            >
               {title}
            </SectionTitle>
            {subTitle && (
               <SectionSubtitle
                  className={twMerge(
                     clsx("max-w-full text-black", subtitleClass)
                  )}
                  animationVariant={animation ? "zoomInUp" : undefined}
                  animationDelay={"100"}
                  color={colorVarient}
               >
                  {subTitle}
               </SectionSubtitle>
            )}
            <Text
               className={twMerge(
                  clsx("max-w-full m-auto text-black", subtitleClass)
               )}
               animationVariant={animation ? "zoomInUp" : undefined}
               animationDelay={"200"}
               color={colorVarient}
               textSize="md"
            >
               {text}
            </Text>
         </div>
         <Link
            href={href}
            data-aos={animation ? "zoom-in-up" : undefined}
            data-aos-duration={500}
            data-aos-delay={300}
            data-aos-anchor-placement="top-bottom"
         >
            <motion.button
               className="relative bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-full transition-all duration-300 overflow-hidden"
               whileHover={{ scale: 1.05 }}
               whileTap={{ scale: 0.95 }}
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               transition={{ duration: 0.5, delay: 0.4 }}
            >
               {/* Button glow effect */}
               <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-blue-400/0 via-blue-400/70 to-blue-400/0"
                  animate={{
                     x: ["-100%", "100%"],
                  }}
                  transition={{
                     duration: 2,
                     repeat: Number.POSITIVE_INFINITY,
                     ease: "linear",
                  }}
               />
               <span className="relative z-10">{buttonText}</span>
            </motion.button>

            {/* <Button
               onClick={onButtonClick}
               className={twMerge(
                  clsx(
                     " text-[14px] text-center  px-[30px] py-[10px] font-bold inter leading-[24px] text-[#ffffff] hover:border-[#1463fd]  hover:text-[#1463fd] connectBtn "
                  )
               )}
            >
               {buttonText}
            </Button> */}
         </Link>
      </div>
   );
};

export default Connect;
