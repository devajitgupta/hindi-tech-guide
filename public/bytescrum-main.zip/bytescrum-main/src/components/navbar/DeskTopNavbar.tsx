"use client";

import clsx from "clsx";
import Image from "next/image";
import Link from "next/link";
import React, { useState } from "react";
import { twMerge } from "tailwind-merge";
import { usePathname } from "next/navigation";
import { Icon } from "@iconify/react/dist/iconify.js";
import useConsultationStore from "@/libs/stores/useConsultationStore";
import { motion, AnimatePresence } from "framer-motion";
import LocaleSwitcher from "../lang-switcher/lang-switcher";
import { TLocale } from "@/i18n-config";
import { genLinkServer } from "@/utils/enums";

interface Iprops {
   className?: string;
   lang: TLocale;
   langText: any;
}

const DeskTopNavbar = ({ className, lang, langText }: Iprops) => {
   const { openModel } = useConsultationStore();
   const navbarData = langText.navbar;
   const pathname = usePathname();
   const [activeSubMenu, setActiveSubMenu] = useState<string | null>(null);
   const [subMenuLinkIcon, setSubMenuLinkIcon] =
      useState<string>("/webDev.svg");

   const handleMouseEnter = (title: string) => setActiveSubMenu(title);
   const handleMouseLeave = () => setActiveSubMenu(null);

   const isLinkActive = (href: string) => {
      const pathWithoutLang = pathname.replace(new RegExp(`^/${lang}`), "");
      return pathWithoutLang === href || pathname === href;
   };

   return (
      <div
         className={twMerge(
            clsx(
               "grid md:grid-cols-3 lg:grid-cols-10 items-center justify-between md:px-[40px] py-1 px-4 inter z-100 bg-transparent",
               className
            )
         )}
      >
         <Link href={genLinkServer("/", lang)} className="lg:col-span-3">
            <Image src={navbarData.logo} width={250} height={250} alt="Logo" />
         </Link>

         <div className="w-full md:grid gap-1 md:col-span-2 lg:col-span-5 xl:col-span-4 items-center text-white hidden">
            <div className="flex justify-between items-center relative mb-0">
               {navbarData.navbarLinks.map((link: any) => (
                  <div key={link.title} className="relative">
                     {link.href !== "/" ||
                     pathname !== genLinkServer("/", lang) ? (
                        <Link
                           target={link.title === "Blogs" ? "_blank" : ""}
                           href={genLinkServer(link.href, lang)}
                           className={clsx(
                              "text-[16px] hover:text-white/90 text-white py-4 inter flex items-center",
                              {
                                 "text-white/50": isLinkActive(link.href),
                              }
                           )}
                           onMouseEnter={() => handleMouseEnter(link.title)}
                           onMouseLeave={handleMouseLeave}
                        >
                           {link.title}
                           {link.title === "Services" && (
                              <Icon
                                 icon={
                                    activeSubMenu === "Services"
                                       ? "material-symbols:expand-less"
                                       : "material-symbols:expand-more"
                                 }
                                 className="ml-2"
                              />
                           )}
                        </Link>
                     ) : null}

                     <AnimatePresence>
                        {link.submenu && activeSubMenu === link.title && (
                           <div className="overflow-hidden">
                              <div className="absolute h-5 w-5 bg-[#0d0d0d] left-[2rem] rotate-45 top-[2.9rem] !z-[9999999999] border-white/20 border-l border-t"></div>
                              <motion.div
                                 className="absolute top-full z-100 -left-16 transform translate-x-[-30%] bg-[#0d0d0d] shadow-10xl w-[1400px] rounded-xl overflow-hidden border-white/20 border"
                                 onMouseEnter={() =>
                                    setActiveSubMenu(link.title)
                                 }
                                 onMouseLeave={handleMouseLeave}
                                 initial={{ height: 0 }}
                                 animate={{ height: "auto" }}
                                 exit={{ height: 0 }}
                                 layout
                              >
                                 <div className="grid grid-cols-4 px-8 py-5">
                                    <div className="col-span-3 grid grid-cols-2 lg:grid-cols-3 overflow-hidden gap-x-1">
                                       {link.submenu.map(
                                          (sublink: any, index: any) => (
                                             <div
                                                key={index}
                                                onMouseEnter={() =>
                                                   setSubMenuLinkIcon(
                                                      sublink.icon || ""
                                                   )
                                                }
                                                onMouseLeave={() =>
                                                   setSubMenuLinkIcon(
                                                      "/webDev.svg"
                                                   )
                                                }
                                             >
                                                <Link
                                                   href={genLinkServer(
                                                      sublink.href,
                                                      lang
                                                   )}
                                                   className="block px-2 py-2 text-white hover:bg-black/30"
                                                >
                                                   <div>
                                                      <h3 className="text-[16px]">
                                                         {sublink.title}
                                                      </h3>
                                                      <p className="text-[13px] text-white/60">
                                                         {sublink.text}
                                                      </p>
                                                   </div>
                                                </Link>
                                             </div>
                                          )
                                       )}
                                       <Link
                                          href={genLinkServer(
                                             "/services",
                                             lang
                                          )}
                                          className="mt-8"
                                       >
                                          <button className="border px-5 py-2 bg-white rounded-full text-black text-[12px] font-semibold">
                                             {navbarData.seeAllServices ||
                                                "See All Services"}
                                          </button>
                                       </Link>
                                    </div>
                                    {subMenuLinkIcon && (
                                       <div className="grid place-items-center">
                                          <Image
                                             src={subMenuLinkIcon}
                                             width={175}
                                             height={175}
                                             alt="icon"
                                             className="m-auto"
                                          />
                                       </div>
                                    )}
                                 </div>
                              </motion.div>
                           </div>
                        )}
                     </AnimatePresence>
                  </div>
               ))}
            </div>
         </div>

         <div className="lg:flex gap-2 items-center justify-end hidden lg:col-span-2 xl:col-span-3">
            <LocaleSwitcher currentLang={lang} />
            <div className="border rounded-full border-[#8a8a8a] bg-white hover:border-white px-5 py-2">
               <button
                  className="text-black inter"
                  onClick={() => openModel("consultation")}
               >
                  {navbarData.navBtn}
               </button>
            </div>
         </div>
      </div>
   );
};

export default DeskTopNavbar;
