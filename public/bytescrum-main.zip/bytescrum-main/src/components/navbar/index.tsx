"use client";
import { useEffect, useState } from "react";
import DeskTopNavbar from "./DeskTopNavbar";
import MobileNavbar from "./MobileNavbar";
import AOS from "aos";
import "aos/dist/aos.css";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import { TLocale } from "@/i18n-config";
type Props = {
   lang: TLocale;
   langText: any;
};
const Navbar = ({ langText, lang }: Props) => {
   const { screenWidth } = useBreakpoints();
   const isMobile = screenWidth >= 768;
   // const isMobile = useMediaQuery("only screen and (max-width: 768px)");
   useEffect(() => {
      AOS.init({
         offset: 200,
         duration: 600,
         easing: "ease-in-sine",
         delay: 100,
      });
   }, []);

   useEffect(() => {
      AOS.refresh();
   }, [isMobile]);

   return (
      <>
         <nav className="sticky top-0 bg-black/20 backdrop-blur-md z-50">
            <div className="hidden xl:block ">
               <DeskTopNavbar lang={lang} langText={langText} />
            </div>
            <div className="xl:hidden">
               <MobileNavbar lang={lang} langText={langText} />
            </div>
         </nav>
      </>
   );
};

export default Navbar;
