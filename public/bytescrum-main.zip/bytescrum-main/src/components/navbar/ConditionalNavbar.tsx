"use client";

import { usePathname } from "next/navigation";
import Navbar from "@/components/navbar";
import { TLocale } from "@/i18n-config";
type Props = {
   lang: TLocale;
   langText: any;
};
const ConditionalNavbar = ({ lang, langText }: Props) => {
   const pathname = usePathname();
   const isHomePage = pathname === "/";

   return isHomePage ? <Navbar lang={lang} langText={langText} /> : null;
};

export default ConditionalNavbar;
