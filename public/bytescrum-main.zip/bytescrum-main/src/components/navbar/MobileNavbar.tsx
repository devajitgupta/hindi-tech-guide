import { Icon } from "@iconify/react/dist/iconify.js";
import clsx from "clsx";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useEffect } from "react";
import { CloseIcon, MenuIcon } from "../Icons";
import homeData from "../../common/data/homeData.json";
import useConsultationStore from "@/libs/stores/useConsultationStore";
import { motion, AnimatePresence } from "framer-motion";
import LocaleSwitcher from "../lang-switcher/lang-switcher";
import { TLocale } from "@/i18n-config";
import { genLinkServer } from "@/utils/enums";

interface Iprops {
   className?: string;
   lang: TLocale;
   langText: any;
}

const MobileNavbar = ({ className, lang, langText }: Iprops) => {
   const { openModel, isOpen, closeModel } = useConsultationStore();
   const navbarData = homeData.navbar;
   const [isNavOpen, setisNavOpen] = useState(false);
   const [isSubMenuOpen, setIsSubMenuOpen] = useState(false);
   const [isFirstOpen, setIsFirstOpen] = useState(true);
   const [isSubMenuFirstOpen, setIsSubMenuFirstOpen] = useState(true);

   const pathname = usePathname();

   const toggleSubMenu = () => {
      if (isSubMenuFirstOpen) {
         setTimeout(() => {
            setIsSubMenuFirstOpen(false);
         }, 2500);
      }
      setIsSubMenuOpen(!isSubMenuOpen);
   };

   const isSubmenuPathActive = (submenu: any) => {
      return submenu.some((sublink: any) => pathname === sublink.href);
   };

   const handleMenuOpen = () => {
      if (isFirstOpen) {
         setTimeout(() => {
            setIsFirstOpen(false);
         }, 2500);
      }

      setisNavOpen(!isNavOpen);
   };

   useEffect(() => {
      if (isNavOpen || isOpen) {
         document.body.style.overflowY = "hidden";
      } else {
         document.body.style.overflowY = "scroll";
      }
   }, [isNavOpen, isOpen]);

   return (
      <div className="grid gap-2  ">
         <div
            className={clsx(
               "px-4 md:px-8 xl:px-32 py-4 grid grid-cols-2 items-center gap-5 inter ",
               className
            )}
         >
            <Link href={"/"} className=" w-[220px]">
               <Image
                  src={navbarData.logo}
                  width={220}
                  height={150}
                  alt="Logo"
               />
            </Link>
            <div className="flex gap-x-5 justify-end items-center xl:hidden text-5xl">
               <div className="flex gap-2 items-center justify-end  lg:col-span-2 xl:col-span-3">
                  <LocaleSwitcher currentLang={lang} onClick={() => {}} />
               </div>
               {!isNavOpen ? <MenuIcon onClick={handleMenuOpen} /> : ""}
            </div>
         </div>

         {isNavOpen && (
            <div className="w-[100dvw]  xl:grid gap-1 items-center  bg-black  absolute h-[100dvh]  ">
               <div className="grid justify-end items-center px-4 md:px-8 xl:px-32 py-4 xl:hidden text-5xl text-white ">
                  {isNavOpen ? <CloseIcon onClick={handleMenuOpen} /> : ""}
               </div>
               <div className="grid gap-3 h-[90dvh]     overflow-hidden overflow-y-auto hide-scrollbar pb-10  ">
                  <div className=" border-t   pt-5  border-white/10 ">
                     {navbarData.navbarLinks.map((link, index) => (
                        <div
                           key={link.title}
                           className="first:mt-0 my-8 px-4 md:px-8 xl:px-32"
                           onClick={
                              link.title !== "Services"
                                 ? () => setisNavOpen(!isNavOpen)
                                 : undefined
                           }
                           data-aos={isFirstOpen ? "fade-left" : ""}
                           data-aos-anchor-placement="bottom-bottom"
                           data-aos-delay={index * 200}
                           data-aos-once="true"
                        >
                           {link.submenu ? (
                              <div>
                                 <Link
                                    href={link.href}
                                    className={clsx(
                                       "text-5xl font-bold inter flex justify-between   text-white items-center",
                                       {
                                          "text-white/50":
                                             pathname == link.href ||
                                             isSubmenuPathActive(link.submenu),
                                       }
                                    )}
                                    onClick={toggleSubMenu}
                                 >
                                    <motion.div
                                       initial={{ x: 600 }}
                                       animate={{ x: 0 }}
                                       className="flex items-center justify-between w-full"
                                    >
                                       {link.title}

                                       <Icon
                                          icon={
                                             isSubMenuOpen
                                                ? "material-symbols:expand-less"
                                                : "material-symbols:expand-more"
                                          }
                                       />
                                    </motion.div>
                                 </Link>
                                 <AnimatePresence>
                                    {isSubMenuOpen && (
                                       <motion.div
                                          initial={{ height: 0 }}
                                          animate={{ height: 500 }}
                                          exit={{ height: 0 }}
                                          className=" overflow-hidden"
                                       >
                                          <motion.div
                                             initial={{ y: -200 }}
                                             animate={{ y: 0 }}
                                             transition={{
                                                duration: 0.3,
                                             }}
                                             className="p-5 mt-4 gap-y-3 grid border-y border rounded  border-white/20 overflow-hidden "
                                          >
                                             {link.submenu.map(
                                                (sublink, index) => (
                                                   <Link
                                                      key={sublink.title}
                                                      href={sublink.href}
                                                      className={clsx(
                                                         "text-2xl  font-semibold text-white inter ",
                                                         {
                                                            "text-white/50":
                                                               pathname ==
                                                               sublink.href,
                                                         }
                                                      )}
                                                      // data-aos={
                                                      //    isSubMenuFirstOpen
                                                      //       ? "fade-up"
                                                      //       : ""
                                                      // }
                                                      // data-aos-anchor-placement="bottom-bottom"
                                                      // data-aos-delay={index * 200}
                                                      // data-aos-once="true"
                                                      onClick={() =>
                                                         setisNavOpen(
                                                            !isNavOpen
                                                         )
                                                      }
                                                   >
                                                      <h3 className="text-[16px] md:text-[20px]">
                                                         {" "}
                                                         {sublink.title}{" "}
                                                      </h3>
                                                   </Link>
                                                )
                                             )}
                                          </motion.div>
                                       </motion.div>
                                    )}
                                 </AnimatePresence>
                              </div>
                           ) : link.href !== "/" || pathname !== "/" ? (
                              <Link
                                 target={link.title === "Blogs" ? "_blank" : ""}
                                 href={link.href}
                                 className={clsx(
                                    "text-5xl font-bold text-white   inter",
                                    {
                                       "text-white/50": pathname == link.href,
                                    }
                                 )}
                                 onClick={toggleSubMenu}
                                 // data-aos={isFirstOpen ? "fade-left" : ""}
                                 // data-aos-anchor-placement="bottom-bottom"
                                 // data-aos-delay={index * 200}
                                 // data-aos-once="true"
                              >
                                 <motion.div
                                    initial={{ x: 600 }}
                                    animate={{ x: 0 }}
                                 >
                                    {link.title}
                                 </motion.div>
                              </Link>
                           ) : null}
                        </div>
                     ))}

                     <div className=" bottom-5 pt-3  m-auto w-full ">
                        <div
                           className="  grid items-center justify-center mt-0
                           
                           "
                           data-aos={isFirstOpen ? "zoom-in" : ""}
                           data-aos-easing="ease-out-cubic"
                           data-aos-once={true}
                           data-aos-delay="1500"
                        >
                           <Link
                              href={"#"}
                              className="border rounded-full border-[#8a8a8a] bg-white hover:border-white px-5 py-2"
                           >
                              <button
                                 className="text-black inter"
                                 onClick={() => {
                                    openModel("consultation");
                                 }}
                              >
                                 {navbarData.navBtn}
                                 {/* {isFirstOpen} */}
                              </button>
                           </Link>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         )}
      </div>
   );
};

export default MobileNavbar;
