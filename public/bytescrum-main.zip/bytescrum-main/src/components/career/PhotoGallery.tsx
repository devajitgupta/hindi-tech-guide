"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useTransform, useSpring } from "framer-motion";
import Gallery from "./Gallery";

interface IProps {
   className?: string;
   data: any;
}

const PhotoGallery = ({ className, data }: IProps) => {
   const ref = useRef<HTMLDivElement>(null);
   const [allImagesInView, setAllImagesInView] = useState(false);
   const { scrollYProgress } = useScroll({
      target: ref,
      offset: ["start end", "end start"],
   });

   const smoothScrollYProgress = useSpring(scrollYProgress, {
      damping: 30,
      stiffness: 100,
   });

   const xTransform = useTransform(
      smoothScrollYProgress,
      [0, 1],
      ["20%", "-20%"]
   );

   useEffect(() => {
      const checkImagesInView = () => {
         const gallery = ref.current;
         if (gallery) {
            const images = gallery.querySelectorAll<HTMLImageElement>("img");
            const allInView = Array.from(images).every((img) => {
               const rect = img.getBoundingClientRect();
               return rect.top >= 0 && rect.bottom <= window.innerHeight;
            });
            setAllImagesInView(allInView);
         }
      };

      checkImagesInView();
      window.addEventListener("scroll", checkImagesInView);
      return () => window.removeEventListener("scroll", checkImagesInView);
   }, []);

   const yTransform = useTransform(smoothScrollYProgress, [0, 1], ["0%", "0%"]);

   return (
      <div ref={ref} className="overflow-x-auto  pb-6 md:pb-0 scrollbar-hide">
         <motion.div
            style={{
               x: xTransform,
               y: yTransform,
            }}
         >
            <Gallery images={data} />
         </motion.div>
      </div>
   );
};

export default PhotoGallery;
