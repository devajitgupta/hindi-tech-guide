"use client";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, EffectCoverflow, Pagination } from "swiper/modules";
import { useState } from "react";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import Image from "next/image";
import "../careerStyle.css";

interface IProps {
   swipperData: any;
   className?: string;
}

const MobileWorkSwipper = ({ swipperData, className }: IProps) => {
   const [currentSlide, setCurrentSlide] = useState(0);

   return (
      <div
         className={twMerge(
            clsx(
               " transition-transform duration-200 ease-in-out transform ",
               className
            )
         )}
      >
         {" "}
         <Swiper
            spaceBetween={-100}
            autoplay={{
               delay: 3000,
               disableOnInteraction: true,
            }}
            pagination={true}
            modules={[Pagination, EffectCoverflow, Autoplay]}
            effect={"coverflow"}
            grabCursor={false}
            centeredSlides={true}
            slidesPerView={"auto"}
            followFinger={true}
            initialSlide={3}
            simulateTouch={true}
            speed={1700}
            roundLengths={true}
            coverflowEffect={{
               rotate: 0,
               stretch: 50,
               depth: 100,
               modifier: 3,
               slideShadows: true,
            }}
            loop={true}
            onSlideChange={(swiper) => setCurrentSlide(swiper.realIndex)}
            className=" workswiper h-[350px] overflow-visible"
         >
            {swipperData.map((item: any, index: number) => (
               <SwiperSlide
                  key={item._Id}
                  className={twMerge(
                     clsx(
                        "border border-[#262626] bg-[#262626]/30 rounded-[16px] p-[20px] h-[299px] space-y-[5px] max-w-[300px]  max-h-[300px] ",
                        {
                           " backdrop-blur-md z-[9999] opacity-100":
                              currentSlide === index,
                        },
                        {
                           " backdrop-blur-md z-[-10] ": index - 1,
                        }
                     )
                  )}
                  data-aos="flip-left"
                  data-aos-easing="ease-out-cubic"
                  data-aos-delay={index * 150}
                  data-aos-anchor-placement="top-bottom"
               >
                  <div className="space-y-[30px]">
                     <Image
                        src={item.icon}
                        width={item.iconWidth}
                        height={item.iconHeight}
                        alt={item.icon}
                     />
                     <h3 className="text-[20px] font-bold poppins">
                        {" "}
                        {item.title}
                     </h3>
                  </div>
                  <p className=" text-[16px] leading-[28px] text-[#f5f5f5] w-full">
                     {item.text}
                  </p>
               </SwiperSlide>
            ))}
         </Swiper>
      </div>
   );
};

export default MobileWorkSwipper;
