"use client";

import useBreakpoints from "@/common/hooks/useBreakpoints ";
import clsx from "clsx";
import { useState } from "react";
import { twMerge } from "tailwind-merge";
import { Swiper, SwiperSlide } from "swiper/react";
import { A11y, Autoplay, Pagination } from "swiper/modules";
import "../careerStyle.css";
import Image from "next/image";

interface IProps {
   className?: string;
   swipperData: any;
}

const WorkSwipper = ({ className, swipperData }: IProps) => {
   const [activeIndex, setActiveIndex] = useState(0);
   const [realIndex, setRealIndex] = useState(0);
   const { screenWidth } = useBreakpoints();
   return (
      <div
         className={twMerge(
            clsx(
               " transition-transform duration-200 ease-in-out transform   px-10 ",
               className
            )
         )}
      >
         <Swiper
            modules={[Pagination, A11y, Autoplay]}
            spaceBetween={10}
            slidesPerView={2}
            slidesPerGroup={2}
            loop={true}
            navigation
            pagination={{
               clickable: true,
            }}
            scrollbar={{ draggable: true }}
            className="min-h-[270px] md:min-h-[365px] "
            // className="mb-40 border h-[365px]"
            onSlideChange={(swiper) => {
               setActiveIndex(swiper.activeIndex);
               setRealIndex(swiper.realIndex);
            }}
            followFinger={true}
            autoplay={{
               delay: 3000,
               disableOnInteraction: false,
            }}
            speed={1100}
            breakpoints={{
               0: {
                  slidesPerView: 2,
                  spaceBetween: 30,
               },
            }}
         >
            {swipperData.map((item: any, index: number) => (
               <SwiperSlide key={item._Id}>
                  <div className="border border-[#262626] rounded-[16px] p-[30px] h-[307px] space-y-[5px] max-w-[400px] m-auto  overflow-hidden">
                     <div className="space-y-[30px]">
                        <Image
                           src={item.icon}
                           width={item.iconWidth}
                           height={item.iconHeight}
                           alt={item.icon}
                        />
                        <h3 className="text-[16px] md:text-[20px] font-bold poppins">
                           {" "}
                           {item.title}
                        </h3>
                     </div>
                     <p className="max-w-[300px] text-[14px] md:text-[12px] leading-[24px] md:leading-[24px] text-[#f5f5f5]">
                        {item.text}
                     </p>
                  </div>
               </SwiperSlide>
            ))}
         </Swiper>
      </div>
   );
};

export default WorkSwipper;
