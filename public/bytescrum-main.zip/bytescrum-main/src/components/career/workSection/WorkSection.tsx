"use client";

import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import WorkSwipper from "./WorkSwipper";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import MobileWorkSwipper from "./MobileWorkSwipper";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";

interface IProps {
   className: string;
   data: any;
}

const WorkSection = ({ className, data }: IProps) => {
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth >= 924;
   return (
      <div
         className={twMerge(
            clsx(
               " px-0 grid lg:grid-cols-3 even:place-items-center gap-10 ",
               className
            )
         )}
      >
         <div className="space-y-[20px]  px-5 md:px-[40px] ">
            <SectionTitle
               animationVariant="fadeRight"
               className="xl:text-start lg:m-auto"
            >
               {" "}
               {data.title}
            </SectionTitle>

            <Text
               className="xl:text-start lg:m-auto"
               animationVariant={!matches ? "fadeUp" : "fadeRight"}
            >
               {" "}
               {data.text}{" "}
            </Text>
         </div>
         <div className="col-span-2 xl:px-5 hidden lg:block ">
            <WorkSwipper swipperData={data.cardData} className="w-full " />
         </div>
         {/* </div> */}

         <div className="lg:hidden">
            <MobileWorkSwipper swipperData={data.cardData} />
         </div>
      </div>
   );
};

export default WorkSection;
