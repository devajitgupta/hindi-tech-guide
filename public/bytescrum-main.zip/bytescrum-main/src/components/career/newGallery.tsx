"use client";

import { useRef, type FC } from "react";
import {
   motion,
   useScroll,
   useTransform,
   type MotionValue,
} from "framer-motion";
import Image from "next/image";
import { GalleryCard } from "../ui/GalleryCard";

const images = [
   { id: 0, url: "/gallery/bytes1.webp", hint: "Brainstorming session" },
   { id: 1, url: "/gallery/bytes2.webp", hint: "Brainstorming session" },
   { id: 2, url: "/gallery/bytes3.webp", hint: "Brainstorming session" },
   { id: 3, url: "/gallery/bytes4.webp", hint: "Brainstorming session" },
   { id: 4, url: "/gallery/bytes5.webp", hint: "Brainstorming session" },
   { id: 5, url: "/gallery/bytes6.webp", hint: "Brainstorming session" },
   { id: 6, url: "/gallery/bytes7.webp", hint: "Brainstorming session" },
   { id: 7, url: "/gallery/bytes8.webp", hint: "Brainstorming session" },
   { id: 8, url: "/gallery/bytes9.webp", hint: "Brainstorming session" },
   { id: 9, url: "/gallery/bytes10.webp", hint: "Brainstorming session" },
   { id: 10, url: "/gallery/bytes11.webp", hint: "Brainstorming session" },
   { id: 11, url: "/gallery/bytes12.webp", hint: "Brainstorming session" },
   { id: 12, url: "/gallery/bytes13.webp", hint: "Brainstorming session" },
   { id: 13, url: "/gallery/bytes14.webp", hint: "Brainstorming session" },
   { id: 14, url: "/gallery/bytes15.webp", hint: "Brainstorming session" },
   { id: 15, url: "/gallery/bytes16.webp", hint: "Brainstorming session" },
   { id: 16, url: "/gallery/bytes17.webp", hint: "Brainstorming session" },
   { id: 17, url: "/gallery/bytes18.webp", hint: "Brainstorming session" },
   { id: 18, url: "/gallery/bytes19.webp", hint: "Brainstorming session" },
   { id: 19, url: "/gallery/bytes20.webp", hint: "Brainstorming session" },
   { id: 20, url: "/gallery/bytes21.webp", hint: "Brainstorming session" },
];
const IMAGES_COUNT = images.length;

const GalleryImage: FC<{
   index: number;
   scrollYProgress: MotionValue<number>;
}> = ({ index, scrollYProgress }) => {
   // const totalImages = IMAGES_COUNT;
   const totalImages = IMAGES_COUNT;
   const step = 1 / totalImages;
   const start = index * step;
   const end = start + step;

   const centerIndex = (totalImages - 1) / 2;
   const finalRotate = (index - centerIndex) * 4;
   const finalX = `${4 + index * 2.5}vw`;
   const finalY = `${(index - centerIndex) * 3}vh`;

   const x = useTransform(scrollYProgress, [start, end], ["100vw", finalX]);
   const y = useTransform(scrollYProgress, [start, end], ["-50vh", finalY]);
   const rotate = useTransform(
      scrollYProgress,
      [start, end],
      [finalRotate + 20, finalRotate]
   );
   const scale = useTransform(scrollYProgress, [start, end], [1.2, 1]);
   const opacity = useTransform(
      scrollYProgress,
      [start, start + step * 0.7],
      [0, 1]
   );

   return (
      <motion.div
         style={{ x, y, rotate, scale, opacity }}
         className="absolute top-1/2 left-0 overflow-hidden"
      >
         <GalleryCard className="overflow-hidden shadow-2xl border-4 border-background/50 hover:border-accent transition-colors duration-300">
            <Image
               src={images[index].url}
               alt={`Gallery image ${index + 1}`}
               width={300}
               height={450}
               className="object-cover w-[200px] md:w-[300px]"
               priority={index < 3}
            />
         </GalleryCard>
      </motion.div>
   );
};

export const GallerySection = () => {
   const galleryRef = useRef<HTMLDivElement | null>(null);
   const { scrollYProgress } = useScroll({
      target: galleryRef,
      offset: ["start start", "end end"],
   });

   return (
      <section ref={galleryRef} className="relative h-[2500vh]">
         <div className="sticky top-0 h-screen overflow-hidden">
            <div className="absolute top-1/2 left-[5vw] md:left-[10vw] z-30 max-w-md transform -translate-y-1/2">
               <motion.h2
                  className="font-headline text-5xl md:text-7xl font-bold text-primary mb-6"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.5 }}
                  transition={{ duration: 0.5 }}
               >
                  Our Career Journey
               </motion.h2>
               <motion.p
                  className="text-lg text-foreground/80"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.5 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
               >
                  Each image represents a step forward, a lesson learned, and a
                  memory cherished. Scroll to see how we've grown.
               </motion.p>
            </div>

            <div className="relative w-full h-screen overflow-hidden">
               {images.map((_, i) => (
                  <GalleryImage
                     key={i}
                     index={i}
                     scrollYProgress={scrollYProgress}
                  />
               ))}
            </div>
         </div>
      </section>
   );
};

export default GallerySection;
