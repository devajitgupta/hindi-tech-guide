import React from "react";
import OpportunityForm from "./OpportunityForm";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import SectionTitle from "@/components/SectionTitle";
import SectionSubtitle from "@/components/SectionSubtitle";
import Text from "@/components/Text";

interface IProps {
   className: string;
   data: any;
}

const OpportunitySection = ({ className, data }: IProps) => {
   return (
      <div className={twMerge(clsx(className))}>
         <div className="grid items-center gap-[61px] ">
            <div className="m-auto space-y-5 overflow-hidden">
               <SectionTitle animationVariant="fadeUp">
                  {data.title}
               </SectionTitle>

               <Text
                  animationVariant="fadeUp"
                  className="m-auto max-w-full md:max-w-[759px]"
               >
                  {" "}
                  {data.text}{" "}
               </Text>
            </div>

            <OpportunityForm opportunityFormData={data.oportunityForm} />
         </div>
      </div>
   );
};

export default OpportunitySection;
