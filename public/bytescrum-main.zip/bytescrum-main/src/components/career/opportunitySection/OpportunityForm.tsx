"use client";
import NextUIModal from "@/components/nextUI/Modal";
import clsx from "clsx";
import { Formik, Field, Form, ErrorMessage } from "formik";
import { useState } from "react";
import { twMerge } from "tailwind-merge";
import * as Yup from "yup";
import "./opportunityForm.css";
import { EContactFormTypes } from "@/common/enums/contact-forms.enum";
import axiosInstance from "@/common/apis/axiosInstance";
import ContactUsApi from "@/common/apis/contactus.api";
import { cn } from "@nextui-org/react";
import useBreakpoints from "@/common/hooks/useBreakpoints ";

const isAtLeast18 = (dateString: any) => {
   const today = new Date();
   const birthDate = new Date(dateString);
   let age = today.getFullYear() - birthDate.getFullYear();
   const monthDifference = today.getMonth() - birthDate.getMonth();

   if (
      monthDifference < 0 ||
      (monthDifference === 0 && today.getDate() < birthDate.getDate())
   ) {
      age--;
   }

   return age >= 18;
};

const validationSchema = Yup.object({
   firstName: Yup.string().required("Required"),
   lastName: Yup.string().required("Required"),
   email: Yup.string()
      .email("Invalid email address")
      .required("Email is required"),
   phoneNumber: Yup.string().required("Required"),
   dob: Yup.string()
      .required("Required")
      .test("is-18", "Candidate should be 18 or 18+", (value) =>
         isAtLeast18(value)
      ),
   city: Yup.string().required("Required"),
   referral: Yup.string().required("Required"),
   position: Yup.string().required("Required"),
   linkedin: Yup.string().url("Invalid URL").required("Required"),
   portfolio: Yup.string().url("Invalid URL"),
   workStatus: Yup.string().required("Required"),
});

type Props = {
   opportunityFormData: any;
};

const OpportunityForm = ({ opportunityFormData }: Props) => {
   const { screenWidth } = useBreakpoints();
   const isLargeScreen = screenWidth >= 1024;
   const [isModalOpen, setIsModalOpen] = useState(false);
   const [workStatus, setWorkStatus] = useState(null);
   const handleTabChange = (status: any) => {
      setWorkStatus(status);
   };
   const [isSuccess, setIsSuccess] = useState(false);
   const [message, setMessage] = useState<string>("");
   const [modalTitle, setModalTitle] = useState<string>("");
   const [modalIcon, setModalIcon] = useState<string>("");
   const [color, setColor] = useState<string>("");

   const fieldStyle =
      "w-full px-[30px] py-[20px] bg-[#000000] rounded-[16px] border border-[#262626] text-[#b0b0b0] outline-none bg-[#090909] ";
   const errorMsgStyle = "text-red-500 ps-2 text-[12px]";

   return (
      <div className="min-h-fit flex items-center justify-center bg-black">
         <div className=" min-w-full  md:min-w-[70%] lg:min-w-[60%]">
            <Formik
               initialValues={{
                  firstName: "",
                  lastName: "",
                  email: "",
                  phoneNumber: "",
                  dob: "",
                  city: "",
                  referral: "",
                  position: "",
                  linkedin: "",
                  portfolio: "",
                  workStatus: "",
               }}
               validationSchema={validationSchema}
               onSubmit={async (values, { setSubmitting, resetForm }) => {
                  try {
                     const payload = {
                        ...values,
                        formTypes: [EContactFormTypes.CAREERS],
                     };

                     const response: any = await axiosInstance.post(
                        ContactUsApi.base,
                        payload
                     );

                     const { statusCode, message: responseMessage } =
                        response.data;

                     if (statusCode === 200 || statusCode === 201) {
                        setMessage(
                           responseMessage || "Form submitted successfully!"
                        );
                        setModalTitle("Success!");
                        setModalIcon("mdi:check-circle");
                        setColor("success");
                        setIsSuccess(true);
                        resetForm();
                        setWorkStatus(null);
                     } else {
                        setMessage(responseMessage || "Something went wrong");
                        setModalTitle("Error");
                        setModalIcon("mdi:close-circle");
                        setColor("danger");
                        setIsSuccess(false);
                     }
                  } catch (error: any) {
                     const serverMessage = error?.response?.data?.message;
                     const errorMsg =
                        serverMessage ||
                        "Something went wrong. Please try again later.";

                     if (
                        errorMsg.toLowerCase().includes("email") &&
                        errorMsg.toLowerCase().includes("already exists")
                     ) {
                        setMessage(
                           "Email already exists. Please use a different email address."
                        );
                        setIsSuccess(false);
                        setModalTitle("Oopsss..");
                        setModalIcon("mdi:alert-circle");
                        setColor("warning");
                     } else {
                        setMessage(errorMsg);
                        setModalTitle("Error");
                        setModalIcon("mdi:close-circle");

                        setColor("danger");
                     }
                     setIsSuccess(false);
                  } finally {
                     setIsModalOpen(true);
                     setSubmitting(false);
                  }
               }}
            >
               {({ isSubmitting, setFieldValue }) => (
                  <Form className="space-y-4">
                     <div className="grid md:grid-cols-2 gap-4">
                        <div>
                           <Field
                              name={opportunityFormData.firstName.name}
                              type="text"
                              placeholder={
                                 opportunityFormData.firstName.placeholder
                              }
                              className={twMerge(
                                 clsx("input-field", fieldStyle)
                              )}
                              data-aos="fade-right"
                              data-aos-easing="ease-out-cubic"
                              data-aos-anchor-placement="top-bottom"
                           />
                           <ErrorMessage
                              name={opportunityFormData.firstName.name}
                              component="div"
                              className={twMerge(clsx(errorMsgStyle))}
                           />
                        </div>
                        <div>
                           <Field
                              name={opportunityFormData.lastName.name}
                              type="text"
                              placeholder={
                                 opportunityFormData.lastName.placeholder
                              }
                              className={twMerge(
                                 clsx("input-field", fieldStyle)
                              )}
                              data-aos="fade-left"
                              data-aos-easing="ease-out-cubic"
                              data-aos-anchor-placement="top-bottom"
                           />
                           <ErrorMessage
                              name={opportunityFormData.lastName.name}
                              component="div"
                              className={twMerge(clsx(errorMsgStyle))}
                           />
                        </div>
                        <div>
                           <Field
                              name={opportunityFormData.email.name}
                              type="email"
                              placeholder={
                                 opportunityFormData.email.placeholder
                              }
                              className={twMerge(
                                 clsx("input-field", fieldStyle)
                              )}
                              data-aos="fade-right"
                              data-aos-easing="ease-out-cubic"
                              data-aos-delay={200}
                              data-aos-anchor-placement="top-bottom"
                           />
                           <ErrorMessage
                              name={opportunityFormData.email.name}
                              component="div"
                              className={twMerge(clsx(errorMsgStyle))}
                           />
                        </div>
                        <div>
                           <Field
                              name={opportunityFormData.phone.name}
                              type="text"
                              placeholder={
                                 opportunityFormData.phone.placeholder
                              }
                              className={twMerge(
                                 clsx("input-field", fieldStyle)
                              )}
                              data-aos="fade-left"
                              data-aos-easing="ease-out-cubic"
                              data-aos-delay={200}
                              data-aos-anchor-placement="top-bottom"
                           />
                           <ErrorMessage
                              name={opportunityFormData.phone.name}
                              component="div"
                              className={twMerge(clsx(errorMsgStyle))}
                           />
                        </div>
                        <div>
                           <Field
                              name={opportunityFormData.dob.name}
                              type="date"
                              placeholder={opportunityFormData.dob.placeholder}
                              className={twMerge(
                                 clsx(
                                    "input-field placeholder:text-white calendar-white-icon",
                                    fieldStyle
                                 )
                              )}
                              data-aos="fade-right"
                              data-aos-easing="ease-out-cubic"
                              data-aos-delay={400}
                              data-aos-anchor-placement="top-bottom"
                           />
                           <ErrorMessage
                              name={opportunityFormData.dob.name}
                              component="div"
                              className={twMerge(clsx(errorMsgStyle))}
                           />
                        </div>
                        <div>
                           <Field
                              name={opportunityFormData.city.name}
                              type="text"
                              placeholder={opportunityFormData.city.placeholder}
                              className={twMerge(
                                 clsx("input-field", fieldStyle)
                              )}
                              data-aos="fade-left"
                              data-aos-easing="ease-out-cubic"
                              data-aos-delay={400}
                              data-aos-anchor-placement="top-bottom"
                           />
                           <ErrorMessage
                              name={opportunityFormData.city.name}
                              component="div"
                              className={twMerge(clsx(errorMsgStyle))}
                           />
                        </div>
                        <div>
                           <Field
                              name={opportunityFormData.referral.name}
                              type="text"
                              placeholder={
                                 opportunityFormData.referral.placeholder
                              }
                              className={twMerge(
                                 clsx("input-field", fieldStyle)
                              )}
                              data-aos="fade-right"
                              data-aos-easing="ease-out-cubic"
                              data-aos-delay={600}
                              data-aos-anchor-placement="top-bottom"
                           />
                           <ErrorMessage
                              name={opportunityFormData.referral.name}
                              component="div"
                              className={twMerge(clsx(errorMsgStyle))}
                           />
                        </div>
                        <div>
                           <Field
                              name={opportunityFormData.position.name}
                              type="text"
                              placeholder={
                                 opportunityFormData.position.placeholder
                              }
                              className={twMerge(
                                 clsx("input-field", fieldStyle)
                              )}
                              data-aos="fade-left"
                              data-aos-easing="ease-out-cubic"
                              data-aos-delay={600}
                              data-aos-anchor-placement="top-bottom"
                           />
                           <ErrorMessage
                              name={opportunityFormData.position.name}
                              component="div"
                              className={twMerge(clsx(errorMsgStyle))}
                           />
                        </div>
                        <div className="md:col-span-2">
                           <Field
                              placeholder={
                                 opportunityFormData.linkedin.placeholder
                              }
                              name={opportunityFormData.linkedin.name}
                              type="text"
                              className={twMerge(
                                 clsx("input-field ", fieldStyle)
                              )}
                              data-aos="fade-up"
                              data-aos-easing="ease-out-cubic"
                              data-aos-delay={800}
                              data-aos-anchor-placement="top-bottom"
                           />
                           <ErrorMessage
                              name={opportunityFormData.linkedin.name}
                              component="div"
                              className={twMerge(clsx(errorMsgStyle))}
                           />
                        </div>
                        <div className="md:col-span-2">
                           <Field
                              name={opportunityFormData.portfolio.name}
                              type="text"
                              placeholder={
                                 opportunityFormData.portfolio.placeholder
                              }
                              className={twMerge(
                                 clsx("input-field", fieldStyle)
                              )}
                              data-aos="fade-up"
                              data-aos-easing="ease-out-cubic"
                              data-aos-delay={900}
                              data-aos-anchor-placement="top-bottom"
                           />
                           <ErrorMessage
                              name={opportunityFormData.portfolio.name}
                              component="div"
                              className={twMerge(clsx(errorMsgStyle))}
                           />
                        </div>
                     </div>
                     <div
                        className="flex items-center justify-between"
                        data-aos="fade-up"
                        data-aos-easing="ease-out-cubic"
                        data-aos-delay={1000}
                        data-aos-anchor-placement="top-bottom"
                     >
                        <div className="flex flex-col md:flex-row md:items-center md:px-[30px] md:gap-10 space-y-[20px] md:space-y-0 md:mt-5">
                           <label className="md:mr-4 text-[20px] poppins font-bold">
                              {opportunityFormData.status.title}
                           </label>
                           <div className="flex  gap-5 ">
                              <button
                                 type="button"
                                 onClick={() => {
                                    handleTabChange("Fresher");
                                    setFieldValue("workStatus", "Fresher");
                                 }}
                                 className={clsx(
                                    "px-[45px] md:px-[55px] py-[8px] md:py-[10px]  rounded-full  hover:bg-white hover:text-black transition-all  duration-1000 ease-in-out",
                                    workStatus === "Fresher"
                                       ? "bg-white text-black"
                                       : "bg-black text-white border border-white"
                                 )}
                              >
                                 {opportunityFormData.status.option.optionOne}
                              </button>
                              <button
                                 type="button"
                                 onClick={() => {
                                    handleTabChange("Experience");
                                    setFieldValue("workStatus", "Experience");
                                 }}
                                 className={clsx(
                                    "md:ml-2 px-[34px] md:px-[44px] py-[8px] md:py-[10px] rounded-full hover:bg-white hover:text-black transition-all  duration-1000 ease-in-out",
                                    workStatus === "Experience"
                                       ? "bg-white text-black"
                                       : "bg-black text-white border border-white"
                                 )}
                              >
                                 {opportunityFormData.status.option.optionTwo}
                              </button>
                           </div>
                           <ErrorMessage
                              name="workStatus"
                              component="div"
                              className={twMerge(clsx(errorMsgStyle))}
                           />
                        </div>
                     </div>
                     <div
                        data-aos="fade-up"
                        data-aos-easing="ease-out-cubic"
                        data-aos-delay={1200}
                        data-aos-anchor-placement="top-bottom"
                     >
                        <div className="flex justify-center mt-[31px] md:mt-[40px] ">
                           <button
                              type="submit"
                              disabled={isSubmitting}
                              className=" btn py-[20px] text-[16px] "
                           >
                              {isSubmitting
                                 ? "Submitting..."
                                 : opportunityFormData.submitBtnText}
                           </button>
                        </div>
                     </div>
                  </Form>
               )}
            </Formik>

            <NextUIModal
               open={isModalOpen}
               headerClass={cn({
                  "text-green-600": color === "success",
                  "text-yellow-600": color === "warning",
                  "text-red-600": color === "danger",
               })}
               titleIcon={modalIcon}
               title={modalTitle}
               color={color}
               showConfetti={isSuccess}
               onClose={() => {
                  setIsModalOpen(false);
                  setMessage("");
                  setModalTitle("");
                  setModalIcon("");
                  setColor("");
                  setIsSuccess(false);
               }}
               size="full"
            >
               <p className="text-center inter text-[#f5f5f5] text-[12px] md:text-lg leading-[24px] md:leading-[28px] poppins md:px-16 ">
                  {message}
               </p>
            </NextUIModal>
         </div>
      </div>
   );
};

export default OpportunityForm;
