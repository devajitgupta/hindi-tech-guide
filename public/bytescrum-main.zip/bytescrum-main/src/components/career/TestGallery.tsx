// components/GallerySection.tsx
"use client";

import { motion, useAnimation, useInView } from "framer-motion";
import Image from "next/image";
import { useEffect, useRef } from "react";
import SectionTitle from "../SectionTitle";
import SectionSubtitle from "../SectionSubtitle";
import { cn } from "@/libs/cn";

type Props = {
   workspaceHeader: any;
};

const TestGallery = ({ workspaceHeader }: Props) => {
   const controls = useAnimation();
   const ref = useRef(null);
   const isInView = useInView(ref, { once: false, margin: "-20%" });

   // Generate 21 image URLs (using placeholder images for demo)
   const images = [
      { id: 0, url: "/gallery/bytes21.webp", hint: "Brainstorming session" },
      { id: 1, url: "/gallery/bytes2.webp", hint: "Brainstorming session" },
      { id: 2, url: "/gallery/bytes3.webp", hint: "Brainstorming session" },
      { id: 3, url: "/gallery/bytes4.webp", hint: "Brainstorming session" },
      { id: 4, url: "/gallery/bytes5.webp", hint: "Brainstorming session" },
      { id: 5, url: "/gallery/bytes6.webp", hint: "Brainstorming session" },
      { id: 6, url: "/gallery/bytes7.webp", hint: "Brainstorming session" },
      { id: 7, url: "/gallery/bytes8.webp", hint: "Brainstorming session" },
      { id: 8, url: "/gallery/bytes9.webp", hint: "Brainstorming session" },
      { id: 9, url: "/gallery/bytes10.webp", hint: "Brainstorming session" },
      { id: 10, url: "/gallery/bytes11.webp", hint: "Brainstorming session" },
      { id: 11, url: "/gallery/bytes12.webp", hint: "Brainstorming session" },
      { id: 12, url: "/gallery/bytes13.webp", hint: "Brainstorming session" },
      { id: 13, url: "/gallery/bytes14.webp", hint: "Brainstorming session" },
      { id: 17, url: "/gallery/bytes18.webp", hint: "Brainstorming session" },
      { id: 15, url: "/gallery/bytes16.webp", hint: "Brainstorming session" },
      { id: 16, url: "/gallery/bytes17.webp", hint: "Brainstorming session" },
      { id: 14, url: "/gallery/bytes15.webp", hint: "Brainstorming session" },
      { id: 18, url: "/gallery/bytes19.webp", hint: "Brainstorming session" },
      { id: 19, url: "/gallery/bytes20.webp", hint: "Brainstorming session" },
      { id: 20, url: "/gallery/bytes1.webp", hint: "Brainstorming session" },
   ];

   // Animation sequence
   useEffect(() => {
      if (isInView) {
         const sequence = async () => {
            // Start all images off-screen to the right
            await controls.start((i) => ({
               x: "100vw",
               opacity: 0,
               transition: { duration: 0 },
            }));

            // Animate each image in sequence with a delay
            for (let i = 0; i < images.length; i++) {
               await controls.start((i) => ({
                  x: i === i ? 0 : "100vw",
                  opacity: i === i ? 1 : 0,
                  transition: {
                     type: "spring",
                     stiffness: 100,
                     damping: 15,
                     delay: i * 0.1,
                  },
               }));
            }
         };

         sequence();
      }
   }, [controls, isInView, images.length]);

   return (
      <section ref={ref} className="py-10">
         <div className="container mx-auto px-4">
            <motion.div
               initial={{ opacity: 0, y: 20 }}
               animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
               transition={{ duration: 0.6 }}
               className="text-center mb-16"
            >
               <SectionTitle>{workspaceHeader.title}</SectionTitle>
               <SectionSubtitle className="m-auto">
                  {workspaceHeader.subtitle}
               </SectionSubtitle>
            </motion.div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
               {images.map((image, index) => (
                  <motion.div
                     key={image.id}
                     custom={index}
                     animate={controls}
                     className={cn(
                        "relative aspect-square overflow-hidden rounded-xl shadow-2xl border border-slate-700 hover:border-[#676767] transition-all duration-300",
                        {
                           "col-span-2 row-span-2":
                              image.id === 0 ||
                              image.id === 9 ||
                              image.id === 14,
                           "col-span-1 row-span-1":
                              image.id !== 0 &&
                              image.id !== 9 &&
                              image.id !== 14,
                        }
                     )}
                     whileHover={{ scale: 1.05, zIndex: 10 }}
                  >
                     <Image
                        src={image.url}
                        alt={image.url}
                        fill
                        className="object-cover"
                        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                     />
                     <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                        {/* <span className="text-white font-medium">
                           Image {image.id}
                        </span> */}
                     </div>
                  </motion.div>
               ))}
            </div>
         </div>
      </section>
   );
};

export default TestGallery;
