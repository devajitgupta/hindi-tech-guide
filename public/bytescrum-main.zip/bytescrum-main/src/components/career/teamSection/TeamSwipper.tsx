"use client";

import { Swiper, SwiperSlide } from "swiper/react";
import { A11y, Autoplay, Pagination } from "swiper/modules";
import { useState } from "react";
// import useBreakpoints from "@/common/hooks/useBreakpoints ";
import { useMediaQuery } from "@react-hook/media-query";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import "./teamSwiperStyle.css";
import { motion } from "framer-motion";
import { cn } from "@/libs/cn";
import Image from "next/image";

interface IProps {
   className?: string;
   swipperData: any;
}

const TeamSwipper = ({ className, swipperData }: IProps) => {
   const [activeIndex, setActiveIndex] = useState(0);
   const [realIndex, setRealIndex] = useState(0);
   // const { screenWidth } = useBreakpoints();
   const matches = useMediaQuery("(max-width: 768px)");

   const variants = {
      initial: {
         backgroundPosition: "0% 50%",
      },
      animate: {
         backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
      },
   };

   function getRandomColor(isDark: boolean): string {
      // Avoid black and white by limiting the range
      let color: string;
      while (true) {
         const r = Math.floor(Math.random() * 256);
         const g = Math.floor(Math.random() * 256);
         const b = Math.floor(Math.random() * 256);
         // Calculate luminance
         const luminance = 0.299 * r + 0.587 * g + 0.114 * b;
         if (isDark && luminance < 100 && luminance > 10) {
            color = `#${r.toString(16).padStart(2, "0")}${g
               .toString(16)
               .padStart(2, "0")}${b.toString(16).padStart(2, "0")}`;
            break;
         }
         if (!isDark && luminance > 180 && luminance < 245) {
            color = `#${r.toString(16).padStart(2, "0")}${g
               .toString(16)
               .padStart(2, "0")}${b.toString(16).padStart(2, "0")}`;
            break;
         }
      }
      return color;
   }

   function generateRandomDarkAndLightColor(): { dark: string; light: string } {
      return {
         dark: getRandomColor(true),
         light: getRandomColor(false),
      };
   }

   function generatePredefinedGradientColors(): {
      dark: string;
      light: string;
      medium: string;
   } {
      // const gradientCombinations = [
      //    // Purple to Pink
      //    { dark: "#8B5CF6", light: "#EC4899" },
      //    // Blue to Cyan
      //    { dark: "#3B82F6", light: "#06B6D4" },
      //    // Green to Teal
      //    { dark: "#10B981", light: "#14B8A6" },
      //    // Orange to Red
      //    { dark: "#F97316", light: "#EF4444" },
      //    // Pink to Purple
      //    { dark: "#EC4899", light: "#A855F7" },
      //    // Cyan to Blue
      //    { dark: "#06B6D4", light: "#3B82F6" },
      //    // Yellow to Orange
      //    { dark: "#F59E0B", light: "#F97316" },
      //    // Teal to Green
      //    { dark: "#14B8A6", light: "#10B981" },
      //    // Indigo to Purple
      //    { dark: "#6366F1", light: "#8B5CF6" },
      //    // Rose to Pink
      //    { dark: "#F43F5E", light: "#EC4899" },
      //    // Emerald to Cyan
      //    { dark: "#059669", light: "#0891B2" },
      //    // Amber to Yellow
      //    { dark: "#D97706", light: "#EAB308" },
      // ];
      const gradientCombinations = [
         // Purple to Pink
         { dark: "#8B5CF6", light: "#EC4899", medium: "#BF52C5" },
         // Blue to Cyan
         { dark: "#3B82F6", light: "#06B6D4", medium: "#219CE5" },
         // Green to Teal
         { dark: "#10B981", light: "#14B8A6", medium: "#12B893" },
         // Orange to Red
         { dark: "#F97316", light: "#EF4444", medium: "#F45B2D" },
         // Pink to Purple
         { dark: "#EC4899", light: "#A855F7", medium: "#C74EC8" },
         // Cyan to Blue
         { dark: "#06B6D4", light: "#3B82F6", medium: "#1FA4E5" },
         // Yellow to Orange
         { dark: "#F59E0B", light: "#F97316", medium: "#F78811" },
         // Teal to Green
         { dark: "#14B8A6", light: "#10B981", medium: "#12B893" },
         // Indigo to Purple
         { dark: "#6366F1", light: "#8B5CF6", medium: "#7761F3" },
         // Rose to Pink
         { dark: "#F43F5E", light: "#EC4899", medium: "#F0437B" },
         // Emerald to Cyan
         { dark: "#059669", light: "#0891B2", medium: "#06948D" },
         // Amber to Yellow
         { dark: "#D97706", light: "#EAB308", medium: "#E19507" },
      ];

      const randomIndex = Math.floor(
         Math.random() * gradientCombinations.length
      );
      return gradientCombinations[randomIndex];
   }

   return (
      <div
         className={twMerge(
            clsx(
               " transition-transform duration-200 ease-in-out transform px-4",
               className
            )
         )}
      >
         <Swiper
            modules={[Pagination, A11y, Autoplay]}
            spaceBetween={10}
            loop={true}
            navigation
            pagination={{
               clickable: true,
            }}
            scrollbar={{ draggable: true }}
            onSwiper={(swiper) => console.log(swiper)}
            className="min-h-[270px] md:min-h-[375px] lg:min-h-[425px]  "
            // onSlideChange={(swiper) => {
            //    setActiveIndex(swiper.activeIndex);
            //    setRealIndex(swiper.realIndex);
            // }}
            followFinger={true}
            autoplay={{
               delay: 3000,
               disableOnInteraction: false,
            }}
            speed={1100}
            breakpoints={{
               0: {
                  slidesPerView: 2,
                  spaceBetween: 10,
               },
               567: {
                  slidesPerView: 3,
                  spaceBetween: 20,
               },

               992: {
                  slidesPerView: 5,
                  spaceBetween: 10,
               },
            }}
         >
            {/* <div className=" grid grid-cols-4 place-items-center "> */}
            {swipperData.map((teamMemeber: any, index: number) => (
               <SwiperSlide key={teamMemeber._id} className="grid    py-10 ">
                  <div className="bg-[#090909]  rounded-[14px] border border-[#262626] md:rounded-[26px] p-2">
                     <motion.div className={cn("relative  group")}>
                        {/* <motion.div
                        variants={variants}
                        style={{
                           backgroundImage: `
   radial-gradient(circle farthest-side at 100% 0, 
      ${generatePredefinedGradientColors().dark}, 
      ${generatePredefinedGradientColors().medium}, 
      ${generatePredefinedGradientColors().light}),
   radial-gradient(circle farthest-side at 100% 100%, 
      ${generatePredefinedGradientColors().dark}, 
      ${generatePredefinedGradientColors().medium}, 
      ${generatePredefinedGradientColors().light}),
   radial-gradient(circle farthest-side at 0 0, 
      ${generatePredefinedGradientColors().dark}, 
      ${generatePredefinedGradientColors().medium}, 
      ${generatePredefinedGradientColors().light})`,
                        }}
                        className={cn(
                           "absolute inset-0 rounded-3xl z-[1] opacity-20 group-hover:opacity-60 blur-md transition duration-500 will-change-transform "
                        )}
                     /> */}
                        <motion.div
                           variants={variants}
                           style={{
                              backgroundImage: `
   radial-gradient(circle farthest-side at 100% 0, 
      ${generatePredefinedGradientColors().dark}, 
      ${generatePredefinedGradientColors().light}),
   radial-gradient(circle farthest-side at 100% 100%, 
      ${generatePredefinedGradientColors().dark}, 

      ${generatePredefinedGradientColors().light}),
   radial-gradient(circle farthest-side at 0 0, 
      ${generatePredefinedGradientColors().dark}, 

      ${generatePredefinedGradientColors().light}) 
     `,
                           }}
                           className={cn(
                              "absolute inset-0 opacity-100 rounded-[12px] md:rounded-[24px] z-[1]"
                           )}
                        />

                        <motion.div className={cn("relative z-10", className)}>
                           {" "}
                           <div
                              className=" rounded-[10px] md:rounded-[20px]  bg-[#fff]/70 border-white/30 backdrop-blur-3xl space-y-[5px] md:space-y-[10px] max-w-[185px] md:max-w-full m-auto"
                              // data-aos="flip-left"
                              // data-aos-easing="ease-out-cubic"
                              // data-aos-delay={index + 2 * 350}
                              // data-aos-anchor-placement="top-bottom"
                           >
                              <motion.img
                                 src={teamMemeber.src}
                                 width={matches ? 176 : 305}
                                 height={0}
                                 alt={teamMemeber.src}
                                 className="h-auto rounded-[10px] md:rounded-[20px] w-full object-cover brightness-105   "
                              />
                           </div>
                        </motion.div>
                     </motion.div>
                     <motion.h3 className="poppins md:bottom-2 text-[12px] md:text-[20px] font-bold text-[#ffffff] ms-[5px] md:ms-[10px] mt-5">
                        {teamMemeber.name}
                     </motion.h3>
                     <motion.p className="poppins  md:bottom-2 opacity-50 text-[10px] md:text-[16px]  text-[#ffffff] ms-[5px] md:ms-[10px]">
                        {teamMemeber.role}
                     </motion.p>
                  </div>
               </SwiperSlide>
            ))}
            {/* </div> */}
         </Swiper>
      </div>
   );
};

export default TeamSwipper;
