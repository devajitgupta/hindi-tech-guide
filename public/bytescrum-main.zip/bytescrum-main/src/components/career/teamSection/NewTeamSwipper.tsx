"use client";
import React, { useRef, useState } from "react";
// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";
import { useMediaQuery } from "@react-hook/media-query";
import "./newTeamSwipper.css";

// import required modules
import { FreeMode, Autoplay, Pagination } from "swiper/modules";
import Image from "next/image";

interface IProps {
   className?: string;
   swipperData: any;
}
export default function NewTeamSwipper({ className, swipperData }: IProps) {
   const matches = useMediaQuery("(max-width: 768px)");
   return (
      <>
         <Swiper
            slidesPerView={matches ? 2 : 4}
            spaceBetween={30}
            // freeMode={true}
            loop={true}
            navigation
            pagination={{
               clickable: true,
            }}
            autoplay={{
               delay: 1500,
               disableOnInteraction: false,
            }}
            speed={1500}
            modules={[FreeMode, Pagination, Autoplay]}
            className="mySwiper"
         >
            {swipperData.map((teamMemeber: any, index: number) => (
               <SwiperSlide>
                  <div
                     className="p-[5px] border border-[#262626] md:p-[10px] rounded-[9px] md:rounded-[16px] bg-[#090909] space-y-[5px] md:space-y-[10px] max-w-[185px] md:max-w-[325px] m-auto"
                     data-aos="flip-left"
                     data-aos-easing="ease-out-cubic"
                     data-aos-delay={index + 2 * 350}
                     data-aos-anchor-placement="top-bottom"
                  >
                     <Image
                        src={teamMemeber.src}
                        width={matches ? 176 : 305}
                        height={0}
                        alt={teamMemeber.src}
                        className="h-auto"
                     />
                     <h3 className="poppins text-[12px] md:text-[20px] font-bold text-[#ffffff] ms-[5px] md:ms-[10px]  ">
                        {teamMemeber.name}
                     </h3>
                  </div>
               </SwiperSlide>
            ))}
         </Swiper>
      </>
   );
}
