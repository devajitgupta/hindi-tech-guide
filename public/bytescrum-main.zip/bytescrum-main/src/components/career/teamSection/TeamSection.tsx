"use client";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import TeamSwipper from "./TeamSwipper";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";

interface IProps {
   className?: string;
   data: any;
}

const TeamSection = ({ className, data }: IProps) => {
   return (
      <div
         className={twMerge(
            clsx("space-y-[30px]    md:space-y-[40px]", className)
         )}
      >
         <div className="grid items-center gap-24 ">
            <div className="m-auto space-y-5 overflow-hidden">
               <SectionTitle animationVariant="fadeUp">
                  {" "}
                  {data.title}
               </SectionTitle>
               <Text animationVariant="fadeUp" className="m-auto">
                  {data.text}{" "}
               </Text>
            </div>
         </div>
         <TeamSwipper swipperData={data.teams} />
      </div>
   );
};

export default TeamSection;
