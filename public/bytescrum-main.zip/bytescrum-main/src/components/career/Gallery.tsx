import clsx from "clsx";
import { motion } from "framer-motion";
import React from "react";

const Gallery = ({ images }: any) => {
   return (
      <div
         className={clsx(
            "grid grid-cols-5 md:py-20 grid-rows-2 gap-x-5 gap-y-2 w-[120%] md:w-[97%] "
         )}
      >
         {images.map((src: any, index: number) => {
            return (
               <motion.div
                  key={index}
                  className={clsx("grid mx-auto overflow-hidden", {
                     "items-center justify-start row-span-2": src._id === 1,
                     "items-center": src._id === 2,
                     "items-center justify-center":
                        src._id === 3 || src._id === 7,
                     "items-start justify-center":
                        src._id === 4 || src._id === 8,
                     "items-start justify-end": src._id === 5 || src._id === 9,
                     "  justify-end -mt-3 md:mt-12": src._id === 6,
                     "-mt-6 md:-mt-16 lg:-mt-24  xl:-mt-32": src._id === 8,
                  })}
                  style={{ width: src.width }}
                  whileHover={{
                     filter: "drop-shadow(0px 10px 20px rgba(20, 99, 253,0.3))",
                     // border: "10px solid blue",
                     position: "relative",
                     zIndex: 20,
                  }}
                  transition={{
                     duration: 0.3,
                     ease: "easeInOut",
                     type: "spring",
                  }}
               >
                  <motion.img
                     src={src.img}
                     width={src.width}
                     height={src.height}
                     alt={src.img}
                     whileHover={{
                        scale: 1.3,
                        position: "relative",
                        zIndex: 20,
                     }}
                     transition={{
                        duration: 0.1,
                        ease: "easeInOut",
                        type: "spring",
                     }}
                     className={clsx(
                        "shadow-none",
                        {
                           "-mt-5 md:-mt-16": src._id == 3,
                        },
                        {
                           " -mt-8 md:-mt-28": src._id == 7,
                        }
                     )}
                     data-aos="fade-up"
                     data-aos-easing="ease-out-cubic"
                     data-aos-delay={index * 50}
                     data-aos-anchor-placement="top-bottom"
                  />
               </motion.div>
            );
         })}
      </div>
   );
};

export default Gallery;
