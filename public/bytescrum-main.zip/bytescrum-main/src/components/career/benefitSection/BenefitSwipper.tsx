"use client";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import { EffectCoverflow } from "swiper/modules";
import { useState } from "react";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import Image from "next/image";
import "../careerStyle.css";
import useRandomNumber from "@/common/hooks/useRandomNumber";

interface IProps {
   swipperData: any;
   className?: string;
}

const BenefitSwipper = ({ swipperData, className }: IProps) => {
   const [currentSlide, setCurrentSlide] = useState(0);
   const randomNumber = useRandomNumber(swipperData.length, 5000);

   return (
      <div
         className={twMerge(
            clsx(
               " transition-transform duration-200 ease-in-out transform ",
               className
            )
         )}
      >
         <Swiper
            spaceBetween={-100}
            autoplay={{
               delay: 3000,
               disableOnInteraction: true,
            }}
            pagination={true}
            modules={[Pagination, EffectCoverflow, Autoplay]}
            effect={"coverflow"}
            grabCursor={false}
            centeredSlides={true}
            slidesPerView={"auto"}
            followFinger={true}
            initialSlide={3}
            simulateTouch={true}
            speed={1700}
            roundLengths={true}
            coverflowEffect={{
               rotate: 0,
               stretch: 50,
               depth: 100,
               modifier: 3,
               slideShadows: true,
            }}
            loop={true}
            onSlideChange={(swiper) => setCurrentSlide(swiper.realIndex)}
            className=" workswiper h-[375px] overflow-visible"
         >
            {" "}
            {swipperData.map((item: any, index: number) => (
               <SwiperSlide
                  key={item._Id}
                  className={twMerge(
                     clsx(
                        "border border-[#262626] max-w-[300px] max-h-[331px] rounded-[16px] bg-[#262626]/30 px-7 py-10",
                        {
                           " backdrop-blur-md z-[9999] opacity-100":
                              currentSlide === index,
                        },
                        {
                           " backdrop-blur-md z-[-10] ": index - 1,
                        }
                     )
                  )}
                  data-aos="flip-left"
                  data-aos-easing="ease-out-cubic"
                  data-aos-delay={index * 150}
                  data-aos-anchor-placement="top-bottom"
               >
                  <div className="space-y-[30px]">
                     <Image
                        src={item.icon}
                        width={item.width ? item.width : 50}
                        height={item.height ? item.height : 50}
                        alt="img"
                     />

                     <h3 className="poppins text-[20px] md:text-[24px] font-bold ">
                        {item.title}
                     </h3>
                  </div>
                  <p className="text-[16px] leading-[28px] text-[#f5f5f5] w-full">
                     {item.text}
                  </p>
               </SwiperSlide>
            ))}
         </Swiper>
      </div>
   );
};

export default BenefitSwipper;
