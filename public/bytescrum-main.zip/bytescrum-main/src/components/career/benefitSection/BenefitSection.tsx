"use client";

import useBreakpoints from "@/common/hooks/useBreakpoints ";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import "../careerStyle.css";
import useRandomNumber from "@/common/hooks/useRandomNumber";
import SectionTitle from "@/components/SectionTitle";
import SectionSubtitle from "@/components/SectionSubtitle";
import Text from "@/components/Text";
import Image from "next/image";
import ExperienceCard from "@/components/service/hireDeveloper/experienceSection/ExperienceCard";

interface IProps {
   className: string;
   data: any;
}

const BenefitSection = ({ className, data }: IProps) => {
   const randomNumber = useRandomNumber(data.cardData.length, 5000);
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth <= 430;

   return (
      <div className={twMerge(clsx(className))}>
         <div className="grid items-center justify-center gap-24 ">
            <div className="m-auto overflow-hidden space-y-[9px] md:space-y-[12px]  ">
               <Text
                  className="text-center text-[14px] md:text-[16px] leading-[24px] md:leading-[28px] border border-[#262626] py-[4px] px-[30px] rounded-full bg-[#090909] space-y-[10px] inter block m-auto w-fit "
                  animationVariant="fadeUp"
               >
                  {data.text}
               </Text>
               <SectionTitle animationVariant="fadeUp">
                  {" "}
                  {data.title}
               </SectionTitle>
               <SectionSubtitle
                  className="m-auto max-w-full md:max-w-[759px] "
                  textSize="sm"
                  animationVariant="fadeUp"
               >
                  {" "}
                  {data.subTitle}{" "}
               </SectionSubtitle>
            </div>

            <div className=" hidden md:grid grid-cols-2 xl:grid-cols-3 gap-5 items-center justify-center">
               {data.cardData.map((item: any, index: number) => (
                  <ExperienceCard
                     key={index}
                     _id={index}
                     icon={item.icon}
                     title={item.title}
                     text={item.text}
                     width={matches ? 45 : item.width}
                     height={matches ? 45 : item.height}
                     className={clsx(" !w-full h-full ", {
                        randomBlob: index === randomNumber,
                     })}
                     cardWrapper={
                        "!w-[380px] !h-[245px]  !lg:w-[380px] !lg:h-[335px]"
                     }
                     cardContentWrapper={"p-10 lg:p-10"}
                  />
               ))}
            </div>
         </div>
      </div>
   );
};

export default BenefitSection;
