"use client";
import PageBanner from "../PageBanner";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import { usePathname } from "next/navigation";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import Image from "next/image";

interface IProps {
   data: any;
}

const CareerBanner = ({ data }: IProps) => {
   const pathName = usePathname();
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth <= 430;
   return (
      <PageBanner bgPath={"/aboutUs/banner.png"}>
         <div className="grid place-items-center md:gap-[10px]">
            <h1
               className="text-[35px] md:text-[70px] md:leading-[80px] font-bold  poppins text-center"
               data-aos="zoom-in"
               data-aos-easing="ease-out-cubic"
               data-aos-anchor-placement="top-bottom"
            >
               {data.pageTitleLineOne}
               <br />
               <span className="font-light">{data.pageTitleLineTwo}</span>
            </h1>
            <p
               className="poppins text-[#b7b7b7] text-[14px] md:text-[18px]"
               data-aos="zoom-in"
               data-aos-easing="ease-out-cubic"
               data-aos-delay={500}
               data-aos-anchor-placement="top-bottom"
            >
               {data.links.map((link: any, index: number) => (
                  <span
                     className={clsx(
                        " text-white first:border-r first:px-3 px-2",
                        {
                           "first:text-[#b7b7b7]": pathName !== `/${pathName}`,
                        }
                     )}
                     key={index}
                  >
                     {link}
                  </span>
               ))}
            </p>
         </div>
      </PageBanner>
   );
};

export default CareerBanner;
