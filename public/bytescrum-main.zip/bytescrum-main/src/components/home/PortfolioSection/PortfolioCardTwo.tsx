"use client";
import { useEffect, useState } from "react";
import clsx from "clsx";
import { Icon } from "@iconify/react/dist/iconify.js";
import { twMerge } from "tailwind-merge";
import "./portfolio.css";
import { useMediaQuery } from "@react-hook/media-query";
import Text from "@/components/Text";

interface IProps {
   id?: any;
   classNameName?: string;
   technology?: string;
   project?: string;
   text?: string;
   items?: any;
   interval?: number;
   transitionDuration?: number;
   _index?: number;
   flipTrigger?: boolean;
   delay?: number;
   cardHeight?: number;
   onClick?: () => void;
}

const PortfolioCardTwo = ({
   technology,
   project,
   text,
   items,
   interval = 1000,
   classNameName,
   delay,
   flipTrigger,
   cardHeight = 360,
   _index,
   onClick,
   id,
}: IProps) => {
   const [currentIndex, setCurrentIndex] = useState(0);
   const isSmallScreen = useMediaQuery("(max-width: 639px)");
   const isMediumScreen = useMediaQuery(
      "(min-width: 640px) and (max-width: 1023px)"
   );
   const [flipclassName, setFlipclassName] = useState("portfolioFlipCardX");

   useEffect(() => {
      const classNameInterval = setInterval(async () => {
         const newclassName =
            Math.random() < 0.5 ? "portfolioFlipCardX" : "portfolioFlipCardX";
         await new Promise((resolve) => setTimeout(resolve, delay));
         setFlipclassName(newclassName);
      }, interval);

      return () => clearInterval(classNameInterval);
   }, [delay, interval]);

   useEffect(() => {
      if (flipTrigger) {
         const intervalId = setInterval(() => {
            setCurrentIndex((prevIndex) => (prevIndex + 1) % items?.length);
         }, interval);

         return () => clearInterval(intervalId);
      }
   }, [flipTrigger, items?.length, interval]);

   const getTextDisplay = () => {
      if (isSmallScreen) {
         return text?.split(" ").slice(0, 25).join(" ") + "...";
      } else if (isMediumScreen) {
         return text?.split(" ").slice(0, 100).join(" ") + "...";
      }
      return text;
   };

   return (
      <div className=" overflow-hidden rounded-[10px] md:rounded-[16px] ">
         <div
            className={twMerge(
               clsx(
                  "card min-w-[50px] max-w-full min-h-[150px] max-h-[200px] sm:min-h-[250px] md:min-w-[250px] md:max-w-full  md:min-h-[400px] md:max-h-[400px] rounded-[10px] md:rounded-[16px] "
               )
            )}
         >
            <div
               className={twMerge(
                  clsx(
                     "face back  rounded-[0px] md:rounded-[10px] bg-white  overflow-hidden"
                  )
               )}
            >
               <div className="content overflow-hidden ">
                  <span className="stars"></span>
                  <div className="desc">
                     <div className=" ">
                        <p className="tracking-[1.2px] text-[10px] md:text-[12px] uppercase laeding-[24px]">
                           {technology}
                        </p>
                        <h3 className="text-[16px] md:text-[22px] font-bold line-clamp-1">
                           {project}
                        </h3>
                     </div>
                  </div>
                  <Text className="desc text-start  text-[#fff] !leading-[16px] !font-medium md:!leading-[28px] line-clamp-6 ">
                     {getTextDisplay()}
                  </Text>
               </div>
            </div>
            <div className="face front relative cursor:pointer">
               {items?.map((item: any, index: number) => (
                  <img
                     key={index}
                     src={item}
                     width={1000}
                     height={0}
                     property="true"
                     alt={item}
                     className={twMerge(
                        clsx(
                           `w-full h-full portfolioFlipCardInner  inset-0 object-cover cursor-pointer ${
                              index === currentIndex
                                 ? "opacity-100 absolute top-0 isHovered"
                                 : `opacity-0  ${flipclassName} transition delay-${delay}ms`
                           }`
                        )
                     )}
                  />
               ))}
               <div
                  className={twMerge(
                     clsx(
                        "absolute bottom-0  rounded-[0px] p-2 md:p-4 flex items-center justify-between w-full h-full max-h-[55px]   md:max-h-[80px] group-hover:hidden  duration-700 ease-in-out bg-gradient-to-b from-transparent to-black cursor-pointer gap-2   "
                     )
                  )}
                  // className={twMerge(
                  //    clsx(
                  //       "absolute sm:bottom-0  rounded-[0px] px-4 py-2 md:p-4 grid place-items-center justify-center sm:flex sm:items-center sm:justify-between w-full h-full sm:max-h-[55px]   md:max-h-[80px] group-hover:hidden  duration-700 ease-in-out bg-gradient-to-b from-transparent to-black cursor-pointer gap-2   "
                  //    )
                  // )}
                  onClick={onClick}
               >
                  <div className="cursor-pointer overflow-hidden  max-w-[80%]">
                     <p className="tracking-[1.2px] text-center sm:text-start text-[12px] uppercase laeding-[24px]  truncate  ">
                        {technology}
                     </p>
                     <h3 className="text-[18px] text-start md:text-[22px] font-bold overflow-hidden line-clamp-2 md:line-clamp-none max-w-[150px] md:truncate  md:max-w-[300px] ">
                        {project}
                     </h3>
                  </div>
                  {id && (
                     <Icon
                        icon="uim:angle-right"
                        className={twMerge(
                           clsx(
                              "text-[32px] ml-auto md:text-[40px] border-2 border-white rounded-full hover:bg-white hover:text-black  cursor-pointer"
                           )
                        )}
                     />
                  )}
               </div>
            </div>
         </div>
      </div>
   );
};

export default PortfolioCardTwo;
