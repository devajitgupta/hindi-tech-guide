"use client";
import clsx from "clsx";
import { useEffect, useRef, useState } from "react";
import { twMerge } from "tailwind-merge";
import tabs from "../../../common/data/homeData.json";
import { Button } from "@nextui-org/react";

interface IProps {             
   className?: string;
   animationDirection?: string;
   selectedTab: string;
   setSelectedTab: (tab: string) => void;
}

const PortFolioTab = ({
   className,
   animationDirection = "fade-left",
   selectedTab,
   setSelectedTab,
}: IProps) => {
   const tabRefs = useRef<{ [key: string]: HTMLButtonElement | null }>({});
   const [hasUserSelected, setHasUserSelected] = useState(false);
   const handleSelected = (tab: string) => {
      setHasUserSelected(true);
      setSelectedTab(tab);
   };

   useEffect(() => {
      if (
         hasUserSelected &&
         window.innerWidth < 1530 &&
         tabRefs.current[selectedTab]
      ) {
         const tabContainer = tabRefs.current[selectedTab]?.parentElement;
         const tabIndex = tabs.portfolioSection.tabs.indexOf(selectedTab);
         const isFirstTab = tabIndex === 0;
         const isLastTab = tabIndex === tabs.portfolioSection.tabs.length - 1;
         const offset = 2000;
         if (tabContainer) {
            const tabElement = tabRefs.current[selectedTab] as HTMLElement;
            const tabRect = tabElement.getBoundingClientRect();
            const containerRect = tabContainer.getBoundingClientRect();

            if (isFirstTab) {
               tabContainer.scrollLeft +=
                  tabRect.left - containerRect.left - offset;
            } else if (isLastTab) {
               tabContainer.scrollLeft +=
                  tabRect.right - containerRect.right + offset;
            } else {
               tabElement.scrollIntoView({
                  behavior: "smooth",
                  block: "nearest",
                  inline: "center",
               });
            }
         }
      }
   }, [selectedTab, hasUserSelected]);

   return (
      <div
         className={twMerge(
            clsx(
               "flex items-center bg-[#626262]/10 rounded-full p-2 w-fit justify-center md:items-start gap-1 md:gap-2 ",
               className
            )
         )}
      >
         {tabs.portfolioSection.tabs.map((tab, index) => {
            const buttonClasses = clsx("rounded-full outline-none ", {
               "!bg-[#1463FD] text-white  !border-[#1463FD] font-bold  ":
                  tab === selectedTab,
               "!bg-[#fff] !text-[#000] border-2 border-[#a8a8a8] ":
                  tab !== selectedTab,
            });
            return (
               <Button
                  key={tab}
                  ref={(el) => {
                     tabRefs.current[tab] = el;
                  }}
                  className={twMerge(
                     clsx(
                        " text-white min-w-[150px]  hover:bg-[#1463FD]  ",
                        buttonClasses
                     )
                  )}
                  onClick={() => handleSelected(tab)}
               >
                  {tab}
               </Button>
            );
         })}
      </div>
   );
};

export default PortFolioTab;
