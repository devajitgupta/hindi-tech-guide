"use client";
import clsx from "clsx";
import React, { useEffect, useState } from "react";
import { useMediaQuery } from "@react-hook/media-query";
import { Icon } from "@iconify/react/dist/iconify.js";
import { twMerge } from "tailwind-merge";
import { Pagination, PaginationItem } from "@nextui-org/react";
import { usePathname } from "next/navigation";
import { useRouter } from "next/navigation";
import { slugify } from "@/common/utils/slugify";
import homeData from "../../../common/data/homeData.json";
import PortfolioCardTwo from "./PortfolioCardTwo";

interface IProps {
   className?: string;
   cardHeight?: number;
   selectedTab: string;
   langText: any;
   lang: string;
}

const PortfolioTwo = ({
   className,
   cardHeight,
   selectedTab,
   langText,
   lang,
}: IProps) => {
   const pathName = usePathname();
   const router = useRouter();
   const [flipIndex, setFlipIndex] = useState(0);
   const [showAll, setShowAll] = useState(false);
   const [currentPage, setCurrentPage] = useState(1);
   const portfolioData = langText?.portfolioSection?.portfolioData || [];

   const isSmallScreen = useMediaQuery("(max-width: 639px)");
   const isMediumScreen = useMediaQuery(
      "(min-width: 640px) and (max-width: 1023px)"
   );
   const isLargeScreen = useMediaQuery("(min-width: 1024px)");

   // Different items per page based on path
   // Different items per page based on path
   const itemsPerPage =
      pathName === "/"
         ? isSmallScreen || isMediumScreen
            ? 6
            : 6
         : pathName === "/portfolio" ||
           pathName === "/es/portfolio" ||
           pathName === "/fr/portfolio" ||
           pathName === "/nl/portfolio"
         ? isSmallScreen || isMediumScreen
            ? 4
            : 8
         : isSmallScreen || isMediumScreen
         ? 2
         : 8;

   // Filter portfolio data based on the selected tab
   const filteredPortfolio = portfolioData.filter(
      (item: any) =>
         selectedTab === "All Works" || item.category === selectedTab
   );

   // Calculate total pages based on filtered data
   const totalPages = Math.ceil(filteredPortfolio.length / itemsPerPage);

   const handlePageChange = (page: number) => {
      setCurrentPage(page);
   };

   // Calculate start and end index for pagination
   const startIndex = (currentPage - 1) * itemsPerPage;
   const endIndex = startIndex + itemsPerPage;

   // Get paginated data
   const data = filteredPortfolio.slice(startIndex, endIndex);

   const handlePortfolioClick = (project: string) => {
      if (!project) return;
      router.push(`/${lang}/${slugify(project)}`);
   };

   useEffect(() => {
      const interval = setInterval(() => {
         setFlipIndex((prevIndex) => (prevIndex + 1) % data.length);
      }, 1500);

      return () => clearInterval(interval);
   }, [selectedTab, data]);

   return (
      <div>
         <div
            className={twMerge(
               clsx(
                  "grid md:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-4 px-5"
               ),
               className
            )}
         >
            {data.map((portfolio: any, index: any) => (
               <div
                  key={index}
                  className={clsx(
                     "rounded-[2px] md:rounded-[16px] overflow-hidden"
                  )}
               >
                  <PortfolioCardTwo
                     id={portfolio._id}
                     items={portfolio.items}
                     project={portfolio.project}
                     technology={portfolio.technology}
                     text={portfolio.text}
                     _index={index}
                     transitionDuration={portfolio.transitionDuration}
                     interval={portfolio.interval}
                     flipTrigger={index === flipIndex}
                     delay={index * 150}
                     cardHeight={cardHeight}
                     onClick={() => handlePortfolioClick(portfolio._id)}
                  />
               </div>
            ))}
         </div>

         {/* View More button for homepage only */}
         {/* {!isLargeScreen && pathName === "/" && (
            <button
               onClick={() => setShowAll(!showAll)}
               className={clsx(
                  "absolute flex items-center justify-center right-5 mt-5 text-white opacity-50 hover:opacity-100",
                  {
                     "border text-2xl p-2 rounded-full": showAll,
                     "rounded p-5": !showAll,
                  }
               )}
            >
               {!showAll ? (
                  <>
                     View More{" "}
                     <Icon icon="pajamas:dash" className="ps-[2px] pt-[2px]" />
                  </>
               ) : (
                  <Icon icon="flowbite:angle-up-outline" />
               )}
            </button>
         )} */}

         {/* Pagination */}
         {totalPages > 1 && (
            <div className="flex justify-center py-6 mt-2">
               <Pagination
                  size="sm"
                  total={totalPages}
                  page={currentPage}
                  onChange={handlePageChange}
                  radius="full"
                  loop
                  showControls
                  className="gap-2"
                  classNames={{
                     item: "bg-transparent border text-white hover:text-black hover:bg-[#1463FD] mx-1",
                     cursor: "bg-[#1463FD] text-white font-bold rounded-full",
                  }}
                  color="secondary"
               />
            </div>
         )}
      </div>
   );
};

export default PortfolioTwo;
