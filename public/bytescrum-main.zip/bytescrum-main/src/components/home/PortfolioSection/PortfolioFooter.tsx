"use client";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import { Icon } from "@iconify/react/dist/iconify.js";
import clsx from "clsx";
import Link from "next/link";
import { twMerge } from "tailwind-merge";

interface IProps {
   footerText: string;
   btnText: string;
   icon: string;
   className?: string;
}

const PortfolioFooter = ({ footerText, btnText, icon, className }: IProps) => {
   return (
      <div
         className={twMerge(
            clsx(
               "flex flex-col md:flex-row justify-evenly gap-[20px] items-center",
               className
            )
         )}
      >
         <SectionTitle animationVariant="fadeRight">{footerText}</SectionTitle>

         <Link
            href={"/contact-us"}
            className="relative group h-20 md:h-24 w-56 md:w-64 grid place-items-center"
            data-aos="fade-left"
            data-aos-duration="800"
            data-aos-anchor-placement="top-bottom"
         >
            <SectionSubtitle className="flex items-center gap-1">
               {" "}
               {btnText}
               <Icon icon={icon} className="text-2xl md:text-4xl " />
            </SectionSubtitle>
            <span className="border absolute border-gray-400 w-20 md:w-24 h-20 md:h-24 rounded-full top-0 left-0 group-hover:left-40 transition-all "></span>
         </Link>
      </div>
   );
};

export default PortfolioFooter;
