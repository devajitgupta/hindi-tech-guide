"use client";
import { usePathname } from "next/navigation";

import { useEffect, useState } from "react";
import PortFolioTab from "./PortFolioTab";
import SectionTitle from "@/components/SectionTitle";
import SectionSubtitle from "@/components/SectionSubtitle";

import dynamic from "next/dynamic";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import { cn } from "@nextui-org/react";
interface Iprops {
   langText?: any;
   lang?: string;
}

const PortfolioTwo = dynamic(() => import("./PortfolioTwo"), {
   ssr: false,
});

const OurPortfolio = ({ langText, lang }: Iprops) => {
   const pathName = usePathname();
   const [selectedTab, setSelectedTab] = useState("React & Node JS");
   const [isClient, setIsClient] = useState(false);

   useEffect(() => {
      // Set isClient to true once component mounts on client side
      setIsClient(true);

      // Load selected tab from localStorage only on client side
      const savedTab = localStorage.getItem("selectedTab");
      if (savedTab) {
         setSelectedTab(savedTab);
      }
   }, []);

   useEffect(() => {
      // Only save to localStorage when on client side
      if (isClient) {
         localStorage.setItem("selectedTab", selectedTab);
      }
   }, [selectedTab, isClient]);

   const isHomePage = pathName === "/";

   return (
      <div className="pt-[20px] pb-[10px] overflow-hidden transition-all duration-1000 ease-in-out   grid items-center gap-[40px]">
         {isHomePage && (
            <>
               <div className="grid lg:grid-cols-12 items-center overflow-hidden  gap-5 transition-all duration-1000 ease-in-out ">
                  <SectionTitle className=" md:px-5 px-4  xl:px-[40px]  lg:col-span-3 lg:text-start">
                     {" "}
                     <span className="text-[#565656]">
                        {" "}
                        {langText.portfolioSection.title.textOne}{" "}
                     </span>
                     {langText.portfolioSection.title.textTwo}
                  </SectionTitle>
                  <SectionSubtitle
                     variant="primary"
                     className=" md:px-[20px] px-4  xl:px-[40px]  lg:text-start lg:hidden m-auto"
                  >
                     {" "}
                     {langText.portfolioSection.text}
                  </SectionSubtitle>
                  <div className="grid  lg:col-span-9  overflow-x-auto scrollbar-hide w-full  px-4  py-1 ">
                     <PortFolioTab
                        selectedTab={selectedTab}
                        setSelectedTab={setSelectedTab}
                     />
                  </div>
               </div>

               <div className="md:px-5 px-4  xl:px-[40px] lg:grid place-items-center lg:place-items-start  w-full md gap-[20px] hidden ">
                  <SectionSubtitle variant="primary" className="lg:text-start ">
                     {" "}
                     {langText.portfolioSection.text}
                  </SectionSubtitle>
               </div>
            </>
         )}
         {!isHomePage && (
            <div className=" grid place-items-center  overflow-x-auto scrollbar-hide w-full  px-4  py-1">
               <PortFolioTab
                  selectedTab={selectedTab}
                  setSelectedTab={setSelectedTab}
               />
            </div>
         )}
         <div
            className={twMerge(
               clsx("pb-0 ", {
                  "pb-10": pathName !== "/",
               })
            )}
         >
            <PortfolioTwo
               lang={lang ?? ""}
               selectedTab={selectedTab}
               langText={langText}
               className={cn("transition-all duration-1000 ease-in-out ", {
                  "2xl:grid-cols-3": pathName === "/",
               })}
            />
         </div>
      </div>
   );
};

export default OurPortfolio;
