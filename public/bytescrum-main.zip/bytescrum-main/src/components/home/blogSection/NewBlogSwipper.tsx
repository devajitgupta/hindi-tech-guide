"use client";

import { Swiper, SwiperSlide } from "swiper/react";
// import "./blogSection.css";
import { Autoplay, Pagination } from "swiper/modules";
import { EffectCoverflow } from "swiper/modules";
import { useMediaQuery } from "@react-hook/media-query";
import { useState } from "react";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import Image from "next/image";
import homeData from "../../../common/data/homeData.json";

interface IProps {
   className?: string;
}

const BlogSwipper = ({ className }: IProps) => {
   const blogs = homeData.blogSection.blogs;
   const isExtraSmallScreen = useMediaQuery("(max-width: 599px)");
   const isSmallScreen = useMediaQuery(
      "(min-width: 600px) and (max-width: 767.99px)"
   );
   const isMediumScreen = useMediaQuery(
      "(min-width: 768px) and (max-width: 1023.99px)"
   );
   const isLargeScreen = useMediaQuery(
      "(min-width: 1024px) and (max-width: 1439.99px)"
   );
   const isExtraLargeScreen = useMediaQuery("(min-width: 1440px)");
   const [currentSlide, setCurrentSlide] = useState(0);

   return (
      <div
         className={twMerge(
            clsx(
               " transition-transform duration-200 ease-in-out transform",
               className
            )
         )}
      >
         <Swiper
            spaceBetween={
               isExtraSmallScreen
                  ? 40
                  : isSmallScreen
                  ? 50
                  : isMediumScreen
                  ? 80
                  : isLargeScreen
                  ? 150
                  : isExtraLargeScreen
                  ? 150
                  : 200
            }
            autoplay={{
               delay: 3000,
               disableOnInteraction: true,
            }}
            autoHeight={true}
            pagination={true}
            modules={[Pagination, EffectCoverflow, Autoplay]}
            effect={"coverflow"}
            grabCursor={false}
            centeredSlides={true}
            slidesPerView={"auto"}
            followFinger={true}
            initialSlide={1}
            simulateTouch={true}
            speed={1700}
            roundLengths={true}
            coverflowEffect={
               isSmallScreen
                  ? {
                       rotate: 0,
                       stretch: 10,
                       depth: 50,
                       modifier: 3,
                       slideShadows: true,
                    }
                  : isMediumScreen
                  ? {
                       rotate: 0,
                       stretch: 10,
                       depth: 100,
                       modifier: 3,
                       slideShadows: true,
                    }
                  : {
                       rotate: 0,
                       stretch: 10,
                       depth: 50,
                       modifier: 3,
                       slideShadows: true,
                    }
            }
            loop={true}
            onSlideChange={(swiper) => setCurrentSlide(swiper.realIndex)}
            className="blogswiper md:rounded-[16px] cursor-pointer transition-transform duration-200 ease-in-out transform rounded-[8px]"
         >
            {blogs.map((blog: any, index: any) => (
               <SwiperSlide key={index}>
                  <div
                     className={clsx(
                        "grid lg:grid-cols-2 border border-[#585858] max-w-[280px] xs:max-w-[323px]  md:max-w-[490px] lg:max-w-[800px] rounded-[8px] md:rounded-[16px] bg-[#0e0e0e]",
                        {
                           "opacity-30  ": currentSlide !== index,
                           "opacity-100": currentSlide === index,
                        }
                     )}
                  >
                     <div className="h-full rounded-[18px] object-fit ">
                        {/* <img
                           src={blog.src}
                           alt=""
                           className="rounded-[18px] object-cover w-full h-full md:aspect-[1.5/1] "
                        /> */}
                        <Image
                           src={blog.src}
                           alt="{blog.src}"
                           width={1120}
                           height={1250}
                           className="rounded-[18px] object-cover w-full h-full  "
                        />
                     </div>

                     <div className="px-[17px] pt-[30px] pb-[40px] md:py-[27px]  md:px-[35px] grid place-items-start gap-[20px]">
                        <span className="bg-[#191919] px-[20px] py-[5px] text-[#ffffff] font-sans text-[12px] rounded-full inter">
                           Bytescrum
                        </span>
                        <div className="grid gap-[10px]">
                           <h3 className="poppins text-[18px] sm:text-[20px] leading-[24px] md:leading-[28px] text-[#ffffff] ">
                              {blog.title}
                           </h3>
                           <p className="inter text-[14px] sm:text-[16px] text-[#a4a4a4] leading-[20px] sm:leading-[24px] md:leading-[28px]">
                              {blog.title}
                           </p>
                        </div>
                        <span className="text-[12px]"> {blog.date}</span>
                     </div>
                  </div>
               </SwiperSlide>
            ))}

            {/* <SwiperSlide>
            <BlogCard />
         </SwiperSlide>
       */}
         </Swiper>
      </div>
   );
};

export default BlogSwipper;
