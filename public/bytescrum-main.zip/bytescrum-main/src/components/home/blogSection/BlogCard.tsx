import Image from "next/image";

interface BlogPost {
   _Id?: string;
   src: string;
   title: string;
   text: string;
   date: string;
}

const BlogCard = ({ _Id, src, title, text, date }: BlogPost) => {
   const today = new Date().toDateString();
   return (
      <div className="grid md:grid-cols-2 border border-[#585858] w-[890px] h-[35rem]  rounded-[16px] bg-[#0e0e0e]">
         <Image
            src={src || "/blog/python.avif"}
            width={489}
            height={348}
            alt=""
            className="rounded-[15px] w-full h-full "
         />

         <div className="px-[17px] pt-[30px] pb-[40px] md:py-[47px]  md:px-[65px]  grid place-items-start gap-[20px]">
            <span className="bg-[#191919] px-[20px] py-[5px] text-[#ffffff] font-sans text-[12px] rounded-full inter">
               Bytescrum
            </span>
            <div className="grid gap-[10px]">
               <h3 className="poppins text-[20px] text-[#ffffff] max-w-[348px]">
                  {title ||
                     "Navigating the World of Data Structures in Python: A Beginner's Guide"}
               </h3>
               <p className="inter text-[16px] text-[#a4a4a4] max-w-[348px] leading-[28px]">
                  {text ||
                     "Graphical User Interfaces (GUIs) are an integral part of modern software applications, allowing users to interact..."}
               </p>
            </div>
            <span className="text-[12px]">{date || today}</span>
         </div>
      </div>
   );
};

export default BlogCard;
