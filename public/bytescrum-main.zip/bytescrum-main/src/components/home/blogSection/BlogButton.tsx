"use client";

import { Icon } from "@iconify/react/dist/iconify.js";
import clsx from "clsx";
import Link from "next/link";
import { twMerge } from "tailwind-merge";
import homeData from "../../../common/data/homeData.json";

interface IProps {
   className?: string;
   title: string;
   href: string;
}

const BlogButton = ({ className, title, href }: IProps) => {
   return (
      <Link
         href={href}
         target="blank"
         className={twMerge(
            clsx(
               "flex text-[14px] leading-[24px] md:text-[16px] md:leading-[28px] items-center justify-center inter ",
               className
            )
         )}
      >
         {title}
         <Icon
            icon={homeData.blogSection.icon}
            className="text-2xl text-white"
         />
      </Link>
   );
};

export default BlogButton;
