"use client";

import { Swiper, SwiperSlide } from "swiper/react";
import "./blogSection.css";
import { Autoplay, Pagination } from "swiper/modules";
import { EffectCoverflow } from "swiper/modules";
import { useMediaQuery } from "@react-hook/media-query";
import { useState } from "react";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import Image from "next/image";
import homeData from "../../../common/data/homeData.json";
import { useRouter } from "next/navigation";
import { Icon } from "@iconify/react/dist/iconify.js";
import { cn } from "@/libs/cn";

interface IProps {
   className?: string;
}

const BlogSwipper = ({ className }: IProps) => {
   const router = useRouter();
   const blogs = homeData.blogSection.blogs;
   const isExtraSmallScreen = useMediaQuery("(max-width: 599px)");
   const isSmallScreen = useMediaQuery(
      "(min-width: 600px) and (max-width: 767.99px)"
   );
   const isMediumScreen = useMediaQuery(
      "(min-width: 768px) and (max-width: 1023.99px)"
   );
   const isLargeScreen = useMediaQuery(
      "(min-width: 1024px) and (max-width: 1439.99px)"
   );
   const isExtraLargeScreen = useMediaQuery("(min-width: 1440px)");
   const [currentSlide, setCurrentSlide] = useState(0);

   return (
      <div
         className={twMerge(
            clsx(
               " transition-transform duration-200 ease-in-out transform",
               className
            )
         )}
      >
         <Swiper
            spaceBetween={
               isExtraSmallScreen
                  ? 40
                  : isSmallScreen
                  ? 50
                  : isMediumScreen
                  ? 80
                  : isLargeScreen
                  ? 150
                  : isExtraLargeScreen
                  ? 150
                  : 200
            }
            autoplay={{
               delay: 3000,
               disableOnInteraction: true,
            }}
            autoHeight={true}
            pagination={true}
            modules={[Pagination, EffectCoverflow, Autoplay]}
            effect={"coverflow"}
            grabCursor={false}
            centeredSlides={true}
            slidesPerView={"auto"}
            followFinger={true}
            initialSlide={2}
            simulateTouch={true}
            speed={1700}
            roundLengths={true}
            coverflowEffect={
               isSmallScreen
                  ? {
                       rotate: 0,
                       stretch: 10,
                       depth: 50,
                       modifier: 3,
                       slideShadows: true,
                    }
                  : isMediumScreen
                  ? {
                       rotate: 0,
                       stretch: 10,
                       depth: 100,
                       modifier: 3,
                       slideShadows: true,
                    }
                  : {
                       rotate: 0,
                       stretch: 10,
                       depth: 50,
                       modifier: 3,
                       slideShadows: true,
                    }
            }
            loop={true}
            // onSlideChange={(swiper) => setCurrentSlide(swiper.realIndex)}
            onSlideChange={(swiper) => {
               setTimeout(() => {
                  setCurrentSlide(swiper.realIndex);
               }, 1000); // 1000ms = 1 second
            }}
            className={cn(
               "blogswiper md:rounded-[16px] transition-transform duration-1000 ease-in-out transform rounded-[8px]"
            )}
         >
            {blogs.map((blog: any, index: any) => (
               <SwiperSlide key={index} className="py-10">
                  <div
                     className={clsx(
                        "grid lg:grid-cols-2 border border-[#585858] max-w-[280px] xs:max-w-[323px]  md:max-w-[490px] lg:max-w-[800px] rounded-[18px] md:rounded-[16px] bg-[#0e0e0e] group transition-all duration-1000 ease-in-out",
                        {
                           "opacity-30 scale-95 cursor-grab ":
                              currentSlide !== index,
                           "opacity-100 cursor-pointer scale-105":
                              currentSlide === index,
                        }
                     )}
                     // onClick={() => router.push(blog.path, "_blank")}

                     onClick={() => {
                        if (currentSlide === index) {
                           window.open(
                              blog.path,
                              "_blank",
                              "noopener,noreferrer"
                           );
                        }
                     }}
                  >
                     {/* <div className=" h-full rounded-tl-[18px] xl:rounded-bl-[18px] overflow-hidden ">
                   
                        <Image
                           src={blog.src}
                           alt="{blog.src}"
                           width={1120}
                           height={0}
                           // fill
                           className={twMerge(
                              clsx(
                                 "object-cover h-full  rounded-tr-[18px] xl:rounded-tr-none rounded-bl-none scale-100  transition-all duration-1000  ease-in-out aspect-auto ",
                                 {
                                    "group-hover:scale-125":
                                       currentSlide === index,
                                 }
                              )
                           )}
                        />
                     </div> */}

                     <div
                        className=" h-full blogImage rounded-[18px] rounded-b-none  overflow-hidden lg:rounded-bl-[18px] lg:rounded-e-none bg-cover bg-no-repeat"
                        style={{ backgroundImage: `url(${blog.src})` }}
                     >
                        {/* <div
                        className=" h-full rounded-t-[18px] md:rounded-t-none md:rounded-l-[18px] xl:rounded-bl-[18px] overflow-hidden bg-cover bg-no-repeat"
                        style={{ backgroundImage: `url(${blog.src})` }}
                     > */}
                        <div className="px-0 backdrop-blur-md bg-transparent grid place-items-center  w-full h-full">
                           <Image
                              src={blog.src}
                              alt="{blog.src}"
                              width={1120}
                              height={0}
                              // fill
                              className={twMerge(
                                 clsx(
                                    "rounded-tr-[18px] xl:rounded-tr-none rounded-bl-none scale-100  transition-all duration-1000  ease-in-out m-auto  ",
                                    {
                                       "group-hover:scale-110":
                                          currentSlide === index,
                                    }
                                 )
                              )}
                           />
                        </div>
                     </div>

                     <div className="px-[17px] pt-[30px] pb-[40px] md:py-[27px]  md:px-[35px] grid place-items-start gap-[20px]">
                        <span className="bg-[#191919] px-[20px] py-[5px] text-[#ffffff] font-sans text-[12px] rounded-full inter">
                           Bytescrum
                        </span>
                        <div className="grid gap-[10px]">
                           <h3 className="poppins text-[18px] sm:text-[20px] leading-[24px] md:leading-[28px] text-[#ffffff] line-clamp-2 ">
                              {blog.title}
                           </h3>
                           <p className="inter text-[14px] sm:text-[16px] text-[#a4a4a4] leading-[20px] sm:leading-[24px] md:leading-[28px] line-clamp-2">
                              {blog.title}
                           </p>
                        </div>
                        <div className=" flex w-full  text-white/50 justify-between">
                           {" "}
                           <span className="text-[12px]"> {blog.date}</span>
                           <span className="text-[12px] flex items-center gap-1">
                              <Icon icon="bytesize:book" fontSize={12} />
                              <span>{blog.readTime} min read</span>
                           </span>
                        </div>
                     </div>
                  </div>
               </SwiperSlide>
            ))}

            {/* <SwiperSlide>
            <BlogCard />
         </SwiperSlide>
       */}
         </Swiper>
      </div>
   );
};

export default BlogSwipper;
