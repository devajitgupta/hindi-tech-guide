"use client";
import { motion, useAnimation } from "framer-motion";
import "./style.css";
import { useEffect } from "react";

const icon = {
   hidden: {
      // opacity: 1,
      pathLength: 1,
   },
   visible: {
      // opacity: 0.5,
      pathLength: 1,
   },
};

const WorkProcessLine = () => {
   const controls = useAnimation();

   useEffect(() => {
      controls.start("visible", {
         repeat: Infinity,
         repeatType: "loop",
         repeatDelay: 0,
         delay: 1,
         duration: 8,
         ease: "easeInOut",
      });
   }, [controls]);

   return (
      <motion.svg
         width="1036"
         height="650"
         //  width="725"
         //  height="450"
         viewBox="0 0 1036 650"
         fill="none"
         xmlns="http://www.w3.org/2000/svg"
      >
         <motion.path
            d="M100 2.5C100 2.5 905.501 2 963.001 2C1023 2 1033 40 1033 62C1033 101 1033 116.5 1033 157C1033 179 1023 217 963.001 217C934.501 217 101 217 72.0001 217C12 217 1.99609 265 2 287C2.00391 324 2.00232 334.5 2 363C1.99768 385 12 433 72.0001 433C110.004 433 922.5 433 963 433C1023 433 1033 481 1033 503C1033 532.289 1033 548.711 1033 578C1033 600 1023 648 963 648C928.5 648 525.001 648 525.001 648"
            // stroke="#62626"
            // stroke="#bbbbbb"
            // stroke="white"
            strokeWidth="3"
            variants={icon}
            initial="hidden"
            animate={controls}
         />
      </motion.svg>
   );
};

export default WorkProcessLine;
