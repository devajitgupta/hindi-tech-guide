"use client";
import { motion, useAnimation } from "framer-motion";
import "./style.css";
import { useEffect } from "react";

const icon = {
   hidden: {
      // opacity: 0,
      pathLength: 1,
   },
   visible: {
      // opacity: 0.3,
      pathLength: 1,
   },
};

const SemiCircle = () => {
   const controls = useAnimation();

   useEffect(() => {
      controls.start("visible", {
         repeat: Infinity,
         repeatType: "loop",
         // repeatDelay: 2,
         delay: 2,
         duration: 1,
         ease: "easeInOut",
      });
   }, [controls]);
   return (
      <motion.svg
         width="227"
         height="115"
         viewBox="0 0 227 115"
         fill="none"
         xmlns="http://www.w3.org/2000/svg"
         //  className="hidden"
      >
         <motion.path
            d="M2 114C2.50391 46.5 57.5779 1.99996 112.977 2C168.98 2.00005 225.004 46.5002 225 114"
            // stroke="#626262"
            stroke="white"
            strokeWidth="4"
            variants={icon}
            initial="hidden"
            animate={controls}
         />
      </motion.svg>
   );
};

export default SemiCircle;
