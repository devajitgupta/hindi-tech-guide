"use client";
import { motion, useAnimation } from "framer-motion";
import React, { useEffect } from "react";

import { useMediaQueries } from "@react-hook/media-query";

interface SvgAttributes {
   svgWidth: string;
   svgHeight: string;
   border: string;
}

const useSvgAttributes = (): SvgAttributes => {
   const { matches } = useMediaQueries({
      md: "only screen and (min-width: 319.99px) and (max-width: 375.99px)",
      lg: "only screen and (min-width: 376px) and (max-width: 413.99px)",
      xl: "only screen and (min-width: 414px) ",
      //   xxl: "only screen and (min-width: 1536px)",
   });

   const activeQuery = matches.md
      ? "md"
      : matches.lg
      ? "lg"
      : matches.xl
      ? "xl"
      : //   : matches.xxl
        //   ? "2xl"
        "default";

   //    let svgWidth, svgHeight, border;

   const getSvgAttributes = (query: typeof activeQuery): SvgAttributes => {
      switch (activeQuery) {
         case "md":
            return {
               svgWidth: "300",
               svgHeight: "800",
               border: "border border-red-500",
            };

         case "lg":
            return {
               svgWidth: "320",
               svgHeight: "820",
               border: "border border-green-500",
            };

         case "xl":
            return {
               svgWidth: "399",
               svgHeight: "986",
               border: "border border-blue-500",
            };
         //  case "2xl":
         //     return {
         //        svgWidth: "1152",
         //        svgHeight: "901",
         //        border: "border border-pink-500",
         //     };
         default:
            return {
               svgWidth: "399",
               svgHeight: "986",
               border: "border border-white-500",
            };
      }
   };

   return getSvgAttributes(activeQuery);
};

const icon = {
   hidden: {
      opacity: 0,
      pathLength: 0,
   },
   visible: {
      opacity: 1,
      pathLength: 1,
   },
};
const arrowIcon = {
   hidden: {
      opacity: 1,
      pathLength: 0,
   },
   visible: {
      opacity: 0,
      pathLength: 1,
   },
};
const star = {
   hidden: {
      opacity: 0.3,
      pathLength: 0,
      fill: "black",
   },
   visible: {
      opacity: 1,
      pathLength: 1,
      fill: "#d9d9d9",
   },
};

const useAnimatedLine = (delay: any, repeatDelay: any, duration: any) => {
   const controls = useAnimation();

   useEffect(() => {
      controls.start("visible", {
         repeat: Infinity,
         repeatType: "loop",
         repeatDelay: repeatDelay,
         duration: duration,
         delay: delay,
         ease: "easeInOut",
      });
   }, [controls, delay, repeatDelay, duration]);

   return controls;
};

const MobileWorkProcessAnimation = () => {
   const controls1 = useAnimatedLine(0, 1, 1);
   const controls2 = useAnimatedLine(0.2, 1, 1);
   const controls3 = useAnimatedLine(0.4, 1, 1);
   const controls4 = useAnimatedLine(0.6, 1, 1);
   const controls5 = useAnimatedLine(0.8, 1, 1);
   const controls6 = useAnimatedLine(1, 1, 1);
   const controls7 = useAnimatedLine(1.2, 1, 1);
   const controls8 = useAnimatedLine(1.4, 1, 1);
   const controls9 = useAnimatedLine(1.6, 1, 1);
   const dottedControls1 = useAnimatedLine(0, 0.2, 0.2);
   const dottedControls2 = useAnimatedLine(0.1, 0.2, 0.2);
   const dottedControls3 = useAnimatedLine(0.2, 0.2, 0.2);
   const dottedControls4 = useAnimatedLine(0.3, 0.2, 0.2);
   const starOneControls = useAnimatedLine(1.8, 12, 3);
   const starTwoControls = useAnimatedLine(3.6, 12, 3);
   const starThreeControls = useAnimatedLine(5.4, 12, 3);
   const starFourControls = useAnimatedLine(7.2, 12, 3);
   const starFiveControls = useAnimatedLine(9.0, 12, 3);
   const strokeColor = "#fff";
   const { svgHeight, svgWidth, border } = useSvgAttributes();
   return (
      <motion.svg
         width={svgWidth}
         height={svgHeight}
         // width="399"
         // height="986"
         viewBox="0 0 399 986"
         fill="none"
         xmlns="http://www.w3.org/2000/svg"
      >
         <motion.path
            d="M322 877V885"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M322 890V898"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M322 905V913"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M322 920V928"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M322 936V944"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />

         <motion.path
            d="M322 952L320.5 960"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M316 968.5L310.5 973"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M304 976L296.5 977.5"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />

         <motion.path
            d="M287.5 978H280"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M271.5 978H264"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M255.5 978H248"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M239.5 978H232"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M223.5 978H216"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M207.5 978H200"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M191.5 978H184"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M175.5 978H168"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M159.5 978H152"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M143.5 978H136"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M127.5 978H120"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M111.5 978H104"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M95.5 978H88"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M79.5 978H72"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M63.4977 978L55.9973 978"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M49.9984 978L41.5 978"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M35.0025 977.5L26.5011 976"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M20.5003 973.5L14.5 968.5"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M10.5 961.5L8.5 953"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M8.5 928L8.50012 920"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M8.5 944L8.50012 936"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M8.5 912L8.49976 904.062"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M8.47656 895.938L8.47632 888"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M8.45312 879.877L8.45288 871.939"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M8.42969 863.815L8.42945 855.877"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M8.40625 847.754L8.40601 839.815"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M8.38281 831.692L8.38257 823.754"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M8.35937 815.631L8.35913 807.692"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M8.33594 799.569L8.3357 791.631"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M8.3125 783.508L8.31226 775.569"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M8.28906 767.446L8.28882 759.508"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M8.26562 751.385L8.26538 743.446"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M8.24219 735.323L8.24195 727.385"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M8.21875 719.262L8.21851 711.323"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M8.19531 703.2L8.19507 695.262"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M8.17163 686.5L8.17188 679.2"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M8.1482 669.5L8.14892 663.139"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M8.125 655.016L8.12476 647.077"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M8.10156 638.954L8.10132 631.016"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M8.07812 622.893L8.07788 614.954"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M8.05469 606.831L8.05445 598.893"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M8.03125 590.77L8.03101 582.831"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M8.00781 574.708L8.00757 566.77"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M7.98437 558.646L7.98413 550.708"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M7.96094 542.585L7.9607 534.647"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M7.9375 526.523L7.93726 518.585"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M7.91406 510.462L7.91382 502.523"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M7.89062 494.4L7.89038 486.462"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M7.86719 478.339L7.86695 470.4"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M7.84375 462.277L7.84351 454.339"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M7.82031 446.216L7.82007 438.277"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M7.79687 430.154L7.79663 422.216"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M7.77344 414.093L7.7732 406.154"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M7.75 398.031L7.74976 390.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M7.75 382.031L7.74976 374.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M7.75 366.031L7.74976 358.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M7.75 350.031L7.74976 342.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M7.75 334.031L7.74976 326.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M7.75 318.031L7.74976 310.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M7.75 302.031L7.74976 294.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M7.75 286.031L7.74976 278.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M7.75 270.031L7.74976 262.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M7.75 254.031L7.74976 246.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M7.75 238.031L7.74976 230.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M7.75 222.031L7.74976 214.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M7.75 206.031L7.74976 198.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M7.75 190.031L7.74976 182.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M7.75 174.031L7.74976 166.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M7.75 158.031L7.74976 150.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M7.75 142.031L7.74976 134.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M7.75 126.031L7.74976 118.093"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M7.75 110.031V102"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M7.5 96V89"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M7.50004 84L9.00296 76"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <motion.path
            d="M10.5 70L15 63"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls3}
         />
         <motion.path
            d="M20 59L26.0025 56.0001"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls4}
         />
         <motion.path
            d="M31 55L39 54"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls1}
         />
         <motion.path
            d="M43 54L50 54"
            stroke="white"
            strokeWidth="2"
            variants={icon}
            initial="hidden"
            animate={dottedControls2}
         />
         <path
            d="M133 54L207 54L299 54C338.5 54 367 76 367 127C367 178 337 194 299 194C299 194 236 194 207 194C178 194 157 189.5 134 236C111 282.5 225 321 225 321H299C327 321 354 352 354 400C354 451 327 480 299 480L93 480C52 480 33 513.166 33 547C33 578.5 52 613 93 613H144C144 613 175.388 613 195.5 613C249.978 613 281.022 613 335.5 613C369 613.5 390.835 641.082 391 673C391.159 703.626 369 733 334.885 733L79 733C50.0017 733.5 26 760.5 26 792C26 821.5 50.5 853 79 853H129H157H227H248"
            stroke="white"
            strokeWidth="2"
         />
         <path
            d="M195.5 611C194.913 571.376 228.371 540 268 540C306 540 336.066 572.746 335.5 611"
            stroke="white"
            strokeWidth="2"
         />
         <rect x="253" y="694" width="101" height="73" rx="16" fill="#1B1B1B" />
         <rect x="81" y="694" width="159" height="73" rx="16" fill="#1B1B1B" />
         <g filter="url(#filter0_b_226_1189)">
            <rect
               x="48"
               y="11"
               width="88"
               height="88"
               rx="16"
               fill="url(#paint0_radial_226_1189)"
            />
            <rect
               x="48.5"
               y="11.5"
               width="87"
               height="87"
               rx="15.5"
               stroke="#626262"
            />
         </g>
         <path
            d="M65.2714 116.432C65.2714 117.164 65.1034 117.836 64.7674 118.448C64.4314 119.048 63.9154 119.534 63.2194 119.906C62.5234 120.278 61.6594 120.464 60.6274 120.464H58.7194V125H55.6414V112.364H60.6274C61.6354 112.364 62.4874 112.538 63.1834 112.886C63.8794 113.234 64.4014 113.714 64.7494 114.326C65.0974 114.938 65.2714 115.64 65.2714 116.432ZM60.3934 118.016C60.9814 118.016 61.4194 117.878 61.7074 117.602C61.9954 117.326 62.1394 116.936 62.1394 116.432C62.1394 115.928 61.9954 115.538 61.7074 115.262C61.4194 114.986 60.9814 114.848 60.3934 114.848H58.7194V118.016H60.3934ZM69.9518 116.63C70.3118 116.078 70.7618 115.646 71.3018 115.334C71.8418 115.01 72.4418 114.848 73.1018 114.848V118.106H72.2558C71.4878 118.106 70.9118 118.274 70.5278 118.61C70.1438 118.934 69.9518 119.51 69.9518 120.338V125H66.8738V114.956H69.9518V116.63ZM79.145 125.144C78.161 125.144 77.273 124.934 76.481 124.514C75.701 124.094 75.083 123.494 74.627 122.714C74.183 121.934 73.961 121.022 73.961 119.978C73.961 118.946 74.189 118.04 74.645 117.26C75.101 116.468 75.725 115.862 76.517 115.442C77.309 115.022 78.197 114.812 79.181 114.812C80.165 114.812 81.053 115.022 81.845 115.442C82.637 115.862 83.261 116.468 83.717 117.26C84.173 118.04 84.401 118.946 84.401 119.978C84.401 121.01 84.167 121.922 83.699 122.714C83.243 123.494 82.613 124.094 81.809 124.514C81.017 124.934 80.129 125.144 79.145 125.144ZM79.145 122.48C79.733 122.48 80.231 122.264 80.639 121.832C81.059 121.4 81.269 120.782 81.269 119.978C81.269 119.174 81.065 118.556 80.657 118.124C80.261 117.692 79.769 117.476 79.181 117.476C78.581 117.476 78.083 117.692 77.687 118.124C77.291 118.544 77.093 119.162 77.093 119.978C77.093 120.782 77.285 121.4 77.669 121.832C78.065 122.264 78.557 122.48 79.145 122.48ZM85.422 119.96C85.422 118.928 85.614 118.022 85.998 117.242C86.394 116.462 86.928 115.862 87.6 115.442C88.272 115.022 89.022 114.812 89.85 114.812C90.51 114.812 91.11 114.95 91.65 115.226C92.202 115.502 92.634 115.874 92.946 116.342V111.68H96.024V125H92.946V123.56C92.658 124.04 92.244 124.424 91.704 124.712C91.176 125 90.558 125.144 89.85 125.144C89.022 125.144 88.272 124.934 87.6 124.514C86.928 124.082 86.394 123.476 85.998 122.696C85.614 121.904 85.422 120.992 85.422 119.96ZM92.946 119.978C92.946 119.21 92.73 118.604 92.298 118.16C91.878 117.716 91.362 117.494 90.75 117.494C90.138 117.494 89.616 117.716 89.184 118.16C88.764 118.592 88.554 119.192 88.554 119.96C88.554 120.728 88.764 121.34 89.184 121.796C89.616 122.24 90.138 122.462 90.75 122.462C91.362 122.462 91.878 122.24 92.298 121.796C92.73 121.352 92.946 120.746 92.946 119.978ZM108.169 114.956V125H105.091V123.632C104.779 124.076 104.353 124.436 103.813 124.712C103.285 124.976 102.697 125.108 102.049 125.108C101.281 125.108 100.603 124.94 100.015 124.604C99.4268 124.256 98.9708 123.758 98.6468 123.11C98.3228 122.462 98.1608 121.7 98.1608 120.824V114.956H101.221V120.41C101.221 121.082 101.395 121.604 101.743 121.976C102.091 122.348 102.559 122.534 103.147 122.534C103.747 122.534 104.221 122.348 104.569 121.976C104.917 121.604 105.091 121.082 105.091 120.41V114.956H108.169ZM109.768 119.978C109.768 118.934 109.978 118.022 110.398 117.242C110.83 116.462 111.424 115.862 112.18 115.442C112.948 115.022 113.824 114.812 114.808 114.812C116.068 114.812 117.118 115.142 117.958 115.802C118.81 116.462 119.368 117.392 119.632 118.592H116.356C116.08 117.824 115.546 117.44 114.754 117.44C114.19 117.44 113.74 117.662 113.404 118.106C113.068 118.538 112.9 119.162 112.9 119.978C112.9 120.794 113.068 121.424 113.404 121.868C113.74 122.3 114.19 122.516 114.754 122.516C115.546 122.516 116.08 122.132 116.356 121.364H119.632C119.368 122.54 118.81 123.464 117.958 124.136C117.106 124.808 116.056 125.144 114.808 125.144C113.824 125.144 112.948 124.934 112.18 124.514C111.424 124.094 110.83 123.494 110.398 122.714C109.978 121.934 109.768 121.022 109.768 119.978ZM126.876 122.39V125H125.31C124.194 125 123.324 124.73 122.7 124.19C122.076 123.638 121.764 122.744 121.764 121.508V117.512H120.54V114.956H121.764V112.508H124.842V114.956H126.858V117.512H124.842V121.544C124.842 121.844 124.914 122.06 125.058 122.192C125.202 122.324 125.442 122.39 125.778 122.39H126.876ZM62.2191 145.52C62.9511 145.676 63.5391 146.042 63.9831 146.618C64.4271 147.182 64.6491 147.83 64.6491 148.562C64.6491 149.618 64.2771 150.458 63.5331 151.082C62.8011 151.694 61.7751 152 60.4551 152H54.5691V139.364H60.2571C61.5411 139.364 62.5431 139.658 63.2631 140.246C63.9951 140.834 64.3611 141.632 64.3611 142.64C64.3611 143.384 64.1631 144.002 63.7671 144.494C63.3831 144.986 62.8671 145.328 62.2191 145.52ZM57.6471 144.476H59.6631C60.1671 144.476 60.5511 144.368 60.8151 144.152C61.0911 143.924 61.2291 143.594 61.2291 143.162C61.2291 142.73 61.0911 142.4 60.8151 142.172C60.5511 141.944 60.1671 141.83 59.6631 141.83H57.6471V144.476ZM59.9151 149.516C60.4311 149.516 60.8271 149.402 61.1031 149.174C61.3911 148.934 61.5351 148.592 61.5351 148.148C61.5351 147.704 61.3851 147.356 61.0851 147.104C60.7971 146.852 60.3951 146.726 59.8791 146.726H57.6471V149.516H59.9151ZM65.8224 146.96C65.8224 145.928 66.0144 145.022 66.3984 144.242C66.7944 143.462 67.3284 142.862 68.0004 142.442C68.6724 142.022 69.4224 141.812 70.2504 141.812C70.9584 141.812 71.5764 141.956 72.1044 142.244C72.6444 142.532 73.0584 142.91 73.3464 143.378V141.956H76.4244V152H73.3464V150.578C73.0464 151.046 72.6264 151.424 72.0864 151.712C71.5584 152 70.9404 152.144 70.2324 152.144C69.4164 152.144 68.6724 151.934 68.0004 151.514C67.3284 151.082 66.7944 150.476 66.3984 149.696C66.0144 148.904 65.8224 147.992 65.8224 146.96ZM73.3464 146.978C73.3464 146.21 73.1304 145.604 72.6984 145.16C72.2784 144.716 71.7624 144.494 71.1504 144.494C70.5384 144.494 70.0164 144.716 69.5844 145.16C69.1644 145.592 68.9544 146.192 68.9544 146.96C68.9544 147.728 69.1644 148.34 69.5844 148.796C70.0164 149.24 70.5384 149.462 71.1504 149.462C71.7624 149.462 72.2784 149.24 72.6984 148.796C73.1304 148.352 73.3464 147.746 73.3464 146.978ZM78.0392 146.978C78.0392 145.934 78.2492 145.022 78.6692 144.242C79.1012 143.462 79.6952 142.862 80.4512 142.442C81.2192 142.022 82.0952 141.812 83.0792 141.812C84.3392 141.812 85.3892 142.142 86.2292 142.802C87.0812 143.462 87.6392 144.392 87.9032 145.592H84.6272C84.3512 144.824 83.8172 144.44 83.0252 144.44C82.4612 144.44 82.0112 144.662 81.6752 145.106C81.3392 145.538 81.1712 146.162 81.1712 146.978C81.1712 147.794 81.3392 148.424 81.6752 148.868C82.0112 149.3 82.4612 149.516 83.0252 149.516C83.8172 149.516 84.3512 149.132 84.6272 148.364H87.9032C87.6392 149.54 87.0812 150.464 86.2292 151.136C85.3772 151.808 84.3272 152.144 83.0792 152.144C82.0952 152.144 81.2192 151.934 80.4512 151.514C79.6952 151.094 79.1012 150.494 78.6692 149.714C78.2492 148.934 78.0392 148.022 78.0392 146.978ZM95.6876 152L92.6276 147.788V152H89.5496V138.68H92.6276V146.042L95.6696 141.956H99.4676L95.2916 146.996L99.5036 152H95.6876ZM103.755 138.68V152H100.677V138.68H103.755ZM110.557 152.144C109.573 152.144 108.685 151.934 107.893 151.514C107.113 151.094 106.495 150.494 106.039 149.714C105.595 148.934 105.373 148.022 105.373 146.978C105.373 145.946 105.601 145.04 106.057 144.26C106.513 143.468 107.137 142.862 107.929 142.442C108.721 142.022 109.609 141.812 110.593 141.812C111.577 141.812 112.465 142.022 113.257 142.442C114.049 142.862 114.673 143.468 115.129 144.26C115.585 145.04 115.813 145.946 115.813 146.978C115.813 148.01 115.579 148.922 115.111 149.714C114.655 150.494 114.025 151.094 113.221 151.514C112.429 151.934 111.541 152.144 110.557 152.144ZM110.557 149.48C111.145 149.48 111.643 149.264 112.051 148.832C112.471 148.4 112.681 147.782 112.681 146.978C112.681 146.174 112.477 145.556 112.069 145.124C111.673 144.692 111.181 144.476 110.593 144.476C109.993 144.476 109.495 144.692 109.099 145.124C108.703 145.544 108.505 146.162 108.505 146.978C108.505 147.782 108.697 148.4 109.081 148.832C109.477 149.264 109.969 149.48 110.557 149.48ZM121.262 141.812C121.97 141.812 122.588 141.956 123.116 142.244C123.656 142.532 124.07 142.91 124.358 143.378V141.956H127.436V151.982C127.436 152.906 127.25 153.74 126.878 154.484C126.518 155.24 125.96 155.84 125.204 156.284C124.46 156.728 123.53 156.95 122.414 156.95C120.926 156.95 119.72 156.596 118.796 155.888C117.872 155.192 117.344 154.244 117.212 153.044H120.254C120.35 153.428 120.578 153.728 120.938 153.944C121.298 154.172 121.742 154.286 122.27 154.286C122.906 154.286 123.41 154.1 123.782 153.728C124.166 153.368 124.358 152.786 124.358 151.982V150.56C124.058 151.028 123.644 151.412 123.116 151.712C122.588 152 121.97 152.144 121.262 152.144C120.434 152.144 119.684 151.934 119.012 151.514C118.34 151.082 117.806 150.476 117.41 149.696C117.026 148.904 116.834 147.992 116.834 146.96C116.834 145.928 117.026 145.022 117.41 144.242C117.806 143.462 118.34 142.862 119.012 142.442C119.684 142.022 120.434 141.812 121.262 141.812ZM124.358 146.978C124.358 146.21 124.142 145.604 123.71 145.16C123.29 144.716 122.774 144.494 122.162 144.494C121.55 144.494 121.028 144.716 120.596 145.16C120.176 145.592 119.966 146.192 119.966 146.96C119.966 147.728 120.176 148.34 120.596 148.796C121.028 149.24 121.55 149.462 122.162 149.462C122.774 149.462 123.29 149.24 123.71 148.796C124.142 148.352 124.358 147.746 124.358 146.978Z"
            fill="white"
         />
         <g filter="url(#filter1_b_226_1189)">
            <circle
               cx="54.5"
               cy="15.5"
               r="15.5"
               fill="url(#paint1_radial_226_1189)"
               fillOpacity="0.8"
            />
            <circle cx="54.5" cy="15.5" r="15" stroke="#626262" />
         </g>
         <path
            d="M51.6022 12.722V9.86H56.5882V23H53.3842V12.722H51.6022Z"
            fill="white"
         />
         <g clipPath="url(#clip0_226_1189)">
            <path
               d="M90.2277 53.2381C90.6828 53.2381 91.041 53.2381 91.4283 53.2381C91.4283 52.5684 91.4283 51.9181 91.4283 51.2192C91.5542 51.2678 91.651 51.3066 91.7382 51.3454C93.2293 52.0831 94.7204 52.8207 96.2212 53.5487C96.8409 53.8496 97.2282 54.2961 97.2282 55.0046C97.2282 55.6937 96.8409 56.1402 96.2309 56.4411C94.6526 57.2176 93.0744 57.9941 91.4477 58.7997C91.4477 58.1009 91.4477 57.4506 91.4477 56.7711C91.041 56.7711 90.6731 56.7711 90.2761 56.7711C90.2761 56.907 90.2858 57.0429 90.2761 57.1691C90.1986 58.4794 90.3148 59.78 90.2761 61.0903C90.2664 61.3524 90.2083 61.6145 90.1696 61.8765C90.1599 61.9251 90.1405 61.9736 90.1405 62.0124C90.1889 62.8763 90.2954 63.7498 90.2567 64.604C90.1986 65.8075 90.3245 67.0014 90.2761 68.1952C90.247 69.0882 89.821 69.5347 88.9399 69.5347C84.4181 69.5347 79.906 69.5347 75.3842 69.5347C74.474 69.5347 74.0383 69.0882 74.0383 68.1661C74.0383 67.8652 74.0674 67.5546 74.0286 67.2537C73.9415 66.5258 74.1448 65.8075 74.0674 65.0796C73.9899 64.3516 74.0286 63.6042 74.0383 62.8666C74.0383 62.6045 74.1061 62.3424 74.1351 62.0804C74.1448 62.0318 74.1739 61.9833 74.1642 61.9445C73.8834 61.0903 74.0093 60.2071 74.048 59.353C74.0964 58.1688 73.9512 56.9847 74.0286 55.8005C74.048 55.5773 74.0867 55.354 74.1255 55.1211C74.1351 55.0628 74.1642 55.0046 74.1545 54.9464C74.1158 54.3349 74.0867 53.7234 74.019 53.1119C73.9318 52.3937 74.1642 51.7045 74.048 50.9766C73.9415 50.268 74.019 49.5304 74.0286 48.8024C74.0286 48.5889 74.0867 48.3753 74.1158 48.1618C74.1255 48.1036 74.1739 48.0356 74.1545 47.9871C73.8737 47.1329 73.9996 46.2497 74.0383 45.3956C74.0964 44.2211 73.9609 43.0467 74.0093 41.8819C74.077 40.8919 74.4644 40.4648 75.452 40.4648C79.935 40.4648 84.4181 40.4648 88.9011 40.4648C89.8597 40.4648 90.2858 40.8919 90.2858 41.8625C90.2858 42.1537 90.2567 42.4449 90.2954 42.7361C90.3729 43.464 90.1793 44.1823 90.2567 44.9102C90.3342 45.6382 90.2954 46.3856 90.2858 47.1232C90.2858 47.3853 90.218 47.6474 90.1889 47.9094C90.1793 47.9677 90.1696 48.0259 90.1696 48.0841C90.2083 49.0548 90.3535 50.0448 90.2567 51.0057C90.1696 51.7531 90.4504 52.4713 90.2277 53.2381ZM75.2196 43.9202C79.8673 43.9202 84.4859 43.9202 89.0948 43.9202C89.0948 43.1437 89.0948 42.3867 89.0948 41.6393C84.4568 41.6393 79.8479 41.6393 75.2196 41.6393C75.2196 42.4061 75.2196 43.1534 75.2196 43.9202ZM89.1045 45.1335C84.4665 45.1335 79.8479 45.1335 75.2293 45.1335C75.2293 45.91 75.2293 46.6671 75.2293 47.4144C79.8673 47.4144 84.4859 47.4144 89.1045 47.4144C89.1045 46.6379 89.1045 45.8906 89.1045 45.1335ZM89.0948 50.9086C89.0948 50.1224 89.0948 49.3751 89.0948 48.6277C84.4568 48.6277 79.8382 48.6277 75.2293 48.6277C75.2293 49.4042 75.2293 50.1613 75.2293 50.9086C79.8673 50.9086 84.4762 50.9086 89.0948 50.9086ZM75.2196 61.3621C79.8673 61.3621 84.4859 61.3621 89.0948 61.3621C89.0948 60.5856 89.0948 59.8286 89.0948 59.0812C84.4568 59.0812 79.8479 59.0812 75.2196 59.0812C75.2196 59.848 75.2196 60.5953 75.2196 61.3621ZM75.2293 62.5657C75.2293 63.3422 75.2293 64.0992 75.2293 64.8466C79.8673 64.8466 84.4859 64.8466 89.1045 64.8466C89.1045 64.0701 89.1045 63.3228 89.1045 62.5657C84.4762 62.5657 79.8673 62.5657 75.2293 62.5657ZM89.1045 66.0696C84.4568 66.0696 79.8382 66.0696 75.2293 66.0696C75.2293 66.8461 75.2293 67.6032 75.2293 68.3505C79.8673 68.3505 84.4762 68.3505 89.1045 68.3505C89.1045 67.5837 89.1045 66.8364 89.1045 66.0696ZM89.1045 52.1122C84.4568 52.1122 79.8382 52.1122 75.2196 52.1122C75.2196 52.8887 75.2196 53.6263 75.2196 54.3931C79.083 54.3931 82.927 54.3931 86.8097 54.3931C86.8097 54.0049 86.8097 53.636 86.8097 53.2478C87.594 53.2478 88.3396 53.2478 89.1045 53.2478C89.1045 52.8596 89.1045 52.5004 89.1045 52.1122ZM86.8097 55.6064C82.9076 55.6064 79.0636 55.6064 75.2196 55.6064C75.2196 56.3829 75.2196 57.1205 75.2196 57.8873C79.8576 57.8873 84.4762 57.8873 89.0948 57.8873C89.0948 57.4991 89.0948 57.1303 89.0948 56.742C88.3202 56.742 87.5843 56.742 86.8097 56.742C86.8097 56.3441 86.8097 55.9849 86.8097 55.6064ZM92.5999 54.432C91.0313 54.432 89.5112 54.432 87.991 54.432C87.991 54.8396 87.991 55.2084 87.991 55.5967C89.5402 55.5967 91.0507 55.5967 92.5999 55.5967C92.5999 56.0335 92.5999 56.4508 92.5999 56.907C92.7161 56.8682 92.7936 56.8391 92.871 56.81C93.8296 56.3344 94.7979 55.8685 95.7468 55.3734C95.8823 55.3055 96.0566 55.1211 96.0469 54.9949C96.0469 54.8687 95.863 54.694 95.7274 54.6261C94.7591 54.1311 93.7909 53.6555 92.8129 53.1799C92.7548 53.1507 92.6871 53.141 92.5999 53.1216C92.5999 53.5487 92.5999 53.9564 92.5999 54.432Z"
               fill="white"
            />
            <path
               d="M98.3984 54.9854C98.3984 53.0928 98.3984 51.2098 98.3984 49.3171C98.3984 48.162 99.115 47.4341 100.277 47.4341C102.901 47.4341 105.515 47.4341 108.139 47.4341C109.272 47.4341 109.998 48.162 109.998 49.2977C109.998 53.1025 109.998 56.8975 109.998 60.7023C109.998 61.8088 109.262 62.5465 108.159 62.5465C105.515 62.5465 102.872 62.5465 100.228 62.5465C99.144 62.5465 98.4081 61.8088 98.4081 60.7218C98.3984 58.8097 98.3984 56.8975 98.3984 54.9854ZM99.57 56.7131C102.668 56.7131 105.738 56.7131 108.807 56.7131C108.807 55.5484 108.807 54.4031 108.807 53.2675C105.719 53.2675 102.649 53.2675 99.57 53.2675C99.57 54.4225 99.57 55.5581 99.57 56.7131ZM108.836 52.0736C108.836 51.1515 108.836 50.2586 108.836 49.3656C108.836 48.7929 108.643 48.5988 108.081 48.5988C106.755 48.5988 105.428 48.5988 104.102 48.5988C102.823 48.5988 101.545 48.5988 100.267 48.5988C99.8605 48.5988 99.5894 48.7638 99.5797 49.0938C99.5604 50.0839 99.57 51.0642 99.57 52.0736C102.659 52.0736 105.719 52.0736 108.836 52.0736ZM99.5604 57.9167C99.5604 58.8194 99.5604 59.6929 99.5604 60.5762C99.5604 61.2168 99.7346 61.3915 100.383 61.3915C102.93 61.3915 105.476 61.3915 108.023 61.3915C108.12 61.3915 108.217 61.4012 108.313 61.3818C108.614 61.343 108.827 61.1585 108.827 60.8674C108.846 59.887 108.836 58.9164 108.836 57.9167C105.738 57.9167 102.678 57.9167 99.5604 57.9167Z"
               fill="white"
            />
            <path
               d="M96.0974 51.4912C95.6713 51.4912 95.3131 51.4912 94.9258 51.4912C94.9258 51.3554 94.9258 51.2389 94.9258 51.1224C94.9258 47.4438 94.9258 43.7555 94.9258 40.0768C94.9258 38.8442 95.6229 38.1356 96.8526 38.1356C98.1888 38.1356 99.5347 38.1356 100.871 38.1356C100.997 38.1356 101.132 38.1356 101.287 38.1356C101.287 37.7474 101.287 37.3882 101.287 37C103.611 37 105.916 37 108.23 37C108.23 38.1356 108.23 39.2809 108.23 40.4457C105.925 40.4457 103.64 40.4457 101.307 40.4457C101.307 40.0768 101.307 39.7177 101.307 39.3295C101.181 39.3198 101.084 39.3101 100.987 39.3101C99.6025 39.3101 98.2082 39.3101 96.8236 39.3101C96.2717 39.3101 96.078 39.5042 96.078 40.0477C96.078 40.9504 96.078 41.8531 96.078 42.7848C97.8209 42.7848 99.5347 42.7848 101.287 42.7848C101.287 42.416 101.287 42.0472 101.287 41.6589C103.63 41.6589 105.925 41.6589 108.239 41.6589C108.239 42.8043 108.239 43.9399 108.239 45.0949C105.945 45.0949 103.64 45.0949 101.307 45.0949C101.307 44.7261 101.307 44.3572 101.307 43.9787C99.5541 43.9787 97.8499 43.9787 96.0974 43.9787C96.0974 46.4635 96.0974 48.9676 96.0974 51.4912ZM102.478 39.2712C104.027 39.2712 105.557 39.2712 107.068 39.2712C107.068 38.883 107.068 38.5142 107.068 38.155C105.519 38.155 104.008 38.155 102.478 38.155C102.478 38.5336 102.478 38.8927 102.478 39.2712ZM102.478 43.9205C104.027 43.9205 105.557 43.9205 107.068 43.9205C107.068 43.5322 107.068 43.1634 107.068 42.8043C105.519 42.8043 104.008 42.8043 102.478 42.8043C102.478 43.1828 102.478 43.5419 102.478 43.9205Z"
               fill="white"
            />
            <path
               d="M101.285 68.341C101.285 67.9527 101.285 67.5936 101.285 67.2248C99.552 67.2248 97.8382 67.2248 96.076 67.2248C96.076 67.6324 96.076 68.0401 96.076 68.4477C96.076 68.9913 96.0663 69.5348 96.076 70.0784C96.0857 70.4375 96.289 70.6801 96.6182 70.6898C98.1577 70.6996 99.707 70.6996 101.276 70.6996C101.276 70.321 101.276 69.9619 101.276 69.5736C103.599 69.5736 105.904 69.5736 108.228 69.5736C108.228 70.7093 108.228 71.8449 108.228 73.0096C105.933 73.0096 103.648 73.0096 101.314 73.0096C101.314 72.6505 101.314 72.2816 101.314 71.8643C101.15 71.8643 101.024 71.8643 100.888 71.8643C99.523 71.8643 98.1577 71.8643 96.7925 71.8643C95.6306 71.8643 94.9141 71.146 94.9141 69.991C94.9141 66.2736 94.9141 62.5561 94.9141 58.8387C94.9141 58.7416 94.9141 58.6445 94.9141 58.5281C95.2917 58.5281 95.6596 58.5281 96.0663 58.5281C96.0663 61.0225 96.0663 63.5267 96.0663 66.0406C97.8188 66.0406 99.523 66.0406 101.276 66.0406C101.276 65.6718 101.276 65.3029 101.276 64.9147C103.619 64.9147 105.914 64.9147 108.228 64.9147C108.228 66.06 108.228 67.1956 108.228 68.3507C105.943 68.341 103.638 68.341 101.285 68.341ZM102.476 67.1762C104.035 67.1762 105.555 67.1762 107.066 67.1762C107.066 66.7783 107.066 66.4192 107.066 66.06C105.517 66.06 104.006 66.06 102.476 66.06C102.476 66.4386 102.476 66.7977 102.476 67.1762ZM102.476 71.8352C104.025 71.8352 105.555 71.8352 107.066 71.8352C107.066 71.4469 107.066 71.0781 107.066 70.719C105.517 70.719 104.006 70.719 102.476 70.719C102.476 71.0878 102.476 71.4469 102.476 71.8352Z"
               fill="white"
            />
            <path
               d="M103.02 55.5581C102.632 55.5581 102.274 55.5581 101.906 55.5581C101.906 55.1796 101.906 54.8301 101.906 54.4419C102.265 54.4419 102.632 54.4419 103.02 54.4419C103.02 54.801 103.02 55.1699 103.02 55.5581Z"
               fill="white"
            />
            <path
               d="M104.211 55.5581C104.211 55.1796 104.211 54.8204 104.211 54.4419C104.579 54.4419 104.947 54.4419 105.334 54.4419C105.334 54.8107 105.334 55.1699 105.334 55.5581C104.976 55.5581 104.618 55.5581 104.211 55.5581Z"
               fill="white"
            />
            <path
               d="M106.535 55.5483C106.535 55.1698 106.535 54.8107 106.535 54.4321C106.913 54.4321 107.281 54.4321 107.658 54.4321C107.658 54.801 107.658 55.1601 107.658 55.5483C107.3 55.5483 106.932 55.5483 106.535 55.5483Z"
               fill="white"
            />
            <path
               d="M100.727 50.8992C100.727 50.5207 100.727 50.1713 100.727 49.7927C101.095 49.7927 101.462 49.7927 101.85 49.7927C101.85 50.1519 101.85 50.5207 101.85 50.8992C101.482 50.8992 101.104 50.8992 100.727 50.8992Z"
               fill="white"
            />
            <path
               d="M103.055 50.8992C103.055 50.5109 103.055 50.1518 103.055 49.783C103.432 49.783 103.781 49.783 104.168 49.783C104.168 50.1421 104.168 50.5109 104.168 50.8992C103.81 50.8992 103.442 50.8992 103.055 50.8992Z"
               fill="white"
            />
            <path
               d="M105.383 49.783C105.751 49.783 106.109 49.783 106.496 49.783C106.496 50.1518 106.496 50.5109 106.496 50.9089C106.138 50.9089 105.77 50.9089 105.383 50.9089C105.383 50.54 105.383 50.1809 105.383 49.783Z"
               fill="white"
            />
            <path
               d="M101.867 59.0911C101.867 59.4793 101.867 59.8384 101.867 60.2073C101.499 60.2073 101.141 60.2073 100.754 60.2073C100.754 59.8481 100.754 59.4793 100.754 59.0911C101.102 59.0911 101.47 59.0911 101.867 59.0911Z"
               fill="white"
            />
            <path
               d="M104.178 59.0815C104.178 59.4601 104.178 59.8192 104.178 60.1977C103.81 60.1977 103.442 60.1977 103.055 60.1977C103.055 59.8289 103.055 59.4601 103.055 59.0815C103.423 59.0815 103.781 59.0815 104.178 59.0815Z"
               fill="white"
            />
            <path
               d="M105.371 60.1977C105.371 59.8192 105.371 59.4601 105.371 59.0815C105.749 59.0815 106.117 59.0815 106.494 59.0815C106.494 59.4504 106.494 59.8095 106.494 60.1977C106.136 60.1977 105.768 60.1977 105.371 60.1977Z"
               fill="white"
            />
         </g>
         <g filter="url(#filter2_b_226_1189)">
            <rect
               x="207"
               y="11"
               width="88"
               height="88"
               rx="16"
               fill="url(#paint2_radial_226_1189)"
            />
            <rect
               x="207.5"
               y="11.5"
               width="87"
               height="87"
               rx="15.5"
               stroke="#626262"
            />
         </g>
         <path
            d="M228.818 125.126C227.894 125.126 227.066 124.976 226.334 124.676C225.602 124.376 225.014 123.932 224.57 123.344C224.138 122.756 223.91 122.048 223.886 121.22H227.162C227.21 121.688 227.372 122.048 227.648 122.3C227.924 122.54 228.284 122.66 228.728 122.66C229.184 122.66 229.544 122.558 229.808 122.354C230.072 122.138 230.204 121.844 230.204 121.472C230.204 121.16 230.096 120.902 229.88 120.698C229.676 120.494 229.418 120.326 229.106 120.194C228.806 120.062 228.374 119.912 227.81 119.744C226.994 119.492 226.328 119.24 225.812 118.988C225.296 118.736 224.852 118.364 224.48 117.872C224.108 117.38 223.922 116.738 223.922 115.946C223.922 114.77 224.348 113.852 225.2 113.192C226.052 112.52 227.162 112.184 228.53 112.184C229.922 112.184 231.044 112.52 231.896 113.192C232.748 113.852 233.204 114.776 233.264 115.964H229.934C229.91 115.556 229.76 115.238 229.484 115.01C229.208 114.77 228.854 114.65 228.422 114.65C228.05 114.65 227.75 114.752 227.522 114.956C227.294 115.148 227.18 115.43 227.18 115.802C227.18 116.21 227.372 116.528 227.756 116.756C228.14 116.984 228.74 117.23 229.556 117.494C230.372 117.77 231.032 118.034 231.536 118.286C232.052 118.538 232.496 118.904 232.868 119.384C233.24 119.864 233.426 120.482 233.426 121.238C233.426 121.958 233.24 122.612 232.868 123.2C232.508 123.788 231.98 124.256 231.284 124.604C230.588 124.952 229.766 125.126 228.818 125.126ZM238.398 116.378C238.698 115.91 239.112 115.532 239.64 115.244C240.168 114.956 240.786 114.812 241.494 114.812C242.322 114.812 243.072 115.022 243.744 115.442C244.416 115.862 244.944 116.462 245.328 117.242C245.724 118.022 245.922 118.928 245.922 119.96C245.922 120.992 245.724 121.904 245.328 122.696C244.944 123.476 244.416 124.082 243.744 124.514C243.072 124.934 242.322 125.144 241.494 125.144C240.798 125.144 240.18 125 239.64 124.712C239.112 124.424 238.698 124.052 238.398 123.596V129.788H235.32V114.956H238.398V116.378ZM242.79 119.96C242.79 119.192 242.574 118.592 242.142 118.16C241.722 117.716 241.2 117.494 240.576 117.494C239.964 117.494 239.442 117.716 239.01 118.16C238.59 118.604 238.38 119.21 238.38 119.978C238.38 120.746 238.59 121.352 239.01 121.796C239.442 122.24 239.964 122.462 240.576 122.462C241.188 122.462 241.71 122.24 242.142 121.796C242.574 121.34 242.79 120.728 242.79 119.96ZM250.615 116.63C250.975 116.078 251.425 115.646 251.965 115.334C252.505 115.01 253.105 114.848 253.765 114.848V118.106H252.919C252.151 118.106 251.575 118.274 251.191 118.61C250.807 118.934 250.615 119.51 250.615 120.338V125H247.537V114.956H250.615V116.63ZM256.784 113.912C256.244 113.912 255.8 113.756 255.452 113.444C255.116 113.12 254.948 112.724 254.948 112.256C254.948 111.776 255.116 111.38 255.452 111.068C255.8 110.744 256.244 110.582 256.784 110.582C257.312 110.582 257.744 110.744 258.08 111.068C258.428 111.38 258.602 111.776 258.602 112.256C258.602 112.724 258.428 113.12 258.08 113.444C257.744 113.756 257.312 113.912 256.784 113.912ZM258.314 114.956V125H255.236V114.956H258.314ZM266.665 114.848C267.841 114.848 268.777 115.232 269.473 116C270.181 116.756 270.535 117.8 270.535 119.132V125H267.475V119.546C267.475 118.874 267.301 118.352 266.953 117.98C266.605 117.608 266.137 117.422 265.549 117.422C264.961 117.422 264.493 117.608 264.145 117.98C263.797 118.352 263.623 118.874 263.623 119.546V125H260.545V114.956H263.623V116.288C263.935 115.844 264.355 115.496 264.883 115.244C265.411 114.98 266.005 114.848 266.665 114.848ZM278.272 122.39V125H276.706C275.59 125 274.72 124.73 274.096 124.19C273.472 123.638 273.16 122.744 273.16 121.508V117.512H271.936V114.956H273.16V112.508H276.238V114.956H278.254V117.512H276.238V121.544C276.238 121.844 276.31 122.06 276.454 122.192C276.598 122.324 276.838 122.39 277.174 122.39H278.272ZM222.219 145.52C222.951 145.676 223.539 146.042 223.983 146.618C224.427 147.182 224.649 147.83 224.649 148.562C224.649 149.618 224.277 150.458 223.533 151.082C222.801 151.694 221.775 152 220.455 152H214.569V139.364H220.257C221.541 139.364 222.543 139.658 223.263 140.246C223.995 140.834 224.361 141.632 224.361 142.64C224.361 143.384 224.163 144.002 223.767 144.494C223.383 144.986 222.867 145.328 222.219 145.52ZM217.647 144.476H219.663C220.167 144.476 220.551 144.368 220.815 144.152C221.091 143.924 221.229 143.594 221.229 143.162C221.229 142.73 221.091 142.4 220.815 142.172C220.551 141.944 220.167 141.83 219.663 141.83H217.647V144.476ZM219.915 149.516C220.431 149.516 220.827 149.402 221.103 149.174C221.391 148.934 221.535 148.592 221.535 148.148C221.535 147.704 221.385 147.356 221.085 147.104C220.797 146.852 220.395 146.726 219.879 146.726H217.647V149.516H219.915ZM225.822 146.96C225.822 145.928 226.014 145.022 226.398 144.242C226.794 143.462 227.328 142.862 228 142.442C228.672 142.022 229.422 141.812 230.25 141.812C230.958 141.812 231.576 141.956 232.104 142.244C232.644 142.532 233.058 142.91 233.346 143.378V141.956H236.424V152H233.346V150.578C233.046 151.046 232.626 151.424 232.086 151.712C231.558 152 230.94 152.144 230.232 152.144C229.416 152.144 228.672 151.934 228 151.514C227.328 151.082 226.794 150.476 226.398 149.696C226.014 148.904 225.822 147.992 225.822 146.96ZM233.346 146.978C233.346 146.21 233.13 145.604 232.698 145.16C232.278 144.716 231.762 144.494 231.15 144.494C230.538 144.494 230.016 144.716 229.584 145.16C229.164 145.592 228.954 146.192 228.954 146.96C228.954 147.728 229.164 148.34 229.584 148.796C230.016 149.24 230.538 149.462 231.15 149.462C231.762 149.462 232.278 149.24 232.698 148.796C233.13 148.352 233.346 147.746 233.346 146.978ZM238.039 146.978C238.039 145.934 238.249 145.022 238.669 144.242C239.101 143.462 239.695 142.862 240.451 142.442C241.219 142.022 242.095 141.812 243.079 141.812C244.339 141.812 245.389 142.142 246.229 142.802C247.081 143.462 247.639 144.392 247.903 145.592H244.627C244.351 144.824 243.817 144.44 243.025 144.44C242.461 144.44 242.011 144.662 241.675 145.106C241.339 145.538 241.171 146.162 241.171 146.978C241.171 147.794 241.339 148.424 241.675 148.868C242.011 149.3 242.461 149.516 243.025 149.516C243.817 149.516 244.351 149.132 244.627 148.364H247.903C247.639 149.54 247.081 150.464 246.229 151.136C245.377 151.808 244.327 152.144 243.079 152.144C242.095 152.144 241.219 151.934 240.451 151.514C239.695 151.094 239.101 150.494 238.669 149.714C238.249 148.934 238.039 148.022 238.039 146.978ZM255.688 152L252.628 147.788V152H249.55V138.68H252.628V146.042L255.67 141.956H259.468L255.292 146.996L259.504 152H255.688ZM263.755 138.68V152H260.677V138.68H263.755ZM270.557 152.144C269.573 152.144 268.685 151.934 267.893 151.514C267.113 151.094 266.495 150.494 266.039 149.714C265.595 148.934 265.373 148.022 265.373 146.978C265.373 145.946 265.601 145.04 266.057 144.26C266.513 143.468 267.137 142.862 267.929 142.442C268.721 142.022 269.609 141.812 270.593 141.812C271.577 141.812 272.465 142.022 273.257 142.442C274.049 142.862 274.673 143.468 275.129 144.26C275.585 145.04 275.813 145.946 275.813 146.978C275.813 148.01 275.579 148.922 275.111 149.714C274.655 150.494 274.025 151.094 273.221 151.514C272.429 151.934 271.541 152.144 270.557 152.144ZM270.557 149.48C271.145 149.48 271.643 149.264 272.051 148.832C272.471 148.4 272.681 147.782 272.681 146.978C272.681 146.174 272.477 145.556 272.069 145.124C271.673 144.692 271.181 144.476 270.593 144.476C269.993 144.476 269.495 144.692 269.099 145.124C268.703 145.544 268.505 146.162 268.505 146.978C268.505 147.782 268.697 148.4 269.081 148.832C269.477 149.264 269.969 149.48 270.557 149.48ZM281.262 141.812C281.97 141.812 282.588 141.956 283.116 142.244C283.656 142.532 284.07 142.91 284.358 143.378V141.956H287.436V151.982C287.436 152.906 287.25 153.74 286.878 154.484C286.518 155.24 285.96 155.84 285.204 156.284C284.46 156.728 283.53 156.95 282.414 156.95C280.926 156.95 279.72 156.596 278.796 155.888C277.872 155.192 277.344 154.244 277.212 153.044H280.254C280.35 153.428 280.578 153.728 280.938 153.944C281.298 154.172 281.742 154.286 282.27 154.286C282.906 154.286 283.41 154.1 283.782 153.728C284.166 153.368 284.358 152.786 284.358 151.982V150.56C284.058 151.028 283.644 151.412 283.116 151.712C282.588 152 281.97 152.144 281.262 152.144C280.434 152.144 279.684 151.934 279.012 151.514C278.34 151.082 277.806 150.476 277.41 149.696C277.026 148.904 276.834 147.992 276.834 146.96C276.834 145.928 277.026 145.022 277.41 144.242C277.806 143.462 278.34 142.862 279.012 142.442C279.684 142.022 280.434 141.812 281.262 141.812ZM284.358 146.978C284.358 146.21 284.142 145.604 283.71 145.16C283.29 144.716 282.774 144.494 282.162 144.494C281.55 144.494 281.028 144.716 280.596 145.16C280.176 145.592 279.966 146.192 279.966 146.96C279.966 147.728 280.176 148.34 280.596 148.796C281.028 149.24 281.55 149.462 282.162 149.462C282.774 149.462 283.29 149.24 283.71 148.796C284.142 148.352 284.358 147.746 284.358 146.978Z"
            fill="white"
         />
         <g clipPath="url(#clip1_226_1189)">
            <path
               d="M233.019 73C233.019 72.6217 233.019 72.2627 233.019 71.8747C233.592 71.8747 234.145 71.8747 234.746 71.8747C234.746 71.7098 234.746 71.574 234.746 71.4285C234.766 70.3517 234.717 69.2652 234.833 68.2078C235.037 66.3161 236.706 64.6669 238.597 64.3953C238.859 64.3565 238.995 64.2692 239.024 64.017C239.024 64.0073 239.024 63.9879 239.034 63.9782C239.441 63.0857 239.286 62.3193 238.578 61.6403C238.432 61.5044 238.316 61.3977 238.103 61.3977C237.404 61.4171 236.696 61.4074 235.998 61.3977C234.261 61.388 233 60.1366 233 58.4196C233 52.2789 233 46.1382 233 40.0073C233 38.2611 234.251 37 235.998 37C246.009 37 256.02 37 266.032 37C267.778 37 269.029 38.2514 269.029 39.9976C269.029 46.1382 269.029 52.2692 269.029 58.4099C269.029 60.1463 267.768 61.388 266.022 61.3977C265.323 61.3977 264.615 61.388 263.917 61.4074C263.781 61.4074 263.616 61.5141 263.509 61.6112C262.724 62.2902 262.627 63.1051 263.024 64.0364C263.112 64.2304 263.179 64.3468 263.412 64.3759C265.566 64.696 267.254 66.6168 267.293 68.7995C267.312 69.7987 267.293 70.8076 267.293 71.8456C267.884 71.8456 268.437 71.8456 269.019 71.8456C269.019 72.2433 269.019 72.6023 269.019 72.9903C257.019 73 245.039 73 233.019 73ZM265.517 57.8957C265.517 52.0849 265.517 46.2935 265.517 40.5117C255.826 40.5117 246.164 40.5117 236.512 40.5117C236.512 46.3226 236.512 52.1043 236.512 57.886C236.9 57.886 237.268 57.886 237.637 57.886C237.763 55.325 239.732 53.9184 241.585 53.8407C243.341 53.7728 245.611 54.9951 245.815 57.886C246.184 57.886 246.552 57.886 246.921 57.886C247.299 55.4123 248.735 53.9184 250.83 53.8407C251.81 53.8019 252.693 54.0736 253.479 54.6653C254.526 55.4705 255.04 56.5667 255.108 57.8763C255.506 57.8763 255.875 57.8763 256.243 57.8763C256.36 55.3735 258.281 53.9281 260.153 53.831C261.909 53.7437 264.217 54.9757 264.421 57.8763C264.77 57.8957 265.129 57.8957 265.517 57.8957ZM264.227 60.2433C264.79 60.2433 265.333 60.2433 265.876 60.2433C267.176 60.2433 267.865 59.5546 267.865 58.2449C267.865 52.2207 267.865 46.1867 267.865 40.1625C267.865 38.8335 267.186 38.1641 265.847 38.1641C255.962 38.1641 246.067 38.1641 236.182 38.1641C234.843 38.1641 234.164 38.8335 234.164 40.1625C234.164 46.1867 234.164 52.2207 234.164 58.2449C234.164 58.3517 234.164 58.4584 234.164 58.5748C234.203 59.4285 234.863 60.1657 235.716 60.2239C236.405 60.2724 237.094 60.2336 237.802 60.2336C237.744 59.8456 237.686 59.4867 237.627 59.0792C237.268 59.0792 236.909 59.0792 236.551 59.0792C235.823 59.0695 235.338 58.5942 235.338 57.8666C235.338 52.0946 235.338 46.3226 235.338 40.5505C235.328 39.8133 235.813 39.3282 236.56 39.3282C246.193 39.3282 255.836 39.3282 265.469 39.3282C266.216 39.3282 266.701 39.8133 266.701 40.5505C266.701 46.3226 266.701 52.0946 266.701 57.8666C266.701 58.5845 266.206 59.0598 265.488 59.0792C265.129 59.0889 264.77 59.0792 264.411 59.0792C264.353 59.4673 264.295 59.8262 264.227 60.2433ZM248.114 61.844C248.114 63.1827 248.114 64.5311 248.114 65.8698C248.114 66.4325 248.308 66.6265 248.88 66.6265C250.306 66.6265 251.732 66.6265 253.158 66.6265C253.731 66.6265 253.925 66.4325 253.925 65.8698C253.925 63.2409 253.925 60.6217 253.915 57.9927C253.915 57.692 253.876 57.3913 253.789 57.1002C253.401 55.7421 252.053 54.8496 250.685 55.0243C249.23 55.2086 248.133 56.4018 248.114 57.8472C248.095 59.1859 248.114 60.515 248.114 61.844ZM244.04 71.8553C244.04 70.8949 244.04 69.9636 244.04 69.042C244.04 67.8779 244.418 66.8593 245.155 65.9766C245.213 65.9087 245.262 65.8213 245.349 65.6952C244.932 65.6176 244.563 65.5012 244.195 65.4915C242.536 65.4721 240.877 65.4527 239.218 65.4915C237.618 65.5206 236.172 66.7623 235.978 68.3436C235.852 69.4107 235.91 70.4875 235.901 71.5643C235.901 71.6613 235.91 71.7486 235.92 71.8359C236.308 71.8359 236.677 71.8359 237.074 71.8359C237.074 70.4778 237.074 69.1584 237.074 67.8197C237.472 67.8197 237.831 67.8197 238.238 67.8197C238.238 69.1778 238.238 70.5166 238.238 71.8553C240.188 71.8553 242.09 71.8553 244.04 71.8553ZM266.119 71.8553C266.119 70.8464 266.138 69.8666 266.119 68.8868C266.08 67.0146 264.576 65.5012 262.714 65.4721C261.113 65.4527 259.522 65.4527 257.922 65.4721C257.524 65.4818 257.126 65.5982 256.66 65.6758C256.796 65.8504 256.874 65.9378 256.942 66.0348C257.592 66.8593 257.97 67.7809 257.989 68.8383C258.009 69.7211 257.989 70.6039 257.999 71.4867C257.999 71.6031 258.009 71.7195 258.019 71.8262C259.968 71.8262 261.88 71.8262 263.829 71.8262C263.829 70.4681 263.829 69.1487 263.829 67.81C264.227 67.81 264.586 67.81 264.994 67.81C264.994 69.1681 264.994 70.5069 264.994 71.8456C265.372 71.8553 265.721 71.8553 266.119 71.8553ZM246.93 65.996C246.106 66.4228 245.417 67.3347 245.281 68.2951C245.194 68.8868 245.213 69.498 245.204 70.0994C245.194 70.6718 245.204 71.2538 245.204 71.8262C245.611 71.8262 245.98 71.8262 246.378 71.8262C246.378 70.4778 246.378 69.1487 246.378 67.81C246.775 67.81 247.134 67.81 247.542 67.81C247.542 69.1681 247.542 70.5069 247.542 71.8359C249.88 71.8359 252.169 71.8359 254.507 71.8359C254.507 70.4875 254.507 69.1487 254.507 67.81C254.914 67.81 255.283 67.81 255.671 67.81C255.671 69.1584 255.671 70.4875 255.671 71.8262C256.069 71.8262 256.428 71.8262 256.806 71.8262C256.806 70.7397 256.864 69.6726 256.787 68.6152C256.709 67.4608 256.098 66.5877 255.099 65.9572C254.914 67.2474 254.303 67.7809 253.023 67.7809C251.645 67.7809 250.268 67.7809 248.88 67.7809C247.716 67.7906 247.057 67.1989 246.93 65.996ZM241.711 61.9798C241.731 61.9798 241.76 61.9798 241.779 61.9798C242.235 61.9701 242.778 62.1156 243.137 61.9216C243.535 61.6985 243.768 61.1843 244.069 60.7866C244.428 60.3112 244.612 59.7583 244.631 59.1665C244.641 58.7203 244.641 58.274 244.631 57.8278C244.593 56.3533 243.419 55.131 241.954 55.0243C240.47 54.9175 239.131 55.9167 238.888 57.3816C238.782 58.0218 238.801 58.6815 238.83 59.3314C238.879 60.3985 239.635 61.1067 240.208 61.9022C240.683 61.9313 241.158 61.9507 241.634 61.9798C241.663 61.9895 241.682 61.9798 241.711 61.9798ZM260.308 61.9798C260.327 61.9798 260.357 61.9798 260.376 61.9798C260.832 61.9701 261.375 62.1059 261.724 61.9119C262.112 61.6985 262.335 61.194 262.627 60.806C263.015 60.2821 263.199 59.7001 263.199 59.0501C263.199 58.6427 263.209 58.2255 263.199 57.8181C263.15 56.363 262.006 55.1504 260.551 55.0243C259.076 54.8981 257.689 55.8973 257.466 57.3525C257.252 58.7785 257.252 60.1851 258.358 61.3395C258.475 61.4559 258.542 61.6306 258.669 61.7373C258.804 61.844 258.979 61.9604 259.134 61.9798C259.532 62.0089 259.93 61.9798 260.308 61.9798ZM246.95 61.4365C245.243 61.2328 245.126 61.2813 244.253 62.4842C244.243 62.5036 244.214 62.523 244.214 62.5424C244.185 62.6491 244.127 62.7753 244.146 62.8723C244.234 63.2991 244.35 63.7162 244.466 64.1334C244.496 64.2207 244.593 64.3274 244.68 64.3662C245.184 64.5408 245.708 64.696 246.222 64.8707C246.494 64.9677 246.95 64.7348 246.95 64.4632C246.95 63.464 246.95 62.4551 246.95 61.4365ZM255.079 61.4074C255.079 62.4066 255.079 63.367 255.079 64.3274C255.079 64.7542 255.487 64.9871 255.884 64.8319C256.34 64.6572 256.825 64.5311 257.291 64.3662C257.398 64.3274 257.534 64.2207 257.572 64.114C258.019 62.7074 258.019 62.7074 257.097 61.5627C257.039 61.485 256.932 61.3977 256.845 61.3977C256.272 61.3977 255.69 61.4074 255.079 61.4074ZM243.293 64.2886C243.196 63.9006 243.099 63.5222 243.011 63.1536C242.138 63.1536 241.294 63.1536 240.431 63.1536C240.334 63.5319 240.247 63.9006 240.15 64.2886C241.207 64.2886 242.235 64.2886 243.293 64.2886ZM261.889 64.2983C261.792 63.9103 261.705 63.5416 261.608 63.1633C260.745 63.1633 259.901 63.1633 259.027 63.1633C258.93 63.5416 258.843 63.9103 258.746 64.2983C259.804 64.2983 260.822 64.2983 261.889 64.2983ZM245.64 60.2142C246.087 60.2142 246.504 60.2142 246.921 60.2142C246.921 59.8262 246.921 59.4576 246.921 59.0986C246.533 59.0986 246.164 59.0986 245.815 59.0986C245.757 59.4867 245.698 59.8456 245.64 60.2142ZM256.214 59.1083C255.826 59.1083 255.467 59.1083 255.108 59.1083C255.108 59.4964 255.108 59.865 255.108 60.2142C255.555 60.2142 255.962 60.2142 256.389 60.2142C256.331 59.8359 256.272 59.477 256.214 59.1083Z"
               fill="white"
            />
            <path
               d="M241.139 50.3677C241.139 50.7752 241.139 51.1244 241.139 51.5027C239.985 51.5027 238.84 51.5027 237.676 51.5027C237.676 50.3677 237.676 49.2327 237.676 48.0686C238.811 48.0686 239.946 48.0686 241.12 48.0686C241.12 48.4276 241.12 48.7962 241.12 49.1842C242.507 49.1842 243.855 49.1842 245.223 49.1842C245.446 47.506 246.203 46.1382 247.561 45.1196C248.57 44.3629 249.715 43.9846 250.976 43.9749C252.47 43.9749 253.77 44.4696 254.885 45.4591C255.991 46.4486 256.612 47.7097 256.796 49.1842C258.649 49.1842 260.463 49.1842 262.335 49.1842C261.685 48.5537 261.074 47.9522 260.444 47.3314C260.774 47.0306 261.045 46.7978 261.268 46.5941C262.316 47.6418 263.412 48.738 264.47 49.7954C263.451 50.814 262.355 51.9005 261.259 53.0064C261.065 52.793 260.812 52.5213 260.531 52.2012C261.103 51.6483 261.715 51.0468 262.413 50.3677C261.21 50.3677 260.114 50.3677 259.018 50.3677C257.922 50.3677 256.816 50.3677 255.671 50.3677C255.768 48.5828 255.186 47.0985 253.74 46.0217C252.829 45.3524 251.791 45.0711 250.665 45.1487C248.366 45.3136 246.135 47.3411 246.358 50.3677C245.485 50.3677 244.622 50.3677 243.758 50.3677C242.895 50.3677 242.031 50.3677 241.139 50.3677ZM238.83 49.223C238.83 49.6208 238.83 49.9797 238.83 50.3483C239.218 50.3483 239.587 50.3483 239.946 50.3483C239.946 49.9603 239.946 49.5917 239.946 49.223C239.567 49.223 239.209 49.223 238.83 49.223Z"
               fill="white"
            />
            <path
               d="M264.381 43.4025C264.381 44.3532 263.595 45.1293 262.654 45.139C261.694 45.1487 260.898 44.3532 260.898 43.3928C260.898 42.4324 261.704 41.6466 262.664 41.6563C263.605 41.666 264.381 42.4518 264.381 43.4025ZM262.635 43.9652C262.945 43.9652 263.217 43.7032 263.217 43.3928C263.217 43.0824 262.955 42.8107 262.645 42.8107C262.334 42.8107 262.063 43.0727 262.063 43.3831C262.053 43.7032 262.315 43.9652 262.635 43.9652Z"
               fill="white"
            />
            <path
               d="M237.664 42.7816C237.664 42.4033 237.664 42.0444 237.664 41.666C239.983 41.666 242.282 41.666 244.6 41.666C244.6 42.0444 244.6 42.4033 244.6 42.7816C242.301 42.7816 240.002 42.7816 237.664 42.7816Z"
               fill="white"
            />
            <path
               d="M237.664 45.11C237.664 44.7317 237.664 44.3727 237.664 43.9944C239.973 43.9944 242.272 43.9944 244.59 43.9944C244.59 44.3533 244.59 44.722 244.59 45.11C242.301 45.11 240.002 45.11 237.664 45.11Z"
               fill="white"
            />
            <path
               d="M259.717 41.6758C259.717 42.0638 259.717 42.413 259.717 42.7914C258.573 42.7914 257.438 42.7914 256.273 42.7914C256.273 42.4325 256.273 42.0638 256.273 41.6758C257.408 41.6758 258.543 41.6758 259.717 41.6758Z"
               fill="white"
            />
            <path
               d="M259.727 43.9944C259.727 44.3824 259.727 44.7317 259.727 45.11C258.582 45.11 257.438 45.11 256.273 45.11C256.273 44.7511 256.273 44.3921 256.273 43.9944C257.408 43.9944 258.553 43.9944 259.727 43.9944Z"
               fill="white"
            />
         </g>
         <g filter="url(#filter3_b_226_1189)">
            <rect
               x="50"
               y="235"
               width="175"
               height="174"
               rx="87"
               fill="url(#paint3_radial_226_1189)"
            />
            <rect
               x="51"
               y="236"
               width="173"
               height="172"
               rx="86"
               stroke="#626262"
               strokeWidth="2"
            />
         </g>
         <path
            d="M108.878 331.175C107.728 331.175 106.695 330.975 105.778 330.575C104.878 330.158 104.17 329.592 103.653 328.875C103.137 328.142 102.87 327.3 102.853 326.35H105.278C105.362 327.167 105.695 327.858 106.278 328.425C106.878 328.975 107.745 329.25 108.878 329.25C109.962 329.25 110.812 328.983 111.428 328.45C112.062 327.9 112.378 327.2 112.378 326.35C112.378 325.683 112.195 325.142 111.828 324.725C111.462 324.308 111.003 323.992 110.453 323.775C109.903 323.558 109.162 323.325 108.228 323.075C107.078 322.775 106.153 322.475 105.453 322.175C104.77 321.875 104.178 321.408 103.678 320.775C103.195 320.125 102.953 319.258 102.953 318.175C102.953 317.225 103.195 316.383 103.678 315.65C104.162 314.917 104.837 314.35 105.703 313.95C106.587 313.55 107.595 313.35 108.728 313.35C110.362 313.35 111.695 313.758 112.728 314.575C113.778 315.392 114.37 316.475 114.503 317.825H112.003C111.92 317.158 111.57 316.575 110.953 316.075C110.337 315.558 109.52 315.3 108.503 315.3C107.553 315.3 106.778 315.55 106.178 316.05C105.578 316.533 105.278 317.217 105.278 318.1C105.278 318.733 105.453 319.25 105.803 319.65C106.17 320.05 106.612 320.358 107.128 320.575C107.662 320.775 108.403 321.008 109.353 321.275C110.503 321.592 111.428 321.908 112.128 322.225C112.828 322.525 113.428 323 113.928 323.65C114.428 324.283 114.678 325.15 114.678 326.25C114.678 327.1 114.453 327.9 114.003 328.65C113.553 329.4 112.887 330.008 112.003 330.475C111.12 330.942 110.078 331.175 108.878 331.175ZM120.301 319.825C120.751 319.042 121.418 318.392 122.301 317.875C123.201 317.342 124.243 317.075 125.426 317.075C126.643 317.075 127.743 317.367 128.726 317.95C129.726 318.533 130.509 319.358 131.076 320.425C131.643 321.475 131.926 322.7 131.926 324.1C131.926 325.483 131.643 326.717 131.076 327.8C130.509 328.883 129.726 329.725 128.726 330.325C127.743 330.925 126.643 331.225 125.426 331.225C124.259 331.225 123.226 330.967 122.326 330.45C121.443 329.917 120.768 329.258 120.301 328.475V337.5H118.026V317.3H120.301V319.825ZM129.601 324.1C129.601 323.067 129.393 322.167 128.976 321.4C128.559 320.633 127.993 320.05 127.276 319.65C126.576 319.25 125.801 319.05 124.951 319.05C124.118 319.05 123.343 319.258 122.626 319.675C121.926 320.075 121.359 320.667 120.926 321.45C120.509 322.217 120.301 323.108 120.301 324.125C120.301 325.158 120.509 326.067 120.926 326.85C121.359 327.617 121.926 328.208 122.626 328.625C123.343 329.025 124.118 329.225 124.951 329.225C125.801 329.225 126.576 329.025 127.276 328.625C127.993 328.208 128.559 327.617 128.976 326.85C129.393 326.067 129.601 325.15 129.601 324.1ZM137.196 319.525C137.596 318.742 138.162 318.133 138.896 317.7C139.646 317.267 140.554 317.05 141.621 317.05V319.4H141.021C138.471 319.4 137.196 320.783 137.196 323.55V331H134.921V317.3H137.196V319.525ZM145.422 315.075C144.988 315.075 144.622 314.925 144.322 314.625C144.022 314.325 143.872 313.958 143.872 313.525C143.872 313.092 144.022 312.725 144.322 312.425C144.622 312.125 144.988 311.975 145.422 311.975C145.838 311.975 146.188 312.125 146.472 312.425C146.772 312.725 146.922 313.092 146.922 313.525C146.922 313.958 146.772 314.325 146.472 314.625C146.188 314.925 145.838 315.075 145.422 315.075ZM146.522 317.3V331H144.247V317.3H146.522ZM157.074 317.05C158.741 317.05 160.091 317.558 161.124 318.575C162.157 319.575 162.674 321.025 162.674 322.925V331H160.424V323.25C160.424 321.883 160.082 320.842 159.399 320.125C158.716 319.392 157.782 319.025 156.599 319.025C155.399 319.025 154.441 319.4 153.724 320.15C153.024 320.9 152.674 321.992 152.674 323.425V331H150.399V317.3H152.674V319.25C153.124 318.55 153.732 318.008 154.499 317.625C155.282 317.242 156.141 317.05 157.074 317.05ZM169.165 319.175V327.25C169.165 327.917 169.307 328.392 169.59 328.675C169.874 328.942 170.365 329.075 171.065 329.075H172.74V331H170.69C169.424 331 168.474 330.708 167.84 330.125C167.207 329.542 166.89 328.583 166.89 327.25V319.175H165.115V317.3H166.89V313.85H169.165V317.3H172.74V319.175H169.165Z"
            fill="white"
         />
         <path
            d="M146.293 417.293C145.902 417.684 145.902 418.317 146.293 418.707L152.657 425.071C153.047 425.462 153.681 425.462 154.071 425.071C154.462 424.681 154.462 424.048 154.071 423.657L148.414 418L154.071 412.343C154.462 411.953 154.462 411.32 154.071 410.929C153.681 410.539 153.047 410.539 152.657 410.929L146.293 417.293ZM232.003 332.925C228.299 381.755 191.636 417 147 417V419C192.783 419 230.222 382.845 233.997 333.076L232.003 332.925Z"
            fill="#626262"
         />
         <path
            d="M43.5325 332.237C43.142 331.846 42.5088 331.846 42.1183 332.237L35.7544 338.601C35.3638 338.991 35.3638 339.624 35.7544 340.015C36.1449 340.405 36.778 340.405 37.1686 340.015L42.8254 334.358L48.4823 340.015C48.8728 340.405 49.506 340.405 49.8965 340.015C50.287 339.624 50.287 338.991 49.8965 338.601L43.5325 332.237ZM128.247 417.2C77.2897 417.2 43.8254 373.393 43.8254 332.944L41.8254 332.944C41.8254 374.337 76.0319 419.2 128.247 419.2L128.247 417.2Z"
            fill="#626262"
         />
         <path
            d="M127.733 225.681C128.108 225.276 128.085 224.644 127.681 224.268L121.088 218.141C120.683 217.765 120.051 217.788 119.675 218.193C119.299 218.597 119.322 219.23 119.726 219.606L125.587 225.052L120.141 230.912C119.765 231.317 119.788 231.95 120.193 232.326C120.597 232.701 121.23 232.678 121.606 232.274L127.733 225.681ZM42.9993 309.037C44.6691 263.323 78.0286 227.796 127.037 225.999L126.963 224.001C76.8904 225.837 42.708 262.221 41.0007 308.964L42.9993 309.037Z"
            fill="#626262"
         />
         <path
            d="M231.477 311.082C231.868 311.471 232.501 311.47 232.891 311.078L239.24 304.699C239.629 304.308 239.628 303.674 239.236 303.285C238.845 302.895 238.212 302.897 237.822 303.288L232.179 308.959L226.508 303.315C226.117 302.926 225.484 302.927 225.094 303.319C224.705 303.71 224.706 304.343 225.098 304.733L231.477 311.082ZM146.567 226.235C195.618 229.839 231.075 265.563 231.182 310.375L233.182 310.37C233.072 264.382 196.673 227.911 146.713 224.241L146.567 226.235Z"
            fill="#626262"
         />
         <path
            d="M243.538 354.569C242.624 354.26 241.916 353.835 241.415 353.294C240.917 352.754 240.62 352.116 240.523 351.378C240.429 350.645 240.534 349.829 240.838 348.93L241.584 346.726L249.698 349.472L248.87 351.92C248.591 352.745 248.199 353.404 247.694 353.897C247.192 354.391 246.591 354.699 245.89 354.821C245.192 354.947 244.408 354.863 243.538 354.569ZM243.841 353.564C244.57 353.811 245.213 353.892 245.769 353.808C246.324 353.728 246.796 353.492 247.184 353.1C247.575 352.712 247.885 352.18 248.114 351.503L248.574 350.143L242.075 347.944L241.686 349.093C241.308 350.21 241.3 351.142 241.662 351.887C242.023 352.636 242.75 353.195 243.841 353.564Z"
            fill="white"
         />
         <path
            d="M244.253 358.665C244.054 359.174 243.771 359.567 243.403 359.843C243.035 360.119 242.61 360.274 242.127 360.308C241.648 360.343 241.137 360.255 240.595 360.043L240.033 359.824L241.645 355.692C240.938 355.429 240.335 355.395 239.836 355.59C239.336 355.785 238.966 356.19 238.726 356.805C238.579 357.183 238.483 357.531 238.438 357.85C238.394 358.168 238.378 358.509 238.391 358.875L237.594 358.564C237.577 358.21 237.596 357.871 237.65 357.548C237.703 357.229 237.809 356.868 237.966 356.464C238.191 355.889 238.503 355.432 238.903 355.094C239.306 354.76 239.781 354.564 240.328 354.505C240.875 354.446 241.478 354.545 242.137 354.802C242.781 355.053 243.296 355.378 243.682 355.775C244.069 356.178 244.314 356.626 244.416 357.118C244.516 357.614 244.461 358.13 244.253 358.665ZM243.514 358.364C243.703 357.88 243.695 357.433 243.491 357.022C243.286 356.611 242.911 356.267 242.365 355.991L241.13 359.157C241.488 359.293 241.823 359.358 242.134 359.354C242.449 359.355 242.723 359.276 242.957 359.116C243.195 358.957 243.381 358.706 243.514 358.364Z"
            fill="white"
         />
         <path
            d="M236.248 360.923L243.109 361.25L242.693 362.206L238.567 361.951C238.284 361.935 237.976 361.909 237.642 361.875C237.308 361.84 237.043 361.802 236.848 361.76L236.832 361.797C236.993 361.918 237.198 362.093 237.448 362.321C237.701 362.55 237.93 362.759 238.135 362.945L241.133 365.79L240.717 366.747L235.803 361.944L236.248 360.923Z"
            fill="white"
         />
         <path
            d="M239.442 369.63C239.205 370.122 238.892 370.492 238.504 370.739C238.116 370.985 237.68 371.107 237.196 371.103C236.716 371.101 236.213 370.974 235.689 370.721L235.146 370.459L237.073 366.464C236.388 366.147 235.79 366.066 235.277 366.222C234.763 366.378 234.363 366.753 234.077 367.348C233.9 367.714 233.777 368.053 233.709 368.367C233.64 368.681 233.597 369.02 233.582 369.386L232.811 369.014C232.822 368.659 232.867 368.323 232.946 368.006C233.024 367.692 233.157 367.34 233.345 366.949C233.613 366.393 233.96 365.962 234.385 365.656C234.813 365.354 235.301 365.195 235.851 365.179C236.401 365.162 236.995 365.307 237.632 365.615C238.254 365.915 238.743 366.278 239.097 366.705C239.452 367.137 239.661 367.602 239.724 368.101C239.786 368.603 239.692 369.113 239.442 369.63ZM238.73 369.273C238.955 368.805 238.982 368.358 238.81 367.933C238.638 367.507 238.29 367.136 237.767 366.818L236.29 369.879C236.637 370.042 236.966 370.133 237.277 370.153C237.59 370.179 237.87 370.12 238.116 369.979C238.365 369.839 238.57 369.604 238.73 369.273Z"
            fill="white"
         />
         <path
            d="M231.495 370.865L231.946 369.997L240.035 374.203L239.584 375.071L231.495 370.865Z"
            fill="white"
         />
         <path
            d="M230.781 378.825C230.321 378.567 229.944 378.277 229.65 377.955C229.356 377.633 229.148 377.29 229.026 376.925C228.903 376.561 228.866 376.181 228.913 375.786C228.961 375.397 229.098 375.001 229.324 374.6C229.535 374.225 229.793 373.917 230.098 373.677C230.405 373.441 230.747 373.279 231.124 373.191C231.498 373.106 231.902 373.102 232.334 373.178C232.763 373.259 233.208 373.428 233.668 373.686C234.281 374.031 234.744 374.427 235.056 374.876C235.372 375.327 235.534 375.808 235.543 376.319C235.553 376.835 235.408 377.361 235.107 377.895C234.82 378.406 234.456 378.788 234.013 379.042C233.569 379.298 233.071 379.411 232.52 379.379C231.97 379.352 231.391 379.168 230.781 378.825ZM233.174 374.565C232.725 374.312 232.301 374.153 231.904 374.086C231.507 374.02 231.148 374.061 230.828 374.208C230.508 374.355 230.238 374.624 230.018 375.016C229.8 375.404 229.711 375.773 229.752 376.123C229.791 376.477 229.942 376.806 230.205 377.111C230.469 377.415 230.825 377.694 231.275 377.947C231.721 378.197 232.139 378.354 232.53 378.416C232.923 378.481 233.279 378.439 233.596 378.289C233.912 378.14 234.182 377.868 234.404 377.473C234.731 376.891 234.778 376.355 234.547 375.867C234.313 375.381 233.856 374.948 233.174 374.565Z"
            fill="white"
         />
         <path
            d="M231.433 384.055C231.009 384.734 230.437 385.13 229.718 385.243C228.998 385.356 228.17 385.119 227.232 384.534C226.612 384.148 226.15 383.73 225.845 383.282C225.539 382.834 225.385 382.373 225.38 381.901C225.374 381.432 225.513 380.969 225.798 380.511C225.978 380.223 226.175 379.993 226.387 379.822C226.6 379.651 226.82 379.528 227.046 379.453C227.273 379.377 227.494 379.336 227.711 379.328L227.748 379.269C227.612 379.198 227.449 379.113 227.259 379.012C227.066 378.915 226.902 378.824 226.766 378.739L224.529 377.343L225.047 376.513L232.931 381.433L232.506 382.114L231.633 381.721L231.608 381.76C231.707 381.97 231.777 382.193 231.818 382.43C231.862 382.67 231.856 382.923 231.799 383.192C231.743 383.466 231.621 383.753 231.433 384.055ZM230.827 383.476C231.063 383.099 231.18 382.748 231.179 382.425C231.176 382.106 231.062 381.802 230.836 381.514C230.614 381.228 230.286 380.945 229.853 380.665L229.694 380.566C229.233 380.279 228.813 380.085 228.433 379.986C228.05 379.891 227.704 379.907 227.394 380.036C227.081 380.167 226.802 380.431 226.556 380.825C226.345 381.163 226.26 381.501 226.302 381.841C226.344 382.18 226.493 382.505 226.749 382.817C227.007 383.135 227.348 383.426 227.772 383.69C228.415 384.092 229.004 384.284 229.539 384.268C230.075 384.257 230.504 383.993 230.827 383.476Z"
            fill="white"
         />
         <path
            d="M225.281 393.093C224.872 393.67 224.412 393.997 223.901 394.075C223.393 394.155 222.807 393.959 222.141 393.487L218.711 391.051L219.268 390.267L222.659 392.676C223.083 392.977 223.466 393.109 223.807 393.074C224.149 393.044 224.448 392.849 224.704 392.489C225.063 391.983 225.178 391.511 225.048 391.073C224.918 390.636 224.568 390.215 223.998 389.81L221.069 387.73L221.629 386.942L225.021 389.351C225.304 389.552 225.569 389.678 225.816 389.729C226.06 389.783 226.287 389.761 226.494 389.664C226.703 389.573 226.894 389.405 227.068 389.159C227.315 388.812 227.441 388.483 227.447 388.171C227.453 387.859 227.348 387.554 227.133 387.258C226.918 386.966 226.605 386.675 226.195 386.383L223.424 384.415L223.987 383.622L229.223 387.34L228.768 387.981L227.943 387.574L227.912 387.617C228.019 387.851 228.078 388.092 228.089 388.339C228.1 388.587 228.068 388.832 227.991 389.075C227.915 389.317 227.797 389.55 227.639 389.773C227.356 390.171 227.045 390.451 226.705 390.612C226.367 390.779 226.003 390.815 225.614 390.721L225.584 390.764C225.764 391.151 225.821 391.546 225.755 391.95C225.692 392.355 225.534 392.736 225.281 393.093Z"
            fill="white"
         />
         <path
            d="M221.658 397.729C221.316 398.155 220.928 398.445 220.495 398.598C220.061 398.751 219.609 398.772 219.139 398.66C218.671 398.55 218.21 398.313 217.756 397.949L217.285 397.571L220.06 394.111C219.465 393.649 218.9 393.435 218.365 393.472C217.83 393.509 217.356 393.784 216.943 394.299C216.688 394.616 216.492 394.92 216.355 395.21C216.217 395.5 216.1 395.821 216.002 396.174L215.335 395.639C215.425 395.295 215.544 394.978 215.693 394.686C215.839 394.398 216.048 394.085 216.319 393.747C216.705 393.265 217.14 392.923 217.624 392.72C218.108 392.522 218.62 392.477 219.159 392.584C219.699 392.692 220.245 392.967 220.796 393.409C221.336 393.842 221.73 394.306 221.979 394.801C222.228 395.301 222.327 395.802 222.277 396.302C222.224 396.805 222.017 397.281 221.658 397.729ZM221.044 397.221C221.369 396.816 221.495 396.386 221.423 395.933C221.351 395.48 221.096 395.039 220.657 394.612L218.531 397.263C218.832 397.5 219.132 397.663 219.431 397.752C219.73 397.847 220.016 397.853 220.287 397.771C220.562 397.691 220.814 397.507 221.044 397.221Z"
            fill="white"
         />
         <path
            d="M217.176 403.012C216.672 403.583 216.15 403.891 215.61 403.936C215.074 403.984 214.496 403.735 213.878 403.189L210.741 400.421L211.377 399.701L214.466 402.426C214.867 402.78 215.249 402.953 215.611 402.944C215.97 402.938 216.317 402.746 216.65 402.369C217.12 401.835 217.3 401.327 217.19 400.844C217.079 400.362 216.737 399.867 216.163 399.36L213.641 397.135L214.285 396.406L219.1 400.655L218.581 401.243L217.789 400.741L217.755 400.78C217.834 401.033 217.861 401.288 217.836 401.547C217.813 401.809 217.745 402.063 217.63 402.311C217.519 402.562 217.367 402.796 217.176 403.012Z"
            fill="white"
         />
         <path
            d="M208.909 403.303C208.798 403.419 208.695 403.547 208.599 403.688C208.502 403.828 208.432 403.95 208.387 404.053L207.841 403.531C207.882 403.414 207.96 403.27 208.075 403.099C208.187 402.93 208.309 402.777 208.442 402.639C208.676 402.393 208.932 402.21 209.208 402.09C209.487 401.973 209.788 401.952 210.11 402.028C210.429 402.106 210.771 402.319 211.136 402.667L213.891 405.297L214.522 404.636L214.865 404.963L214.506 405.892L215.247 407.134L214.843 407.558L213.766 406.531L212.468 407.891L211.917 407.365L213.215 406.005L210.482 403.395C210.191 403.117 209.91 402.976 209.639 402.971C209.365 402.969 209.122 403.08 208.909 403.303Z"
            fill="white"
         />
         <path
            d="M203.166 407.947L203.899 407.264L209.141 412.887L211.113 411.049L211.712 411.692L207.045 416.043L206.445 415.4L208.408 413.57L203.166 407.947Z"
            fill="white"
         />
         <path
            d="M203.174 416.652C202.758 417.006 202.322 417.218 201.867 417.286C201.413 417.354 200.965 417.289 200.524 417.089C200.086 416.893 199.678 416.573 199.301 416.13L198.91 415.67L202.29 412.798C201.793 412.231 201.279 411.915 200.746 411.849C200.214 411.784 199.696 411.965 199.193 412.392C198.884 412.655 198.634 412.916 198.444 413.175C198.254 413.434 198.077 413.727 197.915 414.055L197.361 413.403C197.515 413.083 197.692 412.794 197.893 412.536C198.091 412.28 198.355 412.012 198.686 411.731C199.156 411.332 199.648 411.078 200.161 410.97C200.674 410.868 201.185 410.92 201.695 411.128C202.204 411.336 202.688 411.709 203.146 412.248C203.593 412.775 203.893 413.305 204.043 413.838C204.193 414.377 204.196 414.887 204.052 415.368C203.904 415.853 203.612 416.28 203.174 416.652ZM202.667 416.037C203.063 415.701 203.269 415.303 203.284 414.845C203.299 414.386 203.132 413.905 202.782 413.403L200.192 415.603C200.443 415.893 200.706 416.109 200.983 416.254C201.259 416.404 201.538 416.464 201.82 416.434C202.105 416.407 202.387 416.275 202.667 416.037Z"
            fill="white"
         />
         <path
            d="M193.975 417.887C193.723 417.564 193.592 417.227 193.583 416.878C193.573 416.534 193.676 416.19 193.892 415.844C194.105 415.5 194.419 415.166 194.836 414.843C195.19 414.567 195.519 414.356 195.821 414.21C196.123 414.064 196.411 413.966 196.684 413.917L197.235 414.625C196.949 414.684 196.63 414.783 196.279 414.923C195.927 415.063 195.602 415.249 195.303 415.481C194.865 415.822 194.602 416.14 194.515 416.435C194.428 416.73 194.48 417 194.669 417.244C194.777 417.382 194.912 417.473 195.073 417.515C195.234 417.563 195.446 417.565 195.708 417.52C195.972 417.477 196.314 417.389 196.734 417.255C197.154 417.127 197.529 417.031 197.86 416.966C198.191 416.907 198.489 416.915 198.755 416.99C199.018 417.068 199.259 417.247 199.477 417.528C199.81 417.956 199.893 418.419 199.725 418.916C199.557 419.418 199.19 419.888 198.626 420.327C198.321 420.565 198.011 420.756 197.698 420.9C197.384 421.05 197.072 421.164 196.762 421.242L196.542 420.426C196.822 420.352 197.104 420.254 197.389 420.131C197.675 420.008 197.941 419.85 198.187 419.659C198.542 419.383 198.769 419.112 198.87 418.846C198.966 418.583 198.936 418.349 198.778 418.146C198.655 417.988 198.511 417.893 198.346 417.858C198.177 417.826 197.961 417.84 197.697 417.902C197.434 417.964 197.096 418.058 196.685 418.185C196.276 418.314 195.907 418.406 195.577 418.459C195.25 418.516 194.955 418.503 194.693 418.42C194.43 418.342 194.19 418.165 193.975 417.887Z"
            fill="white"
         />
         <path
            d="M190.805 418.833C190.676 418.927 190.551 419.034 190.431 419.155C190.311 419.275 190.219 419.382 190.157 419.476L189.714 418.863C189.776 418.756 189.879 418.628 190.023 418.481C190.164 418.335 190.312 418.207 190.467 418.095C190.742 417.895 191.027 417.762 191.32 417.695C191.616 417.63 191.915 417.665 192.218 417.797C192.518 417.932 192.816 418.204 193.111 418.612L195.342 421.699L196.083 421.163L196.361 421.548L195.839 422.396L196.342 423.752L195.868 424.096L194.996 422.889L193.471 423.991L193.025 423.374L194.549 422.272L192.335 419.209C192.1 418.883 191.849 418.693 191.584 418.639C191.315 418.588 191.056 418.652 190.805 418.833Z"
            fill="white"
         />
         <path
            d="M191.773 425.146L188.147 419.846L188.95 419.297L192.576 424.597L191.773 425.146ZM193.521 426.861C193.389 426.951 193.247 426.985 193.094 426.962C192.94 426.944 192.801 426.845 192.677 426.664C192.556 426.487 192.514 426.322 192.551 426.169C192.585 426.018 192.668 425.897 192.8 425.807C192.939 425.712 193.085 425.676 193.238 425.699C193.387 425.724 193.523 425.825 193.644 426.003C193.768 426.183 193.813 426.346 193.78 426.492C193.746 426.643 193.66 426.766 193.521 426.861Z"
            fill="white"
         />
         <path
            d="M187.651 427.968C187.007 428.374 186.42 428.523 185.89 428.415C185.361 428.309 184.877 427.908 184.437 427.211L182.204 423.674L183.016 423.161L185.215 426.644C185.501 427.096 185.819 427.369 186.168 427.462C186.515 427.558 186.901 427.471 187.328 427.202C187.929 426.822 188.244 426.385 188.274 425.891C188.303 425.396 188.114 424.825 187.705 424.178L185.91 421.334L186.732 420.815L190.16 426.245L189.496 426.664L188.878 425.96L188.834 425.988C188.839 426.252 188.793 426.505 188.696 426.747C188.601 426.991 188.464 427.217 188.284 427.422C188.107 427.632 187.896 427.813 187.651 427.968Z"
            fill="white"
         />
         <path
            d="M178.128 422.667C178.863 422.253 179.507 422.071 180.06 422.122C180.612 422.17 181.027 422.441 181.305 422.934C181.503 423.285 181.561 423.646 181.48 424.02C181.395 424.395 181.179 424.734 180.83 425.038C181.015 425.024 181.198 425.055 181.38 425.132C181.559 425.21 181.698 425.338 181.798 425.515C181.913 425.719 181.958 425.929 181.932 426.146C181.904 426.368 181.814 426.616 181.659 426.891C182.019 426.845 182.37 426.912 182.713 427.091C183.055 427.275 183.332 427.556 183.545 427.934C183.771 428.335 183.881 428.724 183.873 429.1C183.868 429.48 183.749 429.834 183.517 430.162C183.285 430.491 182.944 430.781 182.495 431.034C182.396 431.09 182.295 431.141 182.19 431.186C182.085 431.237 181.981 431.28 181.879 431.314C181.78 431.353 181.69 431.381 181.611 431.399L179.692 432.48L179.384 431.934L180.343 431.225C180.166 431.15 179.991 431.038 179.817 430.89C179.643 430.741 179.492 430.552 179.364 430.324C179.049 429.766 178.988 429.216 179.179 428.673C179.373 428.133 179.8 427.677 180.46 427.305C180.616 427.217 180.784 427.14 180.963 427.076C181.078 426.89 181.148 426.716 181.173 426.553C181.195 426.393 181.164 426.24 181.082 426.094C181.02 425.985 180.939 425.916 180.838 425.888C180.734 425.862 180.61 425.869 180.467 425.909C180.325 425.953 180.166 426.025 179.989 426.124L179.004 426.68C178.395 427.023 177.857 427.158 177.39 427.085C176.919 427.014 176.546 426.734 176.27 426.244C175.921 425.624 175.905 425.008 176.222 424.394C176.54 423.78 177.175 423.204 178.128 422.667ZM178.476 423.345C178.013 423.606 177.658 423.869 177.408 424.135C177.154 424.4 177.002 424.663 176.952 424.924C176.896 425.184 176.937 425.435 177.073 425.676C177.2 425.901 177.347 426.042 177.514 426.101C177.679 426.155 177.871 426.146 178.09 426.072C178.31 426.001 178.563 425.886 178.849 425.725L179.819 425.178C180.071 425.036 180.268 424.873 180.411 424.689C180.554 424.505 180.634 424.308 180.649 424.098C180.662 423.889 180.604 423.67 180.475 423.442C180.304 423.14 180.047 422.982 179.704 422.969C179.358 422.953 178.949 423.078 178.476 423.345ZM180.777 427.94C180.373 428.168 180.126 428.442 180.036 428.761C179.947 429.081 180.013 429.436 180.234 429.827C180.47 430.246 180.75 430.5 181.075 430.591C181.401 430.685 181.767 430.618 182.172 430.389C182.56 430.171 182.798 429.893 182.886 429.556C182.973 429.225 182.899 428.852 182.665 428.436C182.45 428.055 182.18 427.822 181.854 427.737C181.527 427.652 181.169 427.719 180.777 427.94Z"
            fill="white"
         />
         <path
            d="M60.7603 404.393C60.2195 403.944 59.8294 403.506 59.5901 403.079C59.3454 402.652 59.2494 402.23 59.3023 401.811C59.3551 401.393 59.5575 400.972 59.9094 400.548C60.1989 400.2 60.5041 399.961 60.825 399.831C61.1434 399.705 61.4647 399.654 61.7888 399.68C62.1129 399.705 62.4231 399.775 62.7194 399.889L63.3717 395.426L64.2641 396.168L63.594 400.257L64.9642 401.396L67.248 398.646L68.0142 399.283L62.5407 405.872L60.7603 404.393ZM61.3558 403.768L62.3248 404.573L64.4251 402.045L63.3794 401.176C62.8415 400.729 62.3553 400.511 61.9207 400.521C61.4831 400.528 61.0871 400.745 60.7326 401.171C60.3608 401.619 60.2327 402.048 60.3484 402.459C60.461 402.868 60.7968 403.304 61.3558 403.768Z"
            fill="white"
         />
         <path
            d="M56.8015 398.223C56.3989 397.853 56.1358 397.447 56.0121 397.004C55.8885 396.561 55.8985 396.109 56.0422 395.647C56.1833 395.187 56.4507 394.744 56.8447 394.315L57.2531 393.871L60.5184 396.873C61.02 396.31 61.2706 395.76 61.2702 395.224C61.2698 394.688 61.0266 394.196 60.5406 393.749C60.2415 393.474 59.9519 393.258 59.6716 393.102C59.3913 392.945 59.0786 392.806 58.7335 392.685L59.3125 392.055C59.6489 392.168 59.9576 392.309 60.2383 392.476C60.5162 392.642 60.8147 392.871 61.1339 393.164C61.5883 393.582 61.9005 394.039 62.0706 394.535C62.2353 395.031 62.2458 395.545 62.1022 396.076C61.9587 396.608 61.6476 397.134 61.1691 397.654C60.7012 398.163 60.2119 398.525 59.7012 398.74C59.1849 398.955 58.679 399.021 58.1834 398.936C57.6849 398.85 57.2242 398.612 56.8015 398.223ZM57.3495 397.645C57.7319 397.996 58.1518 398.151 58.6089 398.11C59.0661 398.069 59.5225 397.844 59.978 397.435L57.4762 395.135C57.22 395.419 57.0372 395.707 56.9279 395.999C56.813 396.292 56.7876 396.576 56.8517 396.853C56.9132 397.132 57.0792 397.396 57.3495 397.645Z"
            fill="white"
         />
         <path
            d="M57.9551 390.27L58.6518 390.957L52.2502 397.449L51.5534 396.762L57.9551 390.27Z"
            fill="white"
         />
         <path
            d="M50.2494 391.715C49.8742 391.317 49.6407 390.893 49.5488 390.443C49.457 389.993 49.4992 389.542 49.6754 389.091C49.8488 388.643 50.1472 388.219 50.5707 387.82L51.0097 387.406L54.053 390.633C54.5934 390.107 54.8825 389.577 54.9203 389.042C54.9581 388.507 54.7505 387.999 54.2975 387.519C54.0188 387.223 53.7452 386.987 53.4768 386.811C53.2084 386.634 52.9064 386.474 52.5707 386.328L53.1931 385.741C53.5207 385.878 53.8185 386.04 54.0866 386.228C54.352 386.412 54.6335 386.662 54.931 386.978C55.3544 387.427 55.6333 387.905 55.7677 388.412C55.8966 388.918 55.8705 389.431 55.6895 389.951C55.5085 390.471 55.1608 390.973 54.6465 391.458C54.1435 391.933 53.6296 392.259 53.1049 392.437C52.5747 392.615 52.0654 392.644 51.577 392.525C51.0859 392.403 50.6434 392.133 50.2494 391.715ZM50.8372 391.177C51.1936 391.555 51.6013 391.74 52.0603 391.731C52.5193 391.722 52.9905 391.53 53.474 391.155L51.1423 388.682C50.8665 388.948 50.6636 389.222 50.5338 389.506C50.3983 389.789 50.3528 390.071 50.3971 390.352C50.4385 390.635 50.5852 390.91 50.8372 391.177Z"
            fill="white"
         />
         <path
            d="M46.0774 387.017C45.5804 386.435 45.3422 385.891 45.3628 385.386C45.3834 384.88 45.6804 384.383 46.2539 383.893L49.5744 381.06L50.0346 381.599L49.4343 382.358L49.4647 382.393C49.7596 382.378 50.0314 382.393 50.28 382.437C50.5256 382.484 50.7633 382.579 50.9931 382.722C51.2173 382.865 51.4499 383.077 51.6908 383.359C51.9444 383.656 52.118 383.965 52.2118 384.286C52.3031 384.603 52.3003 384.919 52.2034 385.233C52.104 385.543 51.8924 385.837 51.5685 386.113C51.0812 386.529 50.542 386.656 49.9509 386.492C49.3597 386.329 48.7151 385.863 48.0168 385.093L47.2623 384.281L46.9636 384.536C46.5417 384.896 46.3234 385.239 46.3087 385.564C46.294 385.89 46.4274 386.218 46.7089 386.548C46.9269 386.803 47.172 387.015 47.4441 387.184C47.7161 387.352 47.9914 387.497 48.27 387.619L47.9024 388.325C47.6018 388.202 47.2897 388.032 46.966 387.815C46.6424 387.598 46.3462 387.332 46.0774 387.017ZM47.7913 383.845L48.4577 384.562C49.0013 385.151 49.4673 385.496 49.8556 385.596C50.2439 385.696 50.5985 385.609 50.9194 385.335C51.1987 385.096 51.333 384.835 51.3221 384.552C51.3113 384.268 51.1867 383.987 50.9484 383.708C50.5782 383.274 50.1548 383.022 49.6783 382.951C49.2018 382.88 48.7229 383.05 48.2415 383.46L47.7913 383.845Z"
            fill="white"
         />
         <path
            d="M44.8197 377.813C45.1438 377.561 45.4803 377.431 45.8295 377.422C46.1731 377.413 46.5178 377.516 46.8636 377.732C47.207 377.946 47.5403 378.26 47.8636 378.677C48.139 379.032 48.3495 379.361 48.4951 379.663C48.6407 379.965 48.738 380.253 48.7871 380.527L48.0788 381.076C48.0202 380.79 47.9212 380.472 47.7818 380.12C47.6424 379.768 47.4566 379.443 47.2243 379.143C46.8842 378.705 46.5666 378.442 46.2714 378.355C45.9762 378.268 45.7066 378.319 45.4628 378.508C45.324 378.616 45.2332 378.75 45.1905 378.912C45.1424 379.073 45.1408 379.284 45.1857 379.546C45.2276 379.81 45.3152 380.153 45.4487 380.573C45.5767 380.993 45.6727 381.368 45.7367 381.699C45.7953 382.03 45.7869 382.328 45.7116 382.594C45.6339 382.857 45.4546 383.098 45.1737 383.316C44.7448 383.648 44.282 383.731 43.7854 383.562C43.2834 383.393 42.8132 383.026 42.375 382.461C42.1379 382.156 41.9472 381.846 41.803 381.533C41.6533 381.219 41.5396 380.907 41.4618 380.596L42.2787 380.378C42.352 380.657 42.45 380.94 42.5727 381.225C42.6954 381.511 42.8525 381.777 43.0441 382.024C43.3194 382.379 43.59 382.606 43.8558 382.707C44.1191 382.804 44.3526 382.773 44.5563 382.615C44.7137 382.493 44.8098 382.35 44.8446 382.184C44.877 382.016 44.8625 381.799 44.8011 381.535C44.7397 381.272 44.6459 380.934 44.5196 380.523C44.3902 380.114 44.299 379.745 44.2459 379.415C44.1898 379.088 44.2033 378.793 44.2865 378.531C44.3642 378.268 44.542 378.028 44.8197 377.813Z"
            fill="white"
         />
         <path
            d="M38.8755 377.689C38.561 377.241 38.3904 376.788 38.3639 376.329C38.3374 375.87 38.4436 375.431 38.6824 375.01C38.9181 374.591 39.274 374.214 39.7501 373.879L40.2439 373.532L42.7947 377.161C43.4048 376.718 43.7667 376.234 43.8805 375.71C43.9944 375.186 43.8615 374.654 43.4818 374.114C43.2482 373.782 43.0111 373.509 42.7707 373.296C42.5303 373.083 42.2543 372.881 41.9429 372.689L42.6427 372.197C42.9474 372.379 43.2191 372.582 43.4576 372.806C43.6939 373.027 43.9367 373.314 44.1861 373.669C44.541 374.174 44.7488 374.687 44.8093 375.208C44.8644 375.727 44.7653 376.232 44.5118 376.72C44.2584 377.209 43.8425 377.656 43.2641 378.063C42.6984 378.461 42.1432 378.71 41.5985 378.811C41.0482 378.912 40.54 378.868 40.0736 378.68C39.6051 378.489 39.2057 378.158 38.8755 377.689ZM39.5341 377.24C39.8329 377.665 40.21 377.906 40.6655 377.963C41.121 378.02 41.6149 377.897 42.1471 377.595L40.1927 374.815C39.8817 375.038 39.6417 375.281 39.4726 375.543C39.2981 375.804 39.2127 376.076 39.2165 376.36C39.2171 376.646 39.3229 376.94 39.5341 377.24Z"
            fill="white"
         />
         <path
            d="M40.9033 256.882C41.5129 255.96 42.1386 255.406 42.7804 255.222C43.421 255.032 44.077 255.159 44.7482 255.602C45.0513 255.803 45.3063 256.044 45.5132 256.326C45.719 256.603 45.853 256.921 45.9151 257.28C45.9739 257.637 45.944 258.037 45.8254 258.478C45.7058 258.914 45.4736 259.393 45.129 259.914L44.5538 260.784L47.3643 262.642L46.815 263.473L39.669 258.749L40.9033 256.882ZM41.5603 257.428L40.927 258.387L43.8402 260.312L44.3539 259.535C44.6555 259.079 44.8576 258.667 44.9602 258.299C45.0649 257.928 45.0588 257.594 44.9417 257.297C44.8213 256.997 44.5787 256.727 44.2137 256.485C43.738 256.171 43.2843 256.089 42.8526 256.239C42.4176 256.387 41.9869 256.783 41.5603 257.428Z"
            fill="white"
         />
         <path
            d="M50.876 257.505L50.3099 258.303L42.8735 253.028L43.4396 252.23L50.876 257.505Z"
            fill="white"
         />
         <path
            d="M48.073 250.313C48.5353 249.703 49.0155 249.354 49.5136 249.266C50.0116 249.177 50.5612 249.361 51.1621 249.816L54.6418 252.452L54.2138 253.017L53.3439 252.593L53.3156 252.631C53.3939 252.915 53.438 253.184 53.4477 253.436C53.4543 253.686 53.4125 253.939 53.3222 254.194C53.2312 254.443 53.0736 254.716 52.8496 255.012C52.6137 255.323 52.3493 255.559 52.0564 255.72C51.7658 255.877 51.4569 255.942 51.1297 255.914C50.8048 255.884 50.4727 255.74 50.1333 255.483C49.6226 255.096 49.3835 254.597 49.4161 253.984C49.4487 253.372 49.7663 252.642 50.3687 251.795L51 250.884L50.6871 250.647C50.2449 250.312 49.8632 250.172 49.5418 250.228C49.2204 250.283 48.9289 250.484 48.6671 250.83C48.4642 251.097 48.3097 251.382 48.2036 251.684C48.0975 251.986 48.0148 252.286 47.9556 252.584L47.1866 252.376C47.2429 252.056 47.3421 251.715 47.4845 251.352C47.6268 250.99 47.823 250.644 48.073 250.313ZM51.5394 251.307L50.9813 252.112C50.5227 252.769 50.2862 253.298 50.2718 253.699C50.2574 254.1 50.4183 254.427 50.7546 254.682C51.0473 254.904 51.331 254.979 51.6055 254.908C51.8801 254.836 52.1282 254.654 52.3499 254.362C52.6943 253.907 52.85 253.439 52.8171 252.959C52.7843 252.478 52.5156 252.047 52.0112 251.665L51.5394 251.307Z"
            fill="white"
         />
         <path
            d="M52.3362 244.975C52.8239 244.39 53.3367 244.067 53.8749 244.007C54.4101 243.945 54.9942 244.177 55.6274 244.705L58.8413 247.383L58.2262 248.122L55.0617 245.485C54.6506 245.142 54.2643 244.98 53.9027 244.999C53.5436 245.015 53.2027 245.217 52.8801 245.604C52.425 246.15 52.2594 246.663 52.3835 247.143C52.5075 247.622 52.8636 248.107 53.4518 248.597L56.0355 250.75L55.4128 251.498L50.4794 247.386L50.9821 246.783L51.7871 247.263L51.8208 247.223C51.7343 246.973 51.7 246.718 51.718 246.458C51.733 246.196 51.7943 245.94 51.9018 245.689C52.0064 245.435 52.1512 245.197 52.3362 244.975Z"
            fill="white"
         />
         <path
            d="M56.824 239.906C57.3399 239.345 57.8681 239.048 58.4085 239.015C58.9461 238.979 59.5181 239.24 60.1245 239.798L63.2026 242.632L62.5518 243.339L59.5211 240.549C59.1274 240.186 58.7495 240.006 58.3874 240.007C58.0279 240.005 57.6776 240.19 57.3363 240.561C56.8548 241.084 56.6642 241.588 56.7644 242.073C56.8647 242.558 57.1965 243.06 57.7598 243.578L60.2343 245.856L59.5756 246.572L54.8507 242.223L55.3824 241.645L56.1628 242.164L56.1985 242.125C56.1244 241.871 56.1027 241.615 56.1335 241.357C56.1614 241.096 56.2353 240.843 56.355 240.597C56.4719 240.349 56.6283 240.119 56.824 239.906Z"
            fill="white"
         />
         <path
            d="M60.1725 236.609L64.7393 241.124L64.0555 241.816L59.4887 237.301L60.1725 236.609ZM58.1304 235.258C58.243 235.144 58.3767 235.084 58.5313 235.077C58.6859 235.065 58.841 235.136 58.9966 235.29C59.1494 235.441 59.2221 235.595 59.2147 235.753C59.21 235.908 59.1514 236.042 59.0388 236.156C58.9207 236.275 58.7843 236.338 58.6297 236.345C58.4778 236.348 58.3255 236.274 58.1727 236.123C58.0171 235.97 57.9417 235.818 57.9463 235.669C57.951 235.514 58.0124 235.377 58.1304 235.258Z"
            fill="white"
         />
         <path
            d="M63.6357 233.1C64.1903 232.578 64.7383 232.319 65.2798 232.325C65.8185 232.327 66.3704 232.628 66.9354 233.228L69.8032 236.274L69.1035 236.933L66.2799 233.934C65.9131 233.544 65.5491 233.337 65.1878 233.312C64.8294 233.285 64.4667 233.444 64.0998 233.789C63.5822 234.277 63.3561 234.766 63.4214 235.257C63.4867 235.748 63.7818 236.272 64.3066 236.83L66.6121 239.279L65.9039 239.945L61.5018 235.27L62.0735 234.731L62.8148 235.305L62.8532 235.269C62.7974 235.01 62.7941 234.753 62.8432 234.498C62.8897 234.239 62.9815 233.992 63.1185 233.756C63.2528 233.517 63.4252 233.298 63.6357 233.1Z"
            fill="white"
         />
         <path
            d="M73.894 236.572C73.2523 237.12 72.655 237.422 72.1019 237.478C71.5514 237.537 71.0923 237.352 70.7245 236.921C70.4633 236.615 70.3366 236.271 70.3445 235.889C70.3555 235.505 70.5028 235.13 70.7865 234.765C70.608 234.814 70.422 234.819 70.2285 234.779C70.0379 234.736 69.8767 234.637 69.7448 234.483C69.5926 234.305 69.5084 234.107 69.4923 233.889C69.4767 233.667 69.5181 233.405 69.6165 233.105C69.2723 233.22 68.9146 233.222 68.5437 233.112C68.1732 232.997 67.8472 232.775 67.5656 232.445C67.2663 232.094 67.0842 231.734 67.0192 231.363C66.9518 230.989 67.0003 230.619 67.165 230.252C67.3297 229.886 67.6081 229.535 68.0002 229.2C68.0864 229.127 68.1764 229.057 68.2701 228.993C68.3643 228.923 68.4579 228.861 68.5507 228.807C68.6411 228.751 68.7236 228.706 68.7982 228.673L70.4737 227.242L70.8808 227.719L70.0758 228.599C70.2639 228.639 70.4573 228.715 70.6563 228.828C70.8552 228.94 71.0396 229.096 71.2095 229.295C71.6255 229.782 71.7916 230.311 71.7079 230.881C71.6217 231.447 71.2904 231.977 70.714 232.469C70.5774 232.585 70.4276 232.693 70.2647 232.791C70.1876 232.995 70.1523 233.18 70.1588 233.344C70.1682 233.505 70.2275 233.65 70.3366 233.777C70.4177 233.872 70.5106 233.924 70.6153 233.932C70.7229 233.938 70.843 233.907 70.9758 233.84C71.106 233.77 71.2483 233.669 71.4028 233.537L72.2628 232.803C72.7946 232.349 73.2967 232.113 73.7692 232.095C74.2446 232.074 74.6649 232.278 75.0302 232.705C75.4918 233.246 75.6258 233.848 75.4322 234.512C75.2385 235.175 74.7258 235.862 73.894 236.572ZM73.4217 235.974C73.8257 235.629 74.1244 235.302 74.3178 234.993C74.5166 234.685 74.6155 234.397 74.6143 234.131C74.6186 233.866 74.5308 233.627 74.3507 233.416C74.1833 233.22 74.0119 233.11 73.8365 233.085C73.6637 233.063 73.4772 233.109 73.277 233.224C73.0742 233.335 72.8481 233.497 72.5986 233.71L71.7519 234.433C71.5321 234.621 71.3696 234.819 71.2646 235.027C71.1595 235.234 71.1195 235.443 71.1445 235.653C71.1725 235.86 71.2715 236.063 71.4414 236.262C71.6671 236.527 71.9498 236.632 72.2892 236.579C72.6313 236.528 73.0087 236.327 73.4217 235.974ZM70.2804 231.907C70.6339 231.605 70.8237 231.289 70.8498 230.958C70.8758 230.628 70.743 230.292 70.4513 229.95C70.1394 229.585 69.8154 229.389 69.4795 229.362C69.141 229.333 68.795 229.469 68.4415 229.771C68.1028 230.06 67.9226 230.378 67.9007 230.726C67.8793 231.068 68.0233 231.42 68.3327 231.782C68.6168 232.115 68.927 232.292 69.2634 232.313C69.5998 232.334 69.9388 232.198 70.2804 231.907Z"
            fill="white"
         />
         <path
            d="M215.372 234.445C214.671 235.108 213.963 235.533 213.251 235.723C212.541 235.91 211.837 235.873 211.14 235.613C210.448 235.352 209.777 234.877 209.125 234.187L207.528 232.496L213.757 226.615L215.531 228.493C216.129 229.127 216.527 229.782 216.726 230.459C216.928 231.134 216.918 231.809 216.697 232.485C216.481 233.162 216.04 233.815 215.372 234.445ZM214.627 233.707C215.186 233.178 215.559 232.649 215.746 232.118C215.935 231.59 215.947 231.063 215.783 230.536C215.624 230.009 215.299 229.486 214.808 228.966L213.823 227.922L208.834 232.633L209.667 233.515C210.476 234.372 211.295 234.816 212.124 234.845C212.954 234.877 213.789 234.498 214.627 233.707Z"
            fill="white"
         />
         <path
            d="M219.326 235.726C219.683 236.139 219.898 236.573 219.97 237.027C220.042 237.481 219.98 237.929 219.784 238.372C219.592 238.812 219.275 239.222 218.834 239.603L218.378 239.997L215.479 236.64C214.916 237.142 214.604 237.659 214.542 238.192C214.481 238.725 214.666 239.241 215.098 239.741C215.363 240.048 215.626 240.296 215.887 240.484C216.147 240.672 216.442 240.846 216.771 241.005L216.123 241.565C215.802 241.414 215.512 241.239 215.252 241.04C214.995 240.844 214.725 240.581 214.441 240.253C214.038 239.786 213.78 239.297 213.668 238.784C213.562 238.272 213.61 237.761 213.814 237.25C214.017 236.738 214.387 236.252 214.922 235.789C215.445 235.338 215.973 235.034 216.505 234.879C217.042 234.725 217.552 234.718 218.035 234.858C218.52 235.002 218.951 235.291 219.326 235.726ZM218.715 236.237C218.376 235.844 217.976 235.642 217.518 235.63C217.059 235.619 216.579 235.79 216.08 236.144L218.301 238.716C218.588 238.463 218.803 238.198 218.945 237.92C219.093 237.643 219.151 237.363 219.119 237.081C219.09 236.797 218.955 236.515 218.715 236.237Z"
            fill="white"
         />
         <path
            d="M220.671 244.9C220.351 245.156 220.016 245.292 219.668 245.306C219.324 245.321 218.978 245.223 218.629 245.012C218.282 244.805 217.944 244.495 217.614 244.084C217.333 243.733 217.117 243.408 216.967 243.108C216.816 242.808 216.715 242.522 216.661 242.249L217.361 241.688C217.424 241.973 217.528 242.29 217.673 242.64C217.818 242.989 218.009 243.312 218.246 243.607C218.593 244.04 218.914 244.298 219.211 244.38C219.508 244.463 219.776 244.408 220.017 244.215C220.154 244.105 220.243 243.969 220.283 243.807C220.328 243.645 220.327 243.433 220.278 243.172C220.232 242.909 220.139 242.568 219.998 242.15C219.864 241.732 219.762 241.358 219.693 241.028C219.629 240.699 219.633 240.4 219.704 240.133C219.777 239.869 219.953 239.626 220.23 239.403C220.654 239.064 221.115 238.974 221.614 239.135C222.119 239.296 222.595 239.655 223.042 240.213C223.284 240.515 223.479 240.821 223.629 241.132C223.783 241.444 223.902 241.754 223.984 242.063L223.171 242.295C223.093 242.017 222.991 241.736 222.864 241.452C222.737 241.169 222.575 240.905 222.38 240.661C222.099 240.311 221.825 240.087 221.557 239.991C221.293 239.898 221.06 239.932 220.858 240.093C220.703 240.218 220.609 240.363 220.577 240.529C220.547 240.698 220.565 240.914 220.631 241.177C220.696 241.44 220.795 241.776 220.928 242.185C221.064 242.592 221.161 242.96 221.219 243.289C221.281 243.615 221.272 243.91 221.193 244.174C221.119 244.438 220.945 244.68 220.671 244.9Z"
            fill="white"
         />
         <path
            d="M225.603 243.705L220.489 247.59L219.901 246.815L225.015 242.931L225.603 243.705ZM227.229 241.874C227.326 242.002 227.367 242.143 227.351 242.297C227.341 242.451 227.249 242.595 227.075 242.727C226.904 242.857 226.741 242.907 226.586 242.878C226.433 242.852 226.309 242.775 226.212 242.647C226.11 242.513 226.067 242.369 226.083 242.215C226.1 242.064 226.195 241.924 226.366 241.794C226.54 241.662 226.701 241.608 226.848 241.634C227 241.661 227.127 241.741 227.229 241.874Z"
            fill="white"
         />
         <path
            d="M220.218 252.095C219.727 251.409 219.477 250.788 219.469 250.232C219.457 249.678 219.681 249.237 220.142 248.907C220.469 248.673 220.823 248.577 221.202 248.617C221.584 248.661 221.945 248.84 222.285 249.154C222.251 248.972 222.262 248.786 222.319 248.597C222.378 248.41 222.49 248.258 222.655 248.14C222.846 248.004 223.05 247.937 223.268 247.939C223.491 247.943 223.748 248.007 224.038 248.13C223.954 247.777 223.982 247.421 224.123 247.061C224.27 246.702 224.519 246.396 224.872 246.143C225.247 245.875 225.622 245.725 225.997 245.692C226.375 245.657 226.74 245.737 227.091 245.932C227.442 246.128 227.768 246.435 228.068 246.854C228.134 246.947 228.195 247.042 228.251 247.141C228.313 247.241 228.367 247.339 228.412 247.437C228.461 247.531 228.498 247.617 228.525 247.695L229.806 249.487L229.296 249.851L228.489 248.974C228.433 249.158 228.34 249.344 228.211 249.533C228.082 249.721 227.911 249.892 227.698 250.044C227.177 250.417 226.636 250.537 226.076 250.405C225.518 250.27 225.019 249.895 224.579 249.278C224.474 249.132 224.38 248.974 224.296 248.803C224.099 248.709 223.919 248.658 223.755 248.65C223.593 248.646 223.444 248.692 223.307 248.79C223.206 248.863 223.146 248.951 223.129 249.055C223.114 249.161 223.134 249.284 223.19 249.422C223.248 249.557 223.337 249.708 223.455 249.873L224.113 250.793C224.52 251.361 224.712 251.882 224.69 252.354C224.669 252.83 224.431 253.231 223.973 253.558C223.395 253.972 222.784 254.054 222.139 253.804C221.495 253.554 220.854 252.985 220.218 252.095ZM220.854 251.676C221.163 252.108 221.464 252.433 221.755 252.653C222.045 252.877 222.323 253 222.588 253.022C222.852 253.049 223.097 252.982 223.323 252.82C223.533 252.67 223.657 252.509 223.697 252.337C223.734 252.166 223.704 251.976 223.607 251.767C223.513 251.556 223.371 251.316 223.18 251.05L222.532 250.144C222.364 249.909 222.181 249.73 221.983 249.608C221.785 249.485 221.58 249.427 221.369 249.434C221.16 249.445 220.949 249.526 220.736 249.678C220.454 249.88 220.324 250.153 220.349 250.496C220.37 250.841 220.538 251.234 220.854 251.676ZM225.176 248.894C225.446 249.272 225.745 249.489 226.072 249.543C226.399 249.597 226.745 249.494 227.11 249.232C227.501 248.953 227.724 248.647 227.779 248.314C227.838 247.98 227.732 247.623 227.461 247.245C227.202 246.883 226.9 246.676 226.556 246.625C226.217 246.574 225.854 246.687 225.466 246.965C225.111 247.219 224.908 247.513 224.858 247.846C224.808 248.18 224.914 248.529 225.176 248.894Z"
            fill="white"
         />
         <path
            d="M232.051 252.731C232.467 253.369 232.625 253.954 232.525 254.486C232.427 255.016 232.034 255.506 231.344 255.957L227.84 258.243L227.315 257.439L230.764 255.187C231.212 254.895 231.48 254.573 231.568 254.222C231.658 253.874 231.566 253.489 231.29 253.067C230.902 252.471 230.46 252.163 229.965 252.14C229.47 252.118 228.902 252.316 228.261 252.735L225.445 254.573L224.913 253.759L230.29 250.249L230.72 250.906L230.024 251.535L230.053 251.579C230.318 251.57 230.571 251.612 230.814 251.705C231.06 251.796 231.288 251.93 231.496 252.106C231.708 252.281 231.893 252.489 232.051 252.731Z"
            fill="white"
         />
         <g filter="url(#filter4_b_226_1189)">
            <rect
               x="74"
               y="570"
               width="70"
               height="70"
               rx="16"
               fill="url(#paint4_radial_226_1189)"
            />
            <rect
               x="74.5"
               y="570.5"
               width="69"
               height="69"
               rx="15.5"
               stroke="#626262"
            />
         </g>
         <g filter="url(#filter5_b_226_1189)">
            <rect
               x="154"
               y="814"
               width="70"
               height="70"
               rx="16"
               fill="url(#paint5_radial_226_1189)"
            />
            <rect
               x="154.5"
               y="814.5"
               width="69"
               height="69"
               rx="15.5"
               stroke="#626262"
            />
         </g>
         <g filter="url(#filter6_b_226_1189)">
            <rect
               x="59"
               y="814"
               width="70"
               height="70"
               rx="16"
               fill="url(#paint6_radial_226_1189)"
            />
            <rect
               x="59.5"
               y="814.5"
               width="69"
               height="69"
               rx="15.5"
               stroke="#626262"
            />
         </g>
         <g filter="url(#filter7_b_226_1189)">
            <circle
               cx="77.5"
               cy="576.5"
               r="15.5"
               fill="url(#paint7_radial_226_1189)"
               fillOpacity="0.8"
            />
            <circle cx="77.5" cy="576.5" r="15" stroke="#626262" />
         </g>
         <g filter="url(#filter8_b_226_1189)">
            <circle
               cx="63.5"
               cy="816.5"
               r="15.5"
               fill="url(#paint8_radial_226_1189)"
               fillOpacity="0.8"
            />
            <circle cx="63.5" cy="816.5" r="15" stroke="#626262" />
         </g>
         <path
            d="M73.0604 581.534C73.4684 581.21 73.6544 581.06 73.6184 581.084C74.7944 580.112 75.7184 579.314 76.3904 578.69C77.0744 578.066 77.6504 577.412 78.1184 576.728C78.5864 576.044 78.8204 575.378 78.8204 574.73C78.8204 574.238 78.7064 573.854 78.4784 573.578C78.2504 573.302 77.9084 573.164 77.4524 573.164C76.9964 573.164 76.6364 573.338 76.3724 573.686C76.1204 574.022 75.9944 574.502 75.9944 575.126H73.0244C73.0484 574.106 73.2644 573.254 73.6724 572.57C74.0924 571.886 74.6384 571.382 75.3104 571.058C75.9944 570.734 76.7504 570.572 77.5784 570.572C79.0064 570.572 80.0804 570.938 80.8004 571.67C81.5324 572.402 81.8984 573.356 81.8984 574.532C81.8984 575.816 81.4604 577.01 80.5844 578.114C79.7084 579.206 78.5924 580.274 77.2364 581.318H82.0964V583.82H73.0604V581.534Z"
            fill="white"
         />
         <path
            d="M57.9688 813.568C58.0168 812.284 58.4368 811.294 59.2288 810.598C60.0208 809.902 61.0948 809.554 62.4508 809.554C63.3508 809.554 64.1188 809.71 64.7548 810.022C65.4028 810.334 65.8888 810.76 66.2128 811.3C66.5488 811.84 66.7168 812.446 66.7168 813.118C66.7168 813.91 66.5188 814.558 66.1228 815.062C65.7268 815.554 65.2648 815.89 64.7368 816.07V816.142C65.4208 816.37 65.9608 816.748 66.3568 817.276C66.7528 817.804 66.9508 818.482 66.9508 819.31C66.9508 820.054 66.7768 820.714 66.4288 821.29C66.0928 821.854 65.5948 822.298 64.9348 822.622C64.2868 822.946 63.5128 823.108 62.6128 823.108C61.1728 823.108 60.0208 822.754 59.1568 822.046C58.3048 821.338 57.8548 820.27 57.8068 818.842H60.7948C60.8068 819.37 60.9568 819.79 61.2448 820.102C61.5328 820.402 61.9528 820.552 62.5048 820.552C62.9728 820.552 63.3328 820.42 63.5848 820.156C63.8488 819.88 63.9808 819.52 63.9808 819.076C63.9808 818.5 63.7948 818.086 63.4228 817.834C63.0628 817.57 62.4808 817.438 61.6768 817.438H61.1008V814.936H61.6768C62.2888 814.936 62.7808 814.834 63.1528 814.63C63.5368 814.414 63.7288 814.036 63.7288 813.496C63.7288 813.064 63.6088 812.728 63.3688 812.488C63.1288 812.248 62.7988 812.128 62.3788 812.128C61.9228 812.128 61.5808 812.266 61.3528 812.542C61.1368 812.818 61.0108 813.16 60.9748 813.568H57.9688Z"
            fill="white"
         />
         <g clipPath="url(#clip2_226_1189)">
            <path
               d="M122.102 593.987C122.102 601.328 122.102 608.669 122.102 616.01C122.089 616.051 122.068 616.085 122.061 616.126C121.796 617.291 120.924 617.992 119.726 617.992C112.609 617.992 105.493 617.992 98.3766 617.992C96.9942 617.999 96 617.005 96 615.636C96 608.547 96 601.451 96.0068 594.362C96.0068 594.144 96.034 593.919 96.0885 593.708C96.3541 592.666 97.2598 592.006 98.3971 591.999C103.872 591.999 109.347 591.999 114.829 591.999C116.477 591.999 118.125 591.992 119.773 591.999C120.761 592.006 121.469 592.469 121.898 593.361C121.986 593.558 122.034 593.783 122.102 593.987ZM120.57 599.667C112.875 599.667 105.207 599.667 97.5322 599.667C97.5322 599.783 97.5322 599.885 97.5322 599.987C97.5322 605.162 97.5322 610.331 97.5322 615.506C97.5322 616.208 97.7978 616.473 98.4992 616.473C105.534 616.473 112.562 616.473 119.596 616.473C120.298 616.473 120.57 616.208 120.57 615.506C120.57 610.324 120.57 605.142 120.57 599.96C120.57 599.871 120.57 599.776 120.57 599.667ZM97.5322 598.101C105.227 598.101 112.888 598.101 120.57 598.101C120.57 597.992 120.57 597.903 120.57 597.808C120.57 596.704 120.57 595.601 120.57 594.498C120.57 593.797 120.304 593.531 119.603 593.531C112.568 593.531 105.541 593.531 98.506 593.531C98.4311 593.531 98.3562 593.531 98.2745 593.531C97.8659 593.552 97.539 593.858 97.5322 594.26C97.5254 595.533 97.5322 596.807 97.5322 598.101Z"
               fill="white"
            />
            <path
               d="M112.105 602.773C112.084 602.835 112.057 602.971 112.003 603.093C110.498 606.607 108.993 610.121 107.488 613.635C107.29 614.098 106.868 614.289 106.459 614.118C106.044 613.948 105.887 613.499 106.085 613.029C107.59 609.515 109.095 606.001 110.6 602.487C110.77 602.085 111.11 601.881 111.478 601.956C111.839 602.024 112.105 602.344 112.105 602.773Z"
               fill="white"
            />
            <path
               d="M101.872 608.064C102.553 608.609 103.2 609.127 103.847 609.644C104.194 609.917 104.535 610.196 104.882 610.468C105.27 610.781 105.345 611.238 105.066 611.592C104.787 611.953 104.317 611.98 103.915 611.66C102.689 610.679 101.463 609.699 100.238 608.718C99.7541 608.33 99.7541 607.799 100.238 607.411C101.463 606.43 102.689 605.449 103.915 604.469C104.317 604.149 104.787 604.176 105.066 604.537C105.345 604.898 105.27 605.347 104.862 605.674C103.956 606.403 103.043 607.125 102.138 607.853C102.056 607.908 101.981 607.969 101.872 608.064Z"
               fill="white"
            />
            <path
               d="M116.23 608.058C115.624 607.567 115.039 607.104 114.46 606.641C114.044 606.308 113.622 605.974 113.207 605.64C112.825 605.327 112.757 604.871 113.043 604.517C113.322 604.176 113.779 604.142 114.16 604.442C115.399 605.429 116.639 606.423 117.878 607.418C118.348 607.792 118.341 608.33 117.871 608.711C116.639 609.699 115.406 610.686 114.174 611.667C113.786 611.98 113.316 611.946 113.043 611.592C112.764 611.238 112.832 610.782 113.22 610.475C114.14 609.74 115.059 608.997 115.985 608.262C116.053 608.207 116.121 608.146 116.23 608.058Z"
               fill="white"
            />
            <path
               d="M115.933 595.065C116.668 595.065 117.41 595.065 118.146 595.065C118.643 595.065 118.983 595.378 118.99 595.82C118.997 596.277 118.65 596.59 118.132 596.59C116.668 596.59 115.197 596.59 113.733 596.59C113.222 596.59 112.875 596.277 112.875 595.82C112.875 595.371 113.229 595.065 113.74 595.065C114.469 595.058 115.204 595.065 115.933 595.065Z"
               fill="white"
            />
            <path
               d="M99.8653 595.065C100.281 595.058 100.628 595.405 100.635 595.814C100.642 596.236 100.287 596.597 99.8653 596.59C99.4499 596.59 99.1094 596.243 99.1094 595.827C99.1094 595.412 99.4499 595.065 99.8653 595.065Z"
               fill="white"
            />
            <path
               d="M103.697 595.814C103.704 596.229 103.364 596.576 102.955 596.59C102.533 596.603 102.172 596.249 102.172 595.827C102.172 595.412 102.519 595.064 102.928 595.064C103.343 595.058 103.69 595.398 103.697 595.814Z"
               fill="white"
            />
            <path
               d="M105.989 596.59C105.574 596.59 105.233 596.243 105.227 595.827C105.227 595.405 105.581 595.051 106.003 595.058C106.418 595.065 106.759 595.419 106.752 595.834C106.745 596.249 106.398 596.59 105.989 596.59Z"
               fill="white"
            />
         </g>
         <path
            d="M84.8538 653.664C84.8538 652.416 85.1238 651.306 85.6638 650.334C86.2038 649.35 86.9538 648.588 87.9138 648.048C88.8858 647.496 89.9838 647.22 91.2078 647.22C92.7078 647.22 93.9918 647.616 95.0598 648.408C96.1278 649.2 96.8418 650.28 97.2018 651.648H93.8178C93.5658 651.12 93.2058 650.718 92.7378 650.442C92.2818 650.166 91.7598 650.028 91.1718 650.028C90.2238 650.028 89.4558 650.358 88.8678 651.018C88.2798 651.678 87.9858 652.56 87.9858 653.664C87.9858 654.768 88.2798 655.65 88.8678 656.31C89.4558 656.97 90.2238 657.3 91.1718 657.3C91.7598 657.3 92.2818 657.162 92.7378 656.886C93.2058 656.61 93.5658 656.208 93.8178 655.68H97.2018C96.8418 657.048 96.1278 658.128 95.0598 658.92C93.9918 659.7 92.7078 660.09 91.2078 660.09C89.9838 660.09 88.8858 659.82 87.9138 659.28C86.9538 658.728 86.2038 657.966 85.6638 656.994C85.1238 656.022 84.8538 654.912 84.8538 653.664ZM103.659 660.144C102.675 660.144 101.787 659.934 100.995 659.514C100.215 659.094 99.5967 658.494 99.1407 657.714C98.6967 656.934 98.4747 656.022 98.4747 654.978C98.4747 653.946 98.7027 653.04 99.1587 652.26C99.6147 651.468 100.239 650.862 101.031 650.442C101.823 650.022 102.711 649.812 103.695 649.812C104.679 649.812 105.567 650.022 106.359 650.442C107.151 650.862 107.775 651.468 108.231 652.26C108.687 653.04 108.915 653.946 108.915 654.978C108.915 656.01 108.681 656.922 108.213 657.714C107.757 658.494 107.127 659.094 106.323 659.514C105.531 659.934 104.643 660.144 103.659 660.144ZM103.659 657.48C104.247 657.48 104.745 657.264 105.153 656.832C105.573 656.4 105.783 655.782 105.783 654.978C105.783 654.174 105.579 653.556 105.171 653.124C104.775 652.692 104.283 652.476 103.695 652.476C103.095 652.476 102.597 652.692 102.201 653.124C101.805 653.544 101.607 654.162 101.607 654.978C101.607 655.782 101.799 656.4 102.183 656.832C102.579 657.264 103.071 657.48 103.659 657.48ZM109.936 654.96C109.936 653.928 110.128 653.022 110.512 652.242C110.908 651.462 111.442 650.862 112.114 650.442C112.786 650.022 113.536 649.812 114.364 649.812C115.024 649.812 115.624 649.95 116.164 650.226C116.716 650.502 117.148 650.874 117.46 651.342V646.68H120.538V660H117.46V658.56C117.172 659.04 116.758 659.424 116.218 659.712C115.69 660 115.072 660.144 114.364 660.144C113.536 660.144 112.786 659.934 112.114 659.514C111.442 659.082 110.908 658.476 110.512 657.696C110.128 656.904 109.936 655.992 109.936 654.96ZM117.46 654.978C117.46 654.21 117.244 653.604 116.812 653.16C116.392 652.716 115.876 652.494 115.264 652.494C114.652 652.494 114.13 652.716 113.698 653.16C113.278 653.592 113.068 654.192 113.068 654.96C113.068 655.728 113.278 656.34 113.698 656.796C114.13 657.24 114.652 657.462 115.264 657.462C115.876 657.462 116.392 657.24 116.812 656.796C117.244 656.352 117.46 655.746 117.46 654.978ZM132.232 654.816C132.232 655.104 132.214 655.404 132.178 655.716H125.212C125.26 656.34 125.458 656.82 125.806 657.156C126.166 657.48 126.604 657.642 127.12 657.642C127.888 657.642 128.422 657.318 128.722 656.67H131.998C131.83 657.33 131.524 657.924 131.08 658.452C130.648 658.98 130.102 659.394 129.442 659.694C128.782 659.994 128.044 660.144 127.228 660.144C126.244 660.144 125.368 659.934 124.6 659.514C123.832 659.094 123.232 658.494 122.8 657.714C122.368 656.934 122.152 656.022 122.152 654.978C122.152 653.934 122.362 653.022 122.782 652.242C123.214 651.462 123.814 650.862 124.582 650.442C125.35 650.022 126.232 649.812 127.228 649.812C128.2 649.812 129.064 650.016 129.82 650.424C130.576 650.832 131.164 651.414 131.584 652.17C132.016 652.926 132.232 653.808 132.232 654.816ZM129.082 654.006C129.082 653.478 128.902 653.058 128.542 652.746C128.182 652.434 127.732 652.278 127.192 652.278C126.676 652.278 126.238 652.428 125.878 652.728C125.53 653.028 125.314 653.454 125.23 654.006H129.082Z"
            fill="white"
         />
         <g filter="url(#filter9_b_226_1189)">
            <circle cx="195.5" cy="612.561" r="7.5" fill="#B3B3B3" />
            <circle
               cx="195.5"
               cy="612.561"
               r="6.5"
               stroke="black"
               strokeWidth="2"
            />
         </g>
         <g filter="url(#filter10_b_226_1189)">
            <circle cx="225.5" cy="553.5" r="7.5" fill="#B3B3B3" />
            <circle
               cx="225.5"
               cy="553.5"
               r="6.5"
               stroke="black"
               strokeWidth="2"
            />
         </g>
         <g filter="url(#filter11_b_226_1189)">
            <circle cx="300.5" cy="550.5" r="7.5" fill="#B3B3B3" />
            <circle
               cx="300.5"
               cy="550.5"
               r="6.5"
               stroke="black"
               strokeWidth="2"
            />
         </g>
         <g filter="url(#filter12_b_226_1189)">
            <circle cx="335.5" cy="612.561" r="7.5" fill="#B3B3B3" />
            <circle
               cx="335.5"
               cy="612.561"
               r="6.5"
               stroke="black"
               strokeWidth="2"
            />
         </g>
         <path
            d="M166.834 522.189C166.361 522.189 165.936 522.271 165.557 522.436C165.182 522.596 164.861 522.83 164.596 523.139C164.334 523.443 164.133 523.812 163.992 524.246C163.852 524.68 163.781 525.168 163.781 525.711C163.781 526.43 163.893 527.055 164.115 527.586C164.342 528.113 164.678 528.521 165.123 528.811C165.572 529.1 166.133 529.244 166.805 529.244C167.188 529.244 167.547 529.213 167.883 529.15C168.223 529.084 168.553 529.002 168.873 528.904V529.771C168.561 529.889 168.232 529.975 167.889 530.029C167.545 530.088 167.137 530.117 166.664 530.117C165.793 530.117 165.064 529.938 164.479 529.578C163.896 529.215 163.459 528.703 163.166 528.043C162.877 527.383 162.732 526.604 162.732 525.705C162.732 525.057 162.822 524.465 163.002 523.93C163.186 523.391 163.451 522.926 163.799 522.535C164.15 522.145 164.58 521.844 165.088 521.633C165.6 521.418 166.186 521.311 166.846 521.311C167.279 521.311 167.697 521.354 168.1 521.439C168.502 521.525 168.865 521.648 169.189 521.809L168.791 522.652C168.518 522.527 168.217 522.42 167.889 522.33C167.564 522.236 167.213 522.189 166.834 522.189ZM176.121 526.777C176.121 527.305 176.053 527.775 175.916 528.189C175.779 528.604 175.582 528.953 175.324 529.238C175.066 529.523 174.754 529.742 174.387 529.895C174.023 530.043 173.611 530.117 173.15 530.117C172.721 530.117 172.326 530.043 171.967 529.895C171.611 529.742 171.303 529.523 171.041 529.238C170.783 528.953 170.582 528.604 170.438 528.189C170.297 527.775 170.227 527.305 170.227 526.777C170.227 526.074 170.346 525.477 170.584 524.984C170.822 524.488 171.162 524.111 171.604 523.854C172.049 523.592 172.578 523.461 173.191 523.461C173.777 523.461 174.289 523.592 174.727 523.854C175.168 524.115 175.51 524.494 175.752 524.99C175.998 525.482 176.121 526.078 176.121 526.777ZM171.234 526.777C171.234 527.293 171.303 527.74 171.439 528.119C171.576 528.498 171.787 528.791 172.072 528.998C172.357 529.205 172.725 529.309 173.174 529.309C173.619 529.309 173.984 529.205 174.27 528.998C174.559 528.791 174.771 528.498 174.908 528.119C175.045 527.74 175.113 527.293 175.113 526.777C175.113 526.266 175.045 525.824 174.908 525.453C174.771 525.078 174.561 524.789 174.275 524.586C173.99 524.383 173.621 524.281 173.168 524.281C172.5 524.281 172.01 524.502 171.697 524.943C171.389 525.385 171.234 525.996 171.234 526.777ZM180.088 530.117C179.275 530.117 178.631 529.84 178.154 529.285C177.682 528.73 177.445 527.906 177.445 526.812C177.445 525.707 177.688 524.873 178.172 524.311C178.656 523.744 179.301 523.461 180.105 523.461C180.445 523.461 180.742 523.506 180.996 523.596C181.25 523.686 181.469 523.807 181.652 523.959C181.836 524.107 181.99 524.277 182.115 524.469H182.186C182.17 524.348 182.154 524.182 182.139 523.971C182.123 523.76 182.115 523.588 182.115 523.455V520.883H183.088V530H182.303L182.156 529.086H182.115C181.994 529.277 181.84 529.451 181.652 529.607C181.469 529.764 181.248 529.889 180.99 529.982C180.736 530.072 180.436 530.117 180.088 530.117ZM180.24 529.309C180.928 529.309 181.414 529.113 181.699 528.723C181.984 528.332 182.127 527.752 182.127 526.982V526.807C182.127 525.99 181.99 525.363 181.717 524.926C181.447 524.488 180.955 524.27 180.24 524.27C179.643 524.27 179.195 524.5 178.898 524.961C178.602 525.418 178.453 526.043 178.453 526.836C178.453 527.625 178.6 528.234 178.893 528.664C179.189 529.094 179.639 529.309 180.24 529.309ZM187.623 523.461C188.17 523.461 188.639 523.582 189.029 523.824C189.42 524.066 189.719 524.406 189.926 524.844C190.133 525.277 190.236 525.785 190.236 526.367V526.971H185.801C185.812 527.725 186 528.299 186.363 528.693C186.727 529.088 187.238 529.285 187.898 529.285C188.305 529.285 188.664 529.248 188.977 529.174C189.289 529.1 189.613 528.99 189.949 528.846V529.701C189.625 529.846 189.303 529.951 188.982 530.018C188.666 530.084 188.291 530.117 187.857 530.117C187.24 530.117 186.701 529.992 186.24 529.742C185.783 529.488 185.428 529.117 185.174 528.629C184.92 528.141 184.793 527.543 184.793 526.836C184.793 526.145 184.908 525.547 185.139 525.043C185.373 524.535 185.701 524.145 186.123 523.871C186.549 523.598 187.049 523.461 187.623 523.461ZM187.611 524.258C187.092 524.258 186.678 524.428 186.369 524.768C186.061 525.107 185.877 525.582 185.818 526.191H189.217C189.213 525.809 189.152 525.473 189.035 525.184C188.922 524.891 188.748 524.664 188.514 524.504C188.279 524.34 187.979 524.258 187.611 524.258ZM195.152 521.434H197.578C198.648 521.434 199.453 521.594 199.992 521.914C200.531 522.234 200.801 522.779 200.801 523.549C200.801 523.881 200.736 524.18 200.607 524.445C200.482 524.707 200.299 524.924 200.057 525.096C199.814 525.268 199.516 525.387 199.16 525.453V525.512C199.535 525.57 199.867 525.678 200.156 525.834C200.445 525.99 200.672 526.209 200.836 526.49C201 526.771 201.082 527.129 201.082 527.562C201.082 528.09 200.959 528.535 200.713 528.898C200.471 529.262 200.127 529.537 199.682 529.725C199.236 529.908 198.709 530 198.1 530H195.152V521.434ZM196.148 525.107H197.789C198.535 525.107 199.051 524.984 199.336 524.738C199.625 524.492 199.77 524.133 199.77 523.66C199.77 523.172 199.598 522.82 199.254 522.605C198.914 522.391 198.371 522.283 197.625 522.283H196.148V525.107ZM196.148 525.945V529.15H197.93C198.691 529.15 199.23 529.002 199.547 528.705C199.863 528.404 200.021 528 200.021 527.492C200.021 527.168 199.949 526.891 199.805 526.66C199.664 526.43 199.434 526.254 199.113 526.133C198.797 526.008 198.373 525.945 197.842 525.945H196.148ZM205.236 523.461C205.783 523.461 206.252 523.582 206.643 523.824C207.033 524.066 207.332 524.406 207.539 524.844C207.746 525.277 207.85 525.785 207.85 526.367V526.971H203.414C203.426 527.725 203.613 528.299 203.977 528.693C204.34 529.088 204.852 529.285 205.512 529.285C205.918 529.285 206.277 529.248 206.59 529.174C206.902 529.1 207.227 528.99 207.562 528.846V529.701C207.238 529.846 206.916 529.951 206.596 530.018C206.279 530.084 205.904 530.117 205.471 530.117C204.854 530.117 204.314 529.992 203.854 529.742C203.396 529.488 203.041 529.117 202.787 528.629C202.533 528.141 202.406 527.543 202.406 526.836C202.406 526.145 202.521 525.547 202.752 525.043C202.986 524.535 203.314 524.145 203.736 523.871C204.162 523.598 204.662 523.461 205.236 523.461ZM205.225 524.258C204.705 524.258 204.291 524.428 203.982 524.768C203.674 525.107 203.49 525.582 203.432 526.191H206.83C206.826 525.809 206.766 525.473 206.648 525.184C206.535 524.891 206.361 524.664 206.127 524.504C205.893 524.34 205.592 524.258 205.225 524.258ZM210.475 523.578V530H209.502V523.578H210.475ZM210 521.176C210.16 521.176 210.297 521.229 210.41 521.334C210.527 521.436 210.586 521.596 210.586 521.814C210.586 522.029 210.527 522.189 210.41 522.295C210.297 522.4 210.16 522.453 210 522.453C209.832 522.453 209.691 522.4 209.578 522.295C209.469 522.189 209.414 522.029 209.414 521.814C209.414 521.596 209.469 521.436 209.578 521.334C209.691 521.229 209.832 521.176 210 521.176ZM215.578 523.461C216.34 523.461 216.916 523.648 217.307 524.023C217.697 524.395 217.893 524.992 217.893 525.816V530H216.932V525.881C216.932 525.346 216.809 524.945 216.562 524.68C216.32 524.414 215.947 524.281 215.443 524.281C214.732 524.281 214.232 524.482 213.943 524.885C213.654 525.287 213.51 525.871 213.51 526.637V530H212.537V523.578H213.322L213.469 524.504H213.521C213.658 524.277 213.832 524.088 214.043 523.936C214.254 523.779 214.49 523.662 214.752 523.584C215.014 523.502 215.289 523.461 215.578 523.461ZM221.689 532.883C220.846 532.883 220.195 532.725 219.738 532.408C219.281 532.096 219.053 531.656 219.053 531.09C219.053 530.688 219.18 530.344 219.434 530.059C219.691 529.773 220.047 529.584 220.5 529.49C220.332 529.412 220.188 529.295 220.066 529.139C219.949 528.982 219.891 528.803 219.891 528.6C219.891 528.365 219.955 528.16 220.084 527.984C220.217 527.805 220.418 527.633 220.688 527.469C220.352 527.332 220.078 527.102 219.867 526.777C219.66 526.449 219.557 526.068 219.557 525.635C219.557 525.174 219.652 524.781 219.844 524.457C220.035 524.129 220.312 523.879 220.676 523.707C221.039 523.535 221.479 523.449 221.994 523.449C222.107 523.449 222.221 523.455 222.334 523.467C222.451 523.475 222.562 523.488 222.668 523.508C222.773 523.523 222.865 523.543 222.943 523.566H225.146V524.193L223.963 524.34C224.08 524.492 224.178 524.676 224.256 524.891C224.334 525.105 224.373 525.344 224.373 525.605C224.373 526.246 224.156 526.756 223.723 527.135C223.289 527.51 222.693 527.697 221.936 527.697C221.756 527.697 221.572 527.682 221.385 527.65C221.193 527.756 221.047 527.873 220.945 528.002C220.848 528.131 220.799 528.279 220.799 528.447C220.799 528.572 220.836 528.672 220.91 528.746C220.988 528.82 221.1 528.875 221.244 528.91C221.389 528.941 221.562 528.957 221.766 528.957H222.896C223.596 528.957 224.131 529.104 224.502 529.396C224.877 529.689 225.064 530.117 225.064 530.68C225.064 531.391 224.775 531.936 224.197 532.314C223.619 532.693 222.783 532.883 221.689 532.883ZM221.719 532.121C222.25 532.121 222.689 532.066 223.037 531.957C223.389 531.852 223.65 531.697 223.822 531.494C223.998 531.295 224.086 531.057 224.086 530.779C224.086 530.521 224.027 530.326 223.91 530.193C223.793 530.064 223.621 529.979 223.395 529.936C223.168 529.889 222.891 529.865 222.562 529.865H221.449C221.16 529.865 220.908 529.91 220.693 530C220.479 530.09 220.312 530.223 220.195 530.398C220.082 530.574 220.025 530.793 220.025 531.055C220.025 531.402 220.172 531.666 220.465 531.846C220.758 532.029 221.176 532.121 221.719 532.121ZM221.971 526.988C222.436 526.988 222.785 526.871 223.02 526.637C223.254 526.402 223.371 526.061 223.371 525.611C223.371 525.131 223.252 524.771 223.014 524.533C222.775 524.291 222.424 524.17 221.959 524.17C221.514 524.17 221.17 524.295 220.928 524.545C220.689 524.791 220.57 525.152 220.57 525.629C220.57 526.066 220.691 526.402 220.934 526.637C221.176 526.871 221.521 526.988 221.971 526.988ZM169.975 540.635C169.975 541.6 169.799 542.406 169.447 543.055C169.096 543.699 168.586 544.186 167.918 544.514C167.254 544.838 166.447 545 165.498 545H163.172V536.434H165.756C166.627 536.434 167.377 536.594 168.006 536.914C168.635 537.23 169.119 537.701 169.459 538.326C169.803 538.947 169.975 539.717 169.975 540.635ZM168.926 540.67C168.926 539.9 168.797 539.266 168.539 538.766C168.285 538.266 167.91 537.895 167.414 537.652C166.922 537.406 166.318 537.283 165.604 537.283H164.168V544.145H165.381C166.561 544.145 167.445 543.854 168.035 543.271C168.629 542.689 168.926 541.822 168.926 540.67ZM174.205 538.461C174.752 538.461 175.221 538.582 175.611 538.824C176.002 539.066 176.301 539.406 176.508 539.844C176.715 540.277 176.818 540.785 176.818 541.367V541.971H172.383C172.395 542.725 172.582 543.299 172.945 543.693C173.309 544.088 173.82 544.285 174.48 544.285C174.887 544.285 175.246 544.248 175.559 544.174C175.871 544.1 176.195 543.99 176.531 543.846V544.701C176.207 544.846 175.885 544.951 175.564 545.018C175.248 545.084 174.873 545.117 174.439 545.117C173.822 545.117 173.283 544.992 172.822 544.742C172.365 544.488 172.01 544.117 171.756 543.629C171.502 543.141 171.375 542.543 171.375 541.836C171.375 541.145 171.49 540.547 171.721 540.043C171.955 539.535 172.283 539.145 172.705 538.871C173.131 538.598 173.631 538.461 174.205 538.461ZM174.193 539.258C173.674 539.258 173.26 539.428 172.951 539.768C172.643 540.107 172.459 540.582 172.4 541.191H175.799C175.795 540.809 175.734 540.473 175.617 540.184C175.504 539.891 175.33 539.664 175.096 539.504C174.861 539.34 174.561 539.258 174.193 539.258ZM179.883 545L177.445 538.578H178.488L179.9 542.463C179.998 542.729 180.098 543.021 180.199 543.342C180.301 543.662 180.371 543.92 180.41 544.115H180.451C180.498 543.92 180.576 543.662 180.686 543.342C180.795 543.018 180.895 542.725 180.984 542.463L182.396 538.578H183.439L180.996 545H179.883ZM186.943 538.461C187.49 538.461 187.959 538.582 188.35 538.824C188.74 539.066 189.039 539.406 189.246 539.844C189.453 540.277 189.557 540.785 189.557 541.367V541.971H185.121C185.133 542.725 185.32 543.299 185.684 543.693C186.047 544.088 186.559 544.285 187.219 544.285C187.625 544.285 187.984 544.248 188.297 544.174C188.609 544.1 188.934 543.99 189.27 543.846V544.701C188.945 544.846 188.623 544.951 188.303 545.018C187.986 545.084 187.611 545.117 187.178 545.117C186.561 545.117 186.021 544.992 185.561 544.742C185.104 544.488 184.748 544.117 184.494 543.629C184.24 543.141 184.113 542.543 184.113 541.836C184.113 541.145 184.229 540.547 184.459 540.043C184.693 539.535 185.021 539.145 185.443 538.871C185.869 538.598 186.369 538.461 186.943 538.461ZM186.932 539.258C186.412 539.258 185.998 539.428 185.689 539.768C185.381 540.107 185.197 540.582 185.139 541.191H188.537C188.533 540.809 188.473 540.473 188.355 540.184C188.242 539.891 188.068 539.664 187.834 539.504C187.6 539.34 187.299 539.258 186.932 539.258ZM192.188 545H191.209V535.883H192.188V545ZM199.781 541.777C199.781 542.305 199.713 542.775 199.576 543.189C199.439 543.604 199.242 543.953 198.984 544.238C198.727 544.523 198.414 544.742 198.047 544.895C197.684 545.043 197.271 545.117 196.811 545.117C196.381 545.117 195.986 545.043 195.627 544.895C195.271 544.742 194.963 544.523 194.701 544.238C194.443 543.953 194.242 543.604 194.098 543.189C193.957 542.775 193.887 542.305 193.887 541.777C193.887 541.074 194.006 540.477 194.244 539.984C194.482 539.488 194.822 539.111 195.264 538.854C195.709 538.592 196.238 538.461 196.852 538.461C197.438 538.461 197.949 538.592 198.387 538.854C198.828 539.115 199.17 539.494 199.412 539.99C199.658 540.482 199.781 541.078 199.781 541.777ZM194.895 541.777C194.895 542.293 194.963 542.74 195.1 543.119C195.236 543.498 195.447 543.791 195.732 543.998C196.018 544.205 196.385 544.309 196.834 544.309C197.279 544.309 197.645 544.205 197.93 543.998C198.219 543.791 198.432 543.498 198.568 543.119C198.705 542.74 198.773 542.293 198.773 541.777C198.773 541.266 198.705 540.824 198.568 540.453C198.432 540.078 198.221 539.789 197.936 539.586C197.65 539.383 197.281 539.281 196.828 539.281C196.16 539.281 195.67 539.502 195.357 539.943C195.049 540.385 194.895 540.996 194.895 541.777ZM204.48 538.461C205.281 538.461 205.92 538.736 206.396 539.287C206.873 539.838 207.111 540.666 207.111 541.771C207.111 542.502 207.002 543.115 206.783 543.611C206.564 544.107 206.256 544.482 205.857 544.736C205.463 544.99 204.996 545.117 204.457 545.117C204.117 545.117 203.818 545.072 203.561 544.982C203.303 544.893 203.082 544.771 202.898 544.619C202.715 544.467 202.562 544.301 202.441 544.121H202.371C202.383 544.273 202.396 544.457 202.412 544.672C202.432 544.887 202.441 545.074 202.441 545.234V547.871H201.463V538.578H202.266L202.395 539.527H202.441C202.566 539.332 202.719 539.154 202.898 538.994C203.078 538.83 203.297 538.701 203.555 538.607C203.816 538.51 204.125 538.461 204.48 538.461ZM204.311 539.281C203.865 539.281 203.506 539.367 203.232 539.539C202.963 539.711 202.766 539.969 202.641 540.312C202.516 540.652 202.449 541.08 202.441 541.596V541.783C202.441 542.326 202.5 542.785 202.617 543.16C202.738 543.535 202.936 543.82 203.209 544.016C203.486 544.211 203.857 544.309 204.322 544.309C204.721 544.309 205.053 544.201 205.318 543.986C205.584 543.771 205.781 543.473 205.91 543.09C206.043 542.703 206.109 542.26 206.109 541.76C206.109 541.002 205.961 540.4 205.664 539.955C205.371 539.506 204.92 539.281 204.311 539.281ZM211.283 538.461C211.83 538.461 212.299 538.582 212.689 538.824C213.08 539.066 213.379 539.406 213.586 539.844C213.793 540.277 213.896 540.785 213.896 541.367V541.971H209.461C209.473 542.725 209.66 543.299 210.023 543.693C210.387 544.088 210.898 544.285 211.559 544.285C211.965 544.285 212.324 544.248 212.637 544.174C212.949 544.1 213.273 543.99 213.609 543.846V544.701C213.285 544.846 212.963 544.951 212.643 545.018C212.326 545.084 211.951 545.117 211.518 545.117C210.9 545.117 210.361 544.992 209.9 544.742C209.443 544.488 209.088 544.117 208.834 543.629C208.58 543.141 208.453 542.543 208.453 541.836C208.453 541.145 208.568 540.547 208.799 540.043C209.033 539.535 209.361 539.145 209.783 538.871C210.209 538.598 210.709 538.461 211.283 538.461ZM211.271 539.258C210.752 539.258 210.338 539.428 210.029 539.768C209.721 540.107 209.537 540.582 209.479 541.191H212.877C212.873 540.809 212.812 540.473 212.695 540.184C212.582 539.891 212.408 539.664 212.174 539.504C211.939 539.34 211.639 539.258 211.271 539.258ZM217.834 545.117C217.021 545.117 216.377 544.84 215.9 544.285C215.428 543.73 215.191 542.906 215.191 541.812C215.191 540.707 215.434 539.873 215.918 539.311C216.402 538.744 217.047 538.461 217.852 538.461C218.191 538.461 218.488 538.506 218.742 538.596C218.996 538.686 219.215 538.807 219.398 538.959C219.582 539.107 219.736 539.277 219.861 539.469H219.932C219.916 539.348 219.9 539.182 219.885 538.971C219.869 538.76 219.861 538.588 219.861 538.455V535.883H220.834V545H220.049L219.902 544.086H219.861C219.74 544.277 219.586 544.451 219.398 544.607C219.215 544.764 218.994 544.889 218.736 544.982C218.482 545.072 218.182 545.117 217.834 545.117ZM217.986 544.309C218.674 544.309 219.16 544.113 219.445 543.723C219.73 543.332 219.873 542.752 219.873 541.982V541.807C219.873 540.99 219.736 540.363 219.463 539.926C219.193 539.488 218.701 539.27 217.986 539.27C217.389 539.27 216.941 539.5 216.645 539.961C216.348 540.418 216.199 541.043 216.199 541.836C216.199 542.625 216.346 543.234 216.639 543.664C216.936 544.094 217.385 544.309 217.986 544.309Z"
            fill="white"
         />
         <path
            d="M304.41 501.434C305.516 501.434 306.322 501.65 306.83 502.084C307.342 502.514 307.598 503.131 307.598 503.936C307.598 504.299 307.537 504.645 307.416 504.973C307.299 505.297 307.107 505.584 306.842 505.834C306.576 506.08 306.227 506.275 305.793 506.42C305.363 506.561 304.836 506.631 304.211 506.631H303.168V510H302.172V501.434H304.41ZM304.316 502.283H303.168V505.775H304.1C304.646 505.775 305.102 505.717 305.465 505.6C305.832 505.482 306.107 505.293 306.291 505.031C306.475 504.766 306.566 504.414 306.566 503.977C306.566 503.406 306.385 502.982 306.021 502.705C305.658 502.424 305.09 502.283 304.316 502.283ZM314.547 503.578V510H313.75L313.609 509.098H313.557C313.424 509.32 313.252 509.508 313.041 509.66C312.83 509.812 312.592 509.926 312.326 510C312.064 510.078 311.785 510.117 311.488 510.117C310.98 510.117 310.555 510.035 310.211 509.871C309.867 509.707 309.607 509.453 309.432 509.109C309.26 508.766 309.174 508.324 309.174 507.785V503.578H310.158V507.715C310.158 508.25 310.279 508.65 310.521 508.916C310.764 509.178 311.133 509.309 311.629 509.309C312.105 509.309 312.484 509.219 312.766 509.039C313.051 508.859 313.256 508.596 313.381 508.248C313.506 507.896 313.568 507.467 313.568 506.959V503.578H314.547ZM317.582 510H316.604V500.883H317.582V510ZM320.617 510H319.639V500.883H320.617V510ZM328.252 501.434C328.955 501.434 329.535 501.521 329.992 501.697C330.453 501.869 330.797 502.133 331.023 502.488C331.25 502.844 331.363 503.297 331.363 503.848C331.363 504.301 331.281 504.68 331.117 504.984C330.953 505.285 330.738 505.529 330.473 505.717C330.207 505.904 329.924 506.049 329.623 506.15L331.973 510H330.812L328.715 506.426H326.934V510H325.938V501.434H328.252ZM328.193 502.295H326.934V505.582H328.293C328.992 505.582 329.506 505.439 329.834 505.154C330.166 504.869 330.332 504.449 330.332 503.895C330.332 503.312 330.156 502.9 329.805 502.658C329.457 502.416 328.92 502.295 328.193 502.295ZM335.67 503.461C336.217 503.461 336.686 503.582 337.076 503.824C337.467 504.066 337.766 504.406 337.973 504.844C338.18 505.277 338.283 505.785 338.283 506.367V506.971H333.848C333.859 507.725 334.047 508.299 334.41 508.693C334.773 509.088 335.285 509.285 335.945 509.285C336.352 509.285 336.711 509.248 337.023 509.174C337.336 509.1 337.66 508.99 337.996 508.846V509.701C337.672 509.846 337.35 509.951 337.029 510.018C336.713 510.084 336.338 510.117 335.904 510.117C335.287 510.117 334.748 509.992 334.287 509.742C333.83 509.488 333.475 509.117 333.221 508.629C332.967 508.141 332.84 507.543 332.84 506.836C332.84 506.145 332.955 505.547 333.186 505.043C333.42 504.535 333.748 504.145 334.17 503.871C334.596 503.598 335.096 503.461 335.67 503.461ZM335.658 504.258C335.139 504.258 334.725 504.428 334.416 504.768C334.107 505.107 333.924 505.582 333.865 506.191H337.264C337.26 505.809 337.199 505.473 337.082 505.184C336.969 504.891 336.795 504.664 336.561 504.504C336.326 504.34 336.025 504.258 335.658 504.258ZM344.242 512.871V510.117C344.242 509.965 344.246 509.789 344.254 509.59C344.262 509.391 344.275 509.219 344.295 509.074H344.23C344.051 509.371 343.795 509.619 343.463 509.818C343.131 510.018 342.703 510.117 342.18 510.117C341.395 510.117 340.764 509.84 340.287 509.285C339.811 508.73 339.572 507.902 339.572 506.801C339.572 506.078 339.682 505.469 339.9 504.973C340.119 504.477 340.428 504.102 340.826 503.848C341.229 503.59 341.697 503.461 342.232 503.461C342.744 503.461 343.162 503.562 343.486 503.766C343.811 503.965 344.064 504.209 344.248 504.498H344.295L344.441 503.578H345.215V512.871H344.242ZM342.361 509.309C342.814 509.309 343.178 509.225 343.451 509.057C343.725 508.885 343.924 508.627 344.049 508.283C344.178 507.939 344.246 507.512 344.254 507V506.795C344.254 505.967 344.113 505.34 343.832 504.914C343.551 504.484 343.061 504.27 342.361 504.27C341.76 504.27 341.312 504.5 341.02 504.961C340.727 505.418 340.58 506.039 340.58 506.824C340.58 507.609 340.727 508.221 341.02 508.658C341.312 509.092 341.76 509.309 342.361 509.309ZM352.586 503.578V510H351.789L351.648 509.098H351.596C351.463 509.32 351.291 509.508 351.08 509.66C350.869 509.812 350.631 509.926 350.365 510C350.104 510.078 349.824 510.117 349.527 510.117C349.02 510.117 348.594 510.035 348.25 509.871C347.906 509.707 347.646 509.453 347.471 509.109C347.299 508.766 347.213 508.324 347.213 507.785V503.578H348.197V507.715C348.197 508.25 348.318 508.65 348.561 508.916C348.803 509.178 349.172 509.309 349.668 509.309C350.145 509.309 350.523 509.219 350.805 509.039C351.09 508.859 351.295 508.596 351.42 508.248C351.545 507.896 351.607 507.467 351.607 506.959V503.578H352.586ZM357.115 503.461C357.662 503.461 358.131 503.582 358.521 503.824C358.912 504.066 359.211 504.406 359.418 504.844C359.625 505.277 359.729 505.785 359.729 506.367V506.971H355.293C355.305 507.725 355.492 508.299 355.855 508.693C356.219 509.088 356.73 509.285 357.391 509.285C357.797 509.285 358.156 509.248 358.469 509.174C358.781 509.1 359.105 508.99 359.441 508.846V509.701C359.117 509.846 358.795 509.951 358.475 510.018C358.158 510.084 357.783 510.117 357.35 510.117C356.732 510.117 356.193 509.992 355.732 509.742C355.275 509.488 354.92 509.117 354.666 508.629C354.412 508.141 354.285 507.543 354.285 506.836C354.285 506.145 354.4 505.547 354.631 505.043C354.865 504.535 355.193 504.145 355.615 503.871C356.041 503.598 356.541 503.461 357.115 503.461ZM357.104 504.258C356.584 504.258 356.17 504.428 355.861 504.768C355.553 505.107 355.369 505.582 355.311 506.191H358.709C358.705 505.809 358.645 505.473 358.527 505.184C358.414 504.891 358.24 504.664 358.006 504.504C357.771 504.34 357.471 504.258 357.104 504.258ZM365.535 508.242C365.535 508.652 365.432 508.998 365.225 509.279C365.021 509.557 364.729 509.766 364.346 509.906C363.967 510.047 363.514 510.117 362.986 510.117C362.537 510.117 362.148 510.082 361.82 510.012C361.492 509.941 361.205 509.842 360.959 509.713V508.816C361.221 508.945 361.533 509.062 361.896 509.168C362.26 509.273 362.631 509.326 363.01 509.326C363.564 509.326 363.967 509.236 364.217 509.057C364.467 508.877 364.592 508.633 364.592 508.324C364.592 508.148 364.541 507.994 364.439 507.861C364.342 507.725 364.176 507.594 363.941 507.469C363.707 507.34 363.383 507.199 362.969 507.047C362.559 506.891 362.203 506.736 361.902 506.584C361.605 506.428 361.375 506.238 361.211 506.016C361.051 505.793 360.971 505.504 360.971 505.148C360.971 504.605 361.189 504.189 361.627 503.9C362.068 503.607 362.646 503.461 363.361 503.461C363.748 503.461 364.109 503.5 364.445 503.578C364.785 503.652 365.102 503.754 365.395 503.883L365.066 504.662C364.801 504.549 364.518 504.453 364.217 504.375C363.916 504.297 363.609 504.258 363.297 504.258C362.848 504.258 362.502 504.332 362.26 504.48C362.021 504.629 361.902 504.832 361.902 505.09C361.902 505.289 361.957 505.453 362.066 505.582C362.18 505.711 362.359 505.832 362.605 505.945C362.852 506.059 363.176 506.191 363.578 506.344C363.98 506.492 364.328 506.646 364.621 506.807C364.914 506.963 365.139 507.154 365.295 507.381C365.455 507.604 365.535 507.891 365.535 508.242ZM369.174 509.32C369.334 509.32 369.498 509.307 369.666 509.279C369.834 509.252 369.971 509.219 370.076 509.18V509.936C369.963 509.986 369.805 510.029 369.602 510.064C369.402 510.1 369.207 510.117 369.016 510.117C368.676 510.117 368.367 510.059 368.09 509.941C367.812 509.82 367.59 509.617 367.422 509.332C367.258 509.047 367.176 508.652 367.176 508.148V504.34H366.262V503.865L367.182 503.484L367.568 502.09H368.154V503.578H370.035V504.34H368.154V508.119C368.154 508.521 368.246 508.822 368.43 509.021C368.617 509.221 368.865 509.32 369.174 509.32ZM377.74 501.434L374.553 510H373.592L376.785 501.434H377.74ZM307.545 525L306.49 522.281H303.057L302.008 525H301L304.352 516.398H305.248L308.576 525H307.545ZM306.191 521.396L305.189 518.695C305.166 518.625 305.127 518.51 305.072 518.35C305.021 518.189 304.969 518.023 304.914 517.852C304.859 517.68 304.814 517.541 304.779 517.436C304.74 517.596 304.697 517.756 304.65 517.916C304.607 518.072 304.564 518.219 304.521 518.355C304.479 518.488 304.441 518.602 304.41 518.695L303.391 521.396H306.191ZM314.922 518.578V525H314.125L313.984 524.098H313.932C313.799 524.32 313.627 524.508 313.416 524.66C313.205 524.812 312.967 524.926 312.701 525C312.439 525.078 312.16 525.117 311.863 525.117C311.355 525.117 310.93 525.035 310.586 524.871C310.242 524.707 309.982 524.453 309.807 524.109C309.635 523.766 309.549 523.324 309.549 522.785V518.578H310.533V522.715C310.533 523.25 310.654 523.65 310.896 523.916C311.139 524.178 311.508 524.309 312.004 524.309C312.48 524.309 312.859 524.219 313.141 524.039C313.426 523.859 313.631 523.596 313.756 523.248C313.881 522.896 313.943 522.467 313.943 521.959V518.578H314.922ZM319.053 524.32C319.213 524.32 319.377 524.307 319.545 524.279C319.713 524.252 319.85 524.219 319.955 524.18V524.936C319.842 524.986 319.684 525.029 319.48 525.064C319.281 525.1 319.086 525.117 318.895 525.117C318.555 525.117 318.246 525.059 317.969 524.941C317.691 524.82 317.469 524.617 317.301 524.332C317.137 524.047 317.055 523.652 317.055 523.148V519.34H316.141V518.865L317.061 518.484L317.447 517.09H318.033V518.578H319.914V519.34H318.033V523.119C318.033 523.521 318.125 523.822 318.309 524.021C318.496 524.221 318.744 524.32 319.053 524.32ZM326.793 521.777C326.793 522.305 326.725 522.775 326.588 523.189C326.451 523.604 326.254 523.953 325.996 524.238C325.738 524.523 325.426 524.742 325.059 524.895C324.695 525.043 324.283 525.117 323.822 525.117C323.393 525.117 322.998 525.043 322.639 524.895C322.283 524.742 321.975 524.523 321.713 524.238C321.455 523.953 321.254 523.604 321.109 523.189C320.969 522.775 320.898 522.305 320.898 521.777C320.898 521.074 321.018 520.477 321.256 519.984C321.494 519.488 321.834 519.111 322.275 518.854C322.721 518.592 323.25 518.461 323.863 518.461C324.449 518.461 324.961 518.592 325.398 518.854C325.84 519.115 326.182 519.494 326.424 519.99C326.67 520.482 326.793 521.078 326.793 521.777ZM321.906 521.777C321.906 522.293 321.975 522.74 322.111 523.119C322.248 523.498 322.459 523.791 322.744 523.998C323.029 524.205 323.396 524.309 323.846 524.309C324.291 524.309 324.656 524.205 324.941 523.998C325.23 523.791 325.443 523.498 325.58 523.119C325.717 522.74 325.785 522.293 325.785 521.777C325.785 521.266 325.717 520.824 325.58 520.453C325.443 520.078 325.232 519.789 324.947 519.586C324.662 519.383 324.293 519.281 323.84 519.281C323.172 519.281 322.682 519.502 322.369 519.943C322.061 520.385 321.906 520.996 321.906 521.777ZM335.447 518.461C336.154 518.461 336.688 518.646 337.047 519.018C337.406 519.385 337.586 519.977 337.586 520.793V525H336.625V520.84C336.625 520.32 336.512 519.932 336.285 519.674C336.062 519.412 335.73 519.281 335.289 519.281C334.668 519.281 334.217 519.461 333.936 519.82C333.654 520.18 333.514 520.709 333.514 521.408V525H332.547V520.84C332.547 520.492 332.496 520.203 332.395 519.973C332.297 519.742 332.148 519.57 331.949 519.457C331.754 519.34 331.506 519.281 331.205 519.281C330.779 519.281 330.438 519.369 330.18 519.545C329.922 519.721 329.734 519.982 329.617 520.33C329.504 520.674 329.447 521.098 329.447 521.602V525H328.475V518.578H329.26L329.406 519.486H329.459C329.588 519.264 329.75 519.076 329.945 518.924C330.141 518.771 330.359 518.656 330.602 518.578C330.844 518.5 331.102 518.461 331.375 518.461C331.863 518.461 332.271 518.553 332.6 518.736C332.932 518.916 333.172 519.191 333.32 519.562H333.373C333.584 519.191 333.873 518.916 334.24 518.736C334.607 518.553 335.01 518.461 335.447 518.461ZM341.986 518.473C342.752 518.473 343.32 518.645 343.691 518.988C344.062 519.332 344.248 519.881 344.248 520.635V525H343.539L343.352 524.051H343.305C343.125 524.285 342.938 524.482 342.742 524.643C342.547 524.799 342.32 524.918 342.062 525C341.809 525.078 341.496 525.117 341.125 525.117C340.734 525.117 340.387 525.049 340.082 524.912C339.781 524.775 339.543 524.568 339.367 524.291C339.195 524.014 339.109 523.662 339.109 523.236C339.109 522.596 339.363 522.104 339.871 521.76C340.379 521.416 341.152 521.229 342.191 521.197L343.299 521.15V520.758C343.299 520.203 343.18 519.814 342.941 519.592C342.703 519.369 342.367 519.258 341.934 519.258C341.598 519.258 341.277 519.307 340.973 519.404C340.668 519.502 340.379 519.617 340.105 519.75L339.807 519.012C340.096 518.863 340.428 518.736 340.803 518.631C341.178 518.525 341.572 518.473 341.986 518.473ZM343.287 521.836L342.309 521.877C341.508 521.908 340.943 522.039 340.615 522.27C340.287 522.5 340.123 522.826 340.123 523.248C340.123 523.615 340.234 523.887 340.457 524.062C340.68 524.238 340.975 524.326 341.342 524.326C341.912 524.326 342.379 524.168 342.742 523.852C343.105 523.535 343.287 523.061 343.287 522.428V521.836ZM348.326 524.32C348.486 524.32 348.65 524.307 348.818 524.279C348.986 524.252 349.123 524.219 349.229 524.18V524.936C349.115 524.986 348.957 525.029 348.754 525.064C348.555 525.1 348.359 525.117 348.168 525.117C347.828 525.117 347.52 525.059 347.242 524.941C346.965 524.82 346.742 524.617 346.574 524.332C346.41 524.047 346.328 523.652 346.328 523.148V519.34H345.414V518.865L346.334 518.484L346.721 517.09H347.307V518.578H349.188V519.34H347.307V523.119C347.307 523.521 347.398 523.822 347.582 524.021C347.77 524.221 348.018 524.32 348.326 524.32ZM353.002 518.461C353.549 518.461 354.018 518.582 354.408 518.824C354.799 519.066 355.098 519.406 355.305 519.844C355.512 520.277 355.615 520.785 355.615 521.367V521.971H351.18C351.191 522.725 351.379 523.299 351.742 523.693C352.105 524.088 352.617 524.285 353.277 524.285C353.684 524.285 354.043 524.248 354.355 524.174C354.668 524.1 354.992 523.99 355.328 523.846V524.701C355.004 524.846 354.682 524.951 354.361 525.018C354.045 525.084 353.67 525.117 353.236 525.117C352.619 525.117 352.08 524.992 351.619 524.742C351.162 524.488 350.807 524.117 350.553 523.629C350.299 523.141 350.172 522.543 350.172 521.836C350.172 521.145 350.287 520.547 350.518 520.043C350.752 519.535 351.08 519.145 351.502 518.871C351.928 518.598 352.428 518.461 353.002 518.461ZM352.99 519.258C352.471 519.258 352.057 519.428 351.748 519.768C351.439 520.107 351.256 520.582 351.197 521.191H354.596C354.592 520.809 354.531 520.473 354.414 520.184C354.301 519.891 354.127 519.664 353.893 519.504C353.658 519.34 353.357 519.258 352.99 519.258ZM359.553 525.117C358.74 525.117 358.096 524.84 357.619 524.285C357.146 523.73 356.91 522.906 356.91 521.812C356.91 520.707 357.152 519.873 357.637 519.311C358.121 518.744 358.766 518.461 359.57 518.461C359.91 518.461 360.207 518.506 360.461 518.596C360.715 518.686 360.934 518.807 361.117 518.959C361.301 519.107 361.455 519.277 361.58 519.469H361.65C361.635 519.348 361.619 519.182 361.604 518.971C361.588 518.76 361.58 518.588 361.58 518.455V515.883H362.553V525H361.768L361.621 524.086H361.58C361.459 524.277 361.305 524.451 361.117 524.607C360.934 524.764 360.713 524.889 360.455 524.982C360.201 525.072 359.9 525.117 359.553 525.117ZM359.705 524.309C360.393 524.309 360.879 524.113 361.164 523.723C361.449 523.332 361.592 522.752 361.592 521.982V521.807C361.592 520.99 361.455 520.363 361.182 519.926C360.912 519.488 360.42 519.27 359.705 519.27C359.107 519.27 358.66 519.5 358.363 519.961C358.066 520.418 357.918 521.043 357.918 521.836C357.918 522.625 358.064 523.234 358.357 523.664C358.654 524.094 359.104 524.309 359.705 524.309ZM370.357 516.299C370.779 516.299 371.143 516.373 371.447 516.521C371.756 516.666 371.992 516.875 372.156 517.148C372.324 517.422 372.408 517.752 372.408 518.139C372.408 518.646 372.242 519.076 371.91 519.428C371.582 519.779 371.164 520.1 370.656 520.389L373.035 522.697C373.25 522.447 373.426 522.158 373.562 521.83C373.699 521.498 373.814 521.139 373.908 520.752H374.893C374.768 521.268 374.605 521.742 374.406 522.176C374.211 522.609 373.965 522.99 373.668 523.318L375.385 525H374.066L373.006 523.963C372.756 524.193 372.486 524.396 372.197 524.572C371.912 524.744 371.594 524.879 371.242 524.977C370.895 525.07 370.496 525.117 370.047 525.117C369.5 525.117 369.025 525.027 368.623 524.848C368.221 524.668 367.908 524.404 367.686 524.057C367.467 523.709 367.357 523.283 367.357 522.779C367.357 522.365 367.434 522.01 367.586 521.713C367.738 521.416 367.955 521.152 368.236 520.922C368.518 520.691 368.854 520.467 369.244 520.248C369.061 520.045 368.887 519.84 368.723 519.633C368.559 519.422 368.426 519.197 368.324 518.959C368.223 518.717 368.172 518.451 368.172 518.162C368.172 517.771 368.26 517.438 368.436 517.16C368.615 516.883 368.867 516.67 369.191 516.521C369.52 516.373 369.908 516.299 370.357 516.299ZM369.83 520.863C369.525 521.039 369.264 521.213 369.045 521.385C368.83 521.557 368.664 521.75 368.547 521.965C368.434 522.18 368.377 522.439 368.377 522.744C368.377 523.201 368.531 523.568 368.84 523.846C369.148 524.119 369.561 524.256 370.076 524.256C370.607 524.256 371.059 524.168 371.43 523.992C371.805 523.816 372.123 523.604 372.385 523.354L369.83 520.863ZM370.322 517.102C369.967 517.102 369.678 517.195 369.455 517.383C369.236 517.566 369.127 517.824 369.127 518.156C369.127 518.453 369.207 518.727 369.367 518.977C369.527 519.227 369.756 519.504 370.053 519.809C370.541 519.539 370.895 519.279 371.113 519.029C371.336 518.775 371.447 518.479 371.447 518.139C371.447 517.83 371.344 517.58 371.137 517.389C370.934 517.197 370.662 517.102 370.322 517.102ZM305.939 540L303.062 532.418H303.016C303.031 532.578 303.045 532.773 303.057 533.004C303.068 533.234 303.078 533.486 303.086 533.76C303.094 534.029 303.098 534.305 303.098 534.586V540H302.172V531.434H303.648L306.361 538.559H306.402L309.156 531.434H310.621V540H309.637V534.516C309.637 534.262 309.641 534.008 309.648 533.754C309.656 533.496 309.666 533.254 309.678 533.027C309.689 532.797 309.701 532.598 309.713 532.43H309.666L306.754 540H305.939ZM315.221 533.473C315.986 533.473 316.555 533.645 316.926 533.988C317.297 534.332 317.482 534.881 317.482 535.635V540H316.773L316.586 539.051H316.539C316.359 539.285 316.172 539.482 315.977 539.643C315.781 539.799 315.555 539.918 315.297 540C315.043 540.078 314.73 540.117 314.359 540.117C313.969 540.117 313.621 540.049 313.316 539.912C313.016 539.775 312.777 539.568 312.602 539.291C312.43 539.014 312.344 538.662 312.344 538.236C312.344 537.596 312.598 537.104 313.105 536.76C313.613 536.416 314.387 536.229 315.426 536.197L316.533 536.15V535.758C316.533 535.203 316.414 534.814 316.176 534.592C315.938 534.369 315.602 534.258 315.168 534.258C314.832 534.258 314.512 534.307 314.207 534.404C313.902 534.502 313.613 534.617 313.34 534.75L313.041 534.012C313.33 533.863 313.662 533.736 314.037 533.631C314.412 533.525 314.807 533.473 315.221 533.473ZM316.521 536.836L315.543 536.877C314.742 536.908 314.178 537.039 313.85 537.27C313.521 537.5 313.357 537.826 313.357 538.248C313.357 538.615 313.469 538.887 313.691 539.062C313.914 539.238 314.209 539.326 314.576 539.326C315.146 539.326 315.613 539.168 315.977 538.852C316.34 538.535 316.521 538.061 316.521 537.428V536.836ZM322.527 533.461C323.289 533.461 323.865 533.648 324.256 534.023C324.646 534.395 324.842 534.992 324.842 535.816V540H323.881V535.881C323.881 535.346 323.758 534.945 323.512 534.68C323.27 534.414 322.896 534.281 322.393 534.281C321.682 534.281 321.182 534.482 320.893 534.885C320.604 535.287 320.459 535.871 320.459 536.637V540H319.486V533.578H320.271L320.418 534.504H320.471C320.607 534.277 320.781 534.088 320.992 533.936C321.203 533.779 321.439 533.662 321.701 533.584C321.963 533.502 322.238 533.461 322.527 533.461ZM332.148 533.578V540H331.352L331.211 539.098H331.158C331.025 539.32 330.854 539.508 330.643 539.66C330.432 539.812 330.193 539.926 329.928 540C329.666 540.078 329.387 540.117 329.09 540.117C328.582 540.117 328.156 540.035 327.812 539.871C327.469 539.707 327.209 539.453 327.033 539.109C326.861 538.766 326.775 538.324 326.775 537.785V533.578H327.76V537.715C327.76 538.25 327.881 538.65 328.123 538.916C328.365 539.178 328.734 539.309 329.23 539.309C329.707 539.309 330.086 539.219 330.367 539.039C330.652 538.859 330.857 538.596 330.982 538.248C331.107 537.896 331.17 537.467 331.17 536.959V533.578H332.148ZM336.607 533.473C337.373 533.473 337.941 533.645 338.312 533.988C338.684 534.332 338.869 534.881 338.869 535.635V540H338.16L337.973 539.051H337.926C337.746 539.285 337.559 539.482 337.363 539.643C337.168 539.799 336.941 539.918 336.684 540C336.43 540.078 336.117 540.117 335.746 540.117C335.355 540.117 335.008 540.049 334.703 539.912C334.402 539.775 334.164 539.568 333.988 539.291C333.816 539.014 333.73 538.662 333.73 538.236C333.73 537.596 333.984 537.104 334.492 536.76C335 536.416 335.773 536.229 336.812 536.197L337.92 536.15V535.758C337.92 535.203 337.801 534.814 337.562 534.592C337.324 534.369 336.988 534.258 336.555 534.258C336.219 534.258 335.898 534.307 335.594 534.404C335.289 534.502 335 534.617 334.727 534.75L334.428 534.012C334.717 533.863 335.049 533.736 335.424 533.631C335.799 533.525 336.193 533.473 336.607 533.473ZM337.908 536.836L336.93 536.877C336.129 536.908 335.564 537.039 335.236 537.27C334.908 537.5 334.744 537.826 334.744 538.248C334.744 538.615 334.855 538.887 335.078 539.062C335.301 539.238 335.596 539.326 335.963 539.326C336.533 539.326 337 539.168 337.363 538.852C337.727 538.535 337.908 538.061 337.908 537.428V536.836ZM341.852 540H340.873V530.883H341.852V540ZM349.486 531.434C350.189 531.434 350.77 531.521 351.227 531.697C351.688 531.869 352.031 532.133 352.258 532.488C352.484 532.844 352.598 533.297 352.598 533.848C352.598 534.301 352.516 534.68 352.352 534.984C352.188 535.285 351.973 535.529 351.707 535.717C351.441 535.904 351.158 536.049 350.857 536.15L353.207 540H352.047L349.949 536.426H348.168V540H347.172V531.434H349.486ZM349.428 532.295H348.168V535.582H349.527C350.227 535.582 350.74 535.439 351.068 535.154C351.4 534.869 351.566 534.449 351.566 533.895C351.566 533.312 351.391 532.9 351.039 532.658C350.691 532.416 350.154 532.295 349.428 532.295ZM356.904 533.461C357.451 533.461 357.92 533.582 358.311 533.824C358.701 534.066 359 534.406 359.207 534.844C359.414 535.277 359.518 535.785 359.518 536.367V536.971H355.082C355.094 537.725 355.281 538.299 355.645 538.693C356.008 539.088 356.52 539.285 357.18 539.285C357.586 539.285 357.945 539.248 358.258 539.174C358.57 539.1 358.895 538.99 359.23 538.846V539.701C358.906 539.846 358.584 539.951 358.264 540.018C357.947 540.084 357.572 540.117 357.139 540.117C356.521 540.117 355.982 539.992 355.521 539.742C355.064 539.488 354.709 539.117 354.455 538.629C354.201 538.141 354.074 537.543 354.074 536.836C354.074 536.145 354.189 535.547 354.42 535.043C354.654 534.535 354.982 534.145 355.404 533.871C355.83 533.598 356.33 533.461 356.904 533.461ZM356.893 534.258C356.373 534.258 355.959 534.428 355.65 534.768C355.342 535.107 355.158 535.582 355.1 536.191H358.498C358.494 535.809 358.434 535.473 358.316 535.184C358.203 534.891 358.029 534.664 357.795 534.504C357.561 534.34 357.26 534.258 356.893 534.258ZM362.582 540L360.145 533.578H361.188L362.6 537.463C362.697 537.729 362.797 538.021 362.898 538.342C363 538.662 363.07 538.92 363.109 539.115H363.15C363.197 538.92 363.275 538.662 363.385 538.342C363.494 538.018 363.594 537.725 363.684 537.463L365.096 533.578H366.139L363.695 540H362.582ZM368.143 533.578V540H367.17V533.578H368.143ZM367.668 531.176C367.828 531.176 367.965 531.229 368.078 531.334C368.195 531.436 368.254 531.596 368.254 531.814C368.254 532.029 368.195 532.189 368.078 532.295C367.965 532.4 367.828 532.453 367.668 532.453C367.5 532.453 367.359 532.4 367.246 532.295C367.137 532.189 367.082 532.029 367.082 531.814C367.082 531.596 367.137 531.436 367.246 531.334C367.359 531.229 367.5 531.176 367.668 531.176ZM372.678 533.461C373.225 533.461 373.693 533.582 374.084 533.824C374.475 534.066 374.773 534.406 374.98 534.844C375.188 535.277 375.291 535.785 375.291 536.367V536.971H370.855C370.867 537.725 371.055 538.299 371.418 538.693C371.781 539.088 372.293 539.285 372.953 539.285C373.359 539.285 373.719 539.248 374.031 539.174C374.344 539.1 374.668 538.99 375.004 538.846V539.701C374.68 539.846 374.357 539.951 374.037 540.018C373.721 540.084 373.346 540.117 372.912 540.117C372.295 540.117 371.756 539.992 371.295 539.742C370.838 539.488 370.482 539.117 370.229 538.629C369.975 538.141 369.848 537.543 369.848 536.836C369.848 536.145 369.963 535.547 370.193 535.043C370.428 534.535 370.756 534.145 371.178 533.871C371.604 533.598 372.104 533.461 372.678 533.461ZM372.666 534.258C372.146 534.258 371.732 534.428 371.424 534.768C371.115 535.107 370.932 535.582 370.873 536.191H374.271C374.268 535.809 374.207 535.473 374.09 535.184C373.977 534.891 373.803 534.664 373.568 534.504C373.334 534.34 373.033 534.258 372.666 534.258ZM382.17 539.988L381.027 536.25C380.977 536.09 380.928 535.934 380.881 535.781C380.838 535.625 380.797 535.477 380.758 535.336C380.723 535.191 380.689 535.059 380.658 534.938C380.631 534.812 380.607 534.705 380.588 534.615H380.547C380.531 534.705 380.51 534.812 380.482 534.938C380.455 535.059 380.422 535.191 380.383 535.336C380.348 535.48 380.309 535.633 380.266 535.793C380.223 535.949 380.174 536.107 380.119 536.268L378.924 539.988H377.828L376.059 533.566H377.066L377.992 537.111C378.055 537.346 378.113 537.578 378.168 537.809C378.227 538.035 378.275 538.25 378.314 538.453C378.357 538.652 378.389 538.826 378.408 538.975H378.455C378.479 538.877 378.504 538.76 378.531 538.623C378.562 538.486 378.596 538.342 378.631 538.189C378.67 538.033 378.711 537.879 378.754 537.727C378.797 537.57 378.84 537.424 378.883 537.287L380.066 533.566H381.115L382.258 537.281C382.316 537.469 382.373 537.664 382.428 537.867C382.486 538.07 382.539 538.268 382.586 538.459C382.633 538.646 382.666 538.814 382.686 538.963H382.732C382.748 538.83 382.777 538.666 382.82 538.471C382.863 538.275 382.912 538.061 382.967 537.826C383.025 537.592 383.086 537.354 383.148 537.111L384.086 533.566H385.076L383.301 539.988H382.17Z"
            fill="white"
         />
         <path
            d="M278.441 748.491C278.048 748.491 277.693 748.56 277.377 748.696C277.064 748.83 276.798 749.025 276.576 749.282C276.358 749.536 276.19 749.844 276.073 750.205C275.956 750.566 275.897 750.973 275.897 751.426C275.897 752.025 275.99 752.546 276.176 752.988C276.365 753.428 276.645 753.768 277.016 754.009C277.39 754.25 277.857 754.37 278.417 754.37C278.736 754.37 279.035 754.344 279.315 754.292C279.599 754.237 279.874 754.168 280.141 754.087V754.81C279.88 754.907 279.607 754.979 279.32 755.024C279.034 755.073 278.694 755.098 278.3 755.098C277.574 755.098 276.967 754.948 276.479 754.648C275.993 754.346 275.629 753.919 275.385 753.369C275.144 752.819 275.023 752.17 275.023 751.421C275.023 750.881 275.098 750.387 275.248 749.941C275.401 749.492 275.622 749.105 275.912 748.779C276.205 748.454 276.563 748.203 276.986 748.027C277.413 747.848 277.901 747.759 278.451 747.759C278.812 747.759 279.161 747.795 279.496 747.866C279.831 747.938 280.134 748.04 280.404 748.174L280.072 748.877C279.844 748.773 279.594 748.683 279.32 748.608C279.05 748.53 278.757 748.491 278.441 748.491ZM282.188 755V747.861H283.019V755H282.188ZM290.444 747.861C291.366 747.861 292.038 748.042 292.461 748.403C292.887 748.761 293.101 749.276 293.101 749.946C293.101 750.249 293.05 750.537 292.949 750.811C292.852 751.081 292.692 751.32 292.471 751.528C292.249 751.733 291.958 751.896 291.597 752.017C291.239 752.134 290.799 752.192 290.278 752.192H289.409V755H288.579V747.861H290.444ZM290.366 748.569H289.409V751.479H290.186C290.641 751.479 291.021 751.431 291.323 751.333C291.629 751.235 291.859 751.077 292.012 750.859C292.165 750.638 292.241 750.345 292.241 749.98C292.241 749.505 292.09 749.152 291.787 748.921C291.484 748.687 291.011 748.569 290.366 748.569ZM295.095 755V747.861H295.925V755H295.095ZM300.253 747.861C301.174 747.861 301.846 748.042 302.27 748.403C302.696 748.761 302.909 749.276 302.909 749.946C302.909 750.249 302.859 750.537 302.758 750.811C302.66 751.081 302.501 751.32 302.279 751.528C302.058 751.733 301.767 751.896 301.405 752.017C301.047 752.134 300.608 752.192 300.087 752.192H299.218V755H298.388V747.861H300.253ZM300.175 748.569H299.218V751.479H299.994C300.45 751.479 300.829 751.431 301.132 751.333C301.438 751.235 301.667 751.077 301.82 750.859C301.973 750.638 302.05 750.345 302.05 749.98C302.05 749.505 301.898 749.152 301.596 748.921C301.293 748.687 300.819 748.569 300.175 748.569ZM308.878 755H304.903V747.861H308.878V748.594H305.733V750.903H308.697V751.626H305.733V754.268H308.878V755ZM310.96 755V747.861H311.79V754.258H314.959V755H310.96ZM316.685 755V747.861H317.515V755H316.685ZM325.559 755H324.602L320.71 749.004H320.671C320.681 749.163 320.692 749.346 320.705 749.551C320.718 749.753 320.728 749.969 320.734 750.2C320.744 750.428 320.749 750.661 320.749 750.898V755H319.978V747.861H320.93L324.807 753.838H324.841C324.834 753.724 324.826 753.563 324.816 753.354C324.807 753.143 324.797 752.917 324.787 752.676C324.781 752.432 324.777 752.205 324.777 751.997V747.861H325.559V755ZM331.981 755H328.007V747.861H331.981V748.594H328.837V750.903H331.801V751.626H328.837V754.268H331.981V755Z"
            fill="white"
         />
         <path
            d="M266.195 708.491C265.801 708.491 265.447 708.56 265.131 708.696C264.818 708.83 264.551 709.025 264.33 709.282C264.112 709.536 263.944 709.844 263.827 710.205C263.71 710.566 263.651 710.973 263.651 711.426C263.651 712.025 263.744 712.546 263.93 712.988C264.118 713.428 264.398 713.768 264.77 714.009C265.144 714.25 265.611 714.37 266.171 714.37C266.49 714.37 266.789 714.344 267.069 714.292C267.353 714.237 267.628 714.168 267.895 714.087V714.81C267.634 714.907 267.361 714.979 267.074 715.024C266.788 715.073 266.448 715.098 266.054 715.098C265.328 715.098 264.721 714.948 264.232 714.648C263.747 714.346 263.383 713.919 263.139 713.369C262.898 712.819 262.777 712.17 262.777 711.421C262.777 710.881 262.852 710.387 263.002 709.941C263.155 709.492 263.376 709.105 263.666 708.779C263.959 708.454 264.317 708.203 264.74 708.027C265.167 707.848 265.655 707.759 266.205 707.759C266.566 707.759 266.915 707.795 267.25 707.866C267.585 707.938 267.888 708.04 268.158 708.174L267.826 708.877C267.598 708.773 267.348 708.683 267.074 708.608C266.804 708.53 266.511 708.491 266.195 708.491ZM275.634 711.421C275.634 711.971 275.564 712.472 275.424 712.925C275.284 713.374 275.076 713.761 274.799 714.087C274.525 714.409 274.185 714.658 273.778 714.834C273.371 715.01 272.899 715.098 272.362 715.098C271.809 715.098 271.326 715.01 270.912 714.834C270.502 714.658 270.16 714.408 269.887 714.082C269.617 713.757 269.413 713.368 269.276 712.915C269.143 712.463 269.076 711.961 269.076 711.411C269.076 710.682 269.197 710.042 269.438 709.492C269.678 708.942 270.043 708.514 270.531 708.208C271.023 707.902 271.638 707.749 272.377 707.749C273.083 707.749 273.677 707.9 274.159 708.203C274.644 708.506 275.01 708.932 275.258 709.482C275.508 710.029 275.634 710.675 275.634 711.421ZM269.95 711.421C269.95 712.026 270.036 712.55 270.209 712.993C270.382 713.436 270.645 713.778 271 714.019C271.358 714.259 271.812 714.38 272.362 714.38C272.916 714.38 273.368 714.259 273.72 714.019C274.075 713.778 274.337 713.436 274.506 712.993C274.675 712.55 274.76 712.026 274.76 711.421C274.76 710.5 274.566 709.78 274.179 709.263C273.795 708.742 273.194 708.481 272.377 708.481C271.824 708.481 271.368 708.6 271.01 708.838C270.652 709.076 270.385 709.414 270.209 709.854C270.036 710.29 269.95 710.812 269.95 711.421ZM280.365 715L277.968 708.682H277.929C277.942 708.815 277.953 708.978 277.963 709.17C277.973 709.362 277.981 709.572 277.987 709.8C277.994 710.024 277.997 710.254 277.997 710.488V715H277.226V707.861H278.456L280.717 713.799H280.751L283.046 707.861H284.267V715H283.446V710.43C283.446 710.218 283.45 710.007 283.456 709.795C283.463 709.58 283.471 709.378 283.48 709.189C283.49 708.997 283.5 708.831 283.51 708.691H283.471L281.044 715H280.365ZM288.085 707.861C289.006 707.861 289.678 708.042 290.102 708.403C290.528 708.761 290.741 709.276 290.741 709.946C290.741 710.249 290.691 710.537 290.59 710.811C290.492 711.081 290.333 711.32 290.111 711.528C289.89 711.733 289.599 711.896 289.237 712.017C288.879 712.134 288.44 712.192 287.919 712.192H287.05V715H286.22V707.861H288.085ZM288.007 708.569H287.05V711.479H287.826C288.282 711.479 288.661 711.431 288.964 711.333C289.27 711.235 289.499 711.077 289.652 710.859C289.805 710.638 289.882 710.345 289.882 709.98C289.882 709.505 289.73 709.152 289.428 708.921C289.125 708.687 288.651 708.569 288.007 708.569ZM292.235 715V707.861H293.065V715H292.235ZM295.028 715V707.861H295.858V714.258H299.027V715H295.028ZM304.228 715H300.253V707.861H304.228V708.594H301.083V710.903H304.047V711.626H301.083V714.268H304.228V715Z"
            fill="white"
         />
         <g filter="url(#filter13_b_226_1189)">
            <path
               d="M292 733C292 737.418 288.418 741 284 741C279.582 741 276 737.418 276 733C276 728.582 279.582 725 284 725C288.418 725 292 728.582 292 733Z"
               fill="#B3B3B3"
            />
            <path
               d="M291 733C291 736.866 287.866 740 284 740C280.134 740 277 736.866 277 733C277 729.134 280.134 726 284 726C287.866 726 291 729.134 291 733Z"
               stroke="black"
               strokeWidth="2"
            />
         </g>
         <path
            d="M316.46 707.861H318.481C319.373 707.861 320.044 707.995 320.493 708.262C320.942 708.529 321.167 708.983 321.167 709.624C321.167 709.901 321.113 710.15 321.006 710.371C320.902 710.589 320.749 710.77 320.547 710.913C320.345 711.056 320.096 711.156 319.8 711.211V711.26C320.112 711.309 320.389 711.398 320.63 711.528C320.871 711.659 321.06 711.841 321.196 712.075C321.333 712.31 321.401 712.607 321.401 712.969C321.401 713.408 321.299 713.779 321.094 714.082C320.892 714.385 320.605 714.614 320.234 714.771C319.863 714.924 319.424 715 318.916 715H316.46V707.861ZM317.29 710.923H318.657C319.279 710.923 319.709 710.82 319.946 710.615C320.187 710.41 320.308 710.111 320.308 709.717C320.308 709.31 320.164 709.017 319.878 708.838C319.595 708.659 319.142 708.569 318.521 708.569H317.29V710.923ZM317.29 711.621V714.292H318.774C319.409 714.292 319.858 714.168 320.122 713.921C320.386 713.67 320.518 713.333 320.518 712.91C320.518 712.64 320.457 712.409 320.337 712.217C320.22 712.025 320.028 711.878 319.761 711.777C319.497 711.673 319.144 711.621 318.701 711.621H317.29ZM328.325 707.861V712.48C328.325 712.985 328.223 713.434 328.018 713.828C327.816 714.222 327.51 714.533 327.1 714.761C326.689 714.985 326.175 715.098 325.557 715.098C324.674 715.098 324.002 714.858 323.54 714.38C323.081 713.901 322.852 713.262 322.852 712.461V707.861H323.687V712.485C323.687 713.091 323.846 713.558 324.165 713.887C324.487 714.215 324.967 714.38 325.605 714.38C326.042 714.38 326.398 714.302 326.675 714.146C326.955 713.986 327.161 713.765 327.295 713.481C327.432 713.195 327.5 712.865 327.5 712.49V707.861H328.325ZM330.22 715V707.861H331.05V715H330.22ZM333.013 715V707.861H333.843V714.258H337.012V715H333.013ZM343.906 711.362C343.906 712.166 343.76 712.839 343.467 713.379C343.174 713.916 342.749 714.321 342.192 714.595C341.639 714.865 340.967 715 340.176 715H338.237V707.861H340.391C341.117 707.861 341.742 707.995 342.266 708.262C342.79 708.525 343.193 708.918 343.477 709.438C343.763 709.956 343.906 710.597 343.906 711.362ZM343.032 711.392C343.032 710.75 342.925 710.221 342.71 709.805C342.498 709.388 342.186 709.079 341.772 708.877C341.362 708.672 340.859 708.569 340.264 708.569H339.067V714.287H340.078C341.061 714.287 341.799 714.045 342.29 713.56C342.785 713.075 343.032 712.352 343.032 711.392Z"
            fill="white"
         />
         <g filter="url(#filter14_b_226_1189)">
            <circle cx="330" cy="733" r="8" fill="#B3B3B3" />
            <circle cx="330" cy="733" r="7" stroke="black" strokeWidth="2" />
         </g>
         <path
            d="M194.229 707.861C195.15 707.861 195.822 708.042 196.245 708.403C196.672 708.761 196.885 709.276 196.885 709.946C196.885 710.249 196.834 710.537 196.733 710.811C196.636 711.081 196.476 711.32 196.255 711.528C196.034 711.733 195.742 711.896 195.381 712.017C195.023 712.134 194.583 712.192 194.062 712.192H193.193V715H192.363V707.861H194.229ZM194.15 708.569H193.193V711.479H193.97C194.425 711.479 194.805 711.431 195.107 711.333C195.413 711.235 195.643 711.077 195.796 710.859C195.949 710.638 196.025 710.345 196.025 709.98C196.025 709.505 195.874 709.152 195.571 708.921C195.269 708.687 194.795 708.569 194.15 708.569ZM200.308 707.861C200.894 707.861 201.377 707.935 201.758 708.081C202.142 708.224 202.428 708.444 202.617 708.74C202.806 709.036 202.9 709.414 202.9 709.873C202.9 710.251 202.832 710.566 202.695 710.82C202.559 711.071 202.38 711.274 202.158 711.431C201.937 711.587 201.701 711.707 201.45 711.792L203.408 715H202.441L200.693 712.021H199.209V715H198.379V707.861H200.308ZM200.259 708.579H199.209V711.318H200.342C200.924 711.318 201.353 711.2 201.626 710.962C201.903 710.724 202.041 710.374 202.041 709.912C202.041 709.427 201.895 709.084 201.602 708.882C201.312 708.68 200.864 708.579 200.259 708.579ZM210.742 711.421C210.742 711.971 210.672 712.472 210.532 712.925C210.392 713.374 210.184 713.761 209.907 714.087C209.634 714.409 209.294 714.658 208.887 714.834C208.48 715.01 208.008 715.098 207.471 715.098C206.917 715.098 206.434 715.01 206.021 714.834C205.61 714.658 205.269 714.408 204.995 714.082C204.725 713.757 204.521 713.368 204.385 712.915C204.251 712.463 204.185 711.961 204.185 711.411C204.185 710.682 204.305 710.042 204.546 709.492C204.787 708.942 205.151 708.514 205.64 708.208C206.131 707.902 206.746 707.749 207.485 707.749C208.192 707.749 208.786 707.9 209.268 708.203C209.753 708.506 210.119 708.932 210.366 709.482C210.617 710.029 210.742 710.675 210.742 711.421ZM205.059 711.421C205.059 712.026 205.145 712.55 205.317 712.993C205.49 713.436 205.754 713.778 206.108 714.019C206.466 714.259 206.921 714.38 207.471 714.38C208.024 714.38 208.477 714.259 208.828 714.019C209.183 713.778 209.445 713.436 209.614 712.993C209.784 712.55 209.868 712.026 209.868 711.421C209.868 710.5 209.674 709.78 209.287 709.263C208.903 708.742 208.302 708.481 207.485 708.481C206.932 708.481 206.476 708.6 206.118 708.838C205.76 709.076 205.493 709.414 205.317 709.854C205.145 710.29 205.059 710.812 205.059 711.421ZM218.003 711.362C218.003 712.166 217.856 712.839 217.563 713.379C217.271 713.916 216.846 714.321 216.289 714.595C215.736 714.865 215.063 715 214.272 715H212.334V707.861H214.487C215.213 707.861 215.838 707.995 216.362 708.262C216.886 708.525 217.29 708.918 217.573 709.438C217.86 709.956 218.003 710.597 218.003 711.362ZM217.129 711.392C217.129 710.75 217.021 710.221 216.807 709.805C216.595 709.388 216.283 709.079 215.869 708.877C215.459 708.672 214.956 708.569 214.36 708.569H213.164V714.287H214.175C215.158 714.287 215.895 714.045 216.387 713.56C216.882 713.075 217.129 712.352 217.129 711.392Z"
            fill="white"
         />
         <g filter="url(#filter15_b_226_1189)">
            <path
               d="M213 733C213 737.418 209.418 741 205 741C200.582 741 197 737.418 197 733C197 728.582 200.582 725 205 725C209.418 725 213 728.582 213 733Z"
               fill="#B3B3B3"
            />
            <path
               d="M212 733C212 736.866 208.866 740 205 740C201.134 740 198 736.866 198 733C198 729.134 201.134 726 205 726C208.866 726 212 729.134 212 733Z"
               stroke="black"
               strokeWidth="2"
            />
         </g>
         <path
            d="M138.406 714.101C138.406 714.524 138.3 714.885 138.089 715.185C137.881 715.481 137.588 715.707 137.21 715.863C136.832 716.02 136.388 716.098 135.877 716.098C135.607 716.098 135.351 716.085 135.11 716.059C134.869 716.033 134.648 715.995 134.446 715.946C134.244 715.897 134.067 715.837 133.914 715.766V714.97C134.158 715.071 134.456 715.165 134.808 715.253C135.159 715.338 135.527 715.38 135.911 715.38C136.269 715.38 136.572 715.333 136.819 715.238C137.067 715.141 137.254 715.002 137.381 714.823C137.511 714.641 137.576 714.423 137.576 714.169C137.576 713.925 137.522 713.721 137.415 713.559C137.308 713.393 137.129 713.243 136.878 713.109C136.631 712.973 136.292 712.828 135.862 712.675C135.56 712.567 135.293 712.45 135.062 712.323C134.83 712.193 134.637 712.047 134.48 711.884C134.324 711.721 134.205 711.532 134.124 711.317C134.046 711.103 134.007 710.857 134.007 710.58C134.007 710.199 134.103 709.874 134.295 709.604C134.49 709.33 134.759 709.122 135.101 708.979C135.446 708.832 135.841 708.759 136.287 708.759C136.668 708.759 137.02 708.795 137.342 708.866C137.667 708.938 137.965 709.034 138.235 709.154L137.977 709.867C137.719 709.76 137.446 709.67 137.156 709.599C136.87 709.527 136.574 709.491 136.268 709.491C135.962 709.491 135.703 709.537 135.491 709.628C135.283 709.716 135.123 709.841 135.013 710.004C134.902 710.167 134.847 710.36 134.847 710.585C134.847 710.836 134.899 711.044 135.003 711.21C135.11 711.376 135.28 711.524 135.511 711.654C135.745 711.781 136.054 711.915 136.438 712.055C136.858 712.208 137.215 712.37 137.508 712.543C137.801 712.712 138.024 712.921 138.177 713.168C138.33 713.412 138.406 713.723 138.406 714.101ZM142.059 716H141.224V709.594H138.978V708.861H144.295V709.594H142.059V716ZM149.852 716L148.973 713.734H146.111L145.237 716H144.397L147.19 708.832H147.938L150.711 716H149.852ZM148.724 712.997L147.889 710.746C147.869 710.688 147.837 710.591 147.791 710.458C147.749 710.325 147.705 710.186 147.659 710.043C147.614 709.9 147.576 709.784 147.547 709.696C147.514 709.83 147.479 709.963 147.439 710.097C147.404 710.227 147.368 710.349 147.332 710.463C147.296 710.574 147.265 710.668 147.239 710.746L146.39 712.997H148.724ZM154.754 712.26H157.249V715.722C156.875 715.849 156.489 715.943 156.092 716.005C155.698 716.067 155.257 716.098 154.769 716.098C154.026 716.098 153.4 715.95 152.889 715.653C152.381 715.357 151.995 714.936 151.731 714.389C151.468 713.839 151.336 713.186 151.336 712.431C151.336 711.692 151.481 711.047 151.771 710.497C152.063 709.947 152.485 709.521 153.035 709.218C153.589 708.912 154.253 708.759 155.027 708.759C155.424 708.759 155.8 708.796 156.155 708.871C156.513 708.943 156.845 709.045 157.151 709.179L156.834 709.901C156.57 709.787 156.279 709.69 155.96 709.608C155.644 709.527 155.317 709.486 154.979 709.486C154.396 709.486 153.896 709.607 153.479 709.848C153.066 710.089 152.749 710.429 152.527 710.868C152.309 711.308 152.2 711.828 152.2 712.431C152.2 713.026 152.296 713.546 152.488 713.988C152.68 714.428 152.98 714.77 153.387 715.014C153.794 715.258 154.318 715.38 154.959 715.38C155.281 715.38 155.558 715.362 155.789 715.326C156.02 715.287 156.23 715.242 156.419 715.189V713.002H154.754V712.26ZM158.978 716V708.861H159.808V716H158.978ZM167.352 716H166.395L162.503 710.004H162.464C162.474 710.163 162.485 710.346 162.498 710.551C162.511 710.753 162.521 710.969 162.527 711.2C162.537 711.428 162.542 711.661 162.542 711.898V716H161.771V708.861H162.723L166.6 714.838H166.634C166.627 714.724 166.619 714.563 166.609 714.354C166.6 714.143 166.59 713.917 166.58 713.676C166.574 713.432 166.57 713.205 166.57 712.997V708.861H167.352V716ZM172.352 712.26H174.847V715.722C174.472 715.849 174.087 715.943 173.689 716.005C173.296 716.067 172.854 716.098 172.366 716.098C171.624 716.098 170.997 715.95 170.486 715.653C169.979 715.357 169.593 714.936 169.329 714.389C169.065 713.839 168.934 713.186 168.934 712.431C168.934 711.692 169.078 711.047 169.368 710.497C169.661 709.947 170.083 709.521 170.633 709.218C171.186 708.912 171.85 708.759 172.625 708.759C173.022 708.759 173.398 708.796 173.753 708.871C174.111 708.943 174.443 709.045 174.749 709.179L174.432 709.901C174.168 709.787 173.877 709.69 173.558 709.608C173.242 709.527 172.915 709.486 172.576 709.486C171.993 709.486 171.494 709.607 171.077 709.848C170.664 710.089 170.346 710.429 170.125 710.868C169.907 711.308 169.798 711.828 169.798 712.431C169.798 713.026 169.894 713.546 170.086 713.988C170.278 714.428 170.577 714.77 170.984 715.014C171.391 715.258 171.915 715.38 172.557 715.38C172.879 715.38 173.156 715.362 173.387 715.326C173.618 715.287 173.828 715.242 174.017 715.189V713.002H172.352V712.26Z"
            fill="white"
         />
         <g filter="url(#filter16_b_226_1189)">
            <circle cx="155" cy="733" r="8" fill="#B3B3B3" />
            <circle cx="155" cy="733" r="7" stroke="black" strokeWidth="2" />
         </g>
         <path
            d="M105.756 713.362C105.756 714.166 105.609 714.839 105.316 715.379C105.023 715.916 104.599 716.321 104.042 716.595C103.489 716.865 102.816 717 102.025 717H100.087V709.861H102.24C102.966 709.861 103.591 709.995 104.115 710.262C104.639 710.525 105.043 710.918 105.326 711.438C105.613 711.956 105.756 712.597 105.756 713.362ZM104.882 713.392C104.882 712.75 104.774 712.221 104.56 711.805C104.348 711.388 104.035 711.079 103.622 710.877C103.212 710.672 102.709 710.569 102.113 710.569H100.917V716.287H101.928C102.911 716.287 103.648 716.045 104.14 715.56C104.634 715.075 104.882 714.352 104.882 713.392ZM111.317 717H107.343V709.861H111.317V710.594H108.173V712.903H111.137V713.626H108.173V716.268H111.317V717ZM117.885 709.861L115.321 717H114.486L111.923 709.861H112.792L114.462 714.563C114.53 714.752 114.59 714.933 114.643 715.105C114.698 715.278 114.747 715.444 114.789 715.604C114.831 715.763 114.869 715.918 114.901 716.067C114.934 715.918 114.971 715.763 115.014 715.604C115.056 715.441 115.105 715.273 115.16 715.101C115.215 714.925 115.277 714.741 115.346 714.549L117.006 709.861H117.885Z"
            fill="white"
         />
         <g filter="url(#filter17_b_226_1189)">
            <circle cx="108" cy="733" r="8" fill="#B3B3B3" />
            <circle cx="108" cy="733" r="7" stroke="black" strokeWidth="2" />
         </g>
         <path
            d="M133.21 748.491C132.816 748.491 132.461 748.56 132.146 748.696C131.833 748.83 131.566 749.025 131.345 749.282C131.127 749.536 130.959 749.844 130.842 750.205C130.725 750.566 130.666 750.973 130.666 751.426C130.666 752.025 130.759 752.546 130.944 752.988C131.133 753.428 131.413 753.768 131.784 754.009C132.159 754.25 132.626 754.37 133.186 754.37C133.505 754.37 133.804 754.344 134.084 754.292C134.367 754.237 134.642 754.168 134.909 754.087V754.81C134.649 754.907 134.375 754.979 134.089 755.024C133.802 755.073 133.462 755.098 133.068 755.098C132.342 755.098 131.735 754.948 131.247 754.648C130.762 754.346 130.397 753.919 130.153 753.369C129.912 752.819 129.792 752.17 129.792 751.421C129.792 750.881 129.867 750.387 130.017 749.941C130.17 749.492 130.391 749.105 130.681 748.779C130.974 748.454 131.332 748.203 131.755 748.027C132.181 747.848 132.67 747.759 133.22 747.759C133.581 747.759 133.929 747.795 134.265 747.866C134.6 747.938 134.903 748.04 135.173 748.174L134.841 748.877C134.613 748.773 134.362 748.683 134.089 748.608C133.819 748.53 133.526 748.491 133.21 748.491ZM142.626 751.362C142.626 752.166 142.479 752.839 142.187 753.379C141.894 753.916 141.469 754.321 140.912 754.595C140.359 754.865 139.687 755 138.896 755H136.957V747.861H139.11C139.836 747.861 140.461 747.995 140.985 748.262C141.509 748.525 141.913 748.918 142.196 749.438C142.483 749.956 142.626 750.597 142.626 751.362ZM141.752 751.392C141.752 750.75 141.645 750.221 141.43 749.805C141.218 749.388 140.906 749.079 140.492 748.877C140.082 748.672 139.579 748.569 138.983 748.569H137.787V754.287H138.798C139.781 754.287 140.518 754.045 141.01 753.56C141.505 753.075 141.752 752.352 141.752 751.392ZM149.676 747.861C150.597 747.861 151.269 748.042 151.692 748.403C152.119 748.761 152.332 749.276 152.332 749.946C152.332 750.249 152.282 750.537 152.181 750.811C152.083 751.081 151.924 751.32 151.702 751.528C151.481 751.733 151.189 751.896 150.828 752.017C150.47 752.134 150.031 752.192 149.51 752.192H148.641V755H147.811V747.861H149.676ZM149.598 748.569H148.641V751.479H149.417C149.873 751.479 150.252 751.431 150.555 751.333C150.861 751.235 151.09 751.077 151.243 750.859C151.396 750.638 151.473 750.345 151.473 749.98C151.473 749.505 151.321 749.152 151.019 748.921C150.716 748.687 150.242 748.569 149.598 748.569ZM154.326 755V747.861H155.156V755H154.326ZM159.484 747.861C160.406 747.861 161.078 748.042 161.501 748.403C161.927 748.761 162.141 749.276 162.141 749.946C162.141 750.249 162.09 750.537 161.989 750.811C161.892 751.081 161.732 751.32 161.511 751.528C161.289 751.733 160.998 751.896 160.637 752.017C160.279 752.134 159.839 752.192 159.318 752.192H158.449V755H157.619V747.861H159.484ZM159.406 748.569H158.449V751.479H159.226C159.681 751.479 160.061 751.431 160.363 751.333C160.669 751.235 160.899 751.077 161.052 750.859C161.205 750.638 161.281 750.345 161.281 749.98C161.281 749.505 161.13 749.152 160.827 748.921C160.524 748.687 160.051 748.569 159.406 748.569ZM168.109 755H164.135V747.861H168.109V748.594H164.965V750.903H167.929V751.626H164.965V754.268H168.109V755ZM170.191 755V747.861H171.021V754.258H174.19V755H170.191ZM175.916 755V747.861H176.746V755H175.916ZM184.79 755H183.833L179.941 749.004H179.902C179.912 749.163 179.924 749.346 179.937 749.551C179.95 749.753 179.959 749.969 179.966 750.2C179.976 750.428 179.98 750.661 179.98 750.898V755H179.209V747.861H180.161L184.038 753.838H184.072C184.066 753.724 184.058 753.563 184.048 753.354C184.038 753.143 184.028 752.917 184.019 752.676C184.012 752.432 184.009 752.205 184.009 751.997V747.861H184.79V755ZM191.213 755H187.238V747.861H191.213V748.594H188.068V750.903H191.032V751.626H188.068V754.268H191.213V755Z"
            fill="white"
         />
         <g clipPath="url(#clip3_226_1189)">
            <path
               d="M100.988 846.259C101.472 845.841 102.006 845.983 102.515 846.058C102.632 846.075 102.765 846.292 102.815 846.451C102.915 846.768 102.957 847.102 103.049 847.419C103.082 847.527 103.199 847.611 103.291 847.686C103.333 847.727 103.416 847.719 103.466 847.752C103.992 848.153 104.451 847.978 104.901 847.602C104.993 847.519 105.11 847.46 105.218 847.402C105.452 847.26 105.677 847.277 105.878 847.469C106.262 847.844 106.645 848.228 107.029 848.62C107.23 848.829 107.246 849.063 107.088 849.305C106.904 849.597 106.704 849.88 106.537 850.172C106.487 850.264 106.495 850.398 106.52 850.506C106.545 850.623 106.654 850.732 106.671 850.848C106.746 851.349 107.079 851.483 107.53 851.566C108.556 851.741 108.515 851.783 108.506 852.776C108.506 853.102 108.506 853.419 108.506 853.744C108.498 854.095 108.381 854.245 108.031 854.337C107.981 854.353 107.931 854.362 107.881 854.378C107.547 854.462 107.146 854.453 106.913 854.654C106.687 854.846 106.62 855.238 106.504 855.547C106.47 855.622 106.487 855.747 106.537 855.822C106.712 856.114 106.904 856.406 107.088 856.69C107.255 856.949 107.23 857.182 107.013 857.399C106.645 857.766 106.278 858.134 105.911 858.509C105.686 858.734 105.444 858.759 105.177 858.584C104.926 858.417 104.668 858.259 104.417 858.092C104.367 858.058 104.317 858.017 104.259 857.992C104.084 857.908 103.107 858.384 103.057 858.576C102.982 858.893 102.924 859.21 102.849 859.519C102.765 859.886 102.607 860.003 102.239 860.011C102.056 860.011 101.864 860.036 101.68 860.003C101.455 859.969 101.246 859.894 101.004 859.836C101.004 860.353 101.021 860.937 101.004 861.522C100.971 862.573 100.479 863.349 99.5189 863.783C99.2101 863.925 98.8346 864 98.4925 864C94.8374 864.017 91.1823 864.017 87.5272 864.008C86.1086 864.008 85.0238 862.907 85.0154 861.48C85.0071 859.202 85.0154 856.915 85.0154 854.637C85.0154 854.245 85.199 854.011 85.5161 854.011C85.8249 854.011 86.0168 854.236 86.0168 854.637C86.0168 856.873 86.0168 859.118 86.0168 861.355C86.0168 862.398 86.626 863.007 87.6608 863.007C91.2324 863.007 94.804 863.007 98.3756 863.007C99.3937 863.007 100.011 862.389 100.011 861.371C100.011 856.298 100.011 851.232 100.011 846.159C100.011 846.083 100.011 846.017 100.011 845.942C100.011 844.223 100.07 844.006 100.52 844.014C100.963 844.022 101.013 844.223 101.013 845.925C100.988 846.025 100.988 846.134 100.988 846.259ZM101.004 850.022C102.932 849.797 104.259 851.132 104.467 852.609C104.634 853.828 103.9 855.213 102.79 855.688C102.498 855.814 102.223 855.73 102.097 855.471C101.972 855.221 102.064 854.971 102.323 854.804C102.381 854.762 102.448 854.737 102.515 854.695C103.383 854.161 103.725 853.085 103.307 852.159C102.907 851.266 101.906 850.782 101.004 851.057C101.004 853.777 101.004 856.498 101.004 859.143C101.296 859.068 101.588 858.985 101.939 858.893C102.006 858.601 102.089 858.25 102.164 857.9C102.214 857.658 102.356 857.533 102.581 857.449C103.015 857.282 103.449 857.107 103.875 856.907C104.109 856.798 104.309 856.798 104.518 856.94C104.768 857.107 105.018 857.274 105.285 857.424C105.344 857.458 105.469 857.466 105.519 857.433C105.728 857.291 105.911 857.132 106.095 856.99C105.853 856.615 105.686 856.339 105.502 856.072C105.319 855.814 105.319 855.58 105.469 855.288C105.661 854.921 105.811 854.529 105.944 854.136C106.045 853.844 106.203 853.677 106.504 853.627C106.837 853.569 107.163 853.485 107.488 853.41C107.488 853.11 107.488 852.834 107.488 852.551C107.146 852.476 106.812 852.392 106.479 852.325C106.186 852.267 106.036 852.108 105.944 851.825C105.828 851.474 105.719 851.107 105.527 850.79C105.31 850.423 105.294 850.114 105.561 849.789C105.619 849.713 105.661 849.63 105.711 849.555C106.061 849.004 106.07 849.004 105.569 848.57C105.502 848.512 105.344 848.503 105.26 848.537C104.993 848.679 104.743 848.854 104.492 849.021C104.292 849.154 104.092 849.146 103.875 849.046C103.449 848.854 103.024 848.67 102.581 848.503C102.339 848.412 102.198 848.278 102.148 848.019C102.081 847.677 101.997 847.335 101.914 846.976C101.58 846.951 101.23 847.051 100.996 846.643C101.004 847.844 101.004 848.921 101.004 850.022Z"
               fill="white"
            />
            <path
               d="M86.9931 853.001C83.1294 853.001 79.9917 849.864 80 845.992C80.0084 842.136 83.1461 839.007 87.0014 839.007C90.8568 839.007 93.9945 842.145 93.9945 846C93.9945 849.88 90.7983 853.035 86.9931 853.001ZM91.5828 849.83C93.4604 847.711 93.6106 844.056 91.1572 841.686C88.7705 839.374 84.9903 839.449 82.662 841.869C80.3338 844.289 80.6342 847.861 82.4117 849.83C82.4451 849.78 82.4868 849.73 82.5202 849.68C83.2295 848.579 84.2392 848.019 85.5494 848.011C86.5508 848.003 87.5438 847.994 88.5452 848.011C89.7219 848.036 90.6648 848.545 91.3575 849.505C91.4326 849.605 91.5077 849.713 91.5828 849.83ZM90.7983 850.59C90.5146 849.705 89.605 849.021 88.6203 849.004C87.5355 848.987 86.459 848.987 85.3741 849.004C84.3894 849.021 83.4882 849.697 83.1961 850.59C85.2323 852.401 88.7538 852.409 90.7983 850.59Z"
               fill="white"
            />
            <path
               d="M101.015 838.999C101.983 838.999 102.951 838.999 103.919 838.999C105.096 839.007 105.989 839.866 105.989 840.993C105.989 842.12 105.096 842.987 103.919 842.996C101.967 842.996 100.006 843.004 98.0529 842.996C96.8846 842.996 95.9917 842.111 96.0001 840.985C96.0084 839.866 96.9013 839.007 98.0529 838.999C99.0376 838.999 100.031 838.999 101.015 838.999ZM101.007 842.003C101.975 842.003 102.943 842.003 103.911 842.003C104.545 842.003 104.996 841.577 104.996 841.001C104.996 840.426 104.537 840.008 103.903 840.008C101.967 840.008 100.031 840.008 98.0946 840.008C97.4521 840.008 97.0014 840.417 97.0014 840.993C96.9931 841.585 97.4521 842.003 98.103 842.003C99.071 842.003 100.039 842.003 101.007 842.003Z"
               fill="white"
            />
            <path
               d="M93 834C94.7691 834 96.5383 834 98.3074 834C99.9513 834 100.986 835.043 100.986 836.695C100.986 836.946 100.994 837.196 100.986 837.446C100.978 837.78 100.769 838.006 100.477 837.997C100.193 837.989 100.001 837.78 99.9931 837.455C99.9847 837.129 99.9931 836.812 99.9931 836.487C99.9764 835.652 99.3338 835.001 98.4993 835.001C94.8359 835.001 91.1725 835.001 87.5091 835.001C86.6495 835.001 86.0153 835.652 85.9986 836.503C85.9903 836.812 85.9986 837.129 85.9986 837.438C85.9903 837.78 85.79 837.997 85.4979 837.989C85.2059 837.989 85.0056 837.764 85.0056 837.421C85.0056 837.004 84.9722 836.587 85.0306 836.178C85.1975 834.893 86.2323 834.008 87.5424 834C89.3616 834 91.1808 834 93 834Z"
               fill="white"
            />
            <path
               d="M93.0236 854.996C94.4673 854.996 95.9193 854.996 97.363 854.996C97.7302 854.996 97.9471 855.146 97.9805 855.43C98.0139 855.697 97.822 855.947 97.5466 855.98C97.4465 855.997 97.338 855.989 97.2378 855.989C94.4089 855.989 91.5716 855.989 88.7427 855.989C88.6426 855.989 88.5341 855.997 88.4339 855.98C88.1669 855.93 88 855.764 88 855.488C88 855.213 88.1669 855.046 88.4339 854.996C88.5257 854.979 88.6175 854.987 88.7177 854.987C90.153 854.996 91.5883 854.996 93.0236 854.996Z"
               fill="white"
            />
            <path
               d="M92.0256 858.993C93.1522 858.993 94.2704 858.993 95.397 858.993C95.7391 858.993 95.9477 859.152 95.9895 859.427C96.0312 859.736 95.7975 859.986 95.4387 859.995C94.8462 860.003 94.2537 859.995 93.6612 859.995C91.9922 859.995 90.3316 859.995 88.6626 859.995C88.5208 859.995 88.3288 859.995 88.2537 859.911C88.1369 859.769 88.0201 859.552 88.0368 859.385C88.0618 859.118 88.2954 859.002 88.5625 859.002C89.4721 859.002 90.3733 859.002 91.2829 859.002C91.5249 858.993 91.7753 858.993 92.0256 858.993Z"
               fill="white"
            />
            <path
               d="M90.4957 856.999C91.1299 856.999 91.7641 856.999 92.3983 856.999C92.7655 856.999 92.9908 857.199 92.9908 857.499C92.9908 857.8 92.7655 858 92.3983 858C91.1299 858 89.8615 858 88.5847 858C88.2175 858 87.9922 857.808 87.9922 857.499C87.9922 857.199 88.2175 857.007 88.5847 856.999C89.2272 856.99 89.8615 856.999 90.4957 856.999Z"
               fill="white"
            />
            <path
               d="M92.9822 837.004C92.5149 837.004 92.0476 837.004 91.5802 837.004C91.2214 837.004 90.9961 836.796 90.9961 836.495C91.0044 836.203 91.2214 836.011 91.5635 836.011C92.5149 836.011 93.4578 836.011 94.4092 836.011C94.768 836.011 94.9933 836.22 94.9933 836.52C94.985 836.812 94.768 837.004 94.4259 837.004C93.9419 837.004 93.4578 837.004 92.9822 837.004Z"
               fill="white"
            />
            <path
               d="M82.0003 855.438C82.0003 855.121 82.2256 854.896 82.5177 854.904C82.7847 854.912 83.0017 855.146 83.0017 855.413C82.9933 855.705 82.7513 855.955 82.4676 855.947C82.1755 855.93 81.9919 855.739 82.0003 855.438Z"
               fill="white"
            />
            <path
               d="M82 857.449C82 857.132 82.217 856.898 82.5007 856.898C82.7677 856.898 82.993 857.124 82.993 857.391C82.993 857.683 82.7594 857.933 82.4757 857.933C82.1836 857.933 82 857.741 82 857.449Z"
               fill="white"
            />
            <path
               d="M82.4673 859.936C82.1836 859.928 82 859.736 82 859.435C82 859.118 82.2253 858.884 82.509 858.893C82.7761 858.901 82.993 859.126 82.993 859.393C82.993 859.694 82.751 859.944 82.4673 859.936Z"
               fill="white"
            />
            <path
               d="M86.9951 842.003C88.372 842.003 89.4986 843.129 89.4986 844.506C89.4986 845.883 88.3637 847.001 86.9868 847.001C85.6266 846.993 84.5083 845.875 84.5 844.515C84.5 843.129 85.6182 842.003 86.9951 842.003ZM86.9868 843.004C86.169 843.012 85.5014 843.68 85.5014 844.498C85.5014 845.324 86.1857 846.008 87.0118 846C87.8296 845.992 88.4972 845.324 88.4972 844.506C88.4972 843.672 87.8213 842.996 86.9868 843.004Z"
               fill="white"
            />
         </g>
         <g clipPath="url(#clip4_226_1189)">
            <path
               d="M195.628 864C195.374 863.855 195.289 863.63 195.289 863.34C195.295 862.594 195.277 861.855 195.531 861.14C195.907 860.098 196.574 859.298 197.537 858.747C197.61 858.704 197.683 858.662 197.767 858.619C195.616 857.001 196.095 854.457 197.319 853.323C198.713 852.033 200.827 852.087 202.13 853.463C203.318 854.717 203.542 857.111 201.554 858.607C201.791 858.759 202.039 858.898 202.257 859.068C203.203 859.783 203.772 860.728 203.96 861.903C203.966 861.958 203.996 862.013 204.015 862.067C204.015 862.709 204.015 863.358 204.015 864C201.209 864 198.422 864 195.628 864ZM196.277 863C198.543 863 200.779 863 203.027 863C203.106 861.564 202.633 860.413 201.403 859.668C200.209 858.947 198.979 858.965 197.81 859.722C196.64 860.48 196.18 861.613 196.277 863ZM197.307 856.286C197.477 857.359 198.525 858.201 199.658 858.195C200.791 858.189 201.833 857.335 201.979 856.329C201.548 856.25 201.1 856.232 200.706 856.068C200.306 855.905 199.967 855.602 199.597 855.353C198.949 856.044 198.743 856.129 197.307 856.286ZM200.155 853.432C199.949 854.772 201.033 855.505 201.991 855.238C201.797 854.317 201.052 853.584 200.155 853.432ZM199.131 853.445C198.301 853.517 197.373 854.45 197.325 855.256C198.513 855.438 199.343 854.602 199.131 853.445Z"
               fill="white"
            />
            <path
               d="M174.358 864C174.085 863.873 174 863.655 174 863.358C174.006 862.594 173.982 861.837 174.254 861.104C174.667 859.995 175.406 859.177 176.496 858.613C175.388 857.783 174.854 856.711 175.006 855.341C175.109 854.475 175.515 853.754 176.181 853.184C177.533 852.027 179.587 852.16 180.817 853.445C181.938 854.608 182.332 857.032 180.259 858.607C180.514 858.771 180.774 858.922 181.005 859.104C181.992 859.886 182.574 860.904 182.683 862.17C182.713 862.558 182.695 862.952 182.719 863.339C182.732 863.63 182.635 863.848 182.38 864C179.708 864 177.03 864 174.358 864ZM181.738 863.012C181.823 861.504 181.308 860.322 179.993 859.595C178.744 858.904 177.484 859.001 176.333 859.849C175.279 860.625 174.891 861.716 174.988 863.012C177.248 863.012 179.478 863.012 181.738 863.012ZM176.012 856.256C176.212 857.413 177.308 858.256 178.484 858.195C179.581 858.134 180.629 857.232 180.69 856.256C179.756 856.335 178.969 856.038 178.357 855.287C177.745 856.044 176.957 856.323 176.012 856.256ZM177.854 853.432C176.957 853.572 176.139 854.39 176.024 855.256C177.151 855.468 178.036 854.65 177.854 853.432ZM178.872 853.438C178.666 854.747 179.72 855.493 180.696 855.238C180.574 854.384 179.726 853.541 178.872 853.438Z"
               fill="white"
            />
            <path
               d="M191.417 853.354C191.417 853.82 191.417 854.251 191.417 854.675C191.417 855.135 191.265 855.287 190.799 855.287C190.029 855.287 189.254 855.281 188.484 855.293C188.345 855.293 188.181 855.366 188.078 855.456C187.575 855.935 187.09 856.426 186.606 856.923C186.412 857.117 186.218 857.298 185.921 857.183C185.618 857.068 185.606 856.796 185.612 856.523C185.618 856.123 185.612 855.723 185.612 855.287C185.485 855.287 185.382 855.287 185.279 855.287C184.612 855.287 183.952 855.287 183.285 855.287C182.891 855.287 182.722 855.123 182.715 854.747C182.709 853.499 182.709 852.245 182.715 850.997C182.715 850.633 182.891 850.463 183.261 850.463C184.188 850.457 185.115 850.463 186.072 850.463C186.078 850.342 186.091 850.239 186.091 850.136C186.091 849.167 186.091 848.203 186.091 847.234C186.091 846.737 186.242 846.592 186.739 846.592C189.532 846.592 192.326 846.592 195.119 846.592C195.628 846.592 195.773 846.737 195.773 847.258C195.773 849.064 195.773 850.869 195.773 852.675C195.773 853.208 195.628 853.348 195.095 853.348C193.992 853.348 192.889 853.348 191.786 853.348C191.683 853.354 191.58 853.354 191.417 853.354ZM187.084 850.47C189.029 850.47 190.938 850.47 192.859 850.47C192.859 850.791 192.859 851.088 192.859 851.427C192.374 851.427 191.908 851.427 191.435 851.427C191.435 851.766 191.435 852.063 191.435 852.378C192.562 852.378 193.665 852.378 194.78 852.378C194.78 850.76 194.78 849.161 194.78 847.561C192.204 847.561 189.653 847.561 187.084 847.561C187.084 848.524 187.084 849.476 187.084 850.47ZM190.441 854.329C190.441 853.348 190.441 852.396 190.441 851.433C188.187 851.433 185.945 851.433 183.697 851.433C183.697 852.403 183.697 853.354 183.697 854.329C184.455 854.329 185.194 854.329 185.933 854.329C186.442 854.329 186.587 854.481 186.587 854.996C186.587 855.16 186.587 855.329 186.587 855.493C186.618 855.499 186.642 855.511 186.672 855.517C186.884 855.293 187.121 855.081 187.315 854.838C187.636 854.42 188.042 854.287 188.563 854.323C189.181 854.36 189.793 854.329 190.441 854.329Z"
               fill="white"
            />
            <path
               d="M190.864 840.223C191.785 840.689 192.457 841.356 192.912 842.247C193.396 843.192 193.39 844.204 193.324 845.222C193.318 845.355 193.087 845.489 192.942 845.598C192.881 845.64 192.772 845.61 192.681 845.61C190.233 845.61 187.785 845.61 185.331 845.61C184.78 845.61 184.653 845.476 184.647 844.919C184.641 844.149 184.628 843.374 184.919 842.641C185.343 841.568 186.071 840.774 187.131 840.235C186.071 839.441 185.519 838.411 185.628 837.09C185.707 836.163 186.125 835.394 186.834 834.794C188.173 833.655 190.203 833.764 191.427 835.042C192.154 835.806 192.475 836.721 192.36 837.769C192.251 838.799 191.724 839.605 190.864 840.223ZM192.372 844.634C192.506 843.144 191.821 841.829 190.597 841.174C189.391 840.532 187.907 840.677 186.864 841.544C185.901 842.35 185.537 843.398 185.628 844.634C187.894 844.634 190.124 844.634 192.372 844.634ZM186.664 837.86C186.773 838.981 187.973 839.884 189.203 839.793C190.258 839.72 191.348 838.726 191.312 837.86C190.391 837.939 189.609 837.642 188.997 836.89C188.397 837.648 187.616 837.939 186.664 837.86ZM186.67 836.878C188.052 837.078 188.706 835.945 188.482 835.054C187.664 835.121 186.755 836.03 186.67 836.878ZM189.506 835.06C189.318 836.333 190.342 837.108 191.336 836.854C191.227 835.993 190.318 835.097 189.506 835.06Z"
               fill="white"
            />
            <path
               d="M184.502 835.733C184.599 836.024 184.702 836.315 184.805 836.618C181.678 837.739 179.26 839.696 177.636 842.574C176.012 845.452 175.582 848.53 176.231 851.796C176.079 851.833 175.934 851.869 175.788 851.905C175.637 851.942 175.485 851.966 175.334 852.002C173.783 845.894 177.176 838.145 184.502 835.733Z"
               fill="white"
            />
            <path
               d="M201.779 851.796C202.433 848.524 202.003 845.446 200.379 842.568C198.749 839.696 196.338 837.739 193.211 836.618C193.259 836.454 193.308 836.309 193.356 836.163C193.405 836.024 193.453 835.891 193.52 835.709C196.495 836.751 198.889 838.545 200.634 841.156C202.839 844.458 203.482 848.082 202.724 852.008C202.397 851.936 202.1 851.869 201.779 851.796Z"
               fill="white"
            />
            <path
               d="M194.135 861.031C194.262 861.328 194.377 861.6 194.516 861.921C190.838 863.406 187.185 863.412 183.488 861.921C183.616 861.619 183.737 861.334 183.87 861.031C187.288 862.406 190.693 862.418 194.135 861.031Z"
               fill="white"
            />
            <path
               d="M188.055 849.464C188.055 849.149 188.055 848.852 188.055 848.537C189.988 848.537 191.902 848.537 193.829 848.537C193.829 848.852 193.829 849.149 193.829 849.464C191.902 849.464 189.988 849.464 188.055 849.464Z"
               fill="white"
            />
            <path
               d="M189.471 852.408C189.471 852.717 189.471 853.008 189.471 853.323C187.871 853.323 186.284 853.323 184.672 853.323C184.672 853.02 184.672 852.724 184.672 852.408C186.265 852.408 187.853 852.408 189.471 852.408Z"
               fill="white"
            />
         </g>
         <path
            d="M62.4102 894.434C63.5156 894.434 64.3223 894.65 64.8301 895.084C65.3418 895.514 65.5977 896.131 65.5977 896.936C65.5977 897.299 65.5371 897.645 65.416 897.973C65.2988 898.297 65.1074 898.584 64.8418 898.834C64.5762 899.08 64.2266 899.275 63.793 899.42C63.3633 899.561 62.8359 899.631 62.2109 899.631H61.168V903H60.1719V894.434H62.4102ZM62.3164 895.283H61.168V898.775H62.0996C62.6465 898.775 63.1016 898.717 63.4648 898.6C63.832 898.482 64.1074 898.293 64.291 898.031C64.4746 897.766 64.5664 897.414 64.5664 896.977C64.5664 896.406 64.3848 895.982 64.0215 895.705C63.6582 895.424 63.0898 895.283 62.3164 895.283ZM70.1621 896.461C70.291 896.461 70.4258 896.469 70.5664 896.484C70.707 896.496 70.832 896.514 70.9414 896.537L70.8184 897.439C70.7129 897.412 70.5957 897.391 70.4668 897.375C70.3379 897.359 70.2168 897.352 70.1035 897.352C69.8457 897.352 69.6016 897.404 69.3711 897.51C69.1445 897.611 68.9453 897.76 68.7734 897.955C68.6016 898.146 68.4668 898.379 68.3691 898.652C68.2715 898.922 68.2227 899.223 68.2227 899.555V903H67.2441V896.578H68.0527L68.1582 897.762H68.1992C68.332 897.523 68.4922 897.307 68.6797 897.111C68.8672 896.912 69.084 896.754 69.3301 896.637C69.5801 896.52 69.8574 896.461 70.1621 896.461ZM77.6914 899.777C77.6914 900.305 77.623 900.775 77.4863 901.189C77.3496 901.604 77.1523 901.953 76.8945 902.238C76.6367 902.523 76.3242 902.742 75.957 902.895C75.5938 903.043 75.1816 903.117 74.7207 903.117C74.291 903.117 73.8965 903.043 73.5371 902.895C73.1816 902.742 72.873 902.523 72.6113 902.238C72.3535 901.953 72.1523 901.604 72.0078 901.189C71.8672 900.775 71.7969 900.305 71.7969 899.777C71.7969 899.074 71.916 898.477 72.1543 897.984C72.3926 897.488 72.7324 897.111 73.1738 896.854C73.6191 896.592 74.1484 896.461 74.7617 896.461C75.3477 896.461 75.8594 896.592 76.2969 896.854C76.7383 897.115 77.0801 897.494 77.3223 897.99C77.5684 898.482 77.6914 899.078 77.6914 899.777ZM72.8047 899.777C72.8047 900.293 72.873 900.74 73.0098 901.119C73.1465 901.498 73.3574 901.791 73.6426 901.998C73.9277 902.205 74.2949 902.309 74.7441 902.309C75.1895 902.309 75.5547 902.205 75.8398 901.998C76.1289 901.791 76.3418 901.498 76.4785 901.119C76.6152 900.74 76.6836 900.293 76.6836 899.777C76.6836 899.266 76.6152 898.824 76.4785 898.453C76.3418 898.078 76.1309 897.789 75.8457 897.586C75.5605 897.383 75.1914 897.281 74.7383 897.281C74.0703 897.281 73.5801 897.502 73.2676 897.943C72.959 898.385 72.8047 898.996 72.8047 899.777ZM81.6582 903.117C80.8457 903.117 80.2012 902.84 79.7246 902.285C79.252 901.73 79.0156 900.906 79.0156 899.812C79.0156 898.707 79.2578 897.873 79.7422 897.311C80.2266 896.744 80.8711 896.461 81.6758 896.461C82.0156 896.461 82.3125 896.506 82.5664 896.596C82.8203 896.686 83.0391 896.807 83.2227 896.959C83.4062 897.107 83.5605 897.277 83.6855 897.469H83.7559C83.7402 897.348 83.7246 897.182 83.709 896.971C83.6934 896.76 83.6855 896.588 83.6855 896.455V893.883H84.6582V903H83.873L83.7266 902.086H83.6855C83.5645 902.277 83.4102 902.451 83.2227 902.607C83.0391 902.764 82.8184 902.889 82.5605 902.982C82.3066 903.072 82.0059 903.117 81.6582 903.117ZM81.8105 902.309C82.498 902.309 82.9844 902.113 83.2695 901.723C83.5547 901.332 83.6973 900.752 83.6973 899.982V899.807C83.6973 898.99 83.5605 898.363 83.2871 897.926C83.0176 897.488 82.5254 897.27 81.8105 897.27C81.2129 897.27 80.7656 897.5 80.4688 897.961C80.1719 898.418 80.0234 899.043 80.0234 899.836C80.0234 900.625 80.1699 901.234 80.4629 901.664C80.7598 902.094 81.209 902.309 81.8105 902.309ZM92.0234 896.578V903H91.2266L91.0859 902.098H91.0332C90.9004 902.32 90.7285 902.508 90.5176 902.66C90.3066 902.812 90.0684 902.926 89.8027 903C89.541 903.078 89.2617 903.117 88.9648 903.117C88.457 903.117 88.0312 903.035 87.6875 902.871C87.3438 902.707 87.084 902.453 86.9082 902.109C86.7363 901.766 86.6504 901.324 86.6504 900.785V896.578H87.6348V900.715C87.6348 901.25 87.7559 901.65 87.998 901.916C88.2402 902.178 88.6094 902.309 89.1055 902.309C89.582 902.309 89.9609 902.219 90.2422 902.039C90.5273 901.859 90.7324 901.596 90.8574 901.248C90.9824 900.896 91.0449 900.467 91.0449 899.959V896.578H92.0234ZM96.6523 903.117C96.0742 903.117 95.5645 902.998 95.123 902.76C94.6816 902.521 94.3379 902.158 94.0918 901.67C93.8457 901.182 93.7227 900.566 93.7227 899.824C93.7227 899.047 93.8516 898.412 94.1094 897.92C94.3711 897.424 94.7305 897.057 95.1875 896.818C95.6445 896.58 96.1641 896.461 96.7461 896.461C97.0664 896.461 97.375 896.494 97.6719 896.561C97.9727 896.623 98.2188 896.703 98.4102 896.801L98.1172 897.615C97.9219 897.537 97.6953 897.467 97.4375 897.404C97.1836 897.342 96.9453 897.311 96.7227 897.311C96.2773 897.311 95.9062 897.406 95.6094 897.598C95.3164 897.789 95.0957 898.07 94.9473 898.441C94.8027 898.812 94.7305 899.27 94.7305 899.812C94.7305 900.332 94.8008 900.775 94.9414 901.143C95.0859 901.51 95.2988 901.791 95.5801 901.986C95.8652 902.178 96.2207 902.273 96.6465 902.273C96.9863 902.273 97.293 902.238 97.5664 902.168C97.8398 902.094 98.0879 902.008 98.3105 901.91V902.777C98.0957 902.887 97.8555 902.971 97.5898 903.029C97.3281 903.088 97.0156 903.117 96.6523 903.117ZM101.908 902.32C102.068 902.32 102.232 902.307 102.4 902.279C102.568 902.252 102.705 902.219 102.811 902.18V902.936C102.697 902.986 102.539 903.029 102.336 903.064C102.137 903.1 101.941 903.117 101.75 903.117C101.41 903.117 101.102 903.059 100.824 902.941C100.547 902.82 100.324 902.617 100.156 902.332C99.9922 902.047 99.9102 901.652 99.9102 901.148V897.34H98.9961V896.865L99.916 896.484L100.303 895.09H100.889V896.578H102.77V897.34H100.889V901.119C100.889 901.521 100.98 901.822 101.164 902.021C101.352 902.221 101.6 902.32 101.908 902.32ZM66.9746 917.635C66.9746 918.6 66.7988 919.406 66.4473 920.055C66.0957 920.699 65.5859 921.186 64.918 921.514C64.2539 921.838 63.4473 922 62.498 922H60.1719V913.434H62.7559C63.627 913.434 64.377 913.594 65.0059 913.914C65.6348 914.23 66.1191 914.701 66.459 915.326C66.8027 915.947 66.9746 916.717 66.9746 917.635ZM65.9258 917.67C65.9258 916.9 65.7969 916.266 65.5391 915.766C65.2852 915.266 64.9102 914.895 64.4141 914.652C63.9219 914.406 63.3184 914.283 62.6035 914.283H61.168V921.145H62.3809C63.5605 921.145 64.4453 920.854 65.0352 920.271C65.6289 919.689 65.9258 918.822 65.9258 917.67ZM71.2051 915.461C71.752 915.461 72.2207 915.582 72.6113 915.824C73.002 916.066 73.3008 916.406 73.5078 916.844C73.7148 917.277 73.8184 917.785 73.8184 918.367V918.971H69.3828C69.3945 919.725 69.582 920.299 69.9453 920.693C70.3086 921.088 70.8203 921.285 71.4805 921.285C71.8867 921.285 72.2461 921.248 72.5586 921.174C72.8711 921.1 73.1953 920.99 73.5312 920.846V921.701C73.207 921.846 72.8848 921.951 72.5645 922.018C72.248 922.084 71.873 922.117 71.4395 922.117C70.8223 922.117 70.2832 921.992 69.8223 921.742C69.3652 921.488 69.0098 921.117 68.7559 920.629C68.502 920.141 68.375 919.543 68.375 918.836C68.375 918.145 68.4902 917.547 68.7207 917.043C68.9551 916.535 69.2832 916.145 69.7051 915.871C70.1309 915.598 70.6309 915.461 71.2051 915.461ZM71.1934 916.258C70.6738 916.258 70.2598 916.428 69.9512 916.768C69.6426 917.107 69.459 917.582 69.4004 918.191H72.7988C72.7949 917.809 72.7344 917.473 72.6172 917.184C72.5039 916.891 72.3301 916.664 72.0957 916.504C71.8613 916.34 71.5605 916.258 71.1934 916.258ZM82.4434 915.461C83.1504 915.461 83.6836 915.646 84.043 916.018C84.4023 916.385 84.582 916.977 84.582 917.793V922H83.6211V917.84C83.6211 917.32 83.5078 916.932 83.2812 916.674C83.0586 916.412 82.7266 916.281 82.2852 916.281C81.6641 916.281 81.2129 916.461 80.9316 916.82C80.6504 917.18 80.5098 917.709 80.5098 918.408V922H79.543V917.84C79.543 917.492 79.4922 917.203 79.3906 916.973C79.293 916.742 79.1445 916.57 78.9453 916.457C78.75 916.34 78.502 916.281 78.2012 916.281C77.7754 916.281 77.4336 916.369 77.1758 916.545C76.918 916.721 76.7305 916.982 76.6133 917.33C76.5 917.674 76.4434 918.098 76.4434 918.602V922H75.4707V915.578H76.2559L76.4023 916.486H76.4551C76.584 916.264 76.7461 916.076 76.9414 915.924C77.1367 915.771 77.3555 915.656 77.5977 915.578C77.8398 915.5 78.0977 915.461 78.3711 915.461C78.8594 915.461 79.2676 915.553 79.5957 915.736C79.9277 915.916 80.168 916.191 80.3164 916.562H80.3691C80.5801 916.191 80.8691 915.916 81.2363 915.736C81.6035 915.553 82.0059 915.461 82.4434 915.461ZM92.1172 918.777C92.1172 919.305 92.0488 919.775 91.9121 920.189C91.7754 920.604 91.5781 920.953 91.3203 921.238C91.0625 921.523 90.75 921.742 90.3828 921.895C90.0195 922.043 89.6074 922.117 89.1465 922.117C88.7168 922.117 88.3223 922.043 87.9629 921.895C87.6074 921.742 87.2988 921.523 87.0371 921.238C86.7793 920.953 86.5781 920.604 86.4336 920.189C86.293 919.775 86.2227 919.305 86.2227 918.777C86.2227 918.074 86.3418 917.477 86.5801 916.984C86.8184 916.488 87.1582 916.111 87.5996 915.854C88.0449 915.592 88.5742 915.461 89.1875 915.461C89.7734 915.461 90.2852 915.592 90.7227 915.854C91.1641 916.115 91.5059 916.494 91.748 916.99C91.9941 917.482 92.1172 918.078 92.1172 918.777ZM87.2305 918.777C87.2305 919.293 87.2988 919.74 87.4355 920.119C87.5723 920.498 87.7832 920.791 88.0684 920.998C88.3535 921.205 88.7207 921.309 89.1699 921.309C89.6152 921.309 89.9805 921.205 90.2656 920.998C90.5547 920.791 90.7676 920.498 90.9043 920.119C91.041 919.74 91.1094 919.293 91.1094 918.777C91.1094 918.266 91.041 917.824 90.9043 917.453C90.7676 917.078 90.5566 916.789 90.2715 916.586C89.9863 916.383 89.6172 916.281 89.1641 916.281C88.4961 916.281 88.0059 916.502 87.6934 916.943C87.3848 917.385 87.2305 917.996 87.2305 918.777ZM106.795 913.434L104.504 922H103.502L101.803 916.234C101.752 916.07 101.703 915.906 101.656 915.742C101.613 915.574 101.572 915.416 101.533 915.268C101.494 915.115 101.461 914.982 101.434 914.869C101.41 914.752 101.393 914.664 101.381 914.605C101.373 914.664 101.357 914.75 101.334 914.863C101.314 914.977 101.287 915.107 101.252 915.256C101.221 915.404 101.182 915.562 101.135 915.73C101.092 915.898 101.045 916.068 100.994 916.24L99.3418 922H98.3398L96.0664 913.434H97.1035L98.4805 918.807C98.5273 918.986 98.5703 919.164 98.6094 919.34C98.6523 919.512 98.6895 919.68 98.7207 919.844C98.7559 920.008 98.7871 920.168 98.8145 920.324C98.8418 920.48 98.8672 920.633 98.8906 920.781C98.9102 920.629 98.9355 920.471 98.9668 920.307C98.998 920.139 99.0312 919.969 99.0664 919.797C99.1055 919.625 99.1465 919.451 99.1895 919.275C99.2363 919.1 99.2852 918.924 99.3359 918.748L100.877 913.434H101.902L103.508 918.789C103.562 918.973 103.613 919.154 103.66 919.334C103.707 919.514 103.748 919.689 103.783 919.861C103.822 920.029 103.855 920.191 103.883 920.348C103.914 920.5 103.941 920.645 103.965 920.781C103.992 920.59 104.025 920.389 104.064 920.178C104.104 919.967 104.148 919.746 104.199 919.516C104.254 919.285 104.312 919.047 104.375 918.801L105.752 913.434H106.795ZM108.975 915.578V922H108.002V915.578H108.975ZM108.5 913.176C108.66 913.176 108.797 913.229 108.91 913.334C109.027 913.436 109.086 913.596 109.086 913.814C109.086 914.029 109.027 914.189 108.91 914.295C108.797 914.4 108.66 914.453 108.5 914.453C108.332 914.453 108.191 914.4 108.078 914.295C107.969 914.189 107.914 914.029 107.914 913.814C107.914 913.596 107.969 913.436 108.078 913.334C108.191 913.229 108.332 913.176 108.5 913.176ZM113.111 921.32C113.271 921.32 113.436 921.307 113.604 921.279C113.771 921.252 113.908 921.219 114.014 921.18V921.936C113.9 921.986 113.742 922.029 113.539 922.064C113.34 922.1 113.145 922.117 112.953 922.117C112.613 922.117 112.305 922.059 112.027 921.941C111.75 921.82 111.527 921.617 111.359 921.332C111.195 921.047 111.113 920.652 111.113 920.148V916.34H110.199V915.865L111.119 915.484L111.506 914.09H112.092V915.578H113.973V916.34H112.092V920.119C112.092 920.521 112.184 920.822 112.367 921.021C112.555 921.221 112.803 921.32 113.111 921.32ZM116.287 912.883V915.607C116.287 915.764 116.283 915.922 116.275 916.082C116.268 916.238 116.254 916.383 116.234 916.516H116.299C116.432 916.289 116.6 916.1 116.803 915.947C117.01 915.791 117.244 915.674 117.506 915.596C117.768 915.514 118.045 915.473 118.338 915.473C118.854 915.473 119.283 915.555 119.627 915.719C119.975 915.883 120.234 916.137 120.406 916.48C120.582 916.824 120.67 917.27 120.67 917.816V922H119.709V917.881C119.709 917.346 119.586 916.945 119.34 916.68C119.098 916.414 118.725 916.281 118.221 916.281C117.744 916.281 117.363 916.373 117.078 916.557C116.797 916.736 116.594 917.002 116.469 917.354C116.348 917.705 116.287 918.135 116.287 918.643V922H115.314V912.883H116.287ZM65.0059 938.721C65.0059 939.229 64.8789 939.662 64.625 940.021C64.375 940.377 64.0234 940.648 63.5703 940.836C63.1172 941.023 62.584 941.117 61.9707 941.117C61.6465 941.117 61.3398 941.102 61.0508 941.07C60.7617 941.039 60.4961 940.994 60.2539 940.936C60.0117 940.877 59.7988 940.805 59.6152 940.719V939.764C59.9082 939.885 60.2656 939.998 60.6875 940.104C61.1094 940.205 61.5508 940.256 62.0117 940.256C62.4414 940.256 62.8047 940.199 63.1016 940.086C63.3984 939.969 63.623 939.803 63.7754 939.588C63.9316 939.369 64.0098 939.107 64.0098 938.803C64.0098 938.51 63.9453 938.266 63.8164 938.07C63.6875 937.871 63.4727 937.691 63.1719 937.531C62.875 937.367 62.4688 937.193 61.9531 937.01C61.5898 936.881 61.2695 936.74 60.9922 936.588C60.7148 936.432 60.4824 936.256 60.2949 936.061C60.1074 935.865 59.9648 935.639 59.8672 935.381C59.7734 935.123 59.7266 934.828 59.7266 934.496C59.7266 934.039 59.8418 933.648 60.0723 933.324C60.3066 932.996 60.6289 932.746 61.0391 932.574C61.4531 932.398 61.9277 932.311 62.4629 932.311C62.9199 932.311 63.3418 932.354 63.7285 932.439C64.1191 932.525 64.4766 932.641 64.8008 932.785L64.4902 933.641C64.1816 933.512 63.8535 933.404 63.5059 933.318C63.1621 933.232 62.8066 933.189 62.4395 933.189C62.0723 933.189 61.7617 933.244 61.5078 933.354C61.2578 933.459 61.0664 933.609 60.9336 933.805C60.8008 934 60.7344 934.232 60.7344 934.502C60.7344 934.803 60.7969 935.053 60.9219 935.252C61.0508 935.451 61.2539 935.629 61.5312 935.785C61.8125 935.938 62.1836 936.098 62.6445 936.266C63.1484 936.449 63.5762 936.645 63.9277 936.852C64.2793 937.055 64.5469 937.305 64.7305 937.602C64.9141 937.895 65.0059 938.268 65.0059 938.721ZM68.6855 940.32C68.8457 940.32 69.0098 940.307 69.1777 940.279C69.3457 940.252 69.4824 940.219 69.5879 940.18V940.936C69.4746 940.986 69.3164 941.029 69.1133 941.064C68.9141 941.1 68.7188 941.117 68.5273 941.117C68.1875 941.117 67.8789 941.059 67.6016 940.941C67.3242 940.82 67.1016 940.617 66.9336 940.332C66.7695 940.047 66.6875 939.652 66.6875 939.148V935.34H65.7734V934.865L66.6934 934.484L67.0801 933.09H67.666V934.578H69.5469V935.34H67.666V939.119C67.666 939.521 67.7578 939.822 67.9414 940.021C68.1289 940.221 68.377 940.32 68.6855 940.32ZM73.291 934.473C74.0566 934.473 74.625 934.645 74.9961 934.988C75.3672 935.332 75.5527 935.881 75.5527 936.635V941H74.8438L74.6562 940.051H74.6094C74.4297 940.285 74.2422 940.482 74.0469 940.643C73.8516 940.799 73.625 940.918 73.3672 941C73.1133 941.078 72.8008 941.117 72.4297 941.117C72.0391 941.117 71.6914 941.049 71.3867 940.912C71.0859 940.775 70.8477 940.568 70.6719 940.291C70.5 940.014 70.4141 939.662 70.4141 939.236C70.4141 938.596 70.668 938.104 71.1758 937.76C71.6836 937.416 72.457 937.229 73.4961 937.197L74.6035 937.15V936.758C74.6035 936.203 74.4844 935.814 74.2461 935.592C74.0078 935.369 73.6719 935.258 73.2383 935.258C72.9023 935.258 72.582 935.307 72.2773 935.404C71.9727 935.502 71.6836 935.617 71.4102 935.75L71.1113 935.012C71.4004 934.863 71.7324 934.736 72.1074 934.631C72.4824 934.525 72.877 934.473 73.291 934.473ZM74.5918 937.836L73.6133 937.877C72.8125 937.908 72.248 938.039 71.9199 938.27C71.5918 938.5 71.4277 938.826 71.4277 939.248C71.4277 939.615 71.5391 939.887 71.7617 940.062C71.9844 940.238 72.2793 940.326 72.6465 940.326C73.2168 940.326 73.6836 940.168 74.0469 939.852C74.4102 939.535 74.5918 939.061 74.5918 938.428V937.836ZM78.5234 931.883V936.617C78.5234 936.773 78.5176 936.965 78.5059 937.191C78.4941 937.414 78.4844 937.611 78.4766 937.783H78.5176C78.5996 937.682 78.7188 937.531 78.875 937.332C79.0352 937.133 79.1699 936.973 79.2793 936.852L81.4121 934.578H82.5547L79.9707 937.32L82.7422 941H81.5703L79.3027 937.959L78.5234 938.674V941H77.5566V931.883H78.5234ZM86.334 934.461C86.8809 934.461 87.3496 934.582 87.7402 934.824C88.1309 935.066 88.4297 935.406 88.6367 935.844C88.8438 936.277 88.9473 936.785 88.9473 937.367V937.971H84.5117C84.5234 938.725 84.7109 939.299 85.0742 939.693C85.4375 940.088 85.9492 940.285 86.6094 940.285C87.0156 940.285 87.375 940.248 87.6875 940.174C88 940.1 88.3242 939.99 88.6602 939.846V940.701C88.3359 940.846 88.0137 940.951 87.6934 941.018C87.377 941.084 87.002 941.117 86.5684 941.117C85.9512 941.117 85.4121 940.992 84.9512 940.742C84.4941 940.488 84.1387 940.117 83.8848 939.629C83.6309 939.141 83.5039 938.543 83.5039 937.836C83.5039 937.145 83.6191 936.547 83.8496 936.043C84.084 935.535 84.4121 935.145 84.834 934.871C85.2598 934.598 85.7598 934.461 86.334 934.461ZM86.3223 935.258C85.8027 935.258 85.3887 935.428 85.0801 935.768C84.7715 936.107 84.5879 936.582 84.5293 937.191H87.9277C87.9238 936.809 87.8633 936.473 87.7461 936.184C87.6328 935.891 87.459 935.664 87.2246 935.504C86.9902 935.34 86.6895 935.258 86.3223 935.258ZM91.5723 931.883V934.607C91.5723 934.764 91.5684 934.922 91.5605 935.082C91.5527 935.238 91.5391 935.383 91.5195 935.516H91.584C91.7168 935.289 91.8848 935.1 92.0879 934.947C92.2949 934.791 92.5293 934.674 92.791 934.596C93.0527 934.514 93.3301 934.473 93.623 934.473C94.1387 934.473 94.5684 934.555 94.9121 934.719C95.2598 934.883 95.5195 935.137 95.6914 935.48C95.8672 935.824 95.9551 936.27 95.9551 936.816V941H94.9941V936.881C94.9941 936.346 94.8711 935.945 94.625 935.68C94.3828 935.414 94.0098 935.281 93.5059 935.281C93.0293 935.281 92.6484 935.373 92.3633 935.557C92.082 935.736 91.8789 936.002 91.7539 936.354C91.6328 936.705 91.5723 937.135 91.5723 937.643V941H90.5996V931.883H91.5723ZM103.496 937.777C103.496 938.305 103.428 938.775 103.291 939.189C103.154 939.604 102.957 939.953 102.699 940.238C102.441 940.523 102.129 940.742 101.762 940.895C101.398 941.043 100.986 941.117 100.525 941.117C100.096 941.117 99.7012 941.043 99.3418 940.895C98.9863 940.742 98.6777 940.523 98.416 940.238C98.1582 939.953 97.957 939.604 97.8125 939.189C97.6719 938.775 97.6016 938.305 97.6016 937.777C97.6016 937.074 97.7207 936.477 97.959 935.984C98.1973 935.488 98.5371 935.111 98.9785 934.854C99.4238 934.592 99.9531 934.461 100.566 934.461C101.152 934.461 101.664 934.592 102.102 934.854C102.543 935.115 102.885 935.494 103.127 935.99C103.373 936.482 103.496 937.078 103.496 937.777ZM98.6094 937.777C98.6094 938.293 98.6777 938.74 98.8145 939.119C98.9512 939.498 99.1621 939.791 99.4473 939.998C99.7324 940.205 100.1 940.309 100.549 940.309C100.994 940.309 101.359 940.205 101.645 939.998C101.934 939.791 102.146 939.498 102.283 939.119C102.42 938.74 102.488 938.293 102.488 937.777C102.488 937.266 102.42 936.824 102.283 936.453C102.146 936.078 101.936 935.789 101.65 935.586C101.365 935.383 100.996 935.281 100.543 935.281C99.875 935.281 99.3848 935.502 99.0723 935.943C98.7637 936.385 98.6094 936.996 98.6094 937.777ZM106.156 941H105.178V931.883H106.156V941ZM110.498 941.117C109.686 941.117 109.041 940.84 108.564 940.285C108.092 939.73 107.855 938.906 107.855 937.812C107.855 936.707 108.098 935.873 108.582 935.311C109.066 934.744 109.711 934.461 110.516 934.461C110.855 934.461 111.152 934.506 111.406 934.596C111.66 934.686 111.879 934.807 112.062 934.959C112.246 935.107 112.4 935.277 112.525 935.469H112.596C112.58 935.348 112.564 935.182 112.549 934.971C112.533 934.76 112.525 934.588 112.525 934.455V931.883H113.498V941H112.713L112.566 940.086H112.525C112.404 940.277 112.25 940.451 112.062 940.607C111.879 940.764 111.658 940.889 111.4 940.982C111.146 941.072 110.846 941.117 110.498 941.117ZM110.65 940.309C111.338 940.309 111.824 940.113 112.109 939.723C112.395 939.332 112.537 938.752 112.537 937.982V937.807C112.537 936.99 112.4 936.363 112.127 935.926C111.857 935.488 111.365 935.27 110.65 935.27C110.053 935.27 109.605 935.5 109.309 935.961C109.012 936.418 108.863 937.043 108.863 937.836C108.863 938.625 109.01 939.234 109.303 939.664C109.6 940.094 110.049 940.309 110.65 940.309ZM118.033 934.461C118.58 934.461 119.049 934.582 119.439 934.824C119.83 935.066 120.129 935.406 120.336 935.844C120.543 936.277 120.646 936.785 120.646 937.367V937.971H116.211C116.223 938.725 116.41 939.299 116.773 939.693C117.137 940.088 117.648 940.285 118.309 940.285C118.715 940.285 119.074 940.248 119.387 940.174C119.699 940.1 120.023 939.99 120.359 939.846V940.701C120.035 940.846 119.713 940.951 119.393 941.018C119.076 941.084 118.701 941.117 118.268 941.117C117.65 941.117 117.111 940.992 116.65 940.742C116.193 940.488 115.838 940.117 115.584 939.629C115.33 939.141 115.203 938.543 115.203 937.836C115.203 937.145 115.318 936.547 115.549 936.043C115.783 935.535 116.111 935.145 116.533 934.871C116.959 934.598 117.459 934.461 118.033 934.461ZM118.021 935.258C117.502 935.258 117.088 935.428 116.779 935.768C116.471 936.107 116.287 936.582 116.229 937.191H119.627C119.623 936.809 119.562 936.473 119.445 936.184C119.332 935.891 119.158 935.664 118.924 935.504C118.689 935.34 118.389 935.258 118.021 935.258ZM125.217 934.461C125.346 934.461 125.48 934.469 125.621 934.484C125.762 934.496 125.887 934.514 125.996 934.537L125.873 935.439C125.768 935.412 125.65 935.391 125.521 935.375C125.393 935.359 125.271 935.352 125.158 935.352C124.9 935.352 124.656 935.404 124.426 935.51C124.199 935.611 124 935.76 123.828 935.955C123.656 936.146 123.521 936.379 123.424 936.652C123.326 936.922 123.277 937.223 123.277 937.555V941H122.299V934.578H123.107L123.213 935.762H123.254C123.387 935.523 123.547 935.307 123.734 935.111C123.922 934.912 124.139 934.754 124.385 934.637C124.635 934.52 124.912 934.461 125.217 934.461ZM131.363 939.242C131.363 939.652 131.26 939.998 131.053 940.279C130.85 940.557 130.557 940.766 130.174 940.906C129.795 941.047 129.342 941.117 128.814 941.117C128.365 941.117 127.977 941.082 127.648 941.012C127.32 940.941 127.033 940.842 126.787 940.713V939.816C127.049 939.945 127.361 940.062 127.725 940.168C128.088 940.273 128.459 940.326 128.838 940.326C129.393 940.326 129.795 940.236 130.045 940.057C130.295 939.877 130.42 939.633 130.42 939.324C130.42 939.148 130.369 938.994 130.268 938.861C130.17 938.725 130.004 938.594 129.77 938.469C129.535 938.34 129.211 938.199 128.797 938.047C128.387 937.891 128.031 937.736 127.73 937.584C127.434 937.428 127.203 937.238 127.039 937.016C126.879 936.793 126.799 936.504 126.799 936.148C126.799 935.605 127.018 935.189 127.455 934.9C127.896 934.607 128.475 934.461 129.189 934.461C129.576 934.461 129.938 934.5 130.273 934.578C130.613 934.652 130.93 934.754 131.223 934.883L130.895 935.662C130.629 935.549 130.346 935.453 130.045 935.375C129.744 935.297 129.438 935.258 129.125 935.258C128.676 935.258 128.33 935.332 128.088 935.48C127.85 935.629 127.73 935.832 127.73 936.09C127.73 936.289 127.785 936.453 127.895 936.582C128.008 936.711 128.188 936.832 128.434 936.945C128.68 937.059 129.004 937.191 129.406 937.344C129.809 937.492 130.156 937.646 130.449 937.807C130.742 937.963 130.967 938.154 131.123 938.381C131.283 938.604 131.363 938.891 131.363 939.242Z"
            fill="white"
         />
         <path
            d="M158.172 894.434H160.598C161.668 894.434 162.473 894.594 163.012 894.914C163.551 895.234 163.82 895.779 163.82 896.549C163.82 896.881 163.756 897.18 163.627 897.445C163.502 897.707 163.318 897.924 163.076 898.096C162.834 898.268 162.535 898.387 162.18 898.453V898.512C162.555 898.57 162.887 898.678 163.176 898.834C163.465 898.99 163.691 899.209 163.855 899.49C164.02 899.771 164.102 900.129 164.102 900.562C164.102 901.09 163.979 901.535 163.732 901.898C163.49 902.262 163.146 902.537 162.701 902.725C162.256 902.908 161.729 903 161.119 903H158.172V894.434ZM159.168 898.107H160.809C161.555 898.107 162.07 897.984 162.355 897.738C162.645 897.492 162.789 897.133 162.789 896.66C162.789 896.172 162.617 895.82 162.273 895.605C161.934 895.391 161.391 895.283 160.645 895.283H159.168V898.107ZM159.168 898.945V902.15H160.949C161.711 902.15 162.25 902.002 162.566 901.705C162.883 901.404 163.041 901 163.041 900.492C163.041 900.168 162.969 899.891 162.824 899.66C162.684 899.43 162.453 899.254 162.133 899.133C161.816 899.008 161.393 898.945 160.861 898.945H159.168ZM171.086 896.578V903H170.289L170.148 902.098H170.096C169.963 902.32 169.791 902.508 169.58 902.66C169.369 902.812 169.131 902.926 168.865 903C168.604 903.078 168.324 903.117 168.027 903.117C167.52 903.117 167.094 903.035 166.75 902.871C166.406 902.707 166.146 902.453 165.971 902.109C165.799 901.766 165.713 901.324 165.713 900.785V896.578H166.697V900.715C166.697 901.25 166.818 901.65 167.061 901.916C167.303 902.178 167.672 902.309 168.168 902.309C168.645 902.309 169.023 902.219 169.305 902.039C169.59 901.859 169.795 901.596 169.92 901.248C170.045 900.896 170.107 900.467 170.107 899.959V896.578H171.086ZM174.115 896.578V903H173.143V896.578H174.115ZM173.641 894.176C173.801 894.176 173.938 894.229 174.051 894.334C174.168 894.436 174.227 894.596 174.227 894.814C174.227 895.029 174.168 895.189 174.051 895.295C173.938 895.4 173.801 895.453 173.641 895.453C173.473 895.453 173.332 895.4 173.219 895.295C173.109 895.189 173.055 895.029 173.055 894.814C173.055 894.596 173.109 894.436 173.219 894.334C173.332 894.229 173.473 894.176 173.641 894.176ZM177.156 903H176.178V893.883H177.156V903ZM181.498 903.117C180.686 903.117 180.041 902.84 179.564 902.285C179.092 901.73 178.855 900.906 178.855 899.812C178.855 898.707 179.098 897.873 179.582 897.311C180.066 896.744 180.711 896.461 181.516 896.461C181.855 896.461 182.152 896.506 182.406 896.596C182.66 896.686 182.879 896.807 183.062 896.959C183.246 897.107 183.4 897.277 183.525 897.469H183.596C183.58 897.348 183.564 897.182 183.549 896.971C183.533 896.76 183.525 896.588 183.525 896.455V893.883H184.498V903H183.713L183.566 902.086H183.525C183.404 902.277 183.25 902.451 183.062 902.607C182.879 902.764 182.658 902.889 182.4 902.982C182.146 903.072 181.846 903.117 181.498 903.117ZM181.65 902.309C182.338 902.309 182.824 902.113 183.109 901.723C183.395 901.332 183.537 900.752 183.537 899.982V899.807C183.537 898.99 183.4 898.363 183.127 897.926C182.857 897.488 182.365 897.27 181.65 897.27C181.053 897.27 180.605 897.5 180.309 897.961C180.012 898.418 179.863 899.043 179.863 899.836C179.863 900.625 180.01 901.234 180.303 901.664C180.6 902.094 181.049 902.309 181.65 902.309ZM190.65 896.578V903H189.678V896.578H190.65ZM190.176 894.176C190.336 894.176 190.473 894.229 190.586 894.334C190.703 894.436 190.762 894.596 190.762 894.814C190.762 895.029 190.703 895.189 190.586 895.295C190.473 895.4 190.336 895.453 190.176 895.453C190.008 895.453 189.867 895.4 189.754 895.295C189.645 895.189 189.59 895.029 189.59 894.814C189.59 894.596 189.645 894.436 189.754 894.334C189.867 894.229 190.008 894.176 190.176 894.176ZM196.867 901.242C196.867 901.652 196.764 901.998 196.557 902.279C196.354 902.557 196.061 902.766 195.678 902.906C195.299 903.047 194.846 903.117 194.318 903.117C193.869 903.117 193.48 903.082 193.152 903.012C192.824 902.941 192.537 902.842 192.291 902.713V901.816C192.553 901.945 192.865 902.062 193.229 902.168C193.592 902.273 193.963 902.326 194.342 902.326C194.896 902.326 195.299 902.236 195.549 902.057C195.799 901.877 195.924 901.633 195.924 901.324C195.924 901.148 195.873 900.994 195.771 900.861C195.674 900.725 195.508 900.594 195.273 900.469C195.039 900.34 194.715 900.199 194.301 900.047C193.891 899.891 193.535 899.736 193.234 899.584C192.938 899.428 192.707 899.238 192.543 899.016C192.383 898.793 192.303 898.504 192.303 898.148C192.303 897.605 192.521 897.189 192.959 896.9C193.4 896.607 193.979 896.461 194.693 896.461C195.08 896.461 195.441 896.5 195.777 896.578C196.117 896.652 196.434 896.754 196.727 896.883L196.398 897.662C196.133 897.549 195.85 897.453 195.549 897.375C195.248 897.297 194.941 897.258 194.629 897.258C194.18 897.258 193.834 897.332 193.592 897.48C193.354 897.629 193.234 897.832 193.234 898.09C193.234 898.289 193.289 898.453 193.398 898.582C193.512 898.711 193.691 898.832 193.938 898.945C194.184 899.059 194.508 899.191 194.91 899.344C195.312 899.492 195.66 899.646 195.953 899.807C196.246 899.963 196.471 900.154 196.627 900.381C196.787 900.604 196.867 900.891 196.867 901.242ZM206.529 900.721C206.529 901.229 206.402 901.662 206.148 902.021C205.898 902.377 205.547 902.648 205.094 902.836C204.641 903.023 204.107 903.117 203.494 903.117C203.17 903.117 202.863 903.102 202.574 903.07C202.285 903.039 202.02 902.994 201.777 902.936C201.535 902.877 201.322 902.805 201.139 902.719V901.764C201.432 901.885 201.789 901.998 202.211 902.104C202.633 902.205 203.074 902.256 203.535 902.256C203.965 902.256 204.328 902.199 204.625 902.086C204.922 901.969 205.146 901.803 205.299 901.588C205.455 901.369 205.533 901.107 205.533 900.803C205.533 900.51 205.469 900.266 205.34 900.07C205.211 899.871 204.996 899.691 204.695 899.531C204.398 899.367 203.992 899.193 203.477 899.01C203.113 898.881 202.793 898.74 202.516 898.588C202.238 898.432 202.006 898.256 201.818 898.061C201.631 897.865 201.488 897.639 201.391 897.381C201.297 897.123 201.25 896.828 201.25 896.496C201.25 896.039 201.365 895.648 201.596 895.324C201.83 894.996 202.152 894.746 202.562 894.574C202.977 894.398 203.451 894.311 203.986 894.311C204.443 894.311 204.865 894.354 205.252 894.439C205.643 894.525 206 894.641 206.324 894.785L206.014 895.641C205.705 895.512 205.377 895.404 205.029 895.318C204.686 895.232 204.33 895.189 203.963 895.189C203.596 895.189 203.285 895.244 203.031 895.354C202.781 895.459 202.59 895.609 202.457 895.805C202.324 896 202.258 896.232 202.258 896.502C202.258 896.803 202.32 897.053 202.445 897.252C202.574 897.451 202.777 897.629 203.055 897.785C203.336 897.938 203.707 898.098 204.168 898.266C204.672 898.449 205.1 898.645 205.451 898.852C205.803 899.055 206.07 899.305 206.254 899.602C206.438 899.895 206.529 900.268 206.529 900.721ZM209.107 893.883V896.607C209.107 896.764 209.104 896.922 209.096 897.082C209.088 897.238 209.074 897.383 209.055 897.516H209.119C209.252 897.289 209.42 897.1 209.623 896.947C209.83 896.791 210.064 896.674 210.326 896.596C210.588 896.514 210.865 896.473 211.158 896.473C211.674 896.473 212.104 896.555 212.447 896.719C212.795 896.883 213.055 897.137 213.227 897.48C213.402 897.824 213.49 898.27 213.49 898.816V903H212.529V898.881C212.529 898.346 212.406 897.945 212.16 897.68C211.918 897.414 211.545 897.281 211.041 897.281C210.564 897.281 210.184 897.373 209.898 897.557C209.617 897.736 209.414 898.002 209.289 898.354C209.168 898.705 209.107 899.135 209.107 899.643V903H208.135V893.883H209.107ZM217.896 896.473C218.662 896.473 219.23 896.645 219.602 896.988C219.973 897.332 220.158 897.881 220.158 898.635V903H219.449L219.262 902.051H219.215C219.035 902.285 218.848 902.482 218.652 902.643C218.457 902.799 218.23 902.918 217.973 903C217.719 903.078 217.406 903.117 217.035 903.117C216.645 903.117 216.297 903.049 215.992 902.912C215.691 902.775 215.453 902.568 215.277 902.291C215.105 902.014 215.02 901.662 215.02 901.236C215.02 900.596 215.273 900.104 215.781 899.76C216.289 899.416 217.062 899.229 218.102 899.197L219.209 899.15V898.758C219.209 898.203 219.09 897.814 218.852 897.592C218.613 897.369 218.277 897.258 217.844 897.258C217.508 897.258 217.188 897.307 216.883 897.404C216.578 897.502 216.289 897.617 216.016 897.75L215.717 897.012C216.006 896.863 216.338 896.736 216.713 896.631C217.088 896.525 217.482 896.473 217.896 896.473ZM219.197 899.836L218.219 899.877C217.418 899.908 216.854 900.039 216.525 900.27C216.197 900.5 216.033 900.826 216.033 901.248C216.033 901.615 216.145 901.887 216.367 902.062C216.59 902.238 216.885 902.326 217.252 902.326C217.822 902.326 218.289 902.168 218.652 901.852C219.016 901.535 219.197 901.061 219.197 900.428V899.836ZM225.08 896.461C225.209 896.461 225.344 896.469 225.484 896.484C225.625 896.496 225.75 896.514 225.859 896.537L225.736 897.439C225.631 897.412 225.514 897.391 225.385 897.375C225.256 897.359 225.135 897.352 225.021 897.352C224.764 897.352 224.52 897.404 224.289 897.51C224.062 897.611 223.863 897.76 223.691 897.955C223.52 898.146 223.385 898.379 223.287 898.652C223.189 898.922 223.141 899.223 223.141 899.555V903H222.162V896.578H222.971L223.076 897.762H223.117C223.25 897.523 223.41 897.307 223.598 897.111C223.785 896.912 224.002 896.754 224.248 896.637C224.498 896.52 224.775 896.461 225.08 896.461ZM229.545 896.461C230.092 896.461 230.561 896.582 230.951 896.824C231.342 897.066 231.641 897.406 231.848 897.844C232.055 898.277 232.158 898.785 232.158 899.367V899.971H227.723C227.734 900.725 227.922 901.299 228.285 901.693C228.648 902.088 229.16 902.285 229.82 902.285C230.227 902.285 230.586 902.248 230.898 902.174C231.211 902.1 231.535 901.99 231.871 901.846V902.701C231.547 902.846 231.225 902.951 230.904 903.018C230.588 903.084 230.213 903.117 229.779 903.117C229.162 903.117 228.623 902.992 228.162 902.742C227.705 902.488 227.35 902.117 227.096 901.629C226.842 901.141 226.715 900.543 226.715 899.836C226.715 899.145 226.83 898.547 227.061 898.043C227.295 897.535 227.623 897.145 228.045 896.871C228.471 896.598 228.971 896.461 229.545 896.461ZM229.533 897.258C229.014 897.258 228.6 897.428 228.291 897.768C227.982 898.107 227.799 898.582 227.74 899.191H231.139C231.135 898.809 231.074 898.473 230.957 898.184C230.844 897.891 230.67 897.664 230.436 897.504C230.201 897.34 229.9 897.258 229.533 897.258ZM167.904 913.434L165.613 922H164.611L162.912 916.234C162.861 916.07 162.812 915.906 162.766 915.742C162.723 915.574 162.682 915.416 162.643 915.268C162.604 915.115 162.57 914.982 162.543 914.869C162.52 914.752 162.502 914.664 162.49 914.605C162.482 914.664 162.467 914.75 162.443 914.863C162.424 914.977 162.396 915.107 162.361 915.256C162.33 915.404 162.291 915.562 162.244 915.73C162.201 915.898 162.154 916.068 162.104 916.24L160.451 922H159.449L157.176 913.434H158.213L159.59 918.807C159.637 918.986 159.68 919.164 159.719 919.34C159.762 919.512 159.799 919.68 159.83 919.844C159.865 920.008 159.896 920.168 159.924 920.324C159.951 920.48 159.977 920.633 160 920.781C160.02 920.629 160.045 920.471 160.076 920.307C160.107 920.139 160.141 919.969 160.176 919.797C160.215 919.625 160.256 919.451 160.299 919.275C160.346 919.1 160.395 918.924 160.445 918.748L161.986 913.434H163.012L164.617 918.789C164.672 918.973 164.723 919.154 164.77 919.334C164.816 919.514 164.857 919.689 164.893 919.861C164.932 920.029 164.965 920.191 164.992 920.348C165.023 920.5 165.051 920.645 165.074 920.781C165.102 920.59 165.135 920.389 165.174 920.178C165.213 919.967 165.258 919.746 165.309 919.516C165.363 919.285 165.422 919.047 165.484 918.801L166.861 913.434H167.904ZM170.084 915.578V922H169.111V915.578H170.084ZM169.609 913.176C169.77 913.176 169.906 913.229 170.02 913.334C170.137 913.436 170.195 913.596 170.195 913.814C170.195 914.029 170.137 914.189 170.02 914.295C169.906 914.4 169.77 914.453 169.609 914.453C169.441 914.453 169.301 914.4 169.188 914.295C169.078 914.189 169.023 914.029 169.023 913.814C169.023 913.596 169.078 913.436 169.188 913.334C169.301 913.229 169.441 913.176 169.609 913.176ZM174.221 921.32C174.381 921.32 174.545 921.307 174.713 921.279C174.881 921.252 175.018 921.219 175.123 921.18V921.936C175.01 921.986 174.852 922.029 174.648 922.064C174.449 922.1 174.254 922.117 174.062 922.117C173.723 922.117 173.414 922.059 173.137 921.941C172.859 921.82 172.637 921.617 172.469 921.332C172.305 921.047 172.223 920.652 172.223 920.148V916.34H171.309V915.865L172.229 915.484L172.615 914.09H173.201V915.578H175.082V916.34H173.201V920.119C173.201 920.521 173.293 920.822 173.477 921.021C173.664 921.221 173.912 921.32 174.221 921.32ZM177.396 912.883V915.607C177.396 915.764 177.393 915.922 177.385 916.082C177.377 916.238 177.363 916.383 177.344 916.516H177.408C177.541 916.289 177.709 916.1 177.912 915.947C178.119 915.791 178.354 915.674 178.615 915.596C178.877 915.514 179.154 915.473 179.447 915.473C179.963 915.473 180.393 915.555 180.736 915.719C181.084 915.883 181.344 916.137 181.516 916.48C181.691 916.824 181.779 917.27 181.779 917.816V922H180.818V917.881C180.818 917.346 180.695 916.945 180.449 916.68C180.207 916.414 179.834 916.281 179.33 916.281C178.854 916.281 178.473 916.373 178.188 916.557C177.906 916.736 177.703 917.002 177.578 917.354C177.457 917.705 177.396 918.135 177.396 918.643V922H176.424V912.883H177.396ZM188.975 921.32C189.135 921.32 189.299 921.307 189.467 921.279C189.635 921.252 189.771 921.219 189.877 921.18V921.936C189.764 921.986 189.605 922.029 189.402 922.064C189.203 922.1 189.008 922.117 188.816 922.117C188.477 922.117 188.168 922.059 187.891 921.941C187.613 921.82 187.391 921.617 187.223 921.332C187.059 921.047 186.977 920.652 186.977 920.148V916.34H186.062V915.865L186.982 915.484L187.369 914.09H187.955V915.578H189.836V916.34H187.955V920.119C187.955 920.521 188.047 920.822 188.23 921.021C188.418 921.221 188.666 921.32 188.975 921.32ZM192.15 912.883V915.607C192.15 915.764 192.146 915.922 192.139 916.082C192.131 916.238 192.117 916.383 192.098 916.516H192.162C192.295 916.289 192.463 916.1 192.666 915.947C192.873 915.791 193.107 915.674 193.369 915.596C193.631 915.514 193.908 915.473 194.201 915.473C194.717 915.473 195.146 915.555 195.49 915.719C195.838 915.883 196.098 916.137 196.27 916.48C196.445 916.824 196.533 917.27 196.533 917.816V922H195.572V917.881C195.572 917.346 195.449 916.945 195.203 916.68C194.961 916.414 194.588 916.281 194.084 916.281C193.607 916.281 193.227 916.373 192.941 916.557C192.66 916.736 192.457 917.002 192.332 917.354C192.211 917.705 192.15 918.135 192.15 918.643V922H191.178V912.883H192.15ZM201.01 915.461C201.557 915.461 202.025 915.582 202.416 915.824C202.807 916.066 203.105 916.406 203.312 916.844C203.52 917.277 203.623 917.785 203.623 918.367V918.971H199.188C199.199 919.725 199.387 920.299 199.75 920.693C200.113 921.088 200.625 921.285 201.285 921.285C201.691 921.285 202.051 921.248 202.363 921.174C202.676 921.1 203 920.99 203.336 920.846V921.701C203.012 921.846 202.689 921.951 202.369 922.018C202.053 922.084 201.678 922.117 201.244 922.117C200.627 922.117 200.088 921.992 199.627 921.742C199.17 921.488 198.814 921.117 198.561 920.629C198.307 920.141 198.18 919.543 198.18 918.836C198.18 918.145 198.295 917.547 198.525 917.043C198.76 916.535 199.088 916.145 199.51 915.871C199.936 915.598 200.436 915.461 201.01 915.461ZM200.998 916.258C200.479 916.258 200.064 916.428 199.756 916.768C199.447 917.107 199.264 917.582 199.205 918.191H202.604C202.6 917.809 202.539 917.473 202.422 917.184C202.309 916.891 202.135 916.664 201.9 916.504C201.666 916.34 201.365 916.258 200.998 916.258ZM212.201 914.189C211.729 914.189 211.303 914.271 210.924 914.436C210.549 914.596 210.229 914.83 209.963 915.139C209.701 915.443 209.5 915.812 209.359 916.246C209.219 916.68 209.148 917.168 209.148 917.711C209.148 918.43 209.26 919.055 209.482 919.586C209.709 920.113 210.045 920.521 210.49 920.811C210.939 921.1 211.5 921.244 212.172 921.244C212.555 921.244 212.914 921.213 213.25 921.15C213.59 921.084 213.92 921.002 214.24 920.904V921.771C213.928 921.889 213.6 921.975 213.256 922.029C212.912 922.088 212.504 922.117 212.031 922.117C211.16 922.117 210.432 921.938 209.846 921.578C209.264 921.215 208.826 920.703 208.533 920.043C208.244 919.383 208.1 918.604 208.1 917.705C208.1 917.057 208.189 916.465 208.369 915.93C208.553 915.391 208.818 914.926 209.166 914.535C209.518 914.145 209.947 913.844 210.455 913.633C210.967 913.418 211.553 913.311 212.213 913.311C212.646 913.311 213.064 913.354 213.467 913.439C213.869 913.525 214.232 913.648 214.557 913.809L214.158 914.652C213.885 914.527 213.584 914.42 213.256 914.33C212.932 914.236 212.58 914.189 212.201 914.189ZM216.93 922H215.951V912.883H216.93V922ZM219.959 915.578V922H218.986V915.578H219.959ZM219.484 913.176C219.645 913.176 219.781 913.229 219.895 913.334C220.012 913.436 220.07 913.596 220.07 913.814C220.07 914.029 220.012 914.189 219.895 914.295C219.781 914.4 219.645 914.453 219.484 914.453C219.316 914.453 219.176 914.4 219.062 914.295C218.953 914.189 218.898 914.029 218.898 913.814C218.898 913.596 218.953 913.436 219.062 913.334C219.176 913.229 219.316 913.176 219.484 913.176ZM224.494 915.461C225.041 915.461 225.51 915.582 225.9 915.824C226.291 916.066 226.59 916.406 226.797 916.844C227.004 917.277 227.107 917.785 227.107 918.367V918.971H222.672C222.684 919.725 222.871 920.299 223.234 920.693C223.598 921.088 224.109 921.285 224.77 921.285C225.176 921.285 225.535 921.248 225.848 921.174C226.16 921.1 226.484 920.99 226.82 920.846V921.701C226.496 921.846 226.174 921.951 225.854 922.018C225.537 922.084 225.162 922.117 224.729 922.117C224.111 922.117 223.572 921.992 223.111 921.742C222.654 921.488 222.299 921.117 222.045 920.629C221.791 920.141 221.664 919.543 221.664 918.836C221.664 918.145 221.779 917.547 222.01 917.043C222.244 916.535 222.572 916.145 222.994 915.871C223.42 915.598 223.92 915.461 224.494 915.461ZM224.482 916.258C223.963 916.258 223.549 916.428 223.24 916.768C222.932 917.107 222.748 917.582 222.689 918.191H226.088C226.084 917.809 226.023 917.473 225.906 917.184C225.793 916.891 225.619 916.664 225.385 916.504C225.15 916.34 224.85 916.258 224.482 916.258ZM231.801 915.461C232.562 915.461 233.139 915.648 233.529 916.023C233.92 916.395 234.115 916.992 234.115 917.816V922H233.154V917.881C233.154 917.346 233.031 916.945 232.785 916.68C232.543 916.414 232.17 916.281 231.666 916.281C230.955 916.281 230.455 916.482 230.166 916.885C229.877 917.287 229.732 917.871 229.732 918.637V922H228.76V915.578H229.545L229.691 916.504H229.744C229.881 916.277 230.055 916.088 230.266 915.936C230.477 915.779 230.713 915.662 230.975 915.584C231.236 915.502 231.512 915.461 231.801 915.461ZM238.193 921.32C238.354 921.32 238.518 921.307 238.686 921.279C238.854 921.252 238.99 921.219 239.096 921.18V921.936C238.982 921.986 238.824 922.029 238.621 922.064C238.422 922.1 238.227 922.117 238.035 922.117C237.695 922.117 237.387 922.059 237.109 921.941C236.832 921.82 236.609 921.617 236.441 921.332C236.277 921.047 236.195 920.652 236.195 920.148V916.34H235.281V915.865L236.201 915.484L236.588 914.09H237.174V915.578H239.055V916.34H237.174V920.119C237.174 920.521 237.266 920.822 237.449 921.021C237.637 921.221 237.885 921.32 238.193 921.32ZM159.168 941H158.172V932.434H162.941V933.312H159.168V936.453H162.713V937.326H159.168V941ZM169.762 937.777C169.762 938.305 169.693 938.775 169.557 939.189C169.42 939.604 169.223 939.953 168.965 940.238C168.707 940.523 168.395 940.742 168.027 940.895C167.664 941.043 167.252 941.117 166.791 941.117C166.361 941.117 165.967 941.043 165.607 940.895C165.252 940.742 164.943 940.523 164.682 940.238C164.424 939.953 164.223 939.604 164.078 939.189C163.938 938.775 163.867 938.305 163.867 937.777C163.867 937.074 163.986 936.477 164.225 935.984C164.463 935.488 164.803 935.111 165.244 934.854C165.689 934.592 166.219 934.461 166.832 934.461C167.418 934.461 167.93 934.592 168.367 934.854C168.809 935.115 169.15 935.494 169.393 935.99C169.639 936.482 169.762 937.078 169.762 937.777ZM164.875 937.777C164.875 938.293 164.943 938.74 165.08 939.119C165.217 939.498 165.428 939.791 165.713 939.998C165.998 940.205 166.365 940.309 166.814 940.309C167.26 940.309 167.625 940.205 167.91 939.998C168.199 939.791 168.412 939.498 168.549 939.119C168.686 938.74 168.754 938.293 168.754 937.777C168.754 937.266 168.686 936.824 168.549 936.453C168.412 936.078 168.201 935.789 167.916 935.586C167.631 935.383 167.262 935.281 166.809 935.281C166.141 935.281 165.65 935.502 165.338 935.943C165.029 936.385 164.875 936.996 164.875 937.777ZM174.361 934.461C174.49 934.461 174.625 934.469 174.766 934.484C174.906 934.496 175.031 934.514 175.141 934.537L175.018 935.439C174.912 935.412 174.795 935.391 174.666 935.375C174.537 935.359 174.416 935.352 174.303 935.352C174.045 935.352 173.801 935.404 173.57 935.51C173.344 935.611 173.145 935.76 172.973 935.955C172.801 936.146 172.666 936.379 172.568 936.652C172.471 936.922 172.422 937.223 172.422 937.555V941H171.443V934.578H172.252L172.357 935.762H172.398C172.531 935.523 172.691 935.307 172.879 935.111C173.066 934.912 173.283 934.754 173.529 934.637C173.779 934.52 174.057 934.461 174.361 934.461ZM186.098 932.434V937.977C186.098 938.582 185.975 939.121 185.729 939.594C185.486 940.066 185.119 940.439 184.627 940.713C184.135 940.982 183.518 941.117 182.775 941.117C181.717 941.117 180.91 940.83 180.355 940.256C179.805 939.682 179.529 938.914 179.529 937.953V932.434H180.531V937.982C180.531 938.709 180.723 939.27 181.105 939.664C181.492 940.059 182.068 940.256 182.834 940.256C183.357 940.256 183.785 940.162 184.117 939.975C184.453 939.783 184.701 939.518 184.861 939.178C185.025 938.834 185.107 938.438 185.107 937.988V932.434H186.098ZM193.744 941L192.689 938.281H189.256L188.207 941H187.199L190.551 932.398H191.447L194.775 941H193.744ZM192.391 937.396L191.389 934.695C191.365 934.625 191.326 934.51 191.271 934.35C191.221 934.189 191.168 934.023 191.113 933.852C191.059 933.68 191.014 933.541 190.979 933.436C190.939 933.596 190.896 933.756 190.85 933.916C190.807 934.072 190.764 934.219 190.721 934.355C190.678 934.488 190.641 934.602 190.609 934.695L189.59 937.396H192.391ZM198.596 941H197.594V933.312H194.898V932.434H201.279V933.312H198.596V941Z"
            fill="white"
         />
         <g filter="url(#filter18_b_226_1189)">
            <rect
               x="248"
               y="814"
               width="144"
               height="70"
               rx="16"
               fill="url(#paint9_radial_226_1189)"
            />
            <rect
               x="248.5"
               y="814.5"
               width="143"
               height="69"
               rx="15.5"
               stroke="#626262"
            />
         </g>
         <motion.path
            d="M266 836L268.694 844.292H277.413L270.359 849.416L273.053 857.708L266 852.584L258.947 857.708L261.641 849.416L254.587 844.292H263.306L266 836Z"
            fill="#d9d9d9"
            stroke="white"
            strokeWidth={1}
            variants={star}
            initial="hidden"
            animate={starOneControls}
         />
         <motion.path
            d="M293 836L295.694 844.292H304.413L297.359 849.416L300.053 857.708L293 852.584L285.947 857.708L288.641 849.416L281.587 844.292H290.306L293 836Z"
            fill="#d9d9d9"
            stroke="white"
            strokeWidth={1}
            variants={star}
            initial="hidden"
            animate={starTwoControls}
         />
         <motion.path
            d="M320 836L322.694 844.292H331.413L324.359 849.416L327.053 857.708L320 852.584L312.947 857.708L315.641 849.416L308.587 844.292H317.306L320 836Z"
            fill="#d9d9d9"
            stroke="white"
            strokeWidth={1}
            variants={star}
            initial="hidden"
            animate={starThreeControls}
         />
         <motion.path
            d="M347 836L349.694 844.292H358.413L351.359 849.416L354.053 857.708L347 852.584L339.947 857.708L342.641 849.416L335.587 844.292H344.306L347 836Z"
            fill="#d9d9d9"
            stroke="white"
            strokeWidth={1}
            variants={star}
            initial="hidden"
            animate={starFourControls}
         />
         <motion.path
            d="M374 836L376.694 844.292H385.413L378.359 849.416L381.053 857.708L374 852.584L366.947 857.708L369.641 849.416L362.587 844.292H371.306L374 836Z"
            fill="#d9d9d9"
            stroke="white"
            strokeWidth={1}
            variants={star}
            initial="hidden"
            animate={starFiveControls}
         />

         <motion.path
            d="M321.293 903.207C321.683 903.598 322.317 903.598 322.707 903.207L329.071 896.843C329.462 896.453 329.462 895.819 329.071 895.429C328.681 895.038 328.047 895.038 327.657 895.429L322 901.086L316.343 895.429C315.953 895.038 315.319 895.038 314.929 895.429C314.538 895.819 314.538 896.453 314.929 896.843L321.293 903.207ZM321 901.5V902.5H323V901.5H321Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls7}
         />
         <motion.path
            d="M321.293 913.207C321.683 913.598 322.317 913.598 322.707 913.207L329.071 906.843C329.462 906.453 329.462 905.819 329.071 905.429C328.681 905.038 328.047 905.038 327.657 905.429L322 911.086L316.343 905.429C315.953 905.038 315.319 905.038 314.929 905.429C314.538 905.819 314.538 906.453 314.929 906.843L321.293 913.207ZM321 911.5V912.5H323V911.5H321Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls8}
         />

         <motion.path
            d="M321.293 923.207C321.683 923.598 322.317 923.598 322.707 923.207L329.071 916.843C329.462 916.453 329.462 915.819 329.071 915.429C328.681 915.038 328.047 915.038 327.657 915.429L322 921.086L316.343 915.429C315.953 915.038 315.319 915.038 314.929 915.429C314.538 915.819 314.538 916.453 314.929 916.843L321.293 923.207ZM321 921.5V922.5H323V921.5H321Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls9}
         />
         <motion.path
            d="M257.341 977.293C256.95 977.683 256.95 978.317 257.341 978.707L263.704 985.071C264.095 985.462 264.728 985.462 265.119 985.071C265.509 984.681 265.509 984.047 265.119 983.657L259.462 978L265.119 972.343C265.509 971.953 265.509 971.319 265.119 970.929C264.728 970.538 264.095 970.538 263.704 970.929L257.341 977.293ZM259 977H258.048V979H259V977Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls1}
         />

         <motion.path
            d="M247.817 977.293C247.427 977.683 247.427 978.317 247.817 978.707L254.181 985.071C254.572 985.462 255.205 985.462 255.595 985.071C255.986 984.681 255.986 984.047 255.595 983.657L249.938 978L255.595 972.343C255.986 971.953 255.986 971.319 255.595 970.929C255.205 970.538 254.572 970.538 254.181 970.929L247.817 977.293ZM249.477 977H248.524V979H249.477V977Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls2}
         />

         <motion.path
            d="M238.294 977.293C237.903 977.683 237.903 978.317 238.294 978.707L244.658 985.071C245.048 985.462 245.681 985.462 246.072 985.071C246.462 984.681 246.462 984.047 246.072 983.657L240.415 978L246.072 972.343C246.462 971.953 246.462 971.319 246.072 970.929C245.681 970.538 245.048 970.538 244.658 970.929L238.294 977.293ZM239.953 977H239.001V979H239.953V977Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls3}
         />

         <motion.path
            d="M81.3405 977.293C80.95 977.683 80.95 978.317 81.3405 978.707L87.7045 985.071C88.095 985.462 88.7282 985.462 89.1187 985.071C89.5092 984.681 89.5092 984.047 89.1187 983.657L83.4618 978L89.1187 972.343C89.5092 971.953 89.5092 971.319 89.1187 970.929C88.7282 970.538 88.095 970.538 87.7045 970.929L81.3405 977.293ZM83 977H82.0476V979H83V977Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls4}
         />

         <motion.path
            d="M71.8171 977.293C71.4266 977.683 71.4266 978.317 71.8171 978.707L78.181 985.071C78.5716 985.462 79.2047 985.462 79.5952 985.071C79.9858 984.681 79.9858 984.047 79.5952 983.657L73.9384 978L79.5952 972.343C79.9858 971.953 79.9858 971.319 79.5952 970.929C79.2047 970.538 78.5716 970.538 78.181 970.929L71.8171 977.293ZM73.4766 977H72.5242V979H73.4766V977Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls5}
         />

         <motion.path
            d="M62.2936 977.293C61.9031 977.683 61.9031 978.317 62.2936 978.707L68.6576 985.071C69.0481 985.462 69.6813 985.462 70.0718 985.071C70.4623 984.681 70.4623 984.047 70.0718 983.657L64.415 978L70.0718 972.343C70.4623 971.953 70.4623 971.319 70.0718 970.929C69.6813 970.538 69.0481 970.538 68.6576 970.929L62.2936 977.293ZM63.9531 977H63.0007V979H63.9531V977Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls6}
         />
         <motion.path
            d="M9.20711 908.337C8.81658 907.947 8.18342 907.947 7.79289 908.337L1.42893 914.701C1.03841 915.092 1.03841 915.725 1.42893 916.115C1.81946 916.506 2.45262 916.506 2.84315 916.115L8.5 910.458L14.1569 916.115C14.5474 916.506 15.1805 916.506 15.5711 916.115C15.9616 915.725 15.9616 915.092 15.5711 914.701L9.20711 908.337ZM9.5 909.997V909.044H7.5V909.997H9.5Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls7}
         />

         <motion.path
            d="M9.20711 898.814C8.81658 898.423 8.18342 898.423 7.79289 898.814L1.42893 905.178C1.03841 905.568 1.03841 906.201 1.42893 906.592C1.81946 906.982 2.45262 906.982 2.84315 906.592L8.5 900.935L14.1569 906.592C14.5474 906.982 15.1805 906.982 15.5711 906.592C15.9616 906.201 15.9616 905.568 15.5711 905.178L9.20711 898.814ZM9.5 900.473V899.521H7.5V900.473H9.5Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls8}
         />

         <motion.path
            d="M9.70711 889.293C9.31658 888.902 8.68342 888.902 8.29289 889.293L1.92893 895.657C1.53841 896.047 1.53841 896.681 1.92893 897.071C2.31946 897.462 2.95262 897.462 3.34315 897.071L9 891.414L14.6569 897.071C15.0474 897.462 15.6805 897.462 16.0711 897.071C16.4616 896.681 16.4616 896.047 16.0711 895.657L9.70711 889.293ZM10 891V890H8V891H10Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls9}
         />
         <motion.path
            d="M8.70711 713.338C8.31658 712.947 7.68342 712.947 7.29289 713.338L0.928932 719.702C0.538408 720.092 0.538408 720.725 0.928932 721.116C1.31946 721.507 1.95262 721.507 2.34315 721.116L8 715.459L13.6569 721.116C14.0474 721.507 14.6805 721.507 15.0711 721.116C15.4616 720.725 15.4616 720.092 15.0711 719.702L8.70711 713.338ZM9 714.997V714.045H7V714.997H9Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls1}
         />

         <motion.path
            d="M8.70711 703.814C8.31658 703.424 7.68342 703.424 7.29289 703.814L0.928932 710.178C0.538408 710.569 0.538408 711.202 0.928932 711.593C1.31946 711.983 1.95262 711.983 2.34315 711.593L8 705.936L13.6569 711.593C14.0474 711.983 14.6805 711.983 15.0711 711.593C15.4616 711.202 15.4616 710.569 15.0711 710.178L8.70711 703.814ZM9 705.474V704.521H7V705.474H9Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls2}
         />

         <motion.path
            d="M8.70711 694.291C8.31658 693.9 7.68342 693.9 7.29289 694.291L0.928932 700.655C0.538408 701.045 0.538408 701.679 0.928932 702.069C1.31946 702.46 1.95262 702.46 2.34315 702.069L8 696.412L13.6569 702.069C14.0474 702.46 14.6805 702.46 15.0711 702.069C15.4616 701.679 15.4616 701.045 15.0711 700.655L8.70711 694.291ZM9 695.95V694.998H7V695.95H9Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls3}
         />

         <motion.path
            d="M8.70711 518.339C8.31658 517.948 7.68342 517.948 7.29289 518.339L0.928932 524.703C0.538408 525.093 0.538408 525.726 0.928932 526.117C1.31946 526.507 1.95262 526.507 2.34315 526.117L8 520.46L13.6569 526.117C14.0474 526.507 14.6805 526.507 15.0711 526.117C15.4616 525.726 15.4616 525.093 15.0711 524.703L8.70711 518.339ZM9 519.998V519.046H7V519.998H9Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls4}
         />

         <motion.path
            d="M8.70711 508.815C8.31658 508.425 7.68342 508.425 7.29289 508.815L0.928932 515.179C0.538408 515.57 0.538408 516.203 0.928932 516.593C1.31946 516.984 1.95262 516.984 2.34315 516.593L8 510.936L13.6569 516.593C14.0474 516.984 14.6805 516.984 15.0711 516.593C15.4616 516.203 15.4616 515.57 15.0711 515.179L8.70711 508.815ZM9 510.475V509.522H7V510.475H9Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls5}
         />

         <motion.path
            d="M8.70711 499.292C8.31658 498.901 7.68342 498.901 7.29289 499.292L0.928932 505.656C0.538408 506.046 0.538408 506.679 0.928932 507.07C1.31946 507.46 1.95262 507.46 2.34315 507.07L8 501.413L13.6569 507.07C14.0474 507.46 14.6805 507.46 15.0711 507.07C15.4616 506.679 15.4616 506.046 15.0711 505.656L8.70711 499.292ZM9 500.951V499.999H7V500.951H9Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls6}
         />

         <motion.path
            d="M8.70711 323.339C8.31658 322.949 7.68342 322.949 7.29289 323.339L0.928932 329.703C0.538408 330.094 0.538408 330.727 0.928932 331.117C1.31946 331.508 1.95262 331.508 2.34315 331.117L8 325.461L13.6569 331.117C14.0474 331.508 14.6805 331.508 15.0711 331.117C15.4616 330.727 15.4616 330.094 15.0711 329.703L8.70711 323.339ZM9 324.999V324.046H7V324.999H9Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls7}
         />
         <motion.path
            d="M8.70711 313.816C8.31658 313.425 7.68342 313.425 7.29289 313.816L0.928932 320.18C0.538408 320.57 0.538408 321.204 0.928932 321.594C1.31946 321.985 1.95262 321.985 2.34315 321.594L8 315.937L13.6569 321.594C14.0474 321.985 14.6805 321.985 15.0711 321.594C15.4616 321.204 15.4616 320.57 15.0711 320.18L8.70711 313.816ZM9 315.475V314.523H7V315.475H9Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls8}
         />

         <motion.path
            d="M8.70711 304.292C8.31658 303.902 7.68342 303.902 7.29289 304.292L0.928932 310.656C0.538408 311.047 0.538408 311.68 0.928932 312.071C1.31946 312.461 1.95262 312.461 2.34315 312.071L8 306.414L13.6569 312.071C14.0474 312.461 14.6805 312.461 15.0711 312.071C15.4616 311.68 15.4616 311.047 15.0711 310.656L8.70711 304.292ZM9 305.952V305H7V305.952H9Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls9}
         />
         <motion.path
            d="M8.70711 128.34C8.31658 127.949 7.68342 127.949 7.29289 128.34L0.928932 134.704C0.538408 135.095 0.538408 135.728 0.928932 136.118C1.31946 136.509 1.95262 136.509 2.34315 136.118L8 130.461L13.6569 136.118C14.0474 136.509 14.6805 136.509 15.0711 136.118C15.4616 135.728 15.4616 135.095 15.0711 134.704L8.70711 128.34ZM9 130V129.047H7V130H9Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls1}
         />

         <motion.path
            d="M8.70711 118.817C8.31658 118.426 7.68342 118.426 7.29289 118.817L0.928932 125.181C0.538408 125.571 0.538408 126.204 0.928932 126.595C1.31946 126.985 1.95262 126.985 2.34315 126.595L8 120.938L13.6569 126.595C14.0474 126.985 14.6805 126.985 15.0711 126.595C15.4616 126.204 15.4616 125.571 15.0711 125.181L8.70711 118.817ZM9 120.476V119.524H7V120.476H9Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls2}
         />

         <motion.path
            d="M8.70711 109.293C8.31658 108.903 7.68342 108.903 7.29289 109.293L0.928932 115.657C0.538408 116.048 0.538408 116.681 0.928932 117.071C1.31946 117.462 1.95262 117.462 2.34315 117.071L8 111.414L13.6569 117.071C14.0474 117.462 14.6805 117.462 15.0711 117.071C15.4616 116.681 15.4616 116.048 15.0711 115.657L8.70711 109.293ZM9 110.953V110H7V110.953H9Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls3}
         />
         <motion.path
            d="M158.707 54.7071C159.098 54.3166 159.098 53.6834 158.707 53.2929L152.343 46.9289C151.953 46.5384 151.319 46.5384 150.929 46.9289C150.538 47.3195 150.538 47.9526 150.929 48.3431L156.586 54L150.929 59.6569C150.538 60.0474 150.538 60.6805 150.929 61.0711C151.319 61.4616 151.953 61.4616 152.343 61.0711L158.707 54.7071ZM157 55H158V53H157V55Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls1}
         />

         <motion.path
            d="M168.707 54.7071C169.098 54.3166 169.098 53.6834 168.707 53.2929L162.343 46.9289C161.953 46.5384 161.319 46.5384 160.929 46.9289C160.538 47.3195 160.538 47.9526 160.929 48.3431L166.586 54L160.929 59.6569C160.538 60.0474 160.538 60.6805 160.929 61.0711C161.319 61.4616 161.953 61.4616 162.343 61.0711L168.707 54.7071ZM167 55H168V53H167V55Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls2}
         />
         <motion.path
            d="M178.707 54.7071C179.098 54.3166 179.098 53.6834 178.707 53.2929L172.343 46.9289C171.953 46.5384 171.319 46.5384 170.929 46.9289C170.538 47.3195 170.538 47.9526 170.929 48.3431L176.586 54L170.929 59.6569C170.538 60.0474 170.538 60.6805 170.929 61.0711C171.319 61.4616 171.953 61.4616 172.343 61.0711L178.707 54.7071ZM177 55H178V53H177V55Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls3}
         />
         <motion.path
            d="M365.793 117.207C366.183 117.598 366.817 117.598 367.207 117.207L373.571 110.843C373.962 110.453 373.962 109.819 373.571 109.429C373.181 109.038 372.547 109.038 372.157 109.429L366.5 115.086L360.843 109.429C360.453 109.038 359.819 109.038 359.429 109.429C359.038 109.819 359.038 110.453 359.429 110.843L365.793 117.207ZM365.5 115.5V116.5H367.5V115.5H365.5Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls4}
         />

         <motion.path
            d="M365.793 127.207C366.183 127.598 366.817 127.598 367.207 127.207L373.571 120.843C373.962 120.453 373.962 119.819 373.571 119.429C373.181 119.038 372.547 119.038 372.157 119.429L366.5 125.086L360.843 119.429C360.453 119.038 359.819 119.038 359.429 119.429C359.038 119.819 359.038 120.453 359.429 120.843L365.793 127.207ZM365.5 125.5V126.5H367.5V125.5H365.5Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls5}
         />

         <motion.path
            d="M365.793 137.207C366.183 137.598 366.817 137.598 367.207 137.207L373.571 130.843C373.962 130.453 373.962 129.819 373.571 129.429C373.181 129.038 372.547 129.038 372.157 129.429L366.5 135.086L360.843 129.429C360.453 129.038 359.819 129.038 359.429 129.429C359.038 129.819 359.038 130.453 359.429 130.843L365.793 137.207ZM365.5 135.5V136.5H367.5V135.5H365.5Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls6}
         />
         <motion.path
            d="M295.293 193.293C294.902 193.683 294.902 194.317 295.293 194.707L301.657 201.071C302.047 201.462 302.681 201.462 303.071 201.071C303.462 200.681 303.462 200.047 303.071 199.657L297.414 194L303.071 188.343C303.462 187.953 303.462 187.319 303.071 186.929C302.681 186.538 302.047 186.538 301.657 186.929L295.293 193.293ZM297 193H296V195H297V193Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls7}
         />

         <motion.path
            d="M285.293 193.293C284.902 193.683 284.902 194.317 285.293 194.707L291.657 201.071C292.047 201.462 292.681 201.462 293.071 201.071C293.462 200.681 293.462 200.047 293.071 199.657L287.414 194L293.071 188.343C293.462 187.953 293.462 187.319 293.071 186.929C292.681 186.538 292.047 186.538 291.657 186.929L285.293 193.293ZM287 193H286V195H287V193Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls8}
         />

         <motion.path
            d="M275.293 193.293C274.902 193.683 274.902 194.317 275.293 194.707L281.657 201.071C282.047 201.462 282.681 201.462 283.071 201.071C283.462 200.681 283.462 200.047 283.071 199.657L277.414 194L283.071 188.343C283.462 187.953 283.462 187.319 283.071 186.929C282.681 186.538 282.047 186.538 281.657 186.929L275.293 193.293ZM277 193H276V195H277V193Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls9}
         />
         <motion.path
            d="M270.707 321.707C271.098 321.317 271.098 320.683 270.707 320.293L264.343 313.929C263.953 313.538 263.319 313.538 262.929 313.929C262.538 314.319 262.538 314.953 262.929 315.343L268.586 321L262.929 326.657C262.538 327.047 262.538 327.681 262.929 328.071C263.319 328.462 263.953 328.462 264.343 328.071L270.707 321.707ZM269 322H270V320H269V322Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls1}
         />

         <motion.path
            d="M280.707 321.707C281.098 321.317 281.098 320.683 280.707 320.293L274.343 313.929C273.953 313.538 273.319 313.538 272.929 313.929C272.538 314.319 272.538 314.953 272.929 315.343L278.586 321L272.929 326.657C272.538 327.047 272.538 327.681 272.929 328.071C273.319 328.462 273.953 328.462 274.343 328.071L280.707 321.707ZM279 322H280V320H279V322Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls2}
         />

         <motion.path
            d="M290.707 321.707C291.098 321.317 291.098 320.683 290.707 320.293L284.343 313.929C283.953 313.538 283.319 313.538 282.929 313.929C282.538 314.319 282.538 314.953 282.929 315.343L288.586 321L282.929 326.657C282.538 327.047 282.538 327.681 282.929 328.071C283.319 328.462 283.953 328.462 284.343 328.071L290.707 321.707ZM289 322H290V320H289V322Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls3}
         />

         <motion.path
            d="M353.293 394.207C353.683 394.598 354.317 394.598 354.707 394.207L361.071 387.843C361.462 387.453 361.462 386.819 361.071 386.429C360.681 386.038 360.047 386.038 359.657 386.429L354 392.086L348.343 386.429C347.953 386.038 347.319 386.038 346.929 386.429C346.538 386.819 346.538 387.453 346.929 387.843L353.293 394.207ZM353 392.5V393.5H355V392.5H353Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls4}
         />

         <motion.path
            d="M353.293 404.207C353.683 404.598 354.317 404.598 354.707 404.207L361.071 397.843C361.462 397.453 361.462 396.819 361.071 396.429C360.681 396.038 360.047 396.038 359.657 396.429L354 402.086L348.343 396.429C347.953 396.038 347.319 396.038 346.929 396.429C346.538 396.819 346.538 397.453 346.929 397.843L353.293 404.207ZM353 402.5V403.5H355V402.5H353Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls5}
         />

         <motion.path
            d="M352.793 414.207C353.183 414.598 353.817 414.598 354.207 414.207L360.571 407.843C360.962 407.453 360.962 406.819 360.571 406.429C360.181 406.038 359.547 406.038 359.157 406.429L353.5 412.086L347.843 406.429C347.453 406.038 346.819 406.038 346.429 406.429C346.038 406.819 346.038 407.453 346.429 407.843L352.793 414.207ZM352.5 412.5V413.5H354.5V412.5H352.5Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls6}
         />
         <motion.path
            d="M282.543 479.293C282.152 479.683 282.152 480.317 282.543 480.707L288.907 487.071C289.297 487.462 289.931 487.462 290.321 487.071C290.712 486.681 290.712 486.047 290.321 485.657L284.664 480L290.321 474.343C290.712 473.953 290.712 473.319 290.321 472.929C289.931 472.538 289.297 472.538 288.907 472.929L282.543 479.293ZM284.25 479H283.25V481H284.25V479Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls7}
         />

         <motion.path
            d="M272.543 479.293C272.152 479.683 272.152 480.317 272.543 480.707L278.907 487.071C279.297 487.462 279.931 487.462 280.321 487.071C280.712 486.681 280.712 486.047 280.321 485.657L274.664 480L280.321 474.343C280.712 473.953 280.712 473.319 280.321 472.929C279.931 472.538 279.297 472.538 278.907 472.929L272.543 479.293ZM274.25 479H273.25V481H274.25V479Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls8}
         />

         <motion.path
            d="M262.543 479.293C262.152 479.683 262.152 480.317 262.543 480.707L268.907 487.071C269.297 487.462 269.931 487.462 270.321 487.071C270.712 486.681 270.712 486.047 270.321 485.657L264.664 480L270.321 474.343C270.712 473.953 270.712 473.319 270.321 472.929C269.931 472.538 269.297 472.538 268.907 472.929L262.543 479.293ZM264.25 479H263.25V481H264.25V479Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls9}
         />
         <motion.path
            d="M122.543 479.293C122.152 479.683 122.152 480.317 122.543 480.707L128.907 487.071C129.297 487.462 129.931 487.462 130.321 487.071C130.712 486.681 130.712 486.047 130.321 485.657L124.664 480L130.321 474.343C130.712 473.953 130.712 473.319 130.321 472.929C129.931 472.538 129.297 472.538 128.907 472.929L122.543 479.293ZM124.25 479H123.25V481H124.25V479Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls1}
         />

         <motion.path
            d="M112.543 479.293C112.152 479.683 112.152 480.317 112.543 480.707L118.907 487.071C119.297 487.462 119.931 487.462 120.321 487.071C120.712 486.681 120.712 486.047 120.321 485.657L114.664 480L120.321 474.343C120.712 473.953 120.712 473.319 120.321 472.929C119.931 472.538 119.297 472.538 118.907 472.929L112.543 479.293ZM114.25 479H113.25V481H114.25V479Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls2}
         />

         <motion.path
            d="M102.543 479.293C102.152 479.683 102.152 480.317 102.543 480.707L108.907 487.071C109.297 487.462 109.931 487.462 110.321 487.071C110.712 486.681 110.712 486.047 110.321 485.657L104.664 480L110.321 474.343C110.712 473.953 110.712 473.319 110.321 472.929C109.931 472.538 109.297 472.538 108.907 472.929L102.543 479.293ZM104.25 479H103.25V481H104.25V479Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls3}
         />
         <motion.path
            d="M32.6898 539.141C33.0448 539.564 33.6755 539.619 34.0986 539.264L40.993 533.479C41.4161 533.124 41.4713 532.493 41.1163 532.07C40.7613 531.647 40.1305 531.592 39.7074 531.947L33.5791 537.089L28.4368 530.961C28.0818 530.538 27.451 530.483 27.0279 530.838C26.6049 531.193 26.5497 531.823 26.9047 532.247L32.6898 539.141ZM32.5468 537.415L32.4596 538.411L34.452 538.585L34.5392 537.589L32.5468 537.415Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls4}
         />

         <motion.path
            d="M32.2494 549.182C32.626 549.586 33.2588 549.608 33.6627 549.231L40.2449 543.093C40.6488 542.716 40.6709 542.084 40.2943 541.68C39.9176 541.276 39.2848 541.254 38.8809 541.63L33.0301 547.086L27.5741 541.235C27.1974 540.832 26.5647 540.809 26.1607 541.186C25.7568 541.563 25.7347 542.196 26.1114 542.599L32.2494 549.182ZM32.0162 547.465L31.9813 548.465L33.9801 548.535L34.015 547.535L32.0162 547.465Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls5}
         />

         <motion.path
            d="M32.844 558.727C33.246 559.106 33.8789 559.087 34.2576 558.685L40.4293 552.135C40.8081 551.733 40.7892 551.1 40.3872 550.721C39.9853 550.342 39.3524 550.361 38.9736 550.763L33.4877 556.586L27.665 551.1C27.263 550.721 26.6301 550.74 26.2514 551.142C25.8726 551.544 25.8915 552.177 26.2935 552.556L32.844 558.727ZM32.5004 557.03L32.5302 558.029L34.5293 557.97L34.4996 556.97L32.5004 557.03Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls6}
         />
         <motion.path
            d="M25.6898 784.141C26.0448 784.564 26.6755 784.619 27.0986 784.264L33.993 778.479C34.4161 778.124 34.4713 777.493 34.1163 777.07C33.7613 776.647 33.1305 776.592 32.7074 776.947L26.5791 782.089L21.4368 775.961C21.0818 775.538 20.451 775.483 20.0279 775.838C19.6049 776.193 19.5497 776.823 19.9047 777.247L25.6898 784.141ZM25.5468 782.415L25.4596 783.411L27.452 783.585L27.5392 782.589L25.5468 782.415Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls4}
         />

         <motion.path
            d="M25.2494 794.182C25.626 794.586 26.2588 794.608 26.6627 794.231L33.2449 788.093C33.6488 787.716 33.6709 787.084 33.2943 786.68C32.9176 786.276 32.2848 786.254 31.8809 786.63L26.0301 792.086L20.5741 786.235C20.1974 785.832 19.5647 785.809 19.1607 786.186C18.7568 786.563 18.7347 787.196 19.1114 787.599L25.2494 794.182ZM25.0162 792.465L24.9813 793.465L26.9801 793.535L27.015 792.535L25.0162 792.465Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls5}
         />

         <motion.path
            d="M25.844 803.727C26.246 804.106 26.8789 804.087 27.2576 803.685L33.4293 797.135C33.8081 796.733 33.7892 796.1 33.3872 795.721C32.9853 795.342 32.3524 795.361 31.9736 795.763L26.4877 801.586L20.665 796.1C20.263 795.721 19.6301 795.74 19.2514 796.142C18.8726 796.544 18.8915 797.177 19.2935 797.556L25.844 803.727ZM25.5004 802.03L25.5302 803.029L27.5293 802.97L27.4996 801.97L25.5004 802.03Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls6}
         />
         <motion.path
            d="M159.957 613.707C160.348 613.317 160.348 612.683 159.957 612.293L153.593 605.929C153.203 605.538 152.569 605.538 152.179 605.929C151.788 606.319 151.788 606.953 152.179 607.343L157.836 613L152.179 618.657C151.788 619.047 151.788 619.681 152.179 620.071C152.569 620.462 153.203 620.462 153.593 620.071L159.957 613.707ZM158.25 614H159.25V612H158.25V614Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls7}
         />

         <motion.path
            d="M169.957 613.707C170.348 613.317 170.348 612.683 169.957 612.293L163.593 605.929C163.203 605.538 162.569 605.538 162.179 605.929C161.788 606.319 161.788 606.953 162.179 607.343L167.836 613L162.179 618.657C161.788 619.047 161.788 619.681 162.179 620.071C162.569 620.462 163.203 620.462 163.593 620.071L169.957 613.707ZM168.25 614H169.25V612H168.25V614Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls8}
         />

         <motion.path
            d="M179.957 613.707C180.348 613.317 180.348 612.683 179.957 612.293L173.593 605.929C173.203 605.538 172.569 605.538 172.179 605.929C171.788 606.319 171.788 606.953 172.179 607.343L177.836 613L172.179 618.657C171.788 619.047 171.788 619.681 172.179 620.071C172.569 620.462 173.203 620.462 173.593 620.071L179.957 613.707ZM178.25 614H179.25V612H178.25V614Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls9}
         />
         <motion.path
            d="M259.012 541.599C259.367 541.176 259.312 540.545 258.889 540.19L251.995 534.405C251.572 534.05 250.941 534.105 250.586 534.529C250.231 534.952 250.286 535.582 250.709 535.937L256.837 541.08L251.695 547.208C251.34 547.631 251.395 548.262 251.818 548.617C252.241 548.972 252.872 548.917 253.227 548.494L259.012 541.599ZM257.337 542.04L258.333 541.953L258.159 539.96L257.163 540.047L257.337 542.04Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls4}
         />

         <motion.path
            d="M268.957 540.707C269.348 540.317 269.348 539.683 268.957 539.293L262.593 532.929C262.203 532.538 261.569 532.538 261.179 532.929C260.788 533.319 260.788 533.953 261.179 534.343L266.836 540L261.179 545.657C260.788 546.047 260.788 546.681 261.179 547.071C261.569 547.462 262.203 547.462 262.593 547.071L268.957 540.707ZM267.25 541H268.25V539H267.25V541Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls5}
         />

         <motion.path
            d="M278.885 541.81C279.308 541.455 279.363 540.824 279.008 540.401L273.223 533.506C272.868 533.083 272.237 533.028 271.814 533.383C271.391 533.738 271.336 534.369 271.691 534.792L276.833 540.92L270.705 546.063C270.282 546.418 270.227 547.048 270.582 547.471C270.937 547.895 271.568 547.95 271.991 547.595L278.885 541.81ZM277.159 541.953L278.155 542.04L278.329 540.047L277.333 539.96L277.159 541.953Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls6}
         />
         <motion.path
            d="M317.825 564.013C318.376 564.058 318.859 563.649 318.905 563.099L319.648 554.129C319.693 553.579 319.284 553.096 318.733 553.05C318.183 553.005 317.7 553.414 317.654 553.964L316.994 561.937L309.021 561.276C308.471 561.231 307.988 561.64 307.942 562.191C307.897 562.741 308.306 563.224 308.856 563.27L317.825 564.013ZM316.499 562.899L317.145 563.662L318.671 562.37L318.025 561.607L316.499 562.899Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls7}
         />

         <motion.path
            d="M323.291 571.616C323.835 571.709 324.352 571.344 324.446 570.799L325.968 561.929C326.061 561.385 325.695 560.868 325.151 560.774C324.607 560.681 324.09 561.046 323.996 561.591L322.644 569.476L314.759 568.123C314.215 568.029 313.698 568.395 313.604 568.939C313.511 569.484 313.876 570.001 314.421 570.094L323.291 571.616ZM322.066 570.391L322.644 571.208L324.277 570.053L323.699 569.236L322.066 570.391Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls8}
         />

         <motion.path
            d="M328.125 580.36C328.659 580.501 329.206 580.182 329.346 579.647L331.635 570.943C331.776 570.409 331.457 569.862 330.922 569.722C330.388 569.582 329.841 569.901 329.701 570.435L327.666 578.172L319.929 576.137C319.395 575.996 318.848 576.316 318.708 576.85C318.567 577.384 318.887 577.931 319.421 578.071L328.125 580.36ZM327.011 579.033L327.515 579.897L329.243 578.889L328.739 578.025L327.011 579.033Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls9}
         />
         <motion.path
            d="M202.249 581.802C202.108 581.268 201.561 580.949 201.027 581.09L192.323 583.378C191.789 583.518 191.47 584.065 191.61 584.599C191.75 585.134 192.297 585.453 192.831 585.312L200.569 583.278L202.603 591.015C202.743 591.549 203.29 591.869 203.824 591.728C204.358 591.588 204.677 591.041 204.537 590.507L202.249 581.802ZM201.641 583.424L202.145 582.561L200.418 581.553L199.914 582.416L201.641 583.424Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls1}
         />

         <motion.path
            d="M206.594 574.113C206.501 573.569 205.984 573.203 205.44 573.296L196.569 574.817C196.025 574.911 195.659 575.428 195.753 575.972C195.846 576.516 196.363 576.882 196.907 576.789L204.792 575.437L206.144 583.321C206.237 583.866 206.754 584.231 207.299 584.138C207.843 584.045 208.209 583.528 208.115 582.983L206.594 574.113ZM205.848 575.676L206.425 574.859L204.792 573.705L204.215 574.521L205.848 575.676Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls2}
         />
         <motion.path
            d="M212.229 566.643C212.183 566.093 211.7 565.683 211.15 565.729L202.181 566.471C201.63 566.517 201.221 567 201.266 567.55C201.312 568.101 201.795 568.51 202.345 568.464L210.318 567.805L210.978 575.777C211.023 576.328 211.507 576.737 212.057 576.691C212.607 576.646 213.017 576.163 212.971 575.612L212.229 566.643ZM211.349 568.135L211.995 567.372L210.469 566.079L209.823 566.842L211.349 568.135Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls3}
         />

         <motion.path
            d="M389.93 665.904C390.362 666.249 390.991 666.179 391.336 665.748L396.961 658.722C397.306 658.291 397.236 657.662 396.805 657.317C396.374 656.971 395.745 657.041 395.4 657.472L390.4 663.717L384.155 658.718C383.723 658.372 383.094 658.442 382.749 658.873C382.404 659.304 382.473 659.934 382.905 660.279L389.93 665.904ZM389.451 664.239L389.561 665.233L391.549 665.013L391.439 664.019L389.451 664.239Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls1}
         />

         <motion.path
            d="M390.293 674.679C390.683 675.07 391.317 675.07 391.707 674.679L398.071 668.315C398.462 667.925 398.462 667.292 398.071 666.901C397.681 666.511 397.047 666.511 396.657 666.901L391 672.558L385.343 666.901C384.953 666.511 384.319 666.511 383.929 666.901C383.538 667.292 383.538 667.925 383.929 668.315L390.293 674.679ZM390 672.972V673.972H392V672.972H390Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls2}
         />

         <motion.path
            d="M389.694 683.645C390.051 684.066 390.682 684.118 391.103 683.761L397.97 677.944C398.391 677.587 398.444 676.956 398.086 676.534C397.729 676.113 397.098 676.061 396.677 676.418L390.573 681.589L385.402 675.485C385.045 675.064 384.414 675.011 383.992 675.368C383.571 675.725 383.519 676.356 383.876 676.778L389.694 683.645ZM389.542 681.919L389.46 682.916L391.453 683.081L391.536 682.084L389.542 681.919Z"
            fill="white"
            variants={arrowIcon}
            initial="hidden"
            animate={controls3}
         />
         <defs>
            <filter
               id="filter0_b_226_1189"
               x="36"
               y="-1"
               width="112"
               height="112"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="6" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter1_b_226_1189"
               x="32"
               y="-7"
               width="45"
               height="45"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="3.5" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter2_b_226_1189"
               x="195"
               y="-1"
               width="112"
               height="112"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="6" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter3_b_226_1189"
               x="38"
               y="223"
               width="199"
               height="198"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="6" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter4_b_226_1189"
               x="62"
               y="558"
               width="94"
               height="94"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="6" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter5_b_226_1189"
               x="142"
               y="802"
               width="94"
               height="94"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="6" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter6_b_226_1189"
               x="47"
               y="802"
               width="94"
               height="94"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="6" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter7_b_226_1189"
               x="55"
               y="554"
               width="45"
               height="45"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="3.5" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter8_b_226_1189"
               x="41"
               y="794"
               width="45"
               height="45"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="3.5" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter9_b_226_1189"
               x="184"
               y="601.061"
               width="23"
               height="23"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="2" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter10_b_226_1189"
               x="214"
               y="542"
               width="23"
               height="23"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="2" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter11_b_226_1189"
               x="289"
               y="539"
               width="23"
               height="23"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="2" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter12_b_226_1189"
               x="324"
               y="601.061"
               width="23"
               height="23"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="2" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter13_b_226_1189"
               x="272"
               y="721"
               width="24"
               height="24"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="2" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter14_b_226_1189"
               x="318"
               y="721"
               width="24"
               height="24"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="2" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter15_b_226_1189"
               x="193"
               y="721"
               width="24"
               height="24"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="2" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter16_b_226_1189"
               x="143"
               y="721"
               width="24"
               height="24"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="2" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter17_b_226_1189"
               x="96"
               y="721"
               width="24"
               height="24"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="2" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <filter
               id="filter18_b_226_1189"
               x="236"
               y="802"
               width="168"
               height="94"
               filterUnits="userSpaceOnUse"
               colorInterpolationFilters="sRGB"
            >
               <feFlood floodOpacity="0" result="BackgroundImageFix" />
               <feGaussianBlur in="BackgroundImageFix" stdDeviation="6" />
               <feComposite
                  in2="SourceAlpha"
                  operator="in"
                  result="effect1_backgroundBlur_226_1189"
               />
               <feBlend
                  mode="normal"
                  in="SourceGraphic"
                  in2="effect1_backgroundBlur_226_1189"
                  result="shape"
               />
            </filter>
            <radialGradient
               id="paint0_radial_226_1189"
               cx="0"
               cy="0"
               r="1"
               gradientUnits="userSpaceOnUse"
               gradientTransform="translate(92 50.05) rotate(144.765) scale(84.8445)"
            >
               <stop stopColor="#4E4E4E" />
               <stop offset="1" stopColor="#151515" />
            </radialGradient>
            <radialGradient
               id="paint1_radial_226_1189"
               cx="0"
               cy="0"
               r="1"
               gradientUnits="userSpaceOnUse"
               gradientTransform="translate(54.5 13.7562) rotate(144.765) scale(29.8884)"
            >
               <stop stopColor="#4E4E4E" />
               <stop offset="1" stopColor="#151515" />
            </radialGradient>
            <radialGradient
               id="paint2_radial_226_1189"
               cx="0"
               cy="0"
               r="1"
               gradientUnits="userSpaceOnUse"
               gradientTransform="translate(251 50.05) rotate(144.765) scale(84.8445)"
            >
               <stop stopColor="#4E4E4E" />
               <stop offset="1" stopColor="#151515" />
            </radialGradient>
            <radialGradient
               id="paint3_radial_226_1189"
               cx="0"
               cy="0"
               r="1"
               gradientUnits="userSpaceOnUse"
               gradientTransform="translate(137.5 312.212) rotate(144.919) scale(168.405 168.08)"
            >
               <stop stopColor="#4E4E4E" />
               <stop offset="1" stopColor="#151515" />
            </radialGradient>
            <radialGradient
               id="paint4_radial_226_1189"
               cx="0"
               cy="0"
               r="1"
               gradientUnits="userSpaceOnUse"
               gradientTransform="translate(109 601.062) rotate(144.765) scale(67.49)"
            >
               <stop stopColor="#4E4E4E" />
               <stop offset="1" stopColor="#151515" />
            </radialGradient>
            <radialGradient
               id="paint5_radial_226_1189"
               cx="0"
               cy="0"
               r="1"
               gradientUnits="userSpaceOnUse"
               gradientTransform="translate(189 845.062) rotate(144.765) scale(67.49)"
            >
               <stop stopColor="#4E4E4E" />
               <stop offset="1" stopColor="#151515" />
            </radialGradient>
            <radialGradient
               id="paint6_radial_226_1189"
               cx="0"
               cy="0"
               r="1"
               gradientUnits="userSpaceOnUse"
               gradientTransform="translate(94 845.062) rotate(144.765) scale(67.49)"
            >
               <stop stopColor="#4E4E4E" />
               <stop offset="1" stopColor="#151515" />
            </radialGradient>
            <radialGradient
               id="paint7_radial_226_1189"
               cx="0"
               cy="0"
               r="1"
               gradientUnits="userSpaceOnUse"
               gradientTransform="translate(77.5 574.756) rotate(144.765) scale(29.8884)"
            >
               <stop stopColor="#4E4E4E" />
               <stop offset="1" stopColor="#151515" />
            </radialGradient>
            <radialGradient
               id="paint8_radial_226_1189"
               cx="0"
               cy="0"
               r="1"
               gradientUnits="userSpaceOnUse"
               gradientTransform="translate(63.5 814.756) rotate(144.765) scale(29.8884)"
            >
               <stop stopColor="#4E4E4E" />
               <stop offset="1" stopColor="#151515" />
            </radialGradient>
            <radialGradient
               id="paint9_radial_226_1189"
               cx="0"
               cy="0"
               r="1"
               gradientUnits="userSpaceOnUse"
               gradientTransform="translate(320 845.062) rotate(161.049) scale(119.899 78.1499)"
            >
               <stop stopColor="#4E4E4E" />
               <stop offset="1" stopColor="#151515" />
            </radialGradient>
            <clipPath id="clip0_226_1189">
               <rect
                  width="36"
                  height="36"
                  fill="white"
                  transform="translate(74 37)"
               />
            </clipPath>
            <clipPath id="clip1_226_1189">
               <rect
                  width="36.0291"
                  height="36"
                  fill="white"
                  transform="translate(233 37)"
               />
            </clipPath>
            <clipPath id="clip2_226_1189">
               <rect
                  width="26.1021"
                  height="26"
                  fill="white"
                  transform="translate(96 592)"
               />
            </clipPath>
            <clipPath id="clip3_226_1189">
               <rect
                  width="28.4896"
                  height="30"
                  fill="white"
                  transform="translate(80 834)"
               />
            </clipPath>
            <clipPath id="clip4_226_1189">
               <rect
                  width="30"
                  height="30"
                  fill="white"
                  transform="translate(174 834)"
               />
            </clipPath>
         </defs>
      </motion.svg>
   );
};

export default MobileWorkProcessAnimation;
