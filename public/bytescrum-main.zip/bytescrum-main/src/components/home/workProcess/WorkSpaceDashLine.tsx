"use client";
import { motion, useAnimation } from "framer-motion";
import "./style.css";
import { useEffect } from "react";
import useSvgAttribitesDottedLine from "@/common/hooks/useSvgAttribitesDottedLine";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";

const icon = {
   hidden: {
      opacity: 0,
      pathLength: 0,
   },
   visible: {
      opacity: 1,
      pathLength: 1,
   },
};

const useAnimatedLine = (delay: any, repeatDelay: any, duration: any) => {
   const controls = useAnimation();

   useEffect(() => {
      controls.start("visible", {
         repeat: Infinity,
         repeatType: "loop",
         repeatDelay: repeatDelay,
         duration: duration,
         delay: delay,
         ease: "easeInOut",
      });
   }, [controls, delay, repeatDelay, duration]);

   return controls;
};

const WorkSpaceDashLine = () => {
   const controls1 = useAnimatedLine(0, 0.2, 0.2);
   const controls2 = useAnimatedLine(0.1, 0.2, 0.2);
   const controls3 = useAnimatedLine(0.2, 0.2, 0.2);
   const controls4 = useAnimatedLine(0.3, 0.2, 0.2);
   const strokeColor = "#fff";
   const { svgHeight, svgWidth, border } = useSvgAttribitesDottedLine();

   return (
      // <div className={twMerge(clsx(`${border} relative z-10`))}>
      <div className={twMerge(clsx(`relative z-10 hidden`))}>
         <motion.svg
            width={svgWidth}
            height={svgHeight}
            // width="310"
            // height="650"
            viewBox="0 0 310 650"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
         >
            <motion.line
               x1="310"
               y1="648"
               x2="306"
               y2="648"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M298 648H290.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M282 648H274.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M266 648H258.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M250 648H242.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M234 648H226.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M218 648H210.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M202 648H194.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M186 648H178.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M170 648H162.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M154 648H146.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M138 648H130.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M122 648H114.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M106 648H98.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M90 648H82.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M74 648H66.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M58 647L51 646"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M45 644L38 641"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M32 637L25 632"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M19 626L14 620"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M11 613L8 605"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M5.5 598L4.00012 590"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M3 582L2.99976 574.062"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M2.97656 565.938L2.97632 558"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M2.95312 549.877L2.95288 541.939"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M2.92969 533.815L2.92945 525.877"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M2.90625 517.754L2.90601 509.815"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M2.88281 501.692L2.88257 493.754"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M2.85937 485.631L2.85913 477.692"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M2.83594 469.569L2.8357 461.631"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M2.8125 453.508L2.81226 445.569"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M2.78906 437.446L2.78882 429.508"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M2.76562 421.385L2.76538 413.446"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M2.74219 405.323L2.74195 397.385"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M2.71875 389.262L2.71851 381.323"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M2.69531 373.2L2.69507 365.262"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M2.67187 357.139L2.67163 349.2"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M2.64844 341.077L2.6482 333.139"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M2.625 325.016L2.62476 317.077"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M2.60156 308.954L2.60132 301.016"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M2.57812 292.893L2.57788 284.954"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M2.55469 276.831L2.55445 268.893"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M2.53125 260.77L2.53101 252.831"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M2.50781 244.708L2.50757 236.77"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M2.48437 228.646L2.48413 220.708"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M2.46094 212.585L2.4607 204.647"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M2.4375 196.523L2.43726 188.585"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M2.41406 180.462L2.41382 172.523"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M2.39062 164.4L2.39038 156.462"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M2.36719 148.339L2.36695 140.4"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M2.34375 132.277L2.34351 124.339"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M2.32031 116.216L2.32007 108.277"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M2.29687 100.154L2.29663 92.2159"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M2.27344 84.0928L2.2732 76.1543"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M2.25 68.0313L2.24976 60.0928"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M3.5 51L5.5 43.5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M7.89062 36.5L11 30"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M15.5 23.5L20.5 18"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M26.5 13.5L33 10"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
            <motion.path
               d="M40 7L47 5"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls4}
            />
            <motion.path
               d="M54.5 3.30005L62 2.30005"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls1}
            />
            <motion.path
               d="M69.0058 2.00013L76.5 2"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls2}
            />
            <motion.path
               d="M83 2L85.5 2"
               stroke={strokeColor}
               strokeWidth="4"
               variants={icon}
               initial="hidden"
               animate={controls3}
            />
         </motion.svg>
      </div>
   );
};

export default WorkSpaceDashLine;
