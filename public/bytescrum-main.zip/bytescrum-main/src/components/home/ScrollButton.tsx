"use client";

import { Icon } from "@iconify/react/dist/iconify.js";
import { useMediaQuery } from "@react-hook/media-query";
import clsx from "clsx";
import Image from "next/image";
import { Link as ScrollLink } from "react-scroll";
import { twMerge } from "tailwind-merge";

interface IProps {
   img: any;
   icon: string;
   link: string;
   className?: string;
   iconClass?: string;
   iconWrapper?: string;
   imgClass?: string;
}

const ScrollButton = ({
   img,
   icon,
   link,
   className,
   iconClass,
   iconWrapper,
   imgClass,
}: IProps) => {
   return (
      <div>
         <div
            className={twMerge(
               clsx("relative z-20  w-fit md:hidden", className)
            )}
            data-aos={"fade-up"}
            data-aos-duration="1500"
            data-aos-delay="150"
            data-aos-anchor-placement="top-bottom"
         >
            <ScrollLink
               to={link}
               smooth={true}
               duration={500}
               className=" cursor-pointer  "
            >
               <Image
                  src={img}
                  width={120}
                  height={120}
                  alt="Banner"
                  className={twMerge(
                     clsx(
                        "relative w-[80px] md:w-[130px] lg:w-[160px] rotate-180 scroll",
                        imgClass
                     )
                  )}
               />
               <span
                  className={twMerge(
                     clsx(
                        " absolute bg-[#312938] w-12 h-12 md:w-[80px] md:h-[80px] lg:w-[100px] lg:h-[100px] grid place-items-center rounded-full top-[16px] left-[16.3px] md:top-[23px] md:left-[25px] lg:top-[28px] lg:left-[30px]",
                        iconWrapper
                     )
                  )}
               >
                  <Icon
                     icon={icon}
                     className={twMerge(
                        clsx(
                           " w-[30px] h-[30px]  md:w-[45px] md:h-[45px]   lg:w-[60px] lg:h-[60px]",
                           iconClass
                        )
                     )}
                  />
               </span>
            </ScrollLink>
         </div>
         <div
            className={twMerge(
               clsx("relative z-20  w-fit  md:block hidden", className)
            )}
            data-aos={"fade-left"}
            data-aos-duration="1500"
            data-aos-delay="150"
            data-aos-anchor-placement="top-bottom"
         >
            <ScrollLink
               to={link}
               smooth={true}
               duration={500}
               className=" cursor-pointer  "
            >
               <Image
                  src={img}
                  width={120}
                  height={120}
                  alt="Banner"
                  className={twMerge(
                     clsx(
                        "relative w-[80px] md:w-[130px] lg:w-[160px] rotate-180 scroll",
                        imgClass
                     )
                  )}
               />
               <span
                  className={twMerge(
                     clsx(
                        " absolute bg-[#312938] w-12 h-12 md:w-[80px] md:h-[80px] lg:w-[100px] lg:h-[100px] grid place-items-center rounded-full top-[16px] left-[16.3px] md:top-[23px] md:left-[25px] lg:top-[28px] lg:left-[30px]",
                        iconWrapper
                     )
                  )}
               >
                  <Icon
                     icon={icon}
                     className={twMerge(
                        clsx(
                           " w-[30px] h-[30px]  md:w-[45px] md:h-[45px]   lg:w-[60px] lg:h-[60px]",
                           iconClass
                        )
                     )}
                  />
               </span>
            </ScrollLink>
         </div>
      </div>
   );
};

export default ScrollButton;
