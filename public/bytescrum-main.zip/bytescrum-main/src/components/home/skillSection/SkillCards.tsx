"use client";

import React, { useEffect, useState } from "react";
import SkillCard from "./SkillCard";
import clsx from "clsx";
import homeData from "../../../common/data/homeData.json";
import "./skill.css";

interface IProps {
   className?: string;
}

const SkillCards = ({ className }: IProps) => {
   const skillData = homeData.skillSection.skillData;
   const [flipIndex, setFlipIndex] = useState(0);

   useEffect(() => {
      const interval = setInterval(() => {
         setFlipIndex((prevIndex: any) => (prevIndex + 1) % skillData.length);
      }, 1500);

      return () => clearInterval(interval);
   }, []);

   return (
      <div className="grid grid-cols-3 gap-[2px] xs:gap-2">
         {skillData.map((skill: any, index: any) => (
            <div
               key={skill._id}
               className={clsx(
                  "last:col-start-3 last:col-end-4 [&:nth-child(7)]:col-start-2  [&:nth-child(7)]:col-end-3 rounded-[10px] md:rounded-[13px] border-2 border-transparent hover:border-[#fff]   "
               )}
               data-aos={"fade-left"}
               data-aos-duration="500"
               data-aos-delay={index * 150}
               data-aos-anchor-placement="top-bottom"
            >
               <SkillCard
                  key={skill._id}
                  items={skill.items}
                  transitionDuration={skill.transitionDuration}
                  interval={skill.interval}
                  _index={index}
                  flipTrigger={index === flipIndex}
               />
            </div>
         ))}
      </div>
   );
};

export default SkillCards;
