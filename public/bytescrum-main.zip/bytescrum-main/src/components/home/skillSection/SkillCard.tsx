import clsx from "clsx";
import { useState, useEffect } from "react";
import { twMerge } from "tailwind-merge";
import "./skill.css";

interface IProps {
   items: any;
   interval?: number;
   transitionDuration?: number;
   className?: string;
   _index: number;
   flipTrigger: boolean; // New prop to control flipping
}

const SkillCard = ({
   items,
   interval = 1000,
   transitionDuration = 1000,
   className,
   _index,
   flipTrigger,
}: IProps) => {
   const [currentIndex, setCurrentIndex] = useState(0);
   const [flipClass, setFlipClass] = useState("flip-card-Y");

   useEffect(() => {
      const classInterval = setInterval(() => {
         const newClass = Math.random() < 0.5 ? "flip-card-Y " : "flip-card-X";
         setFlipClass(newClass);
      }, interval);

      return () => clearInterval(classInterval);
   }, []);

   useEffect(() => {
      if (flipTrigger) {
         setCurrentIndex((_index) => (_index + 1) % items.length);
      }
   }, [flipTrigger, items.length]);

   return (
      <div
         className={twMerge(
            clsx(
               "relative md:rounded-[13px]  w-[90px] h-[80px] xs:w-[115px] xs:h-[96px] md:w-[165px] lg:w-[150px] md:h-[105px]  grid place-items-center transition-all ease-in-out ",
               className
            )
         )}
      >
         {items.map((item: any, index: any) => (
            <div
               key={index}
               className={`px-2 w-[90px] h-[80px] xs:w-[115px] xs:h-[96px] rounded-[7px] xs:rounded-[10px]  md:w-[165px] lg:w-[150px] grid place-items-center md:h-[105px]  absolute  aspect-ratio:16/9 flip-card-inner   ease-in duration-${transitionDuration} ${
                  index === currentIndex
                     ? "opacity-100  bg-[#555555] "
                     : `opacity-0  ${flipClass}   `
               }`}
            >
               <img src={item} className=" px-2 py-1 w-fit h-fit " />
            </div>
         ))}
      </div>
   );
};

export default SkillCard;
