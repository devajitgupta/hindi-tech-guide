"use client";
import HeroTitle from "./HeroTitle";
import "./style.css";
import HeroSubTitle from "./HeroSubTitle";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import { Button } from "@nextui-org/react";
import { useRouter } from "next/navigation";
import { TLocale } from "@/i18n-config";
type Props = {
   lang: TLocale;
   langText: any;
};
interface IProps {
   className?: string;
}

const HomeBanner = ({ className, langText, lang }: IProps & Props) => {
  const project = langText.portfolioSection.portfolioData.find((proj: any) => proj.id === "/perfect-screenshot");
   const data = langText.heroSection;
   const router = useRouter();
   return (
      <div
         className={twMerge(
            clsx(
               "relative max-w-[1728px] min-h-[100dvh]  overflow-hidden",
               className
            )
         )}
      >
         <div className=" hidden md:block   absolute top-0  right-0 kenburns-bottom-left kenburns-bottom-right kenburns-top-left z-10 bg-[url('/herobanner.png')] bg-auto md:bg-cover   bg-no-repeat bg-right md:bg-center w-full h-full overflow-hidden">
            {/* NOTE: This is Hero Animated  Banner for Desktop */}
         </div>
         <div className="  md:hidden  absolute top-0  right-0 kenburns-bottom-left kenburns-bottom-right kenburns-top-left z-10 bg-[url('/mobildeBanner.png')] bg-cover   bg-no-repeat bg-right md:bg-center w-full h-full">
            {/* NOTE: This is Hero Animated  Banner for Mobile */}
         </div>
         <div className=" min-h-[85vh] md:min-h-[65vh]  xl:min-h-[100vh] heroSectionResponsive  grid items-center  w-screen relative overflow-hidden">
            <div className="grid heroLeftWrapper gap-[10px] xs:gap-[30px] xs:mt-5 items-center justify-start  md:px-16 py-4 px-4 z-20">
               <div className="grid items-center  justify-center md:justify-start gap-[10px]   ">
                  <p
                     className="text-center text-[14px] md:text-[20px] md:text-start tracking-[2.8px] md:-mb-4 z-20 inter digitalText"
                     data-aos="fade-up"
                     data-aos-duration="300"
                     // data-aos-delay="300"
                  >
                     {data.text}
                  </p>
                  <div
                     className="gird place-items-center  md:w-fit "
                     data-aos="fade-up"
                     data-aos-duration="700"
                     data-aos-delay="30"
                  >
                     <HeroTitle title={data.title} />
                  </div>

                  <div
                     className="flex gap-4  md:justify-start md:gap-[30px]   "
                     data-aos="fade-up"
                     data-aos-duration="1200"
                     data-aos-delay="60"
                  >
                     <HeroSubTitle
                        subtitle={data.subtitle}
                        subtitleData={data.subtitleData}
                        subtitleSequence={data.subtitleSequence}
                        animationDuration={data.animationDuration}
                     />
                  </div>
               </div>
               <p
                  className=" heroPara text-center md:text-start text-[16px] md:text-[18px] max-w-[690px] inter text-[#fafafa]"
                  data-aos="fade-up"
                  data-aos-duration="1500"
                  data-aos-delay="90"
               >
                  {data.para}
               </p>

               <div
                  className="mt-[10px] grid place-items-center md:place-items-start justify-center md:justify-start"
                  data-aos="fade-up"
                  data-aos-duration="1800"
                  data-aos-delay="120"
                  data-aos-anchor-placement="top-bottom"
               >
                  <Button
                     className=" text-[#1a1a1a]  px-[30px] py-[10px] text-[16px] border !bg-white after:bg-[#262626]/35 after:text-white homeBtn "
                     onPress={() => router.push("/contact-us")}
                  >
                     {data.btnText}
                  </Button>
               </div>
            </div>
         </div>
      </div>
   );
};

export default HomeBanner;
