import clsx from "clsx";
import Image from "next/image";
import { twMerge } from "tailwind-merge";

interface IProps {
   logo: any;
   width: number;
   height: number;
   mobileWidth?: number;
   mobileHeight?: number;
   className?: string;
}

const TrustedCard = ({
   logo,
   className,
   width,
   height,
   mobileWidth,
   mobileHeight,
}: IProps) => {
   return (
      <div
         className={clsx(
            "w-[150px] md:w-[210px] h-[60px] md:h-[79px] border border-[#5a5a5a] bg-[#191919] grid place-items-center md:rounded-[13px] rounded-[6px] ",
            className
         )}
      >
         <img
            src={logo}
            alt={logo}
            className={clsx(
               `md:min-w-${width} md:min-h-${height} w-${mobileWidth} h-${mobileHeight}`
            )}
         />
      </div>
   );
};

export default TrustedCard;
