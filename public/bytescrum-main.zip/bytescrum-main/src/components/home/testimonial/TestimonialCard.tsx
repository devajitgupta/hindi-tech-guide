"use client";
import { Icon } from "@iconify/react/dist/iconify.js";
import clsx from "clsx";
import { useEffect, useState } from "react";
import { useMediaQuery } from "@react-hook/media-query";
import "./testimonial.css";
import { twMerge } from "tailwind-merge";
import Image from "next/image";
interface IProps {
   className?: string;
   langText: any;
}

const TestimonialCard = ({ className, langText }: IProps) => {
   const clientData = langText;
   const [profileData, setProfileData] = useState<any>(clientData);
   const [currProfileIndex, setCurrProfileIndex] = useState<number>(0);
   const [currProfile, setCurrProfile] = useState<any>(
      profileData[Object.keys(profileData)[0]]
   );
   const [selectedProfile, setSelectedProfile] = useState<string>(
      Object.keys(profileData)[0]
   );

   const isSmallScreen = useMediaQuery("(max-width: 639px)");
   const isMediumScreen = useMediaQuery(
      "(min-width: 640px) and (max-width: 1023px)"
   );
   const isLargeScreen = useMediaQuery("(min-width: 1024px)");

   const truncateText = (text: any, wordLimit: any) => {
      const words = text.split(" ");
      if (words.length > wordLimit) {
         return words.slice(0, wordLimit).join(" ") + "...";
      }
      return text;
   };

   const handleProfile = (key: string, index: number) => {
      setCurrProfile(profileData[key]);
      setSelectedProfile(key);
      setCurrProfileIndex(index);
   };

   const nextProfile = () => {
      const keys = Object.keys(profileData);
      const nextIndex = (currProfileIndex + 1) % keys.length;
      const nextKey = keys[nextIndex];
      handleProfile(nextKey, nextIndex);
   };

   const prevProfile = () => {
      const keys = Object.keys(profileData);
      const prevIndex = (currProfileIndex - 1 + keys.length) % keys.length;
      const prevKey = keys[prevIndex];
      handleProfile(prevKey, prevIndex);
   };

   useEffect(() => {
      const interval = setInterval(() => {
         const keys = Object.keys(profileData);
         const nextIndex = (currProfileIndex + 1) % keys.length;
         const nextKey = keys[nextIndex];
         handleProfile(nextKey, nextIndex);
      }, 5000);

      return () => {
         clearInterval(interval);
      };
   }, [currProfileIndex]);

   const visibleProfiles = Object.keys(profileData).slice(
      0,
      isSmallScreen ? 4 : undefined
   );
   return (
      <div className={twMerge(clsx("grid gap-[65px]", className))}>
         <div className="flex items-center justify-center gap-[10px] md:gap-[40px]">
            {visibleProfiles.map((key, index) => (
               <div
                  className=" odd:mt-[-40px] even:mt-[40px] md:odd:mt-[-80px]  md:even:mt-[80px]"
                  key={index}
                  data-aos={index % 2 === 0 ? "zoom-in-up" : "zoom-in-down"}
                  data-aos-duration="800"
                  data-aos-delay={index * 200}
                  data-aos-anchor-placement="top-bottom"
               >
                  <Image
                     width={155}
                     height={0}
                     priority={true}
                     src={profileData[key].profile}
                     alt={profileData[key].profile}
                     className={clsx(
                        " border-2 h-auto md:border-4 cursor-pointer   rounded-full mt-[60px]",
                        {
                           "border-blue-500 scale-110  glowEffect":
                              selectedProfile === key,
                           noGlowEffect: selectedProfile !== key,
                        }
                     )}
                     onClick={() => handleProfile(key, index)}
                  />
               </div>
            ))}
         </div>
         <div className="grid place-items-center  gap-[20px]">
            <img src="testimonial/comma.png" alt="" />
            <div className="grid place-items-center gap-[5px]">
               <h3 className="text-[18px] md:text-[20px] font-bold  font-poppins text-[#ffffff] poppins">
                  {currProfile.name}
               </h3>
               <span className="text-[14px] md:text-[16px] leading-[24px] md:leading-[28px] text-[#b2b2b2] inter">
                  {currProfile.clientPosition}
               </span>
            </div>
            <div className="grid grid-cols-9 gap-y-[25px]">
               <div className="md:grid items-center justify-start hidden ">
                  <div
                     className=" p-[10px] bg-[#1b1b1b] rounded-full grid place-items-center"
                     onClick={prevProfile}
                  >
                     <Icon
                        icon="carbon:arrow-left"
                        className="text-2xl text-[#ffffff]"
                     />
                  </div>
               </div>
               <div className="col-span-full md:col-span-7 md:max-w-[875px]  md:min-h-[200px] grid place-items-center">
                  <p className="  text-center text-[14px] leading-[24px] md:text-[16px] md:leading-[28px]  text-[#ffffff] inter">
                     {isSmallScreen
                        ? truncateText(currProfile.text, 25)
                        : isMediumScreen
                        ? truncateText(currProfile.text, 50)
                        : currProfile.text}
                  </p>
                  {/* <span className="hidden md:block  w-full h-[1px] divider bg-[#2f2f2f]"></span> */}
               </div>

               <div className="grid col-span-4  items-center justify-end md:hidden">
                  <div
                     className=" p-[10px] bg-[#1b1b1b] rounded-full grid place-items-center"
                     onClick={prevProfile}
                  >
                     <Icon
                        icon="carbon:arrow-left"
                        className="text-2xl text-[#ffffff]"
                     />
                  </div>
               </div>
               <div className="md:hidden"></div>

               <div className="grid col-span-4 md:col-span-1 items-center justify-start md:justify-end">
                  <div
                     className=" p-[10px] bg-[#1b1b1b] rounded-full grid place-items-center"
                     onClick={nextProfile}
                  >
                     <Icon
                        icon="ph:arrow-right"
                        className="text-2xl text-[#ffffff]"
                     />
                  </div>
               </div>
               {/* <span className="block md:hidden col-span-9 w-full  h-[1px] divider bg-[#2f2f2f]"></span> */}
            </div>
         </div>
      </div>
   );
};

export default TestimonialCard;
