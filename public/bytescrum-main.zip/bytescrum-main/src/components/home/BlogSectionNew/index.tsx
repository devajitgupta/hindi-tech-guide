// "use client";
// import BlogCard from "../blogSection/BlogCard";
// import homeData from "../../../common/data/homeData.json";
// import { useEffect, useRef, useState } from "react";
// import { motion, useScroll, useTransform, useSpring } from "framer-motion";

// const BlogSectionNew = () => {
//    const blogs = homeData.blogSection.blogs;
//    const ref = useRef<HTMLDivElement>(null);
//    const [allImagesInView, setAllImagesInView] = useState(false);
//    const [isInView, setIsInView] = useState(false); // Track if section is in view
//    const { scrollYProgress } = useScroll({
//       target: ref,
//       offset: ["start end", "end start"],
//    });

//    const smoothScrollYProgress = useSpring(scrollYProgress, {
//       damping: 30,
//       stiffness: 100,
//    });

//    const xTransform = useTransform(
//       smoothScrollYProgress,
//       [0, 1],
//       ["20%", "-20%"]
//    );

//    const yTransform = useTransform(smoothScrollYProgress, [0, 1], ["0%", "0%"]);

//    useEffect(() => {
//       const checkImagesInView = () => {
//          const gallery = ref.current;
//          if (gallery) {
//             const images = gallery.querySelectorAll<HTMLImageElement>("img");
//             const allInView = Array.from(images).every((img) => {
//                const rect = img.getBoundingClientRect();
//                return rect.top >= 0 && rect.bottom <= window.innerHeight;
//             });
//             setAllImagesInView(allInView);
//          }
//       };

//       checkImagesInView();
//       window.addEventListener("scroll", checkImagesInView);

//       return () => window.removeEventListener("scroll", checkImagesInView);
//    }, []);

//    // Handle scroll lock and unlocking for horizontal scroll
//    //    useEffect(() => {
//    //       if (isInView) {
//    //          document.body.style.overflow = "hidden"; // Disable page scroll
//    //       } else {
//    //          document.body.style.overflow = "auto"; // Re-enable page scroll
//    //       }
//    //    }, [isInView]);

//    // Handle if the section is in the viewport
//    const handleVisibilityChange = () => {
//       const rect = ref.current?.getBoundingClientRect();
//       if (rect) {
//          const isVisible = rect.top >= 0 && rect.bottom <= window.innerHeight;
//          setIsInView(isVisible);
//       }
//    };

//    useEffect(() => {
//       window.addEventListener("scroll", handleVisibilityChange);
//       return () => window.removeEventListener("scroll", handleVisibilityChange);
//    }, []);

//    const [divWidth, setDivWidth] = useState<number>(0);

//    //    useEffect(() => {
//    //       const checkDivWidth = () => {
//    //          if (ref.current) {
//    //             setDivWidth(ref.current.offsetWidth); // or use clientWidth if needed
//    //          }
//    //       };

//    //       // Check width on component mount
//    //       checkDivWidth();

//    //       // Optionally, set up a resize listener to check width on window resize
//    //       window.addEventListener("resize", checkDivWidth);

//    //       // Cleanup listener on component unmount
//    //       return () => {
//    //          window.removeEventListener("resize", checkDivWidth);
//    //       };
//    //    }, []);


//    return (
//       <div ref={ref} className="flex w-screen overflow-hidden gap-4">
//          <motion.div
//             style={{
//                x: xTransform,
//                y: yTransform,
//             }}
//             className="flex gap-60"
//          >
//             {blogs.map((blog, index) => (
//                <div key={blog.title}>
//                   <BlogCard
//                      src={blog.src}
//                      title={blog.title}
//                      text={blog.text}
//                      date={blog.date}
//                   />
//                </div>
//             ))}
//          </motion.div>
//       </div>
//    );
// };

// export default BlogSectionNew;
// "use client";

// import { motion, useTransform, useScroll } from "framer-motion";
// import { useRef } from "react";
// import homeData from "../../../common/data/homeData.json";
// import BlogCard from "../blogSection/BlogCard";

// const BlogSectionNew = () => {
//    const blogs = homeData.blogSection.blogs;
//    const targetRef = useRef<HTMLDivElement | null>(null);
//    const { scrollYProgress } = useScroll({
//       target: targetRef,
//    });

//    const x = useTransform(scrollYProgress, [0, 1], ["1%", "-73%"]);

//    return (
//       <section ref={targetRef} className="relative border h-[300dvh]">
//          <div className="sticky top-0 flex h-[80vh] boirder items-center overflow-auto ">
//             <motion.div style={{ x }} className="flex gap-4">
//                {blogs.map((blog, index) => (
//                   <BlogCard
//                      key={blog.title}
//                      src={blog.src}
//                      title={blog.title}
//                      text={blog.text}
//                      date={blog.date}
//                   />
//                ))}
//             </motion.div>
//          </div>
//       </section>
//    );
// };

// export default BlogSectionNew;

"use client";

import { motion, useTransform, useScroll, useSpring } from "framer-motion";
import { useRef } from "react";
import homeData from "../../../common/data/homeData.json";
import BlogCard from "../blogSection/BlogCard";

const BlogSectionNew = () => {
   const blogs = homeData.blogSection.blogs;
   const targetRef = useRef<HTMLDivElement | null>(null);
   const { scrollYProgress } = useScroll({
      target: targetRef,
   });

   // Calculate the total scroll range dynamically
   const cardWidth = 890; // Adjust based on your BlogCard width
   const gap = 128; // Tailwind's `gap-4` (16px)
   const totalWidth = blogs.length * (cardWidth + gap);

   // Adjust x transform dynamically
   // const x = useTransform(
   //    scrollYProgress,
   //    [0, 1],
   //    ["1%", `-${totalWidth - window.innerWidth}px`]
   // );

   const rawX = useTransform(
      scrollYProgress,
      [0, 1],
      ["50%", `-${totalWidth - window.innerWidth}px`]
   );
   const x = useSpring(rawX, {
      stiffness: 100, // Lower = smoother movement
      damping: 30, // Higher = more resistance, less overshoot
      mass: 1, // Lower = quicker response, Higher = sluggish
   });


   return (
      <div
         ref={targetRef}
         className="relative   "
         style={{ height: totalWidth }}
      >
         <div className="sticky top-0 flex h-screen items-center overflow-hidden">
            <motion.div
               style={{ x, width: totalWidth }}
               className="flex gap-32"
            >
               {blogs.map((blog) => (
                  <div>
                     <BlogCard
                        key={blog.title}
                        src={blog.src}
                        title={blog.title}
                        text={blog.text}
                        date={blog.date}
                     />
                  </div>
               ))}
            </motion.div>
         </div>
      </div>
   );
};

export default BlogSectionNew;
