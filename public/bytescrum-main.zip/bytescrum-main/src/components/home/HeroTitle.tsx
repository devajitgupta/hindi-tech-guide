"use client";

import { useRef, useEffect } from "react";
import "./style.css";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";

interface IProps {
   title: string;
   className?: string;
}

const HeroTitle = ({ className, title }: IProps) => {
   const videoRef = useRef<HTMLVideoElement>(null);

   useEffect(() => {
      if (videoRef.current) {
         videoRef.current.playbackRate = 1;
      }
   }, []);

   return (
      <div
         className={twMerge(
            clsx(
               "grid items-center  justify-center md:justify-start",
               className
            )
         )}
      >
         <div className="  heroTitle px-[4px] md:px-0 md:top-0 bg-black mix-blend-multiply ">
            <h1 className=" text-center text-[32px] sm:text-[42px] md:text-[56px] lg:text-[70px] font-black text-[#ffffff] poppins">
               {title}
            </h1>
         </div>
      </div>
   );
};

export default HeroTitle;
