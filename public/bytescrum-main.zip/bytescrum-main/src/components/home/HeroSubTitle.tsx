"use client";

// import clsx from "clsx";
// import { useEffect, useState } from "react";
// import "animate.css";
// import "./style.css";

// const HeroSubTitle: React.FC = () => {
//    const [flipIndex, setFlipIndex] = useState(0);
//    const flips = ["Mobile Apps", "Blockchain", "Web Services"];
//    const subtitleData = [
//       {
//          icon: "/AI.svg",
//          title: "Mobile Apps",
//       },
//       {
//          icon: "/AI.svg",
//          title: "Mobile Apps",
//       },
//       {
//          icon: "/AI.svg",
//          title: "Mobile Apps",
//       },
//    ];
//    const textBeforeFlip = "Mobile Apps";
//    const textAfterFlip = "Development";

//    useEffect(() => {
//       const interval = setInterval(() => {
//          setFlipIndex((prevIndex) => (prevIndex + 1) % subtitleData.length);
//       }, 2500);
//       return () => clearInterval(interval);
//    }, []);

//    return (
//       <div className="flex gap-4 justify-start md:gap-[30px] items-center SubTitle ">
//          <div
//             className={`transition-transform duration-2000 transform ${
//                flipIndex !== 0 ? "rotate-180" : "rotate-0"
//             }`}
//          >
//             <img
//                src="/heroIcon.svg"
//                width={98}
//                height={98}
//                alt="Icon"
//                className="w-[50px] md:w-[98px]"
//             />
//          </div>
//          <div className="flex flex-col">
//             <h1 className="text-white  text-[35px] md:text-[70px] font-bold from-[#0E7BDA] to-[#04D7FF] md:leading-[80px] leading-[40px] text-center  md:text-start poppins ">
//                IT Services in
//             </h1>

//             {/* <p
//                className={`text-white text-[35px] md:text-[70px] font-bold from-[#0E7BDA] to-[#04D7FF] md:leading-[80px] leading-[40px] text-center md:text-start poppins transition-opacity duration-1000 ${
//                   flipIndex !== 0 ? "hidden " : "opacity-100"
//                }`}
//             >
//                {textBeforeFlip}
//             </p> */}
//             <p
//                className={clsx(
//                   "text-white text-[35px] md:text-[70px] font-bold from-[#0E7BDA] to-[#04D7FF] md:leading-[80px] leading-[40px] text-center md:text-start poppins  subtitle flipTitle animate__animated animate__bounce transition-all duration-1000 transform"
//                )}
//             >
//                {/* {flips[flipIndex]} */}
//                {subtitleData[flipIndex.title]}
//             </p>
//          </div>
//       </div>
//    );
// };
// export default HeroSubTitle;

"use client";

import { useEffect, useRef, useState } from "react";
import "animate.css";
import "./style.css";
import { TypeAnimation } from "react-type-animation";
import { useTransition, animated } from "@react-spring/web";

interface IProps {
   subtitle: string;
   subtitleData: string[];
   subtitleSequence: any[];
   animationDuration: number[];
}

const HeroSubTitle = ({
   subtitle,
   animationDuration,
   subtitleSequence,
   subtitleData,
}: IProps) => {
   const [iconIndex, setIconIndex] = useState(0);

   useEffect(() => {
      setIconIndex(0);
   }, []);

   const transitions = useTransition(iconIndex, {
      key: iconIndex,
      from: { opacity: 0 },
      enter: { opacity: 1 },
      leave: { opacity: 0 },
      config: { duration: animationDuration[iconIndex] },
      exitBeforeEnter: true,
      onRest: (_a, _b, item) => {
         if (iconIndex === item) {
            setTimeout(() => {
               setIconIndex((state) => (state + 1) % subtitleData.length);
            }, animationDuration[iconIndex]);
         }
      },
   });

   return (
      <div className=" heroSubTitleWrapper flex gap-2 sm:gap-4 justify-start md:gap-[8px] lg:gap-[12px] items-center">
         <div className="flex fill center">
            {transitions((style, i) => (
               <animated.div
                  className=" heroSubTitleImg w-[55px] h-[55px] sm:w-[75px] sm:h-[75px] md:w-20 md:h-20 lg:w-24 lg:h-24 bg-center bg-cover"
                  style={{
                     ...style,
                     backgroundImage: `url(${subtitleData[i]})`,
                  }}
               />
            ))}
         </div>

         <div className="flex flex-col">
            <h1 className="heroSubTitle text-white text-[24px] sm:text-[32px] md:text-[50px] lg:text-[70px]  font-bold from-[#0E7BDA] to-[#04D7FF] leading-[40px] md:leading-[60px] lg:leading-[80px] md:text-start poppins">
               {subtitle}
            </h1>

            <TypeAnimation
               preRenderFirstString={true}
               sequence={subtitleSequence}
               speed={44}
               className="heroSubTitle text-white text-[24px] sm:text-[35px] md:text-[50px] lg:text-[70px] font-bold from-[#0E7BDA] to-[#04D7FF] leading-[40px] md:leading-[60px] lg:leading-[80px] text-start poppins"
               repeat={Infinity}
            />
         </div>
      </div>
   );
};

export default HeroSubTitle;
