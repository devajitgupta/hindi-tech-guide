"use client";

import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import { usePathname } from "next/navigation";
import { useInView } from "react-intersection-observer";
import statsCountUp from "../../../common/data/homeData.json";
import CountUp from "react-countup";

interface IProps {
   className?: string;
   countUpClass?: string;
   textClass?: string;
   symbolClass?: string;
   wrapper?: string;
   langText: any;
}

const StatsCountUp = ({
   className,
   countUpClass,
   textClass,
   symbolClass,
   wrapper,
   langText,
}: IProps) => {
   const pathName = usePathname();
   const { ref, inView } = useInView({
      triggerOnce: true,
      threshold: 0.5,
   });
   return (
      <div
         className={twMerge(
            clsx(
               "grid grid-cols-2 xl:grid-cols-4 gap-[15px] md:gap-[40px] py-[50px]",
               className
            )
         )}
      >
         {langText.realvalueSection.statsData.map(
            (item: any, index: number) => (
               <div
                  ref={ref}
                  key={index}
                  className={twMerge(
                     clsx(
                        "text-[#1463FD] w-full px-[15px] md:px-[25px] py-[20px] rounded-xl shadow-2xl",
                        wrapper
                     )
                  )}
                  data-aos={
                     pathName === "/services/hire-dedicated-developers"
                        ? "fade-right"
                        : "fade-up"
                  }
                  data-aos-delay={
                     pathName === "/services/hire-dedicated-developers"
                        ? (index + 1) * 300
                        : 300
                  }
                  data-aos-easing="ease-out-cubic"
                  data-aos-anchor-placement="top-bottom"
               >
                  <div
                     className={twMerge(
                        clsx(
                           "text-[45px] font-semibold poppins text-center",
                           countUpClass
                        )
                     )}
                  >
                     {inView && typeof item.number === "number" ? (
                        <CountUp
                           duration={2.5}
                           end={item.number}
                           useEasing={false}
                           enableScrollSpy={true}
                           scrollSpyOnce
                           scrollSpyDelay={800}
                           start={item.startNumber ?? 0}
                        />
                     ) : (
                        <span>{item.number ?? 0}</span> // Fallback value
                     )}
                     <span
                        className={twMerge(
                           clsx("text-[42px] md:text-[42px]", symbolClass)
                        )}
                        data-aos="zoom-in"
                        data-aos-delay="2700"
                        data-aos-once="true"
                     >
                        {item.symbol}
                     </span>
                  </div>
                  <p
                     className={twMerge(
                        clsx(
                           "text-[18px] text-white text-md font-medium text-center inter",
                           textClass
                        )
                     )}
                  >
                     {item.text}
                  </p>
               </div>
            )
         )}
      </div>
   );
};

export default StatsCountUp;
