"use client";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import { usePathname } from "next/navigation";

import useBreakpoints from "@/common/hooks/useBreakpoints ";

import dynamic from "next/dynamic";
import { cn } from "@/libs/cn";

const ChampionCard = dynamic(() => import("./ChampionCard"), {
   ssr: false,
});

interface IProps {
   className?: string;
   data?: any;
}

const ChampionCards = ({ className, data }: IProps) => {
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth >= 1279;
   const pathname = usePathname();

   return (
      <div
         className={cn({
            "hidden md:grid md:grid-cols-2 xl:grid-cols-4 gap-[26px]": [
               "/",
               "/es/",
               "/nl/",
               "/fr/",
            ].includes(pathname),
            "grid md:grid-cols-2 xl:grid-cols-3 gap-x-[20px] gap-y-5 md:gap-y-0 xl:gap-y-[20px]":
               [
                  "/services/",
                  "/es/services/",
                  "/nl/services/",
                  "/fr/services/",
               ].includes(pathname),
         })}
      >
         {data.cardData.map((item: any, index: number) => (
            <div
               className={clsx({
                  "md:even:mt-[42px] ": ["/", "/es/", "/nl/", "/fr/"].includes(
                     pathname
                  ),
               })}
               key={index}
            >
               <ChampionCard
                  index={index}
                  icon={item.icon}
                  titleOne={item.titleOne}
                  titleTwo={item.titleTwo}
                  text={item.text}
                  href={item.href}
                  btnText={data.btnText}
                  cardIcon={data.cardIcon}
                  className={twMerge(
                     matches
                        ? clsx("max-w-[325px]", {
                             "md:mt-2":
                                (index === 1 || index === 4 || index === 7) &&
                                [
                                   "/services/",
                                   "/es/services/",
                                   "/nl/services/",
                                   "/fr/services/",
                                ].includes(pathname),

                             "md:-mt-10":
                                index !== 1 &&
                                index !== 4 &&
                                index !== 7 &&
                                [
                                   "/services/",
                                   "/es/services/",
                                   "/nl/services/",
                                   "/fr/services/",
                                ].includes(pathname),
                          })
                        : clsx("max-w-[325px]", {
                             "md:-mt-10":
                                (index === 1 ||
                                   index === 3 ||
                                   index === 5 ||
                                   index === 7) &&
                                [
                                   "/services/",
                                   "/es/services/",
                                   "/nl/services/",
                                   "/fr/services/",
                                ].includes(pathname),

                             "md:mt-10":
                                index !== 0 &&
                                index !== 2 &&
                                index !== 4 &&
                                index !== 6 &&
                                [
                                   "/services/",
                                   "/es/services/",
                                   "/nl/services/",
                                   "/fr/services/",
                                ].includes(pathname),
                          })
                  )}
                  delay={index * 50}
               />
            </div>
         ))}
      </div>
   );
};

export default ChampionCards;
