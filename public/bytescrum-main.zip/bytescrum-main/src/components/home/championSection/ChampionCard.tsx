"use client";
import { Icon } from "@iconify/react/dist/iconify.js";
import clsx from "clsx";
import Image from "next/image";
import Link from "next/link";
import { useMediaQuery } from "@react-hook/media-query";
import { twMerge } from "tailwind-merge";
import { usePathname, useRouter } from "next/navigation";

interface IProps {
   icon: any;
   titleOne: string;
   titleTwo: string;
   text: string;
   href: string;
   index: number;
   className?: string;
   btnText: string;
   cardIcon: string;
   delay: number;
}

const ChampionCard = ({
   titleOne,
   titleTwo,
   text,
   href,
   icon,
   className,
   index,
   btnText,
   cardIcon,
   delay,
}: IProps) => {
   const router = useRouter();
   const isExtraSmallScreen = useMediaQuery("(max-width: 599px)");
   const pathName = usePathname();
   return (
      <div
         className={twMerge(
            clsx(
               "grid gap-[50px] md:min-h-[500px] border-[#676767]  border-2 hover:border-white rounded-xl px-[35px] py-[40px] backdrop-blur-[13px] bg-[#0f0f0f] group w-[325px] h-[500px] cursor-pointer ",
               className
            )
         )}
         data-aos="fade-up"
         data-aos-duration={300}
         data-aos-delay={isExtraSmallScreen ? 0 : delay}
         data-aos-anchor-placement="top-bottom"
         onClick={() => router.push(href)}
      >
         <Image width={75} height={75} alt="Icon" src={icon} />
         <div className="grid grid-rows-3 gap-[10px] ">
            <h3 className="text-[#ffffff] font-bold text-[20px] poppins">
               {titleOne} <br />
               {titleTwo}
            </h3>

            <div className="relative overflow-hidden row-span-2">
               <p
                  className={clsx(
                     "  md:group-hover:text-[#f5f5f5] inter absolute bottom-0 w-full h-full flex justify-center items-center text-white transition-all duration-1000 ease-in-out  transform   text-[14px] inter ",
                     { "text-[16px]": pathName === "/services" }
                  )}
               >
                  {text}
               </p>
            </div>
         </div>{" "}
         <Link
            href={href}
            className="flex items-center gap-2 text-[#ffffff] text-[20px] font-bold poppins "
         >
            {btnText}
            <Icon icon="solar:arrow-right-up-line-duotone" />
         </Link>
      </div>
   );
};

export default ChampionCard;
