"use client";

import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import { Swiper, SwiperSlide } from "swiper/react";
// import "swiper/css";
// import "swiper/css/pagination";
import "./championSection.css";
import { Autoplay, Pagination } from "swiper/modules";
import { EffectCoverflow } from "swiper/modules";

import { Icon } from "@iconify/react/dist/iconify.js";
import Link from "next/link";
import { useState } from "react";
import "swiper/css/effect-coverflow";
import homeData from "../../../common/data/homeData.json";
import Image from "next/image";
interface IProps {
   className?: string;
}

const MobileChampionCards = ({ className }: IProps) => {
   const data = homeData.chanmpionSection;
   const [currentSlide, setCurrentSlide] = useState(0);

   return (
      <div
         className={twMerge(
            clsx(
               " transition-transform duration-200 ease-in-out transform ",
               className
            )
         )}
      >
         <Swiper
            spaceBetween={40}
            autoplay={{
               delay: 3000,
               disableOnInteraction: true,
            }}
            autoHeight={true}
            modules={[Pagination, EffectCoverflow, Autoplay]}
            effect={"coverflow"}
            centeredSlides={true}
            slidesPerView={"auto"}
            followFinger={true}
            initialSlide={1}
            simulateTouch={true}
            pagination={{ clickable: true }}
            scrollbar={{ draggable: true }}
            speed={1700}
            roundLengths={true}
            coverflowEffect={{
               rotate: 0,
               stretch: 10,
               depth: 50,
               modifier: 3,
               slideShadows: true,
            }}
            loop={true}
            onSlideChange={(swiper) => setCurrentSlide(swiper.realIndex)}
            className="swipperChampion md:rounded-[16px] cursor-pointer transition-transform duration-200 ease-in-out transform rounded-[8px]"
         >
            {data.cardData.map((item: any, index: any) => (
               <SwiperSlide key={item._id}>
                  <div
                     className={clsx(
                        "md:grid md:grid-cols-2 xl:grid-cols-4 gap-[26px]",
                        {
                           "opacity-40": currentSlide !== index,
                           "opacity-100": currentSlide === index,
                        }
                     )}
                  >
                     <div
                        className={twMerge(
                           clsx(
                              "grid gap-[50px] md:min-h-[500px]  border-2  rounded-xl px-[25px] py-[30px] bg-[#0f0f0f] w-[280px] sm:w-[325px] sm:h-[500px] ",
                              {
                                 "border-[#676767]": currentSlide !== index,
                                 "border-white": currentSlide === index,
                              }
                           )
                        )}
                     >
                        <Image
                           width={75}
                           height={75}
                           alt="Icon"
                           src={item.icon}
                        />
                        <div className="grid grid-rows-3 gap-[10px] ">
                           <h3 className="text-[#ffffff] font-bold text-[20px] poppins">
                              {item.titleOne} <br />
                              {item.titleTwo}
                           </h3>

                           <div className="relative   overflow-hidden row-span-2">
                              <p
                                 className={clsx(
                                    "md:text-transparent text-[#f5f5f5] inter absolute  w-full h-full flex justify-center items-center  transition-all delay-1000 ease-linear  transform text-[16px]",
                                    {
                                       "translate-y-full ":
                                          currentSlide !== index,
                                       "bottom-0": currentSlide === index,
                                    }
                                 )}
                              >
                                 {item.text}
                              </p>
                           </div>
                        </div>
                        <Link
                           href={item.href}
                           className="flex items-center gap-2 text-[#ffffff] text-[20px] font-bold poppins"
                        >
                           Explore
                           <Icon icon="solar:arrow-right-up-line-duotone" />
                        </Link>
                     </div>
                  </div>
               </SwiperSlide>
            ))}

            {/* <SwiperSlide>
            <BlogCard />
         </SwiperSlide>
       */}
         </Swiper>
      </div>
   );
};

export default MobileChampionCards;
