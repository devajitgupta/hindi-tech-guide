"use client";

import React, {
   createContext,
   useContext,
   useState,
   useEffect,
   ReactNode,
} from "react";

export interface CookiePreferences {
   necessary: boolean;
   analytics: boolean;
   marketing: boolean;
   functional: boolean;
}

interface CookieContextType {
   preferences: CookiePreferences;
   hasConsented: boolean;
   showBanner: boolean;
   acceptAll: () => void;
   rejectAll: () => void;
   savePreferences: (prefs: CookiePreferences) => void;
   resetConsent: () => void;
}

const CookieContext = createContext<CookieContextType | undefined>(undefined);

const COOKIE_CONSENT_KEY = "bytescrum-cookie-consent";
const COOKIE_PREFERENCES_KEY = "bytescrum-cookie-preferences";

const defaultPreferences: CookiePreferences = {
   necessary: true, // Always true, cannot be disabled
   analytics: false,
   marketing: false,
   functional: false,
};

export function CookieProvider({ children }: { children: ReactNode }) {
   const [preferences, setPreferences] =
      useState<CookiePreferences>(defaultPreferences);
   const [hasConsented, setHasConsented] = useState(false);
   const [showBanner, setShowBanner] = useState(false);

   useEffect(() => {
      // Check if user has already given consent
      const consentGiven = localStorage.getItem(COOKIE_CONSENT_KEY);
      const savedPreferences = localStorage.getItem(COOKIE_PREFERENCES_KEY);

      if (consentGiven === "true" && savedPreferences) {
         try {
            const parsedPreferences = JSON.parse(savedPreferences);
            setPreferences(parsedPreferences);
            setHasConsented(true);
            setShowBanner(false);
         } catch (error) {
            console.error("Error parsing saved cookie preferences:", error);
            setShowBanner(true);
         }
      } else {
         setShowBanner(true);
      }
   }, []);

   const acceptAll = () => {
      const allAccepted: CookiePreferences = {
         necessary: true,
         analytics: true,
         marketing: true,
         functional: true,
      };
      savePreferences(allAccepted);
   };

   const rejectAll = () => {
      const onlyNecessary: CookiePreferences = {
         necessary: true,
         analytics: false,
         marketing: false,
         functional: false,
      };
      savePreferences(onlyNecessary);
   };

   const savePreferences = (prefs: CookiePreferences) => {
      // Ensure necessary cookies are always enabled
      const finalPrefs = { ...prefs, necessary: true };

      setPreferences(finalPrefs);
      setHasConsented(true);
      setShowBanner(false);

      localStorage.setItem(COOKIE_CONSENT_KEY, "true");
      localStorage.setItem(COOKIE_PREFERENCES_KEY, JSON.stringify(finalPrefs));

      // Trigger any analytics or tracking initialization based on preferences
      if (finalPrefs.analytics) {
         // Initialize analytics (Google Analytics, etc.)
      }

      if (finalPrefs.marketing) {
         // Initialize marketing pixels (Facebook Pixel, etc.)
      }

      if (finalPrefs.functional) {
         // Initialize functional cookies (chat widgets, etc.)
      }
   };

   const resetConsent = () => {
      localStorage.removeItem(COOKIE_CONSENT_KEY);
      localStorage.removeItem(COOKIE_PREFERENCES_KEY);
      setPreferences(defaultPreferences);
      setHasConsented(false);
      setShowBanner(true);
   };

   return (
      <CookieContext.Provider
         value={{
            preferences,
            hasConsented,
            showBanner,
            acceptAll,
            rejectAll,
            savePreferences,
            resetConsent,
         }}
      >
         {children}
      </CookieContext.Provider>
   );
}

export function useCookie() {
   const context = useContext(CookieContext);
   if (context === undefined) {
      throw new Error("useCookie must be used within a CookieProvider");
   }
   return context;
}
