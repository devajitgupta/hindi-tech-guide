"use client";

import React, { useState } from "react";
import { useCookie, CookiePreferences } from "./CookieContext";
import { Button } from "@nextui-org/react";

export default function CookieSettings() {
   const { preferences, savePreferences, resetConsent } = useCookie();
   const [localPreferences, setLocalPreferences] =
      useState<CookiePreferences>(preferences);
   const [isOpen, setIsOpen] = useState(false);

   const handlePreferenceChange = (
      type: keyof CookiePreferences,
      value: boolean
   ) => {
      if (type === "necessary") return; // Necessary cookies cannot be disabled
      setLocalPreferences((prev) => ({ ...prev, [type]: value }));
   };

   const handleSave = () => {
      savePreferences(localPreferences);
      setIsOpen(false);
   };

   const handleReset = () => {
      resetConsent();
      setIsOpen(false);
   };

   return (
      <>
         {/* Cookie Settings Button */}
         <Button
            size="md"
            isIconOnly
            onClick={() => setIsOpen(true)}
            className="fixed bottom-4 right-4 bg-black border primaryBorder text-white p-1 rounded-full shadow-lg hover:bg-gray-700 transition-colors z-40"
            aria-label="Cookie Settings"
         >
            <svg
               className="w-6 h-6"
               fill="none"
               stroke="currentColor"
               viewBox="0 0 24 24"
            >
               <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 100 4m0-4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 100 4m0-4v2m0-6V4"
               />
            </svg>
         </Button>

         {/* Cookie Settings Modal */}
         {isOpen && (
            <div className="fixed inset-0 z-[9999999] flex items-center justify-center bg-black bg-opacity-50">
               <div className="w-full bg-[#171717] max-w-6xl mx-4 rounded-lg shadow-2xl max-h-[90vh] overflow-y-auto">
                  {/* Header */}
                  <div className="flex items-center justify-between p-4 md:p-6 border-b border-[#272727]">
                     <h2 className="text-xl text-white font-semibold ">
                        Cookie Preferences
                     </h2>
                     <Button
                        size="sm"
                        isIconOnly
                        onClick={() => setIsOpen(false)}
                        className="bg-black border-white/50 border"
                     >
                        <svg
                           className="w-6 h-6"
                           fill="none"
                           stroke="#ffffff"
                           viewBox="0 0 24 24"
                        >
                           <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M6 18L18 6M6 6l12 12"
                           />
                        </svg>
                     </Button>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                     <p className=" mb-4 text-white/70">
                        Manage your cookie preferences for ByteScrum Tech Pvt
                        Ltd. You can enable or disable different types of
                        cookies below.
                     </p>

                     <div className="space-y-4">
                        {/* Necessary Cookies */}
                        <div className="border border-[#272727] rounded-lg p-4">
                           <div className="flex items-center justify-between">
                              <div className="flex-1">
                                 <h3 className="font-medium text-white  mb-2">
                                    Necessary Cookies
                                 </h3>
                                 <p className="text-sm text-white/70">
                                    These cookies are essential for the website
                                    to function and cannot be switched off. They
                                    are usually only set in response to actions
                                    made by you which amount to a request for
                                    services.
                                 </p>
                              </div>
                              <div className="ml-4">
                                 <div className="relative inline-block w-10 mr-2 align-middle select-none">
                                    <input
                                       type="checkbox"
                                       checked={true}
                                       disabled={true}
                                       className="absolute block w-6 h-6 rounded-full bg-green-500 border-4 appearance-none cursor-not-allowed"
                                    />
                                    <label className="block h-6 overflow-hidden bg-gray-300 rounded-full cursor-not-allowed"></label>
                                 </div>
                              </div>
                           </div>
                           <div className="mt-3 text-xs text-green-500 bg-green-500/10 border border-green-500 w-fit px-4 py-1 rounded-full">
                              Always Active
                           </div>
                        </div>

                        {/* Analytics Cookies */}
                        <div className="border primaryBorder rounded-lg p-4">
                           <div className="flex items-center justify-between">
                              <div className="flex-1">
                                 <h3 className="font-medium text-white mb-2">
                                    Analytics Cookies
                                 </h3>
                                 <p className="text-sm text-white/70">
                                    These cookies allow us to count visits and
                                    traffic sources so we can measure and
                                    improve the performance of our site. They
                                    help us to know which pages are the most and
                                    least popular.
                                 </p>
                              </div>
                              <div className="ml-4">
                                 <label className="relative inline-flex items-center cursor-pointer">
                                    <input
                                       type="checkbox"
                                       checked={localPreferences.analytics}
                                       onChange={(e) =>
                                          handlePreferenceChange(
                                             "analytics",
                                             e.target.checked
                                          )
                                       }
                                       className="sr-only peer"
                                    />
                                    <div className="relative w-11 h-6 bg-[#272727] peer-focus:outline-none peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                 </label>
                              </div>
                           </div>
                        </div>

                        {/* Marketing Cookies */}
                        <div className="border primaryBorder rounded-lg p-4">
                           <div className="flex items-center justify-between">
                              <div className="flex-1">
                                 <h3 className="font-medium text-white mb-2">
                                    Marketing Cookies
                                 </h3>
                                 <p className="text-sm text-white/70">
                                    These cookies may be set through our site by
                                    our advertising partners. They may be used
                                    to build a profile of your interests and
                                    show you relevant adverts on other sites.
                                 </p>
                              </div>
                              <div className="ml-4">
                                 <label className="relative inline-flex items-center cursor-pointer">
                                    <input
                                       type="checkbox"
                                       checked={localPreferences.marketing}
                                       onChange={(e) =>
                                          handlePreferenceChange(
                                             "marketing",
                                             e.target.checked
                                          )
                                       }
                                       className="sr-only peer"
                                    />
                                    <div className="relative w-11 h-6 bg-[#272727] peer-focus:outline-none peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                 </label>
                              </div>
                           </div>
                        </div>

                        {/* Functional Cookies */}
                        <div className="border primaryBorder rounded-lg p-4">
                           <div className="flex items-center justify-between">
                              <div className="flex-1">
                                 <h3 className="font-medium  mb-2">
                                    Functional Cookies
                                 </h3>
                                 <p className="text-sm text-white/70">
                                    These cookies enable the website to provide
                                    enhanced functionality and personalisation.
                                    They may be set by us or by third party
                                    providers whose services we have added to
                                    our pages.
                                 </p>
                              </div>
                              <div className="ml-4">
                                 <label className="relative inline-flex items-center cursor-pointer">
                                    <input
                                       type="checkbox"
                                       checked={localPreferences.functional}
                                       onChange={(e) =>
                                          handlePreferenceChange(
                                             "functional",
                                             e.target.checked
                                          )
                                       }
                                       className="sr-only peer"
                                    />
                                    <div className="relative w-11 h-6 bg-[#272727] peer-focus:outline-none peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                 </label>
                              </div>
                           </div>
                        </div>
                     </div>

                     {/* Current Preferences Summary */}
                     <div className="mt-6 p-4  rounded-lg">
                        <h4 className="font-medium text-white  mb-2">
                           Current Settings Summary
                        </h4>
                        <div className="grid md:grid-cols-2 gap-2 text-sm">
                           <div className="flex justify-between">
                              <span className="text-white/70">Necessary:</span>
                              <span className="text-green-600 font-medium">
                                 Always Active
                              </span>
                           </div>
                           <div className="flex justify-between">
                              <span className="text-white/70">Analytics:</span>
                              <span
                                 className={`font-medium ${
                                    localPreferences.analytics
                                       ? "text-green-600"
                                       : "text-red-600"
                                 }`}
                              >
                                 {localPreferences.analytics
                                    ? "Enabled"
                                    : "Disabled"}
                              </span>
                           </div>
                           <div className="flex justify-between">
                              <span className="text-white/70">Marketing:</span>
                              <span
                                 className={`font-medium ${
                                    localPreferences.marketing
                                       ? "text-green-600"
                                       : "text-red-600"
                                 }`}
                              >
                                 {localPreferences.marketing
                                    ? "Enabled"
                                    : "Disabled"}
                              </span>
                           </div>
                           <div className="flex justify-between">
                              <span className="text-white/70">Functional:</span>
                              <span
                                 className={`font-medium ${
                                    localPreferences.functional
                                       ? "text-green-600"
                                       : "text-red-600"
                                 }`}
                              >
                                 {localPreferences.functional
                                    ? "Enabled"
                                    : "Disabled"}
                              </span>
                           </div>
                        </div>
                     </div>
                  </div>

                  {/* Footer */}
                  <div className="flex flex-col sm:flex-row gap-3 p-6 border-t primaryBorder">
                     <button
                        onClick={handleSave}
                        className="flex-1 bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
                     >
                        Save Preferences
                     </button>
                     <button
                        onClick={handleReset}
                        className="flex-1 bg-red-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-red-700 transition-colors"
                     >
                        Reset All
                     </button>
                     <button
                        onClick={() => setIsOpen(false)}
                        className="flex-1 bg-white/70 text-gray-800 px-6 py-2 rounded-lg font-medium hover:bg-gray-300 transition-colors"
                     >
                        Cancel
                     </button>
                  </div>
               </div>
            </div>
         )}
      </>
   );
}
