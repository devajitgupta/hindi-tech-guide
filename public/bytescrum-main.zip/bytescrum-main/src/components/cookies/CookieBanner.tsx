// "use client";

// import React, { useState } from "react";
// import { useCookie, CookiePreferences } from "./CookieContext";
// import { Button, Link } from "@nextui-org/react";

// export default function CookieBanner() {
//    const { showBanner, preferences, acceptAll, rejectAll, savePreferences } =
//       useCookie();
//    const [showDetails, setShowDetails] = useState(false);
//    const [localPreferences, setLocalPreferences] =
//       useState<CookiePreferences>(preferences);

//    if (!showBanner) {
//       return null;
//    }

//    const handlePreferenceChange = (
//       type: keyof CookiePreferences,
//       value: boolean
//    ) => {
//       if (type === "necessary") return; // Necessary cookies cannot be disabled
//       setLocalPreferences((prev) => ({ ...prev, [type]: value }));
//    };

//    const handleSavePreferences = () => {
//       savePreferences(localPreferences);
//    };

//    return (
//       <div className="fixed inset-0 z-[999999999] flex items-end justify-center bg-black bg-opacity-50 ">
//          <div className=" overflow-y-auto max-h-[90vh] w-full max-w-5xl mx-4 mb-4 bg-[#171717] border primaryBorder rounded-lg shadow-2xl">
//             {/* Header */}
//             <div className="p-4 md:p-6 border-b border-[#272727]">
//                <div className="flex items-center justify-between">
//                   <div className="flex items-center space-x-3">
//                      <div className="p-2 bg-black border border-white/50 rounded-lg">
//                         <svg
//                            className="w-6 h-6 text-white"
//                            fill="none"
//                            stroke="currentColor"
//                            viewBox="0 0 24 24"
//                         >
//                            <path
//                               strokeLinecap="round"
//                               strokeLinejoin="round"
//                               strokeWidth={2}
//                               d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 100 4m0-4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 100 4m0-4v2m0-6V4"
//                            />
//                         </svg>
//                      </div>
//                      <div>
//                         <h3 className="text-[16px]  md:text-lg font-semibold text-white ">
//                            Cookie Settings
//                         </h3>

//                         <p className="text-xs md:text-sm text-white/70">
//                            ByteScrum Technologies - Custom Software Development
//                            Company
//                         </p>
//                      </div>
//                   </div>
//                   <Button
//                      size="sm"
//                      onClick={() => setShowDetails(!showDetails)}
//                      className="text-sm text-white bg-[#1463fd] hover:bg-white transition-all duration-300 ease-in-out  rounded-lg   hover:text-blue-700 font-medium"
//                   >
//                      {showDetails ? "Hide " : "Details"}
//                   </Button>
//                </div>
//             </div>

//             {/* Content */}
//             <div className="p-6">
//                <p className="text-white/70 mb-4">
//                   We use cookies to enhance your browsing experience, serve
//                   personalized content, and analyze our traffic. By clicking
//                   "Accept All", you consent to our use of cookies. You can
//                   manage your preferences below.
//                </p>

//                {showDetails && (
//                   <div className="space-y-4 mb-6">
//                      {/* Necessary Cookies */}
//                      <div className="flex items-center justify-between p-4  border primaryBorder rounded-lg">
//                         <div className="flex-1">
//                            <h4 className="font-medium text-white ">
//                               Necessary Cookies
//                            </h4>
//                            <p className="text-sm text-white/70 mt-1">
//                               Essential for the website to function properly.
//                               These cannot be disabled.
//                            </p>
//                         </div>
//                         <div className="ml-4">
//                            <div className="relative inline-block w-10 mr-2 align-middle select-none">
//                               <input
//                                  type="checkbox"
//                                  checked={true}
//                                  disabled={true}
//                                  className="absolute block w-6 h-6 rounded-full bg-green-500 border-4 appearance-none cursor-not-allowed"
//                               />
//                               <label className="block h-6 overflow-hidden bg-gray-300 rounded-full cursor-not-allowed"></label>
//                            </div>
//                         </div>
//                      </div>

//                      {/* Analytics Cookies */}
//                      <div className="flex items-center justify-between p-4 border primaryBorder rounded-lg">
//                         <div className="flex-1">
//                            <h4 className="font-medium text-white ">
//                               Analytics Cookies
//                            </h4>
//                            <p className="text-sm text-white/70 mt-1">
//                               Help us understand how visitors interact with our
//                               website by collecting and reporting information.
//                            </p>
//                         </div>
//                         <div className="ml-4">
//                            <label className="relative inline-flex items-center cursor-pointer">
//                               <input
//                                  type="checkbox"
//                                  checked={localPreferences.analytics}
//                                  onChange={(e) =>
//                                     handlePreferenceChange(
//                                        "analytics",
//                                        e.target.checked
//                                     )
//                                  }
//                                  className="sr-only peer"
//                               />
//                               <div className="relative w-11 h-6 bg-[#272727] peer-focus:outline-none   rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
//                            </label>
//                         </div>
//                      </div>

//                      {/* Marketing Cookies */}
//                      <div className="flex items-center justify-between p-4 border primaryBorder rounded-lg">
//                         <div className="flex-1">
//                            <h4 className="font-medium text-white ">
//                               Marketing Cookies
//                            </h4>
//                            <p className="text-sm text-white/70 mt-1">
//                               Used to track visitors across websites to display
//                               relevant and engaging advertisements.
//                            </p>
//                         </div>
//                         <div className="ml-4">
//                            <label className="relative inline-flex items-center cursor-pointer">
//                               <input
//                                  type="checkbox"
//                                  checked={localPreferences.marketing}
//                                  onChange={(e) =>
//                                     handlePreferenceChange(
//                                        "marketing",
//                                        e.target.checked
//                                     )
//                                  }
//                                  className="sr-only peer"
//                               />
//                               <div className="relative w-11 h-6 bg-[#272727] peer-focus:outline-none   rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
//                            </label>
//                         </div>
//                      </div>

//                      {/* Functional Cookies */}
//                      <div className="flex items-center justify-between p-4 border primaryBorder rounded-lg">
//                         <div className="flex-1">
//                            <h4 className="font-medium text-white ">
//                               Functional Cookies
//                            </h4>
//                            <p className="text-sm text-white/70 mt-1">
//                               Enable enhanced functionality and personalization,
//                               such as chat widgets and social media features.
//                            </p>
//                         </div>
//                         <div className="ml-4">
//                            <label className="relative inline-flex items-center cursor-pointer">
//                               <input
//                                  type="checkbox"
//                                  checked={localPreferences.functional}
//                                  onChange={(e) =>
//                                     handlePreferenceChange(
//                                        "functional",
//                                        e.target.checked
//                                     )
//                                  }
//                                  className="sr-only peer"
//                               />
//                               <div className="relative w-11 h-6 bg-[#272727] peer-focus:outline-none   rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
//                            </label>
//                         </div>
//                      </div>
//                   </div>
//                )}

//                <div className="flex items-center justify-between flex-col md:flex-row gap-4">
//                   {/* Links */}
//                   <div className="mt-4 text-center">
//                      <Link
//                         href="/privacy-policy"
//                         className="text-sm text-blue-600 hover:text-blue-700 underline mr-4 underline-offset-2"
//                      >
//                         Privacy Policy
//                      </Link>
//                      <Link
//                         href="/terms-conditions"
//                         className="text-sm text-blue-600 hover:text-blue-700 underline underline-offset-2"
//                      >
//                         Terms Conditions
//                      </Link>
//                   </div>

//                   {/* Action Buttons */}
//                   <div className="flex flex-col md:flex-row gap-x-3 gap-y-1 justify-end md:ml-auto  w-full  md:w-fit">
//                      <Button
//                         onClick={acceptAll}
//                         className="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors"
//                      >
//                         Accept All Cookies
//                      </Button>
//                      <Button
//                         onClick={rejectAll}
//                         className="flex-1 bg-red-500 text-white px-6 py-3 rounded-lg font-medium hover:bg-red-500/30 transition-colors"
//                      >
//                         Reject All
//                      </Button>
//                      {showDetails && (
//                         <Button
//                            onClick={handleSavePreferences}
//                            className="flex-1 bg-green-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-green-700 transition-colors"
//                         >
//                            Save Preferences
//                         </Button>
//                      )}
//                   </div>
//                </div>
//             </div>
//          </div>
//       </div>
//    );
// }

"use client";

import React, { useState, useEffect } from "react";
import { useCookie, CookiePreferences } from "./CookieContext";
import { Button, Link } from "@nextui-org/react";
import { usePathname } from "next/navigation";

const TWELVE_HOURS = 12 * 60 * 60 * 1000;

export default function CookieBanner() {
   const { showBanner, preferences, acceptAll, rejectAll, savePreferences } =
      useCookie();
   const [showDetails, setShowDetails] = useState(false);
   const [localPreferences, setLocalPreferences] =
      useState<CookiePreferences>(preferences);
   const [displayBanner, setDisplayBanner] = useState(false);
   const pathname = usePathname();

   const handlePreferenceChange = (
      type: keyof CookiePreferences,
      value: boolean
   ) => {
      if (type === "necessary") return;
      setLocalPreferences((prev) => ({ ...prev, [type]: value }));
   };

   useEffect(() => {
      if (!showBanner) {
         setDisplayBanner(false);
         return;
      }

      const lastShown = localStorage.getItem("cookieBannerLastShown");
      const now = Date.now();

      if (lastShown && now - parseInt(lastShown) <= TWELVE_HOURS) {
         return;
      }

      const showBannerAfterDelay = () => {
         if (pathname === "/") {
            setTimeout(() => {
               setDisplayBanner(true);
               localStorage.setItem("cookieBannerLastShown", now.toString());
            }, 15000);
         } else {
            setDisplayBanner(true);
            localStorage.setItem("cookieBannerLastShown", now.toString());
         }
      };

      // Handle page load state
      if (document.readyState === "complete") {
         showBannerAfterDelay();
      } else {
         window.addEventListener("load", showBannerAfterDelay);
         return () => window.removeEventListener("load", showBannerAfterDelay);
      }
   }, [showBanner, pathname]);

   const handleSavePreferences = () => {
      savePreferences(localPreferences);
   };

   if (!displayBanner) {
      return null;
   }

   return (
      <div className="fixed inset-0 z-[999999999] flex items-end justify-center bg-black bg-opacity-50 ">
         <div className=" overflow-y-auto max-h-[90vh] w-full max-w-5xl mx-4 mb-4 bg-[#171717] border primaryBorder rounded-lg shadow-2xl">
            {/* Header */}
            <div className="p-4 md:p-6 border-b border-[#272727]">
               <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                     <div className="p-2 bg-black border border-white/50 rounded-lg">
                        <svg
                           className="w-6 h-6 text-white"
                           fill="none"
                           stroke="currentColor"
                           viewBox="0 0 24 24"
                        >
                           <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 100 4m0-4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 100 4m0-4v2m0-6V4"
                           />
                        </svg>
                     </div>
                     <div>
                        <h3 className="text-[16px]  md:text-lg font-semibold text-white ">
                           Cookie Settings
                        </h3>

                        <p className="text-xs md:text-sm text-white/70">
                           ByteScrum Technologies - Custom Software Development
                           Company
                        </p>
                     </div>
                  </div>
                  <Button
                     size="sm"
                     onClick={() => setShowDetails(!showDetails)}
                     className="text-sm text-white bg-[#1463fd] hover:bg-white transition-all duration-300 ease-in-out  rounded-lg   hover:text-blue-700 font-medium"
                  >
                     {showDetails ? "Hide " : "Details"}
                  </Button>
               </div>
            </div>

            {/* Content */}
            <div className="p-6">
               <p className="text-white/70 mb-4">
                  We use cookies to enhance your browsing experience, serve
                  personalized content, and analyze our traffic. By clicking
                  "Accept All", you consent to our use of cookies. You can
                  manage your preferences below.
               </p>

               {showDetails && (
                  <div className="space-y-4 mb-6">
                     {/* Necessary Cookies */}
                     <div className="flex items-center justify-between p-4  border primaryBorder rounded-lg">
                        <div className="flex-1">
                           <h4 className="font-medium text-white ">
                              Necessary Cookies
                           </h4>
                           <p className="text-sm text-white/70 mt-1">
                              Essential for the website to function properly.
                              These cannot be disabled.
                           </p>
                        </div>
                        <div className="ml-4">
                           <div className="relative inline-block w-10 mr-2 align-middle select-none">
                              <input
                                 type="checkbox"
                                 checked={true}
                                 disabled={true}
                                 className="absolute block w-6 h-6 rounded-full bg-green-500 border-4 appearance-none cursor-not-allowed"
                              />
                              <label className="block h-6 overflow-hidden bg-gray-300 rounded-full cursor-not-allowed"></label>
                           </div>
                        </div>
                     </div>

                     {/* Analytics Cookies */}
                     <div className="flex items-center justify-between p-4 border primaryBorder rounded-lg">
                        <div className="flex-1">
                           <h4 className="font-medium text-white ">
                              Analytics Cookies
                           </h4>
                           <p className="text-sm text-white/70 mt-1">
                              Help us understand how visitors interact with our
                              website by collecting and reporting information.
                           </p>
                        </div>
                        <div className="ml-4">
                           <label className="relative inline-flex items-center cursor-pointer">
                              <input
                                 type="checkbox"
                                 checked={localPreferences.analytics}
                                 onChange={(e) =>
                                    handlePreferenceChange(
                                       "analytics",
                                       e.target.checked
                                    )
                                 }
                                 className="sr-only peer"
                              />
                              <div className="relative w-11 h-6 bg-[#272727] peer-focus:outline-none   rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                           </label>
                        </div>
                     </div>

                     {/* Marketing Cookies */}
                     <div className="flex items-center justify-between p-4 border primaryBorder rounded-lg">
                        <div className="flex-1">
                           <h4 className="font-medium text-white ">
                              Marketing Cookies
                           </h4>
                           <p className="text-sm text-white/70 mt-1">
                              Used to track visitors across websites to display
                              relevant and engaging advertisements.
                           </p>
                        </div>
                        <div className="ml-4">
                           <label className="relative inline-flex items-center cursor-pointer">
                              <input
                                 type="checkbox"
                                 checked={localPreferences.marketing}
                                 onChange={(e) =>
                                    handlePreferenceChange(
                                       "marketing",
                                       e.target.checked
                                    )
                                 }
                                 className="sr-only peer"
                              />
                              <div className="relative w-11 h-6 bg-[#272727] peer-focus:outline-none   rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                           </label>
                        </div>
                     </div>

                     {/* Functional Cookies */}
                     <div className="flex items-center justify-between p-4 border primaryBorder rounded-lg">
                        <div className="flex-1">
                           <h4 className="font-medium text-white ">
                              Functional Cookies
                           </h4>
                           <p className="text-sm text-white/70 mt-1">
                              Enable enhanced functionality and personalization,
                              such as chat widgets and social media features.
                           </p>
                        </div>
                        <div className="ml-4">
                           <label className="relative inline-flex items-center cursor-pointer">
                              <input
                                 type="checkbox"
                                 checked={localPreferences.functional}
                                 onChange={(e) =>
                                    handlePreferenceChange(
                                       "functional",
                                       e.target.checked
                                    )
                                 }
                                 className="sr-only peer"
                              />
                              <div className="relative w-11 h-6 bg-[#272727] peer-focus:outline-none   rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                           </label>
                        </div>
                     </div>
                  </div>
               )}

               <div className="flex items-center justify-between flex-col md:flex-row gap-4">
                  {/* Links */}
                  <div className="mt-4 text-center">
                     <Link
                        href="/privacy-policy"
                        className="text-sm text-blue-600 hover:text-blue-700 underline mr-4 underline-offset-2"
                     >
                        Privacy Policy
                     </Link>
                     <Link
                        href="/terms-conditions"
                        className="text-sm text-blue-600 hover:text-blue-700 underline underline-offset-2"
                     >
                        Terms Conditions
                     </Link>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-col md:flex-row gap-x-3 gap-y-1 justify-end md:ml-auto  w-full  md:w-fit">
                     <Button
                        onClick={acceptAll}
                        className="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors"
                     >
                        Accept All Cookies
                     </Button>
                     <Button
                        onClick={rejectAll}
                        className="flex-1 bg-red-500 text-white px-6 py-3 rounded-lg font-medium hover:bg-red-500/30 transition-colors"
                     >
                        Reject All
                     </Button>
                     {showDetails && (
                        <Button
                           onClick={handleSavePreferences}
                           className="flex-1 bg-green-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-green-700 transition-colors"
                        >
                           Save Preferences
                        </Button>
                     )}
                  </div>
               </div>
            </div>
         </div>
      </div>
   );
}
