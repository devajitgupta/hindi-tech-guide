"use client";
import React, { useEffect, useState } from "react";
import ConsultationForm from "./ConsultationForm";
import useConsultationStore from "@/libs/stores/useConsultationStore";
import { usePathname } from "next/navigation";
import { TLocale } from "@/i18n-config";

// const TWELVE_HOURS = 11000;
const TWELVE_HOURS = 12 * 60 * 60 * 1000;
type Props = {
   langText: any;
};
const Consultation = ({ langText }: Props) => {
   const { isOpen, closeModel, openModel } = useConsultationStore();
   const [isVisible, setIsVisible] = useState(isOpen);
   const pathname = usePathname();

   useEffect(() => {
      isOpen ? setIsVisible(true) : setTimeout(() => setIsVisible(false), 80);
   }, [isOpen]);

   useEffect(() => {
      const handleEscape = (event: KeyboardEvent) => {
         isOpen && event.key === "Escape" && closeModel();
      };
      window.addEventListener("keydown", handleEscape);
      return () => window.removeEventListener("keydown", handleEscape);
   }, [isOpen, closeModel]);

   useEffect(() => {
      if (pathname !== "/") return;

      const lastShown = localStorage.getItem("consultationLastShown");
      const now = Date.now();

      if (lastShown && now - parseInt(lastShown) <= TWELVE_HOURS) return;

      const openModalAfterDelay = () => {
         setTimeout(() => {
            openModel("consultation");
            localStorage.setItem("consultationLastShown", now.toString());
         }, 12000);
      };

      if (document.readyState === "complete") {
         openModalAfterDelay();
      } else {
         window.addEventListener("load", openModalAfterDelay);
         return () => window.removeEventListener("load", openModalAfterDelay);
      }
   }, [pathname, openModel]);

   return (
      <>
         {isVisible && (
            <ConsultationForm
               langText={langText}
               onSucces={closeModel}
               isConsultationFormOpen={isOpen}
            />
         )}
      </>
   );
};

export default Consultation;
