"use client";
import { twMerge } from "tailwind-merge";
import * as Yup from "yup";
import clsx from "clsx";
import SectionTitle from "../SectionTitle";
import { Formik, Field, Form, ErrorMessage } from "formik";
import Text from "../Text";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@nextui-org/react";
import { Icon } from "@iconify/react/dist/iconify.js";
import ReactConfetti from "react-confetti";
import useConsultationStore from "@/libs/stores/useConsultationStore";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import axiosInstance from "@/common/apis/axiosInstance";
import { EContactFormTypes } from "@/common/enums/contact-forms.enum";
import ContactUsApi from "@/common/apis/contactus.api";

const validationSchema = Yup.object({
   firstName: Yup.string().required("Full Name is required"),
   email: Yup.string()
      .email("Invalid email address")
      .required("Email is required"),
   phoneNumber: Yup.string().required("phoneNumber Number is required"),
   company: Yup.string(),
   service: Yup.string().required("Service is required"),
   budget: Yup.string(),
   message: Yup.string().required("Message is required"),
});

type Props = {
   className?: string;
   onSucces?: () => void;
   isConsultationFormOpen: boolean;
   langText: any;
};

const ConsultationForm = ({
   className,
   onSucces,
   langText,
   isConsultationFormOpen,
}: Props) => {
   const { screenWidth } = useBreakpoints();
   const isLargeScreen = screenWidth >= 1024;
   const { formType } = useConsultationStore();

   // State management
   const [isModalOpen, setIsModalOpen] = useState(false);
   const [isSuccess, setIsSuccess] = useState(false);
   const [message, setMessage] = useState<string>("");
   const [modalTitle, setModalTitle] = useState<string>("");
   const [modalIcon, setModalIcon] = useState<string>("");

   const formTitle =
      formType === "consultation" ? langText.title : langText.titleTwo;

   const fieldStyle =
      "w-full px-3 py-2 md:px-6 md:py-4 bg-[#262626]/30 rounded-[6px] md:rounded-[16px] border border-[#262626] text-[#b0b0b0] outline-none placeholder:text-[#fff]/50 ";

   return (
      <>
         <AnimatePresence>
            {isConsultationFormOpen && (
               <div className=" grid items-content-center m-auto fixed overflow-hidden top-0 py-20 w-full h-full !z-[99999999] backdrop-blur-md p-4 placeholder: ">
                  {/* Show confetti only on success */}
                  {isSuccess && (
                     <ReactConfetti
                        width={screenWidth}
                        height={window.innerHeight}
                        recycle={false}
                        numberOfPieces={200}
                        gravity={0.1}
                     />
                  )}

                  <motion.div
                     itemID="form"
                     key={isLargeScreen ? "animate" : "stopAnimation"}
                     className={twMerge(
                        clsx(
                           "flex relative  m-auto  flex-col items-center justify-center w-full max-w-4xl  rounded-2xl p-4 py-10 md:p-8 bg-black border border-[#262626] text-white overflow-hidden",
                           className
                        )
                     )}
                     initial={
                        isLargeScreen
                           ? { opacity: 0, x: 800, y: -400, scale: 0 }
                           : { opacity: 0, scale: 0 }
                     }
                     animate={
                        isLargeScreen
                           ? { opacity: 1, x: 0, y: 0, scale: 1 }
                           : { opacity: 1, scale: 1 }
                     }
                     exit={
                        isLargeScreen
                           ? { opacity: 0, x: 800, y: -400, scale: 0 }
                           : { opacity: 0, scale: 0 }
                     }
                     transition={
                        isLargeScreen ? { duration: 0.2, mass: 100 } : {}
                     }
                  >
                     <Button
                        size="sm"
                        isIconOnly
                        className="absolute rounded top-5 right-5 bg-stone-900 border border-stone-500/30"
                        onPress={onSucces}
                     >
                        <Icon
                           icon="line-md:close-small"
                           width="24"
                           height="24"
                           className="text-[#fff]"
                        />
                     </Button>

                     <div className="space-y-[10px] mb-6 w-full">
                        <SectionTitle>{formTitle}</SectionTitle>
                        <Text className="text-center  m-auto">
                           {formType === "consultation"
                              ? langText.subtitle
                              : langText.subtitleTwo}
                        </Text>
                     </div>

                     <Formik
                        initialValues={{
                           firstName: "",
                           email: "",
                           phoneNumber: "",
                           company: "",
                           service: "",
                           budget: "",
                           message: "",
                        }}
                        validationSchema={validationSchema}
                        onSubmit={async (
                           values,
                           { setSubmitting, resetForm }
                        ) => {
                           try {
                              const payload = {
                                 ...values,
                                 formTypes: [
                                    EContactFormTypes.FREE_CONSULTANCY,
                                 ],
                              };

                              const response = await axiosInstance.post(
                                 ContactUsApi.base,
                                 payload
                              );

                              const { statusCode, message: responseMessage } =
                                 response.data;

                              if (statusCode === 200 || statusCode === 201) {
                                 setMessage(
                                    responseMessage || langText.successMsg
                                 );
                                 setModalTitle("Success");
                                 setModalIcon("mdi:check-circle");
                                 setIsSuccess(true);
                                 resetForm();
                              } else {
                                 setMessage(
                                    responseMessage || langText.failedMsg
                                 );
                                 setModalTitle("Warning");
                                 setModalIcon("mdi:alert-circle");
                                 setIsSuccess(false);
                              }
                           } catch (error: any) {
                              const serverMessage =
                                 error?.response?.data?.message;
                              setMessage(
                                 serverMessage || langText.serverMessage
                              );
                              setModalTitle("Error");
                              setModalIcon("mdi:close-circle");
                              setIsSuccess(false);
                           } finally {
                              setIsModalOpen(true);
                              setSubmitting(false);
                           }
                        }}
                     >
                        {({ isSubmitting }) => (
                           <Form className="w-full max-w-4xl">
                              <div className="grid grid-cols-1 gap-2 md:gap-4">
                                 <div className="grid grid-cols-2 gap-2 md:gap-4">
                                    <div>
                                       <Field
                                          name="firstName"
                                          type="text"
                                          placeholder={
                                             langText.placeholder.name
                                          }
                                          className={fieldStyle}
                                       />
                                       <ErrorMessage
                                          name="firstName"
                                          component="div"
                                          className="text-red-500 text-sm"
                                       />
                                    </div>
                                    <div>
                                       <Field
                                          name="email"
                                          type="email"
                                          placeholder={
                                             langText.placeholder.email
                                          }
                                          className={fieldStyle}
                                       />
                                       <ErrorMessage
                                          name="email"
                                          component="div"
                                          className="text-red-500 text-sm"
                                       />
                                    </div>
                                    <div>
                                       <Field
                                          name="phoneNumber"
                                          type="text"
                                          placeholder={
                                             langText.placeholder.phoneNumber
                                          }
                                          className={fieldStyle}
                                       />
                                       <ErrorMessage
                                          name="phoneNumber"
                                          component="div"
                                          className="text-red-500 text-sm"
                                       />
                                    </div>
                                    <div>
                                       <Field
                                          name="company"
                                          type="text"
                                          placeholder={
                                             langText.placeholder.company
                                          }
                                          className={fieldStyle}
                                       />
                                    </div>
                                 </div>

                                 <div className="grid grid-cols-2 gap-4">
                                    <div>
                                       <Field
                                          name="service"
                                          type="text"
                                          placeholder={
                                             langText.placeholder.service
                                          }
                                          className={fieldStyle}
                                       />
                                       <ErrorMessage
                                          name="service"
                                          component="div"
                                          className="text-red-500 text-sm"
                                       />
                                    </div>
                                    <Field
                                       name="budget"
                                       type="text"
                                       placeholder={langText.placeholder.budget}
                                       className={fieldStyle}
                                    />
                                 </div>
                                 <div>
                                    <Field
                                       as="textarea"
                                       name="message"
                                       placeholder={
                                          langText.placeholder.message
                                       }
                                       className={clsx(
                                          "resize-none h-32 md:h-[150px]",
                                          fieldStyle
                                       )}
                                    />
                                    <ErrorMessage
                                       name="message"
                                       component="div"
                                       className="text-red-500 text-sm"
                                    />
                                 </div>
                                 <div className="flex items-center justify-center ml-auto ">
                                    <motion.button
                                       type="submit"
                                       disabled={isSubmitting}
                                       className="relative bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold py-3 px-8 rounded-full transition-all duration-300 overflow-hidden flex gap-2 items-center justify-center"
                                       whileHover={{ scale: 1.05 }}
                                       whileTap={{ scale: 0.95 }}
                                       viewport={{ once: true }}
                                       transition={{
                                          duration: 0.2,
                                       }}
                                    >
                                       {/* Button glow effect */}
                                       <motion.div
                                          className="absolute inset-0 bg-gradient-to-r from-blue-400/0 via-blue-400/70 to-blue-400/0"
                                          animate={{
                                             x: ["-100%", "100%"],
                                          }}
                                          transition={{
                                             duration: 2,
                                             repeat: Number.POSITIVE_INFINITY,
                                             ease: "linear",
                                          }}
                                       />
                                       <motion.span
                                          animate={{ x: [0, 4, 0] }}
                                          transition={{
                                             repeat: Number.POSITIVE_INFINITY,
                                             duration: 1.5,
                                          }}
                                       >
                                          <Icon
                                             icon="tabler:send"
                                             className="text-lg"
                                          />
                                       </motion.span>
                                       <span className="relative z-10 w-full">
                                          {isSubmitting
                                             ? langText.buttonTextLoading
                                             : langText.buttonText}
                                       </span>
                                    </motion.button>
                                 </div>
                              </div>
                           </Form>
                        )}
                     </Formik>

                     {/* Success/Error Modal */}
                     {isModalOpen && (
                        <div className="absolute backdrop-blur-md w-full h-full z-[99999] flex items-center justify-center bg-[#000]/20">
                           <motion.div
                              className="flex flex-col m-auto border border-[#262626] rounded-lg p-10 md:p-20 lg:p-60 bg-black/20 items-center justify-center text-center"
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ duration: 0.5 }}
                           >
                              <motion.div
                                 className={`w-20 h-20 rounded-full flex items-center justify-center mb-6 ${
                                    isSuccess ? "bg-green-100" : "bg-red-100"
                                 }`}
                                 initial={{ scale: 0 }}
                                 animate={{ scale: 1 }}
                                 transition={{
                                    delay: 0.2,
                                    type: "spring",
                                    stiffness: 200,
                                 }}
                              >
                                 <Icon
                                    icon={modalIcon}
                                    className={`w-10 h-10 ${
                                       isSuccess
                                          ? "text-green-600"
                                          : "text-red-600"
                                    }`}
                                 />
                              </motion.div>
                              <h3 className="text-2xl font-bold mb-2">
                                 {modalTitle}
                              </h3>
                              <p className="text-gray-400 max-w-md mb-4">
                                 {message}
                              </p>
                              <Button
                                 color="primary"
                                 onClick={() => {
                                    setIsModalOpen(false);
                                    setIsSuccess(false);
                                 }}
                                 className="w-full max-w-xs"
                              >
                                 OK
                              </Button>
                           </motion.div>
                        </div>
                     )}
                  </motion.div>
               </div>
            )}
         </AnimatePresence>
      </>
   );
};

export default ConsultationForm;
