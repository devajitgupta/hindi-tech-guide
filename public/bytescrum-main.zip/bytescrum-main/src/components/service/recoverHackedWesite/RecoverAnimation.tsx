"use client";

import { useRef, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Icon } from "@iconify/react/dist/iconify.js";

export default function RecoverAnimation() {
   const containerRef = useRef<HTMLDivElement>(null);
   const [terminalCommands, setTerminalCommands] = useState<string[]>([]);
   const canvasRef = useRef<HTMLCanvasElement>(null);

   const [windowHeight, setWindHeight] = useState<number>(720);
   const [windowWidth, setWindWidth] = useState<number>(1080);

   useEffect(() => {
      if (typeof window !== "undefined") {
         const width = window.innerWidth;
         const height = window.innerHeight;
         setWindWidth(width);
         setWindHeight(height);
      }
   }, []);

   useEffect(() => {
      const canvas = canvasRef.current;

      if (!canvas) return;

      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;

      const fontSize = 14;
      const columns = Math.floor(canvas.width / fontSize);

      const drops: number[] = [];
      for (let i = 0; i < columns; i++) {
         drops[i] = Math.random() * -100;
      }

      const matrix = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789@#$%^&*()*&^%$#@!~";

      function draw() {
         if (canvas && ctx) {
            ctx.fillStyle = "rgba(0, 0, 0, 0.05)";
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            ctx.fillStyle = "#0f0";
            ctx.font = `${fontSize}px monospace`;

            for (let i = 0; i < drops.length; i++) {
               const text = matrix[Math.floor(Math.random() * matrix.length)];
               const x = i * fontSize;
               const y = drops[i] * fontSize;

               //  Add some randomness to the green color
               const greenIntensity = 128 + Math.floor(Math.random() * 128);
               ctx.fillStyle = `rgba(0, ${greenIntensity}, 0, 0.8)`;

               ctx.fillText(text, x, y);

               if (y > canvas.height && Math.random() > 0.975) {
                  drops[i] = 0;
               }

               drops[i]++;
            }
         }
      }

      const interval = setInterval(draw, 35);

      const handleResize = () => {
         canvas.width = window.innerWidth;
         canvas.height = window.innerHeight;
      };

      window.addEventListener("resize", handleResize);

      return () => {
         clearInterval(interval);
         window.removeEventListener("resize", handleResize);
      };
   }, []);

   //  Generate random terminal commands
   useEffect(() => {
      const commands = [
         "> scanning system files...",
         "> detecting malware signatures...",
         "> removing backdoor access...",
         "> patching vulnerabilities...",
         "> updating security protocols...",
         "> firewall status: active",
         "> malicious code detected in: wp-content/uploads/",
         "> quarantining infected files...",
         "> restoring from clean backup...",
         "> implementing security hardening...",
         "> changing all passwords...",
         "> updating CMS core files...",
         "> scanning database for injections...",
         "> removing suspicious admin accounts...",
         "> enabling two-factor authentication...",
         "> THREAT NEUTRALIZED",
         "> system secured",
      ];

      const updateCommands = () => {
         setTerminalCommands((prevCommands) => {
            const newCommands = [...prevCommands];
            if (newCommands.length > 15) {
               newCommands.shift();
            }
            newCommands.push(
               commands[Math.floor(Math.random() * commands.length)]
            );
            return newCommands;
         });
      };

      // Initialize with a few commands
      for (let i = 0; i < 5; i++) {
         updateCommands();
      }

      // Update commands periodically
      const interval = setInterval(updateCommands, 1500);
      return () => clearInterval(interval);
   }, []);

   //  Binary code fragments for background
   const generateBinaryString = (length: number) => {
      return Array.from({ length }, () => Math.round(Math.random())).join("");
   };

   const binaryFragments = Array.from({ length: 20 }, () => ({
      content: generateBinaryString(Math.floor(Math.random() * 20) + 10),
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 10 + 10,
      opacity: Math.random() * 0.5 + 0.1,
   }));

   //  Hacking attempt visuals
   // const hackingAttempts = Array.from({ length: 15 }, () => ({
   //    x: Math.random() * 100,
   //    y: Math.random() * 100,
   //    size: Math.random() * 100 + 50,
   //    duration: Math.random() * 10 + 5,
   //    delay: Math.random() * 5,
   // }));

   const hackingAttempts = Array.from({ length: 15 }, () => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 100 + 24,
      duration: Math.random() * 10 + 5,
      delay: Math.random() * 5,
      icon: [
         "mdi:matrix",
         "mdi:shield-check",
         "mdi:lock",
         "mdi:alert",
         "mdi:bug",
      ][Math.floor(Math.random() * 50)], // Randomly select one of the five icons
   }));

   return (
      <div
         // ref={containerRef}
         className=" absolute inset-0 z-0 overflow-hidden bg-black  "
      >
         {/* Digital Matrix Background */}

         {/* Binary Code Fragments */}
         {/* {binaryFragments.map((fragment, index) => (
            <motion.div
               key={`binary-${index}`}
               className="absolute font-mono text-red-500/70"
               style={{
                  left: `${fragment.x}%`,
                  top: `${fragment.y}%`,
                  fontSize: fragment.size,
                  opacity: fragment.opacity,
               }}
               animate={{
                  opacity: [
                     fragment.opacity,
                     fragment.opacity + 0.2,
                     fragment.opacity,
                  ],
               }}
               transition={{
                  duration: Math.random() * 3 + 2,
                  repeat: Number.POSITIVE_INFINITY,
                  repeatType: "loop",
               }}
            >
               {fragment.content}
            </motion.div>
         ))} */}
         {/* Terminal Windows */}
         {Array.from({ length: 3 }).map((_, index) => {
            const width = Math.random() * 300 + 200;
            const height = Math.random() * 200 + 150;
            const posX = Math.random() * 70 + 5;
            const posY = Math.random() * 70 + 5;

            return (
               <motion.div
                  key={`terminal-${index}`}
                  className="absolute rounded-md border border-[#262626] bg-black/90 backdrop-blur-sm overflow-hidden"
                  style={{
                     width,
                     height,
                     left: `${posX}%`,
                     top: `${posY}%`,
                  }}
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{
                     opacity: [0, 0.5, 0.5, 0],
                     scale: [0, 1, 1, 0],
                     x: [0, 20, -20, 0],
                     y: [0, -20, 20, 0],
                  }}
                  transition={{
                     duration: 20,
                     times: [0, 0.1, 0.9, 1],
                     repeat: Number.POSITIVE_INFINITY,
                     repeatDelay: Math.random() * 10,
                  }}
               >
                  <div className="h-6 bg-gray-800 flex items-center px-2">
                     <div className="w-3 h-3 rounded-full bg-red-500 mr-1"></div>
                     <div className="w-3 h-3 rounded-full bg-yellow-500 mr-1"></div>
                     <div className="w-3 h-3 rounded-full bg-green-500"></div>
                     <div className="ml-2 text-xs text-gray-300">
                        security_scan.sh
                     </div>
                  </div>
                  <div className="p-3 font-mono text-xs text-green-400 h-[calc(100%-24px)] overflow-hidden">
                     {terminalCommands
                        .slice(index * 5, index * 5 + 10)
                        .map((cmd, cmdIndex) => (
                           <motion.div
                              key={`cmd-${index}-${cmdIndex}`}
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ duration: 0.3 }}
                              className="mb-1"
                           >
                              {cmd}
                           </motion.div>
                        ))}
                     <motion.div
                        className="h-4 w-2 bg-green-500 inline-block ml-1"
                        animate={{ opacity: [1, 0] }}
                        transition={{
                           duration: 0.8,
                           repeat: Number.POSITIVE_INFINITY,
                        }}
                     />
                  </div>
               </motion.div>
            );
         })}
         {/* Enhanced Shield Animation */}
         <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <motion.div
               className="relative w-[400px] h-[400px]"
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               transition={{ duration: 2 }}
            >
               {/* Shield Base */}
               <motion.div
                  className="absolute inset-0 flex items-center justify-center"
                  animate={{
                     scale: [0.95, 1.05, 0.95],
                     rotateY: [0, 360],
                  }}
                  transition={{
                     scale: {
                        duration: 4,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "loop",
                     },
                     rotateY: {
                        duration: 20,
                        repeat: Number.POSITIVE_INFINITY,
                        ease: "linear",
                     },
                  }}
               >
                  <svg
                     xmlns="http:www.w3.org/2000/svg"
                     className="h-64 w-64 text-blue-500"
                     viewBox="0 0 24 24"
                     fill="none"
                  >
                     <motion.path
                        d="M20.618 5.984A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                        stroke="currentColor"
                        strokeWidth={1.5}
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        initial={{ pathLength: 0, opacity: 0 }}
                        animate={{
                           pathLength: 1,
                           opacity: 1,
                           stroke: ["#3b82f6", "#10b981", "#3b82f6"],
                        }}
                        transition={{
                           duration: 3,
                           stroke: {
                              duration: 8,
                              repeat: Number.POSITIVE_INFINITY,
                           },
                        }}
                     />
                  </svg>
               </motion.div>

               {/* Shield Inner Elements */}
               <motion.div
                  className="absolute inset-0 flex items-center justify-center"
                  animate={{ rotate: [0, 360] }}
                  transition={{
                     duration: 30,
                     repeat: Number.POSITIVE_INFINITY,
                     ease: "linear",
                  }}
               >
                  {Array.from({ length: 3 }).map((_, i) => (
                     <motion.div
                        key={`shield-ring-${i}`}
                        className="absolute rounded-full border-2 border-dashed"
                        style={{
                           width: `${60 - i * 15}%`,
                           height: `${60 - i * 15}%`,
                           borderColor:
                              i === 0
                                 ? "#3b82f6"
                                 : i === 1
                                 ? "#10b981"
                                 : "#8b5cf6",
                        }}
                        animate={{
                           rotate: [0, 360],
                           scale: [1, 1.1, 1],
                           opacity: [0.7, 1, 0.7],
                        }}
                        transition={{
                           rotate: {
                              duration: 20 - i * 5,
                              repeat: Number.POSITIVE_INFINITY,
                              ease: "linear",
                           },
                           scale: {
                              duration: 4,
                              repeat: Number.POSITIVE_INFINITY,
                              repeatType: "loop",
                           },
                           opacity: {
                              duration: 3,
                              repeat: Number.POSITIVE_INFINITY,
                              repeatType: "loop",
                           },
                        }}
                     />
                  ))}
               </motion.div>

               {/* Shield Icon */}
               <motion.div
                  className="absolute inset-0 flex items-center justify-center"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 2 }}
               >
                  <motion.div
                     className="text-green-500 text-5xl"
                     animate={{
                        scale: [1, 1.2, 1],
                        opacity: [0.8, 1, 0.8],
                        rotateY: [0, 360],
                     }}
                     transition={{
                        duration: 4,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "loop",
                        rotateY: {
                           duration: 10,
                           repeat: Number.POSITIVE_INFINITY,
                           ease: "linear",
                        },
                     }}
                  >
                     ✓
                  </motion.div>
               </motion.div>

               {/* Orbiting Security Elements */}
               {Array.from({ length: 5 }).map((_, i) => {
                  const icons = ["🔒", "🛡️", "🔐", "🔍", "⚠️"];
                  const colors = [
                     "text-blue-500",
                     "text-green-500",
                     "text-purple-500",
                     "text-yellow-500",
                     "text-red-500",
                  ];
                  const size = 30 + Math.random() * 20;
                  const distance = 150 + i * 10;
                  const speed = 10 + i * 2;
                  const startAngle = i * (360 / 5);

                  return (
                     <motion.div
                        key={`orbiting-${i}`}
                        className={`absolute text-2xl ${colors[i]}`}
                        style={{
                           width: size,
                           height: size,
                           borderRadius: "50%",
                        }}
                        animate={{
                           x: Array.from({ length: 60 }).map(
                              (_, j) =>
                                 Math.cos(
                                    ((startAngle + j * 6) * Math.PI) / 180
                                 ) * distance
                           ),
                           y: Array.from({ length: 60 }).map(
                              (_, j) =>
                                 Math.sin(
                                    ((startAngle + j * 6) * Math.PI) / 180
                                 ) * distance
                           ),
                        }}
                        transition={{
                           duration: speed,
                           repeat: Number.POSITIVE_INFINITY,
                           ease: "linear",
                        }}
                     >
                        <div className="flex items-center justify-center h-full">
                           {icons[i]}
                        </div>
                     </motion.div>
                  );
               })}
            </motion.div>
         </div>
         {/* Code Recovery Animation */}
         {/* <div className="absolute bottom-0 left-0 right-0 h-[200px] overflow-hidden">
            {Array.from({ length: 1 }).map((_, index) => {
               const width = Math.random() * 200 + 100;
               const startX = Math.random() * 100;

               return (
                  <motion.div
                     key={`code-recovery-${index}`}
                     className="absolute h-4 bg-gradient-to-r from-red-500/0 via-green-500/50 to-blue-500/0"
                     style={{
                        width,
                        left: `${startX}%`,
                        bottom: `${index * 20}px`,
                     }}
                     initial={{ scaleX: 0, opacity: 0 }}
                     animate={{
                        scaleX: [0, 1, 0],
                        opacity: [0, 0.7, 0],
                        x: [0, width],
                     }}
                     transition={{
                        duration: Math.random() * 5 + 5,
                        delay: index * 0.5,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatDelay: Math.random() * 3,
                     }}
                  />
               );
            })}
         </div> */}

         {/* Scanning Effect */}
         {/* <motion.div
            className="absolute inset-0 bg-gradient-to-t from-blue-500/0 via-blue-500/10 to-blue-500/0"
            animate={{
               top: ["-100%", "100%", "-100%"],
            }}
            transition={{
               duration: 8,
               repeat: Number.POSITIVE_INFINITY,
               ease: "linear",
            }}
         /> */}

         {/* Floating Code Blocks */}
         {/* {Array.from({ length: 6 }).map((_, index) => {
            const codeSnippets = [
               `function scanMalware() {
   const files = getWebsiteFiles();
   return files.filter(file =>
     containsMaliciousCode(file));
 }`,
               `async function removeBackdoors() {
   const suspiciousFiles = await findBackdoors();
   for (const file of suspiciousFiles) {
     await quarantine(file);
   }
   return "Backdoors removed";
 }`,
               `class SecurityMonitor {
   constructor() {
     this.alerts = [];
     this.status = "SECURE";
   }

   scan() {
      Continuous monitoring
   }
 }`,
            ];

            const snippet = codeSnippets[index % codeSnippets.length];
            const size = Math.random() * 100 + 150;

            return (
               <motion.div
                  key={`code-block-${index}`}
                  className="absolute rounded-md border border-blue-500/30 bg-black/80 backdrop-blur-sm p-3 font-mono text-xs text-blue-400 overflow-hidden"
                  style={{
                     width: size,
                     height: size * 0.8,
                  }}
                  initial={{
                     x: Math.random() * window.innerWidth,
                     y: Math.random() * window.innerHeight,
                     opacity: 0,
                     rotateX: Math.random() * 40 - 20,
                     rotateY: Math.random() * 40 - 20,
                  }}
                  animate={{
                     opacity: [0, 0.7, 0],
                     rotateX: [
                        Math.random() * 40 - 20,
                        Math.random() * 40 - 20,
                     ],
                     rotateY: [
                        Math.random() * 40 - 20,
                        Math.random() * 40 - 20,
                     ],
                     x: [
                        Math.random() * window.innerWidth,
                        Math.random() * window.innerWidth,
                     ],
                     y: [
                        Math.random() * window.innerHeight,
                        Math.random() * window.innerHeight,
                     ],
                  }}
                  transition={{
                     duration: Math.random() * 20 + 15,
                     repeat: Number.POSITIVE_INFINITY,
                     repeatType: "loop",
                  }}
               >
                  <pre>{snippet}</pre>
               </motion.div>
            );
         })} */}

         {/* Digital Particles */}
         {Array.from({ length: 30 }).map((_, index) => {
            const size = Math.random() * 6 + 2;
            return (
               <motion.div
                  key={`particle-${index}`}
                  className="absolute rounded-full"
                  style={{
                     width: size,
                     height: size,
                     backgroundColor:
                        index % 3 === 0
                           ? "#3b82f6"
                           : index % 3 === 1
                           ? "#10b981"
                           : "#8b5cf6",
                     boxShadow:
                        index % 2 === 0 && index % 3 !== 0
                           ? `0 0 ${size}px #1463fd, 0 0 ${size}px #1463fd`
                           : index % 3 === 0
                           ? `0 0 ${size}px #ec4899 , 0 0 ${size}px #ec4899 `
                           : `0 0 ${size}px #a855f7, 0 0 ${size}px #a855f7`,
                  }}
                  initial={{
                     x: Math.random() * windowWidth,
                     y: Math.random() * windowHeight,
                     opacity: 0,
                  }}
                  animate={{
                     x: [
                        Math.random() * windowWidth,
                        Math.random() * windowWidth,
                        Math.random() * windowWidth,
                     ],
                     y: [
                        Math.random() * windowHeight,
                        Math.random() * windowHeight,
                        Math.random() * windowHeight,
                     ],
                     opacity: [0, 0.8, 0],
                     scale: [0, 1, 0],
                  }}
                  transition={{
                     duration: Math.random() * 20 + 10,
                     repeat: Number.POSITIVE_INFINITY,
                     repeatType: "loop",
                  }}
               />
            );
         })}
         {/* <canvas
            ref={canvasRef}
            className="absolute top-0 left-0 w-full h-full opacity-20"
         /> */}

         {Array.from({ length: 20 }).map((_, index) => (
            <motion.div
               key={index}
               className="absolute rounded-full "
               style={{
                  width: Math.random() * 6 + 2,
                  height: Math.random() * 6 + 2,
                  backgroundColor:
                     index % 3 === 0
                        ? "#3b82f6"
                        : index % 3 === 1
                        ? "#10b981"
                        : "#8b5cf6",
                  boxShadow:
                     index % 3 === 0
                        ? "0 0 10px #3b82f6"
                        : index % 3 === 1
                        ? "0 0 10px #10b981"
                        : "0 0 10px #8b5cf6",
               }}
               animate={{
                  x: [
                     Math.random() * windowWidth,
                     Math.random() * windowWidth,
                     Math.random() * windowWidth,
                  ],
                  y: [
                     Math.random() * windowHeight,
                     Math.random() * windowHeight,
                     Math.random() * windowHeight,
                  ],
               }}
               transition={{
                  duration: Math.random() * 20 + 20,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "linear",
               }}
            />
         ))}
         {/* Shield animation */}
         <motion.div
            className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none"
            initial={{ scale: 0.3, opacity: 0.2 }}
            animate={{
               scale: [0.3, 0.8, 0.3],
               opacity: [0.1, 0.5, 0.1],
               y: 50,
            }}
            transition={{
               duration: 8,
               repeat: Number.POSITIVE_INFINITY,
               repeatType: "loop",
            }}
         >
            <svg
               width="600"
               height="600"
               viewBox="0 0 24 24"
               fill="none"
               xmlns="http:www.w3.org/2000/svg"
            >
               <motion.path
                  d="M12 22C12 22 20 18 20 12V5L12 2L4 5V12C4 18 12 22 12 22Z"
                  stroke="rgba(0, 255, 0, 0.5)"
                  strokeWidth="1"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{
                     duration: 3,
                     repeat: Number.POSITIVE_INFINITY,
                  }}
               />
            </svg>
         </motion.div>

         {/* Circuit board lines */}
         {/* <div className="absolute inset-0 overflow-hidden opacity-80">
            {Array.from({ length: 20 }).map((_, i) => (
               <motion.div
                  key={`circuit-${i}`}
                  className="absolute h-px bg-gradient-to-r from-transparent via-red-500 to-transparent"
                  style={{
                     width: `${Math.random() * 30 + 20}%`,
                     left: `${Math.random() * 100}%`,
                     top: `${Math.random() * 100}%`,
                     rotate: `${Math.random() * 360}deg`,
                  }}
                  animate={{
                     opacity: [0, 0.8, 0],
                     width: [
                        `${Math.random() * 10 + 10}%`,
                        `${Math.random() * 30 + 20}%`,
                     ],
                  }}
                  transition={{
                     duration: Math.random() * 4 + 2,
                     repeat: Number.POSITIVE_INFINITY,
                     repeatType: "reverse",
                     ease: "easeInOut",
                     delay: Math.random() * 2,
                  }}
               />
            ))}
         </div> */}

         {/* Hacking Attempt */}
         {/* <div className="relative w-full  overflow-hidden h-screen bg-transparent">
            {hackingAttempts.map((item, i) => (
               <motion.div
                  key={i}
                  initial={{
                     x: item.x * windowWidth * 0.01,
                     y: -100,
                     opacity: 0,
                  }}
                  animate={{
                     x: item.x * windowWidth * 0.01,
                     y: item.y * windowHeight * 0.01,
                     opacity: 1,
                  }}
                  transition={{
                     duration: item.duration,
                     delay: item.delay,
                     ease: "easeOut",
                  }}
                  className="absolute"
               >
                  <Icon
                     icon={item.icon} // Dynamically set the icon
                     width={item.size}
                     height={item.size}
                     color="lime"
                     className="opacity-70"
                  />
               </motion.div>
            ))}
         </div> */}
      </div>
   );
}
