"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Icon } from "@iconify/react/dist/iconify.js";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import SectionTitle from "@/components/SectionTitle";
import SectionSubtitle from "@/components/SectionSubtitle";

type Props = {
   className: string;
   data?: any;
};

export default function RecoverySteps({ className, data }: Props) {
   const ref = useRef(null);
   const isInView = useInView(ref, { once: false });

   // const steps = [
   //    {
   //       icon: "material-symbols:search",
   //       title: "Identify the Breach",
   //       description:
   //          "Our security experts thoroughly scan your website to identify all malicious code, backdoors, and compromised files.",
   //    },
   //    {
   //       icon: "eva:alert-triangle-outline",
   //       title: "Isolate & Contain",
   //       description:
   //          "We isolate affected areas to prevent further damage and contain the breach from spreading to other parts of your website.",
   //    },
   //    {
   //       icon: "lucide:file-warning",
   //       title: "Clean & Remove",
   //       description:
   //          "All malicious code, files, and unauthorized access points are systematically removed from your website.",
   //    },
   //    {
   //       icon: "solar:database-outline",
   //       title: "Restore & Recover",
   //       description:
   //          "We restore your website from clean backups or rebuild compromised components to return your site to normal operation.",
   //    },
   //    {
   //       icon: "proicons:shield",
   //       title: "Secure & Fortify",
   //       description:
   //          "Implementation of robust security measures to protect against future attacks and vulnerabilities.",
   //    },
   //    {
   //       icon: "bitcoin-icons:refresh-filled",
   //       title: "Monitor & Maintain",
   //       description:
   //          "Ongoing monitoring and maintenance to ensure your website remains secure and protected from emerging threats.",
   //    },
   // ];

   const containerVariants = {
      hidden: { opacity: 0 },
      visible: {
         opacity: 1,
         transition: {
            staggerChildren: 0.2,
         },
      },
   };

   const itemVariants = {
      hidden: { y: 20, opacity: 0 },
      visible: {
         y: 0,
         opacity: 1,
         transition: { duration: 0.5 },
      },
   };

   return (
      <div
         className={twMerge(
            clsx(
               "py-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden",
               className
            )
         )}
      >
         {/* Background elements */}
         <div className="absolute inset-0 overflow-hidden ">
            {Array.from({ length: 5 }).map((_, i) => (
               <motion.div
                  key={`bg-line-${i}`}
                  className="absolute h-px bg-gradient-to-r from-transparent via-[#262626] to-transparent"
                  style={{
                     width: "100%",
                     left: 0,
                     top: `${20 + i * 15}%`,
                  }}
                  animate={{
                     x: ["-100%", "100%"],
                  }}
                  transition={{
                     duration: 15 + i * 5,
                     repeat: Number.POSITIVE_INFINITY,
                     ease: "linear",
                  }}
               />
            ))}
         </div>

         <div className=" relative z-10">
            <motion.div
               className="text-center mb-16"
               initial={{ opacity: 0, y: 20 }}
               animate={isInView ? { opacity: 1, y: 0 } : {}}
               transition={{ duration: 0.8 }}
            >
               <SectionTitle className="max-w-3xl m-auto">
                  {data.title}               </SectionTitle>
               <SectionSubtitle className="m-auto">
                  {data.subTitle}
               </SectionSubtitle>
            </motion.div>

            <motion.div
               ref={ref}
               className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 "
               variants={containerVariants}
               initial="hidden"
               animate={isInView ? "visible" : "hidden"}
            >
               {data.steps.map((step: any, index: number) => (
                  <motion.div
                     key={index}
                     className="bg-black/40 backdrop-blur-sm border border-[#262626] rounded-lg p-6 relative overflow-hidden group"
                     variants={itemVariants}
                     whileHover={{
                        y: -5,
                        boxShadow: "0 10px 25px -5px rgba(0, 255, 0, 0.1)",
                        borderColor: "#fff",
                     }}
                  >
                     <div className="absolute group -top-10 right-5 w-20 h-20 opacity-5 group-hover:opacity-20 group-hover:text-blue-500 transition-all duration-1000">
                        <Icon icon={step.icon} width="170" height="170" />
                     </div>

                     <div className="flex items-center mb-4">
                        <div className="w-12 h-12 rounded-full bg-[#626262]/30 flex items-center justify-center mr-4">
                           <Icon icon={step.icon} width="24" height="24" />
                        </div>
                        <span className="text-xs font-medium text-[#fafafa] bg-[#626262]/30 px-2 py-1 rounded-full">
                           {data.step} {index + 1}
                        </span>
                     </div>

                     <h3 className="text-xl font-bold mb-3">{step.title}</h3>
                     <p className="text-gray-300">{step.description}</p>

                     <motion.div
                        className="w-full h-1 bg-gradient-to-r from-stone-500/0 via-[#fff]/50 to-stone-500/0 absolute bottom-0 left-0"
                        animate={{
                           x: ["-100%", "100%"],
                        }}
                        transition={{
                           duration: 3,
                           repeat: Number.POSITIVE_INFINITY,
                           ease: "linear",
                           delay: index * 0.5,
                        }}
                     />
                  </motion.div>
               ))}
            </motion.div>
         </div>
      </div>
   );
}
