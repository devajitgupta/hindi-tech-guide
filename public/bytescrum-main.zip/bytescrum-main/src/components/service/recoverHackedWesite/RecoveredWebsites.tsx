"use client";

import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import { EffectCoverflow } from "swiper/modules";
import { useMediaQuery } from "@react-hook/media-query";
import { useState } from "react";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import clsx from "clsx";
import Image from "next/image";
import React from "react";
import { twMerge } from "tailwind-merge";
import "./recoverHacked.css";

interface IProps {
   className?: string;
   data?: any;
}

const RecoveredWebsites = ({ className, data }: IProps) => {
   const isExtraSmallScreen = useMediaQuery("(max-width: 599px)");
   const isSmallScreen = useMediaQuery(
      "(min-width: 600px) and (max-width: 767.99px)"
   );
   const isMediumScreen = useMediaQuery(
      "(min-width: 768px) and (max-width: 1023.99px)"
   );
   const isLargeScreen = useMediaQuery(
      "(min-width: 1024px) and (max-width: 1439.99px)"
   );
   const isExtraLargeScreen = useMediaQuery("(min-width: 1440px)");
   const [currentSlide, setCurrentSlide] = useState(0);
   return (
      <div className={twMerge(clsx(className, "pt-20"))}>
         {" "}
         <SectionTitle>{data.title}</SectionTitle>
         <SectionSubtitle
            className=" text-center m-auto max-w-[325px]  md:max-w-[750px] "
            variant="primary"
         >
        {data.subTitle}
         </SectionSubtitle>
         <div
            className={twMerge(
               clsx(
                  " transition-transform duration-200 ease-in-out transform my-20 ",
                  className
               )
            )}
         >
            <Swiper
               spaceBetween={
                  isExtraSmallScreen
                     ? 40
                     : isSmallScreen
                     ? 50
                     : isMediumScreen
                     ? 80
                     : isLargeScreen
                     ? 150
                     : isExtraLargeScreen
                     ? 150
                     : 200
               }
               autoplay={{
                  delay: 3000,
                  disableOnInteraction: true,
               }}
               autoHeight={true}
               pagination={true}
               modules={[Pagination, EffectCoverflow, Autoplay]}
               effect={"coverflow"}
               grabCursor={false}
               centeredSlides={true}
               slidesPerView={"auto"}
               followFinger={true}
               initialSlide={1}
               simulateTouch={true}
               speed={1700}
               roundLengths={true}
               coverflowEffect={
                  isSmallScreen
                     ? {
                          rotate: 0,
                          stretch: 10,
                          depth: 50,
                          modifier: 3,
                          slideShadows: true,
                       }
                     : isMediumScreen
                     ? {
                          rotate: 0,
                          stretch: 10,
                          depth: 100,
                          modifier: 3,
                          slideShadows: true,
                       }
                     : {
                          rotate: 0,
                          stretch: 10,
                          depth: 50,
                          modifier: 3,
                          slideShadows: true,
                       }
               }
               loop={true}
               onSlideChange={(swiper) => setCurrentSlide(swiper.realIndex)}
               className="blogswiper md:rounded-[16px] cursor-pointer transition-transform duration-200 ease-in-out transform rounded-[8px]"
            >
               {data.cardData.map((item: any, index: number) => (
                  <SwiperSlide key={index}>
                     <div
                        className={clsx(
                           "grid lg:grid-cols-2 border border-[#585858] max-w-[280px] xs:max-w-[323px]  md:max-w-[490px] lg:max-w-[800px] rounded-[8px] md:rounded-[16px] bg-[#0e0e0e] group",
                           {
                              "opacity-30  ": currentSlide !== index,
                              "opacity-100": currentSlide === index,
                           }
                        )}
                     >
                        <div className="h-full object-fit rounded-tl-[18px] xl:rounded-bl-[18px] overflow-hidden ">
                           <Image
                              src={item.img}
                              alt="{blog.src}"
                              width={1120}
                              height={0}
                              className={twMerge(
                                 clsx(
                                    "object-cover rounded-tr-[18px] xl:rounded-tr-none rounded-bl-none  h-auto  transition-all duration-1000  ",
                                    {
                                       "group-hover:scale-125":
                                          currentSlide === index,
                                    }
                                 )
                              )}
                           />
                        </div>

                        <div className="px-[17px] pt-[30px] pb-[40px] md:py-[27px]  md:px-[35px] grid items-center gap-[20px]">
                           <div className="grid gap-[10px]">
                              <h3 className="poppins text-[18px] sm:text-[20px] leading-[24px] md:leading-[28px] text-[#ffffff] ">
                                 {item.title}
                              </h3>
                              <p className="inter text-[14px] sm:text-[16px] text-[#a4a4a4] leading-[20px] sm:leading-[24px] md:leading-[28px]">
                                 {item.text}
                              </p>
                           </div>
                        </div>
                     </div>
                  </SwiperSlide>
               ))}
            </Swiper>
         </div>
      </div>
   );
};

export default RecoveredWebsites;

// const cardData = [
//    {
//       img: "/recoverHacked/hacked-services-01.webp",
//       title: " COTE - WordPress",
//       text: "  We have stored this WordPress site by removing the javascript injections from database and files. Then we have protected this website by adding firewall, file permissions, change default login url.",
//    },
//    {
//       img: "/recoverHacked/hacked-services-02.webp",
//       title: "Web Application Firewall (WAF) Implementation",
//       text: "We set up a Web Application Firewall to monitor and filter incoming web traffic, preventing malicious requests and safeguarding your website from typical assaults.",
//    },
//    {
//       img: "/recoverHacked/hacked-services-03.webp",
//       title: "Malware Scanning and Removal",
//       text: "Our security professionals employ powerful scanning techniques to discover and remove malware, viruses, and harmful code from your website, guaranteeing that it is clean and secure for users.",
//    },
//    {
//       img: "/recoverHacked/hacked-services-02.webp",
//       title: "Web Application Firewall (WAF) Implementation",
//       text: "We set up a Web Application Firewall to monitor and filter incoming web traffic, preventing malicious requests and safeguarding your website from typical assaults.",
//    },
// ];
