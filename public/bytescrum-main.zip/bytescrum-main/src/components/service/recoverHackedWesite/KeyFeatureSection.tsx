"use client";

import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";

import { Icon } from "@iconify/react/dist/iconify.js";
import clsx from "clsx";
import React from "react";
import { twMerge } from "tailwind-merge";
interface IProps {
   className?: string;
   data?: any;
}

const KeyFeatureSection = ({ className, data }: IProps) => {
   return (
      <div className={twMerge(clsx(className))}>
         <SectionSubtitle
            textSize="sm"
            className="text-center  tracking-widest m-auto border border-[#262626] w-fit px-5 py-1 rounded-full bg-[#1a1a1a]/65  "
         >
            {data.title}
         </SectionSubtitle>
         <SectionTitle>{data.titleOne}</SectionTitle>
         <div className="md:py-10 lg:px-20 grid md:grid-cols-2 lg:grid-cols-3 justify-center items-center gap-4 md:gap-8 mt-10">
            {data.cardData.map((item:any, index:number) => (
               <div key={index} className="group transition-all duration-500 ">
                  <div
                     className="border  flex flex-col gap-2 md:gap-4 p-5 w-full rounded-lg border-[#262626] md:min-h-[235px] 
        transition-all duration-500 ease-in-out transform group-hover:scale-105 group-hover:bg-white"
                  >
                     <div className="flex items-center w-full gap-4">
                        <div
                           className="w-12 h-12 border rounded-full bg-[#1a1a1a]/65 border-[#262626] 
            transition-all duration-500 ease-in-out transform group-hover:border-gray-300 group-hover:bg-gray-200 flex items-center  justify-center"
                        >
                           <Icon
                              icon={item.icon}
                              className="text-white m-auto text-lg lg:text-xl transition-all duration-500 ease-in-out group-hover:text-gray-700"
                           />
                        </div>
                        <h3 className="text-[16px] lg:text-[18px] font-semibold transition-all duration-500 ease-in-out group-hover:text-black  ">
                           {item.title}
                        </h3>
                     </div>

                     <div>
                        <p
                           className="inter text-[12px] md:text-[16px] leading-[28px] max-w-full lg:max-w-[743px] text-start mt-3 
            transition-all duration-500 ease-in-out group-hover:text-black line-clamp-4"
                        >
                           {item.text}
                        </p>
                     </div>
                  </div>
               </div>
            ))}
         </div>
      </div>
   );
};

export default KeyFeatureSection;

// const cardData = [
//    {
//       icon: "fa-solid:eye",
//       title: "Unusual Website Behavior",
//       text: "Unusual Website Behavior Website abnormalities, such as unexpected content, diverting viewers to other page, or slow loading, may indicate a hacking event.",
//    },
//    {
//       icon: "fa6-solid:layer-group",
//       title: "Spam or Malicious Content",
//       text: "On your website's pages, the inclusion of spammy or irrelevant content, unapproved adverts, or strange connections might indicate a hack.",
//    },
//    {
//       icon: "fa:database",
//       title: "Traffic Spikes or Drops",
//       text: "Significant and unexplained fluctuations in internet traffic patterns might indicate that your website has been hacked, either spiking up or down.",
//    },
//    {
//       icon: "fa6-solid:lock",
//       title: "Strange Pop-ups or Alerts",
//       text: "Strange Pop-ups or Alerts If your website displays unexpected pop-ups, prompts to download suspicious files, or browser alerts, it could be a sign of a hack.",
//    },
//    {
//       icon: "fa6-solid:cloud-bolt",
//       title: "Google Search Warnings",
//       text: "Google Search Warnings Google may display security warnings in search results  your site is blocked  for websites deemed hacked or harmful malwares.",
//    },
//    {
//       icon: "fa6-solid:chart-pie",
//       title: "Injected Malicious Code",
//       text: "Examine the source code of your website for any strange or suspicious code snippets that may have been introduced by attackers.",
//    },
// ];
