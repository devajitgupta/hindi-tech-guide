"use client";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import { useRef } from "react";
import { motion, useScroll, useTransform, useSpring } from "framer-motion";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import Image from "next/image";
import Text from "@/components/Text";

interface IProps {
   className?: string;
   data?: any;
}

const FutureHacking = ({ className, data }: IProps) => {
   const ref = useRef(null);
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth <= 430;

   const { scrollYProgress } = useScroll({
      target: ref,
      offset: ["center end", "end start"],
   });

   const smoothScrollYProgress = useSpring(scrollYProgress, {
      damping: 20,
      stiffness: 100,
   });

   const imgY = useTransform(scrollYProgress, [0, 1], ["0%", "20%"]);
   const colY = useTransform(smoothScrollYProgress, [0, 1], ["15%", "-15%"]);
   return (
      <div className={twMerge(clsx(className))}>
         {/* <SectionSubtitle
            textSize="sm"
            className="text-center  tracking-widest m-auto border border-[#262626] w-fit px-5 py-1 rounded-full bg-[#1a1a1a]/65  "
         >
            Preventing Future Hacking
         </SectionSubtitle> */}
         {/* <SectionTitle>Hacked Website Recovery</SectionTitle> */}

         <div
            className="grid lg:grid-cols-11  md:gap-10 items-center justify-center "
            ref={ref}
         >
            <motion.div
               className="m-auto  md:pe-1 lg:col-span-5"
               style={{ y: imgY }}
            >
               <div className="relative transition-all duration-[50s]">
                  <Image
                     src={"/recoverHacked/recoveryBanner.png"}
                     width={500}
                     height={0}
                     alt="Banner"
                     className="m-auto h-auto"
                  />
               </div>
            </motion.div>
            <div className="  lg:col-span-6 max-w-[650px]">
               <motion.div
                  className=" space-y-5  "
                  style={!matches ? { y: colY } : {}}
               >
                  <SectionSubtitle
                     textSize="sm"
                     className="text-center  tracking-widest m-auto border border-[#262626] w-fit px-5 py-1 rounded-full bg-[#1a1a1a]/65  "
                  >
                     {data.title}
                  </SectionSubtitle>
                  <SectionTitle className="group text-start flex justify-start items-center max-w-[346px] md:max-w-[712px] ">
                     {" "}
 {data.titleOne}                  </SectionTitle>
                  <Text className="text-start">
                     {" "}
                 {data.subTitle}
                  </Text>
                  <p className="py-5 px-2 border border-[#1b1b1b] bg-[#090909] max-w-[620px] flex items-center rounded-[8px] ">
                     {/* <VerticleLineIcon /> */}
                     <span className="inter text-[16px] md:text-[20px] lg:leading-[28px]  ps-5 flex  md:max-w-full ">
 {data.titleTwo}                     </span>
                  </p>

                  <Text className=" text-start space-y-[30px] mt-[10px]">
                    {data.subTitleOne}
                  </Text>
                  <p className="py-5 px-2 border border-[#1b1b1b] bg-[#090909] max-w-[620px] flex items-center rounded-[8px] ">
                     {/* <VerticleLineIcon /> */}
                     <span className="inter text-[16px] md:text-[20px] lg:leading-[28px]  ps-5 flex  md:max-w-full ">
                        {data.subTitleTwo}
                     </span>
                  </p>
                  <Text className="text-start">
                                        {data.subTitleThree}

                  </Text>
               </motion.div>
            </div>
         </div>
      </div>
   );
};

export default FutureHacking;
