"use client";
import PageBanner from "@/components/PageBanner";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";

interface IProps {
   className?: string;
   data?: any;
}

const RecoverPageBanner = ({ className, data }: IProps) => {
   return (
      <PageBanner
         bgPath={"/recoverHacked/recoverBanner.png"}
         bannerHeight={"h-[32vh ] md:h-[55vh]"}
         className={twMerge(
            clsx(
               "relative overflow-hidden px-[22px] md:px-[54px]  items-center justify-normal "
            )
         )}
      >
         <div className="grid  gap-y-5  ">
            <div className="grid items-center">
               <div>
                  <p
                     className="poppins text-[#b7b7b7] text-[14px] md:text-[18px]"
                     data-aos="fade-up"
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  ></p>
                  <h1
                     className="text-[35px] md:text-[70px] md:leading-[80px] font-light  poppins text-center "
                     data-aos="fade-up"
                     data-aos-delay={300}
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     Website Rescue:
                     <br />
                     <span className="font-bold"> Regain Website Control</span>
                  </h1>
                  <p
                     className="max-w-[609px] text-[16px] leading-[28px]  text-center m-auto"
                     data-aos="fade-up"
                     data-aos-delay={500}
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     Home | Recover-Hacked-Website
                  </p>
               </div>
            </div>
         </div>
      </PageBanner>
   );
};

export default RecoverPageBanner;
