"use client";
import SectionTitle from "@/components/SectionTitle";
import clsx from "clsx";
import Image from "next/image";
import React from "react";
import { twMerge } from "tailwind-merge";
import ParallaxBanner from "@/components/ParallaxBanner";

interface IProps {
   className?: string;
   data?: any;
}

const SecuritySection = ({ className, data }: IProps) => {
   const sData = data.securitySection
   return (
      <div className={twMerge(clsx(className))}>
         {" "}
         <SectionTitle className="text-start  mb-10 max-w-[650px]">
            {sData.title}
         </SectionTitle>
         <div className="grid lg:grid-cols-7 pb-8 lg:pb-16">
            <div className="space-y-5 lg:col-span-4 m-auto lg:order-1 order-2">
               <p className="text-[16px]">
                  {sData.subTitleitle}
               </p>
               <p>
                  {sData.subTitleTwo}    </p>
               <p>
                  {sData.subTitleThree}
               </p>
            </div>
            <div className="lg:col-span-3 m-auto order-1 lg:order-2  w-full lg:w-auto my-12 ">
               <div className="flex items-center justify-center m-auto pb-4 ps-2  relative  w-full ">
                  <span className="text-[13rem] md:text-[18rem] text-white  absolute -top-36 -right-4 md:-top-52 md:-right-5 font-semibold">
                     ?
                  </span>
                  <Image
                     src={"/recoverHacked/websecurity.png"}
                     // src={"/recoverHacked/para_img.jpg"}
                     width={375}
                     height={375}
                     alt="Cyber Security"
                     className="m-auto w-full"
                  />
               </div>
            </div>
         </div>
         <ParallaxBanner
            className="mt-16"
            desktopBgImage={"/recoverHacked/para_002_1.png"}
            mobileBgImage={"/recoverHacked/parraMobile.png"}
            sData={data}
            href={"/"}
         />
      </div>
   );
};

export default SecuritySection;

// const sData = {
//    title: "HACK RECOVERY SERVICE",
// };
