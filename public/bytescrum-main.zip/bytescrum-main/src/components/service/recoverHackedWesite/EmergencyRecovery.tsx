"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Icon } from "@iconify/react/dist/iconify.js";
import SectionTitle from "@/components/SectionTitle";

import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import Text from "@/components/Text";
import { Button } from "@nextui-org/react";
import useConsultationStore from "@/libs/stores/useConsultationStore";

export default function EmergencyRecovery({
   className,
   data,
}: {
   className: string;
   data:any
}) {
   const { openModel, isOpen, closeModel } = useConsultationStore();
   const ref = useRef(null);
   const isInView = useInView(ref, { once: false, amount: 0.2 });

   return (
      <div
         ref={ref}
         className={twMerge(
            clsx(
               "  bg-gradient-to-b lg:bg-gradient-to-r  from-[#0D0D0D]/50 to-[#2A2A2A]/50 relative overflow-hidden group",
               className
            )
         )}
      >
         {" "}
         <div className="absolute group -bottom-40 -right-20  opacity-5 group-hover:opacity-20 group-hover:text-blue-500 transition-all duration-1000 -rotate-45">
            <Icon icon="proicons:shield" width="370" height="370" />
         </div>
         <div className=" sm:px-4 md::px-6 max-w-7xl m-auto lg:px-8 relative overflow-hidden">
            {/* Animated background elements */}
            <div className="absolute inset-0">
               <motion.div
                  className="absolute inset-0 bg-gradient-radial from-green-900/20 to-transparent opacity-30"
                  animate={{
                     scale: [1, 1.1, 1],
                  }}
                  transition={{
                     duration: 8,
                     repeat: Number.POSITIVE_INFINITY,
                     repeatType: "reverse",
                  }}
               />

               {Array.from({ length: 3 }).map((_, i) => (
                  <motion.div
                     key={`shield-${i}`}
                     className="absolute opacity-20"
                     style={{
                        top: `${20 + i * 25}%`,
                        left: `${10 + i * 30}%`,
                     }}
                     animate={{
                        rotate: [0, 360],
                        scale: [1, 2, 0.9, 1],
                     }}
                     transition={{
                        rotate: {
                           duration: 20 + i * 5,
                           repeat: Number.POSITIVE_INFINITY,
                           ease: "linear",
                        },
                        scale: {
                           duration: 8,
                           repeat: Number.POSITIVE_INFINITY,
                           repeatType: "loop",
                        },
                     }}
                  >
                     <Icon
                        icon="proicons:shield"
                        width="42"
                        height="42"
                        className="text-[#565656]"
                     />
                  </motion.div>
               ))}
            </div>

            <div className=" relative z-10">
               <motion.div
                  initial={{ opacity: 0, x: -50 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ duration: 0.8 }}
                  className="grid md:grid-cols-2 gap-x-20 gap-y-10 items-center"
               >
                  <div>
                     <SectionTitle className="text-start">
                       {data.title}{' '}
                        <span className="text-[#565656]">{data.titleThree}</span>
                        ?
                     </SectionTitle>
                     <Text className="text-start lg:max-w-2xl mt-1">
                       {data.subTitle}
                     </Text>

                     <Button
                        className={twMerge(
                           clsx(
                              " text-[14px] text-center  md:px-[30px] py-[10px] font-bold inter leading-[24px] text-[#ffffff] hover:border-[#1463fd]  hover:text-[#1463fd] connectBtn mt-5 "
                           )
                        )}
                        onPress={() => openModel("emergency")}
                     >
                       {data.titleOne}
                        <motion.span
                           animate={{ x: [0, 4, 0] }}
                           transition={{
                              repeat: Number.POSITIVE_INFINITY,
                              duration: 1.5,
                           }}
                           className="ml-2"
                        >
                        
                           <Icon
                              icon="formkit:arrowright"
                              width="25"
                              height="15"
                              className="text-[#fff]"
                           />
                        </motion.span>
                     </Button>
                  </div>

                  <div className=" md:ml-20 rounded-lg md:p-6 mb-8">
                     <h3 className="text-xl font-bold mb-4 flex items-center">
                        <Icon icon="proicons:shield" width="24" height="24" />
{data.titleTwo}                     </h3>
                     <ul className="space-y-3">
                        {[
                           "24/7 Emergency Response Team",
                           "Complete Malware Removal",
                           "Security Vulnerability Patching",
                           "Post-Recovery Monitoring",
                           "Preventive Security Measures",
                        ].map((item, index) => (
                           <motion.li
                              key={index}
                              className="flex items-center justify-start"
                              initial={{ opacity: 0, x: -20 }}
                              animate={isInView ? { opacity: 1, x: 0 } : {}}
                              transition={{ duration: 0.5, delay: 0.1 * index }}
                           >
                              <motion.div
                                 className="mr-2 mt-1"
                                 animate={{
                                    rotate: [0, 10, 0],
                                    scale: [0.8, 1.1, 0.8],
                                 }}
                                 transition={{
                                    duration: 1,
                                    delay: 0.2 * index,
                                    repeat: Number.POSITIVE_INFINITY,
                                    repeatDelay: 5,
                                 }}
                              >
                                 <Icon
                                    icon="formkit:arrowright"
                                    width="25"
                                    height="15"
                                    className="text-[#565656]"
                                 />
                              </motion.div>
                              <span>{item}</span>
                           </motion.li>
                        ))}
                     </ul>
                  </div>
               </motion.div>
            </div>
         </div>
      </div>
   );
}
