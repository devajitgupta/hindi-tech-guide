"use client";

import useBreakpoints from "@/common/hooks/useBreakpoints ";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import clsx from "clsx";
import Image from "next/image";
import React, { useState } from "react";
import { twMerge } from "tailwind-merge";
interface IProps {
   className?: string;
   data?: any;
}

const OfferSection = ({ className, data }: IProps) => {
   const { screenWidth } = useBreakpoints();
   const isSmall = screenWidth <= 1023;
   const [selectedCard, setSelectedCard] = useState(data.cardData[0]);

   const handleCardClick = (card: (typeof data.cardData)[0]) => {
      setSelectedCard(card);
   };

   return (
      <div className={twMerge(clsx(className))}>
         {" "}
         <SectionTitle className="mb-10 ">
            {data.title}
         </SectionTitle>
         <div className="grid lg:grid-cols-12 gap-16 xl:p-5">
            {/* NOTE: Left-side  */}

            <div className="hidden lg:block lg:col-span-6 xl:col-span-7 space-y-5">
               <div
                  className=" overflow-hidden w-full min-h-[350px]"
                  style={{
                     backgroundImage: `url(${selectedCard.img})`,
                     backgroundSize: "cover",
                     backgroundPosition: "center",
                  }}
               >
                  {/* <Image
                     src={selectedCard.img}
                     width={500}
                     height={500}
                     alt="Img"
                     className="w-full h-[330px]"
                  /> */}
               </div>
               <div className="py-5 space-y-3">
                  <SectionSubtitle
                     className="text-start font-semibold md:text-[42px]"
                     textSize="xxxl"
                  >
                     {selectedCard.title}
                  </SectionSubtitle>
                  <Text className="text-start pe-10">{selectedCard.text}</Text>
               </div>
            </div>

            {/* NOTE: Right-side  */}
            <div className=" lg:col-span-6 xl:col-span-5 pe-2 space-y-5 lg:max-h-[540px] lg:overflow-y-auto ">
               {data.cardData.map((item:any, index:number) => (
                  <div
                     key={index}
                     className="w-full grid lg:grid-cols-12 items-center gap-5 bg-[#0f0f0f]/70 cursor-pointer "
                     onClick={() => handleCardClick(item)}
                  >
                     <div className="lg:col-span-4 ">
                        {" "}
                        <Image
                           src={item.img}
                           width={500}
                           height={700}
                           alt="Img"
                           className="w-full h-full"
                        />
                     </div>
                     <div className="lg:col-span-8 space-y-3 p-3 lg-0">
                        <SectionSubtitle
                           className="text-start"
                           textSize={isSmall ? "xxxl" : "sm"}
                        >
                           {item.title}
                        </SectionSubtitle>
                        <p className="text-start text-[16px] lg:text-[12px] text-[#bcbcbc] lg:truncate lg:line-clamp-2 text-wrap lg:pe-5">
                           {item.text}
                        </p>
                     </div>
                  </div>
               ))}
            </div>
         </div>
      </div>
   );
};

export default OfferSection;

// const cardData = [
//    {
//       img: "/recoverHacked/websecurity_02.png",
//       title: "Website Security Audit",
//       text: "We do a comprehensive security assessment on your website to detect weaknesses, potential access points for hackers, and areas that need to be strengthened.",
//    },
//    {
//       img: "/recoverHacked/img-02.jpg",
//       title: "Web Application Firewall (WAF) Implementation",
//       text: "We set up a Web Application Firewall to monitor and filter incoming web traffic, preventing malicious requests and safeguarding your website from typical assaults.",
//    },
//    {
//       img: "/recoverHacked/img-03.jpg",
//       title: "Malware Scanning and Removal",
//       text: "Our security professionals employ powerful scanning techniques to discover and remove malware, viruses, and harmful code from your website, guaranteeing that it is clean and secure for users.",
//    },
//    {
//       img: "/recoverHacked/img-04.jpg",
//       title: "SSL Certificate Installation",
//       text: "We safeguard critical information such as login passwords and payment details by securing your website with an SSL certificate, which encrypts data passed between your server and visitors' browsers",
//    },
//    {
//       img: "/recoverHacked/img-05.jpg",
//       title: "Regular Software Updates",
//       text: "Our staff guarantees that the CMS, plugins, themes, and other software on your website are kept up to date with the most recent security updates and versions to address known vulnerabilities.",
//    },
//    {
//       img: "/recoverHacked/img-06.svg",
//       title: "24/7 Security Support",
//       text: "Our specialized security support team is accessible 24 hours a day, 7 days a week to assist you with any security issues or occurrences.",
//    },
// ];
