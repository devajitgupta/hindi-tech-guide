"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useAnimation, useInView } from "framer-motion";
import { Icon } from "@iconify/react";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";

// Define the type for our elements
interface AnimatedElement {
   id: number;
   x: number;
   y: number;
   size: number;
   opacity: number;
   speed: number;
   delay: number;
   icon: string;
   rotate: number;
}

export default function WebDevBanner({
   className = "",
   primaryColor = "#1463fd",
   secondaryColor = "#002774",
   density = 55, // Number of elements
}) {
   const ref = useRef(null);
   const isInView = useInView(ref, { once: false });
   const controls = useAnimation();
   const [windowSize, setWindowSize] = useState({ width: 0, height: 0 });

   // Generate random elements
   const generateElements = (count: number): AnimatedElement[] => {
      const elements: AnimatedElement[] = [];
      const icons = [
         "logos:react",
         "logos:nodejs",
         "devicon:mongodb",
         "logos:postgresql",
         "logos:javascript",
         "devicon:typescript",
         "logos:html-5",
         "logos:css-3",
         "logos:sass",
         "skill-icons:tailwindcss-light",
         "logos:redux",
         "logos:graphql",
         "material-icon-theme:docker",
         "material-icon-theme:git",
         "fontisto:aws",
      ];

      for (let i = 0; i < count; i++) {
         elements.push({
            id: i,
            x: Math.random() * 100, // % position
            y: Math.random() * 100, // % position
            size: Math.random() * 20 + 20, // Size between 20-40px
            opacity: Math.random() * 0.4 + 0.1, // Opacity between 0.1-0.5
            speed: Math.random() * 40 + 20, // Animation duration 20-60s
            delay: Math.random() * 2, // Delay 0-5s
            icon: icons[Math.floor(Math.random() * icons.length)],
            rotate: Math.random() * 360, // Initial rotation
         });
      }
      return elements;
   };

   const [elements, setElements] = useState<AnimatedElement[]>([]);

   useEffect(() => {
      if (typeof window !== "undefined") {
         setWindowSize({
            width: window.innerWidth,
            height: window.innerHeight,
         });

         const handleResize = () => {
            setWindowSize({
               width: window.innerWidth,
               height: window.innerHeight,
            });
         };

         window.addEventListener("resize", handleResize);
         return () => window.removeEventListener("resize", handleResize);
      }
   }, []);

   useEffect(() => {
      if (windowSize.width > 0) {
         setElements(generateElements(density));
      }
   }, [windowSize, density]);

   useEffect(() => {
      if (isInView) {
         controls.start("visible");
      }
   }, [controls, isInView]);

   // Generate code snippets
   const codeSnippets = [
      "<div className='container'>",
      "function App() {",
      "const [state, setState] = useState()",
      "return <Component />",
      "import React from 'react'",
      "@tailwind base;",
      ".header { display: flex; }",
      "export default function()",
      "<motion.div animate={{ x: 100 }}>",
      "npm install next",
      "git commit -m 'Update'",
      "const router = useRouter()",
      '<Image src={logo || "/placeholder.svg"} />',
      "async function getData()",
      "const data = await fetch('/api')",
   ];

   return (
      <div
         ref={ref}
         className={` absolute inset-0 w-full h-full overflow-hidden pointer-events-none ${className}`}
      >
         {/* Floating code snippets */}
         {codeSnippets.map((snippet, index) => (
            <motion.div
               key={`code-${index}`}
               className={`absolute w-full h-full text-xs sm:text-sm md:text-base font-mono text-green-500 opacity-80 whitespace-nowrap`}
               initial={{
                  x: Math.random() * windowSize.width,
                  y: Math.random() * windowSize.height,
                  opacity: 0.1,
               }}
               animate={{
                  x: [
                     Math.random() * windowSize.width,
                     Math.random() * windowSize.width,
                     Math.random() * windowSize.width,
                  ],
                  y: [
                     Math.random() * windowSize.height,
                     Math.random() * windowSize.height,
                     Math.random() * windowSize.height,
                  ],
                  opacity: [0.1, 0.7, 0.1],
               }}
               transition={{
                  duration: Math.random() * 60 + 30,
                  delay: Math.random() * 5,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "linear",
               }}
            >
               {snippet}
            </motion.div>
         ))}

         {/* Animated particles */}
         <div className="absolute w-full h-full inset-0">
            {[...Array(80)].map((_, index) => {
               const size = Math.random() * 1 + 20;
               return (
                  <motion.div
                     key={`particle-${index}`}
                     className={twMerge(
                        clsx("absolute w-1 h-1 rounded-full bg-purple-500 ", {
                           "bg-[#1463fd] ": index % 2 === 0,
                        })
                     )}
                     style={{
                        width: size,
                        height: size,
                        boxShadow:
                           index % 2 === 0
                              ? `0 0 ${size}px #1463fd, 0 0 ${size}px #1463fd`
                              : `0 0 ${size}px #a855f7, 0 0 ${size}px #a855f7`,
                     }}
                     initial={{
                        x: Math.random() * windowSize.width,
                        y: Math.random() * windowSize.height,
                        opacity: 1,
                        scale: 0,
                     }}
                     animate={{
                        z: [
                           Math.random() * windowSize.height,
                           -Math.random() * windowSize.height,
                        ],
                        x: [
                           Math.random() * windowSize.width,
                           Math.random() * windowSize.width,
                        ],
                        y: [
                           Math.random() * windowSize.height,
                           Math.random() * windowSize.height,
                        ],
                        opacity: [0, 1, 0],
                        scale: [0, 1, 0],
                     }}
                     transition={{
                        duration: Math.random() * 10 + 10,
                        delay: Math.random() * 5,
                        repeat: Number.POSITIVE_INFINITY,
                        ease: "easeInOut",
                     }}
                  />
               );
            })}
         </div>

         {/* Responsive design elements */}
         <div className="absolute bottom-0 left-0 right-0 h-40 opacity-30">
            <motion.div
               className={`absolute bottom-0 left-0 right-0 h-full bg-gradient-to-t from-[#000]/30 to-transparent`}
               initial={{ y: 40, opacity: 0 }}
               animate={{ y: 0, opacity: 1 }}
               transition={{ duration: 1.5, ease: "easeOut" }}
            />

            <motion.div
               className="absolute bottom-10 left-1/2 transform -translate-x-1/2 flex space-x-2"
               initial={{ y: 20, opacity: 0 }}
               animate={{ y: 0, opacity: 0.7 }}
               transition={{ duration: 1, delay: 0.5 }}
            >
               <motion.div
                  className={`w-8 h-8 rounded-full border-2 border-purple-500`}
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
               />
               <motion.div
                  className={`w-4 h-8 rounded-full border-2 border-purple-500`}
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{
                     duration: 2,
                     delay: 0.3,
                     repeat: Number.POSITIVE_INFINITY,
                  }}
               />
               <motion.div
                  className={`w-12 h-8 rounded border-2 border-purple-500`}
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{
                     duration: 2,
                     delay: 0.6,
                     repeat: Number.POSITIVE_INFINITY,
                  }}
               />
            </motion.div>
         </div>

         {/* Floating icon */}
         {Array.from({ length: 25 }).map((_, index) => {
            const icons = [
               "logos:react",
               "logos:nodejs",
               "devicon:mongodb",
               "logos:postgresql",
               "logos:javascript",
               "devicon:typescript",
               "logos:html-5",
               "logos:css-3",
               "logos:sass",
               "skill-icons:tailwindcss-light",
               "logos:redux",
               "logos:graphql",
               "material-icon-theme:docker",
               "material-icon-theme:git",
               "fontisto:aws",
            ];

            const icon = icons[index % icons.length];
            const size = Math.random() * 30 + 30;
            const layer = Math.floor(Math.random() * 3);
            const yPos =
               layer === 0
                  ? Math.random() * 30 + 100
                  : layer === 1
                  ? Math.random() * 30 + 300
                  : Math.random() * 30 + 500;

            return (
               <motion.div
                  key={`icon-${index}`}
                  className="absolute  flex items-center justify-center"
                  style={{
                     width: size,
                     height: size,
                  }}
                  initial={{
                     x: Math.random() * windowSize.width,
                     y: Math.random() * windowSize.height,
                     opacity: 0,
                  }}
                  animate={{
                     x: [
                        Math.random() * windowSize.width,
                        Math.random() * windowSize.width,
                        Math.random() * windowSize.width,
                     ],
                     y: [
                        Math.random() *
                           windowSize.height *
                           Math.sin(index * 0.2),
                        Math.random() *
                           windowSize.height *
                           Math.sin(index * 0.2),
                        Math.random() *
                           windowSize.height *
                           Math.sin(index * 0.2),
                     ],
                     z: [
                        Math.random() * windowSize.height,
                        Math.random() * windowSize.width,
                     ],
                     opacity: [0, 0.8, 0],
                     rotate: [0, 360],
                  }}
                  transition={{
                     duration: Math.random() * 20 + 20,
                     repeat: Number.POSITIVE_INFINITY,
                     repeatType: "loop",
                     rotate: {
                        duration: Math.random() * 10 + 10,
                        repeat: Number.POSITIVE_INFINITY,
                        ease: "linear",
                     },
                  }}
               >
                  <Icon icon={icon} width={size} height={size} />
               </motion.div>
            );
         })}
      </div>
   );
}
