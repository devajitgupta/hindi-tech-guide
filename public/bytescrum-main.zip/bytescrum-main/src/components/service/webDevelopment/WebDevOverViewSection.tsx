"use client";
import SectionTitle from "@/components/SectionTitle";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
// import data from "../../../common/data/webDevData.json";
import Text from "@/components/Text";
import { StatsCountUp } from "@/components/home";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import OverViewBanner from "@/components/ui/OverViewBanner";

interface IProps {
   className?: string;
}

const WebDevOverViewSection = ({ className }: IProps) => {
   const { screenWidth } = useBreakpoints();

   return (
      <div className={twMerge(clsx("relative h-full  w-full z-20", className))}>
         <div className="grid lg:grid-cols-2 lg:pb-24 ">
            <div className="order-2 lg:order-1 ">
               <div className="space-y-[20px]  pt-[60px]  mt-8 lg:mt-0 ">
                  <SectionTitle className="text-start">title</SectionTitle>
                  <div className="space-y-[10px]">
                     <Text className="text-start  max-w-full md:max-w-[622px] lg:max-w-full ">
                        textOne
                     </Text>
                     <Text className="text-start  max-w-full md:max-w-[622px] lg:max-w-full hidden xl:block">
                        text-two
                     </Text>
                  </div>
               </div>
               {/* <StatsCountUp
                  className="lg:flex justify-between hidden  md:gap-[0px] py-0 lg:pt-[5px] gap-0 lg:max-w-[670px] overflow-hidden "
                  wrapper={clsx(
                     "  px-0 md:px-0 w-fit [&:nth-child(1)]:hidden  [&:nth-child(2)]:hidden [&:nth-child(2)]:border-r [&:nth-child(2)]:border-[#262626] [&:nth-child(2)]:rounded-none w-[300px]"
                  )}
                  countUpClass=" text-start text-[28px] md:text-[45px] px-0 md:px-0 py-0 md:py-0 "
                  symbolClass="text-[20px] md:[42px]"
                  textClass="font-normal text-start text-[14px]  md:text-[20px]"
               /> */}
            </div>

            {/* <div className={`order-1 lg:order-2 -mt-10 lg:mt-0`}>
               <Image
                  src={data.Overview.bannerImg}
                  width={440}
                  height={0}
                  alt={data.Overview.bannerImg}
                  className="ml-auto h-auto hidden lg:block"
               />
               <Image
                  src={data.Overview.bannerImg}
                  width={232}
                  height={0}
                  alt={data.Overview.bannerImg}
                  className="ml-auto h-auto lg:hidden"
               />
               <div className="relative ml-auto">
                  <div className=" absolute rounded-[16px] bg-[#087DD9] px-[15px] py-[20px] lg:py-[85px] lg:px-[27px]  grid place-items-center gap-5 lg:gap-[30px] max-w-[251px]  md:max-w-[339px] lg:max-h-[340px] -bottom-24 -lg:bottom-20 lg:left-36">
                     <div className="space-y-[10px]">
                        <Text
                           className="font-bold text-[20px] poppins"
                           textSize="lg"
                        >
                           Be Part of the Tribe
                        </Text>
                        <Text className="max-w-[305px]">
                           Drop your development requirements and join them as
                           our pride.
                        </Text>
                     </div>

                     <Button
                        as={Link}
                        href="/contact-us"
                        className={twMerge(
                           clsx(
                              "btn !bg-white text-black after:bg-[#087DD9] border !after:border-white m-auto !w-fit after:text-white py-[10px] px-[30px]"
                           )
                        )}
                     >
                        {" "}
                        Contact us now
                     </Button>
                  </div>
               </div>
            </div> */}
            <OverViewBanner className="order-1  lg:order-2" />
         </div>
      </div>
   );
};

export default WebDevOverViewSection;
