"use client";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import Text from "@/components/Text";
import ProgressBar from "@/components/ProgressBar";
import Link from "next/link";
import { Button } from "@nextui-org/react";
import { motion } from "framer-motion";
interface IProps {
   className?: string;
   data?:any;
}

const DevelopmentExpertise = ({ className, data }: IProps) => {
   return (
      <div className={twMerge(clsx(className))}>
         <div className="space-y-[60px] xl:px-[153px]">
            <div className="space-y-[20px] overflow-hidden ">
               <SectionTitle animationVariant="fadeUp">
                  {data.developmentExpertiseSection.titlLineOne} <br />
                  {data.developmentExpertiseSection.titlLineTwo}
               </SectionTitle>
            </div>
            <div className="grid md:grid-cols-2 items-center gap-y-10 gap-x-[30px] lg:gap-x-[60px]">
               <div className="space-y-5 lg:max-w-[554px] ">
                  <SectionSubtitle
                     textSize="lg"
                     className="text-start font-bold poppins max-w-[190px] md:max-w-full "
                  >
                     {data.developmentExpertiseSection.subtitle}
                  </SectionSubtitle>
                  <Text className="text-start">
                     {data.developmentExpertiseSection.textOne}
                  </Text>
                  <Text className="text-start mt-5">
                     {data.developmentExpertiseSection.textTwo}
                  </Text>
                  <Button
                     as={Link}
                     href="/contact-us"
                     className={twMerge(
                        clsx(
                           "btn !bg-[#1463FD] text-white after:bg-[#fff] m-auto !w-fit after:text-white py-[10px] px-[30px] inter font-bold text-[14px] leading-[24px]"
                        )
                     )}
                  >
                     {" "}
                     {data.title}
                  </Button>
               </div>
               <motion.div
                  className="space-y-6"
                  initial={{ opacity: 0, x: 30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8 }}
               >
                  {data.developmentExpertiseSection.expertiseIn.map(
                     (skill:any, index:number) => (
                        <ProgressBar
                           key={index}
                           name={skill.name}
                           level={skill.level}
                        />
                     )
                  )}
               </motion.div>
               {/* <div className="w-full">
                  {data.developmentExpertiseSection.expertiseIn.map(
                     (item, index) => (
                        <ProgressBar
                           key={index}
                           label={item.label}
                           percentage={item.percentage}
                        />
                     )
                  )}
               </div> */}
            </div>
         </div>
      </div>
   );
};

export default DevelopmentExpertise;
