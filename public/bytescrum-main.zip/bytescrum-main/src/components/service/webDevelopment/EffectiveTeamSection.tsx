import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";

interface IProps {
   className?: string;
   data?:any;
}

const EffectiveTeamSection = ({ className, data }: IProps) => {
   return (
      <div className={twMerge(clsx(className))}>
         {" "}
         <div className="space-y-[60px] lg:px-[40px]">
            <div className="space-y-[20px]">
               <SectionTitle>
                  {data.effectiveTeamSection.titlLineOne} <br />
                  {data.effectiveTeamSection.titlLineTwo}
               </SectionTitle>
               <Text
                  className="max-w-[491px] lg:max-w-[491px] m-auto"
                  variant="primary"
               >
                  {data.effectiveTeamSection.subtitle}
               </Text>
            </div>
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5 ">
               {data.effectiveTeamSection.cardData.map((item:any, index:number) => (
                  <div
                     key={index}
                     className="space-y-[5px] bg-[#1a1a1a] px-[48px] py-[42px] rounded-[16px] relative"
                  >
                     <span className="block bg-[#1463FD] w-1 h-[60%] absolute top-1/2 left-[-1.5px] rounded-full transform -translate-y-1/2"></span>
                     <h3 className="poppins text-[20px] text-[#fff] font-bold">
                        {item.cardTitle}
                     </h3>
                     <Text className="text-start" variant="primary">
                        {item.text}
                     </Text>
                  </div>
               ))}
            </div>
         </div>
      </div>
   );
};

export default EffectiveTeamSection;
