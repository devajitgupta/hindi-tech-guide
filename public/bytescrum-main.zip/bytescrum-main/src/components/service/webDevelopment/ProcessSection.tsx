"use client";
import SectionTitle from "@/components/SectionTitle";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import data from "../../../common/data/webDevData.json";
import Text from "@/components/Text";
import Image from "next/image";
import { useState } from "react";
import { Line } from "@/components/Icons";

interface IProps {
   className?: string;
}

const ProcessSection = ({ className }: IProps) => {
   const [isSelected, setIsSelected] = useState<number | null>(0);

   const handleSelect = (index: number) => {
      setIsSelected(index);
   };
   return (
      <div className={twMerge(clsx(className))}>
         {" "}
         <div className="space-y-[60px]">
            <div className="space-y-[20px]">
               {" "}
               <SectionTitle className="text-start">
                  {data.processSection.title}
               </SectionTitle>
               <Text className="max-w-full lg:max-w-[1170px] text-start leading-[28px]">
                  {" "}
                  {data.processSection.text}
               </Text>
            </div>
            <div className="grid  xl:grid-cols-6 gap-5 xl:gap-0">
               <div className="xl:col-span-2  md:grid items-center w-[90dvw] md:w-full overflow-scroll xl:overflow-hidden  ">
                  <ul className="xl:ps-5 xl:space-y-[50px] flex justify-between xl:grid gap-5    ">
                     {data.processSection.tabs.map((item, index) => (
                        <li
                           className={twMerge(
                              clsx(
                                 "list-decimal text-[20px] font-bold cursor-pointer grid xl:grid-cols-3 items-center w-full mb-2 ",
                                 {
                                    "text-[#087DD9] ": isSelected === index,
                                 }
                              )
                           )}
                           onClick={() => handleSelect(index)}
                        >
                           <span className="xl:col-span-2  text-nowrap  ">
                              {item}
                           </span>

                           {isSelected === index && (
                              <span className="hidden xl:block">
                                 <Line trigger={isSelected} />
                              </span>
                           )}
                        </li>
                     ))}
                  </ul>
               </div>
               <div className="xl:col-span-4 grid xl:grid-cols-2 gap-5 ">
                  <div className="border border-[#262626] bg-[#090909] px-[42px] py-[38px] rounded-[16px]">
                     <div className="space-y-[20px] ">
                        <Image
                           src={data.processSection.tab.icon}
                           width={44}
                           height={50}
                           alt="icon"
                        />
                        <SectionTitle className=" list-decimal text-start  text-[#087DD9]  max-w-[200px] md:max-w-full ">
                           {data.processSection.tab.title}
                        </SectionTitle>
                        <Text className="text-start max-w-full xl:max-w-[356px] leading-[28px]">
                           {" "}
                           {data.processSection.tab.text}
                        </Text>
                     </div>
                  </div>
                  <div className="grid grid-cols-2 gap-5 ">
                     <Image
                        src={data.processSection.tab.imgOne}
                        width={440}
                        height={200}
                        alt="img"
                        className="col-span-2 w-full h-full"
                     />
                     <Image
                        src={data.processSection.tab.imgTwo}
                        width={210}
                        height={200}
                        alt="img"
                        className="w-full h-full"
                     />
                     <div className="bg-[#087DD9] rounded-[16px] grid place-items-center">
                        <div className="grid place-items-center">
                           <span className="text-[45px] text-white font-semibold poppins">
                              200+
                           </span>
                           <span>Successful Project</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   );
};

export default ProcessSection;
