import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import Text from "@/components/Text";
import { Button } from "@nextui-org/react";
import Link from "next/link";
import Image from "next/image";
import data from "../../../common/data/webDevData.json";

interface IProps {
   className?: string;
}

const TechShowCase = ({ className }: IProps) => {
   const cardStyle =
      " rounded-[16px] grid place-items-center px-[33px] min-h-[325px]";
   return (
      <div className={twMerge(clsx(className))}>
         <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            <div className="bg-[#1A1A1A]/35 rounded-[16px] sm:col-span-2 sm:row-span-2 grid place-items-center ">
               <div className="m-auto space-y-[50px] py-[60px] lg:py-[170px]">
                  <div className="space-y-5">
                     <SectionTitle>{data.techData.title}</SectionTitle>
                     <Text className="max-w-full md:max-w-[508px] lg:max-w-[508px] px-[30px] lg:px-0">
                        {data.techData.text}
                     </Text>
                  </div>
                  <div className="grid place-items-center ">
                     <Button
                        as={Link}
                        href="/contact-us"
                        className={twMerge(
                           clsx(
                              "btn !bg-[#1463FD] text-white after:bg-[#fff]  !w-fit after:text-white py-[10px] px-[30px] inter font-bold text-[14px] leading-[24px] m-auto"
                           )
                        )}
                     >
                        {data.techData.btnText}
                     </Button>
                  </div>
               </div>
            </div>

            {data.techData.cardsData.map((item, index) => (
               <div className="bg-[#090909] rounded-[16px]">
                  <div
                     key={index}
                     className={twMerge(
                        clsx(" bg-fit  bg-no-repeat bg-opacity-20", cardStyle)
                     )}
                     style={{ backgroundImage: `url(${item.bg})` }}
                  >
                     <div className="space-y-[40px] ">
                        <Image
                           src={item.icon}
                           width={50}
                           height={50}
                           alt={item.icon}
                        />
                        <div className="space-y-[10px] sm:max-w-[260px]">
                           <h3 className="text-[20px] font-bold poppins">
                              {item.title}
                           </h3>
                           <p className="inter leading-[28px] ">{item.text}</p>
                        </div>
                     </div>
                  </div>
               </div>
            ))}
         </div>
      </div>
   );
};

export default TechShowCase;
