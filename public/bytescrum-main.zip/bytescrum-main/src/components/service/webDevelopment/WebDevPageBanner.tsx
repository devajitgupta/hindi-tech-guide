"use client";
import PageBanner from "@/components/PageBanner";
import clsx from "clsx";
import { usePathname } from "next/navigation";
import WebDevBanner from "./WebDevBanner";
import { twMerge } from "tailwind-merge";
type Props = {
   data?: any;
};
const WebDevPageBanner = ({data}:Props) => {
   const pathName = usePathname();
   return (
      <div
         className={twMerge(
            clsx(
               "relative overflow-hidden px-[22px]  md:px-[54px]  items-center justify-normal  "
            )
         )}
      >
         <WebDevBanner />
         <div className="grid place-items-center py-10 md:py-16 md:gap-[10px]">
            <h1
               className="text-[35px]  md:text-[70px] md:leading-[80px] font-bold  poppins text-center"
               data-aos="zoom-in"
               data-aos-easing="ease-out-cubic"
               data-aos-anchor-placement="top-bottom"
            >
               {data.webDevelopment.pageTitle}
            </h1>
            <p
               className="poppins text-[#b7b7b7] text-[14px] md:text-[18px]"
               data-aos="zoom-in"
               data-aos-easing="ease-out-cubic"
               data-aos-delay={500}
               data-aos-anchor-placement="top-bottom"
            >
               {data.webDevelopment.links.map((link:any, index:number) => (
                  <span
                     className={clsx(
                        " text-white first:border-r first:px-3 px-2",
                        {
                           "first:text-[#b7b7b7]": pathName !== `/${pathName}`,
                        }
                     )}
                     key={index}
                  >
                     {link}
                  </span>
               ))}
            </p>
         </div>
      </div>
   );
};

export default WebDevPageBanner;
