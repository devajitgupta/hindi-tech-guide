"use client";

import PageBanner from "@/components/PageBanner";
import ChampionCards from "@/components/home/championSection/ChampionCards";
import React from "react";

import homeData from "../../common/data/homeData.json";
import { StatsCountUp } from "@/components/home";
import clsx from "clsx";
import { usePathname } from "next/navigation";
import SectionTitle from "../SectionTitle";
import SectionSubtitle from "../SectionSubtitle";
import SkillCards from "../home/skillSection/SkillCards";
import dynamic from "next/dynamic";

const ProcessSectionSrevice = dynamic(() => import("./ProcessSectionSrevice"), {
   ssr: false,
});
const TestimonialCard = dynamic(
   () => import("../home/testimonial/TestimonialCard"),
   {
      ssr: false,
   }
);

type Props = {
   langText: any;
   langTextShared: any;
};

const Service = ({ langText, langTextShared }: Props) => {
   const pathName = usePathname();

   return (
      <div>
         <PageBanner bgPath="/service/serviceBg.png">
            <div className="grid place-items-center md:gap-[10px]">
               <h1
                  className="text-[35px] md:text-[70px] md:leading-[80px] font-bold poppins"
                  data-aos="zoom-in"
                  data-aos-easing="ease-out-cubic"
                  data-aos-anchor-placement="top-bottom"
               >
                  {langText.pageTitle}
               </h1>
               <p
                  className="poppins text-[#b7b7b7] text-[14px] md:text-[18px]"
                  data-aos="zoom-in"
                  data-aos-easing="ease-out-cubic"
                  data-aos-delay={500}
                  data-aos-anchor-placement="top-bottom"
               >
                  {langText.links.map((link: any, index: any) => (
                     <span
                        className={clsx(
                           " text-white first:border-r first:px-3 px-2",
                           {
                              "first:text-[#b7b7b7]":
                                 pathName !== `/${pathName}`,
                           }
                        )}
                        key={index}
                     >
                        {link}
                     </span>
                  ))}
               </p>
            </div>
         </PageBanner>

         <div className="grid place-items-center px-4 py-[40px] md:py-[80px] gap-[40px] md:gap-[100px]">
            <div className="grid place-items-center gap-[10px]">
               <SectionTitle> {langText.title}</SectionTitle>
               <SectionSubtitle> {langText.text}</SectionSubtitle>
            </div>
            <div className="grid items-center justify-center">
               <ChampionCards data={langText} />
            </div>
         </div>

         <ProcessSectionSrevice
            header={langText.processSectionHeader}
            steps={langText.steps}
            processMarker={langText.processMarker}
         />
         <div
            id="realValue"
            className="md:px-16 xl:px-32 pt-[60px] pb-[15px] md:pb-[30px] md:pt-[60px] px-4 "
         >
            <SectionTitle>
               {" "}
               <span className="text-[#565656]">
                  {langTextShared.realvalueSection.title.textOne}{" "}
               </span>
               {langTextShared.realvalueSection.title.textTwo}
            </SectionTitle>
            <StatsCountUp langText={langTextShared} />
         </div>

         <div className="md:px-[20px]  xl:px-24 py-[60px] md:py-[60px] px-4 grid  items-center gap-[40px]  bg-gradient-to-b lg:bg-gradient-to-r from-[#0D0D0D] to-[#2A2A2A]">
            <div className="grid lg:grid-cols-2 items-center gap-[60px] md:gap-[60px]">
               <div
                  className="grid gap-[20px]"
                  data-aos={"fade-right"}
                  data-aos-duration="500"
                  data-aos-delay="150"
               >
                  <SectionTitle className="text-center lg:text-start">
                     {" "}
                     {langTextShared.skillSection.title}
                  </SectionTitle>
                  <SectionSubtitle className="text-center lg:text-start max-w-full">
                     {" "}
                     {langTextShared.skillSection.text}
                  </SectionSubtitle>
               </div>

               <div className="grid justify-center  lg:justify-end">
                  <SkillCards />
               </div>
            </div>
         </div>

         <div className="mt-20">
            <SectionTitle>
               {langTextShared.clientSection.titleOne.textOne}{" "}
               <span className="text-[#a4a4a4]">
                  {langTextShared.clientSection.titleOne.textTwo}
               </span>{" "}
               <br /> {langTextShared.clientSection.titleTwo.textOne}
               <span className="text-[#a4a4a4]">
                  {langTextShared.clientSection.titleTwo.textTwo}
               </span>
            </SectionTitle>
         </div>

         <TestimonialCard langText={langTextShared.clientSection.clientData} />
      </div>
   );
};

export default Service;
