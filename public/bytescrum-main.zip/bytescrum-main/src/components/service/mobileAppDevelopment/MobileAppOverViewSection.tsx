import { StatsCountUp } from "@/components/home";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import OverViewBanner from "@/components/ui/OverViewBanner";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";

interface IProps {
   className?: string;
}

const MobileAppOverViewSection = ({ className }: IProps) => {
   return (
      <div className={twMerge(clsx("relative h-full  w-full z-20", className))}>
         <div className="grid lg:grid-cols-2 lg:pb-24 ">
            <div className="order-2 lg:order-1 ">
               <div className="space-y-[20px]  pt-[60px]  mt-8 lg:mt-0 ">
                  <SectionTitle className="text-start">Overview</SectionTitle>
                  <div className="space-y-[10px]">
                     <Text className="text-start  max-w-full md:max-w-[622px] lg:max-w-full">
                        Mobile app development focuses on creating
                        user-friendly, secure, and scalable applications for
                        both iOS and Android platforms. Our approach emphasizes
                        innovative design, seamless functionality, and
                        exceptional user experiences, ensuring that each app
                        meets the specific needs of its users while leveraging
                        the latest technologies.
                     </Text>
                     <Text className="text-start  max-w-full md:max-w-[622px] lg:max-w-full">
                        We prioritize agile development methodologies, allowing
                        for flexibility and rapid iteration. Our team is
                        dedicated to integrating advanced features such as
                        real-time data processing, cloud integration, and robust
                        security measures, empowering businesses to thrive in a
                        competitive digital landscape.
                     </Text>
                  </div>
               </div>
               {/* <StatsCountUp
                  className="lg:flex justify-between hidden  md:gap-[0px] py-0 lg:pt-[5px] gap-0 lg:max-w-[670px] overflow-hidden "
                  wrapper={clsx(
                     "  px-0 md:px-0 w-fit [&:nth-child(1)]:hidden  [&:nth-child(2)]:hidden [&:nth-child(2)]:border-r [&:nth-child(2)]:border-[#262626] [&:nth-child(2)]:rounded-none w-[300px]"
                  )}
                  countUpClass=" text-start text-[28px] md:text-[45px] px-0 md:px-0 py-0 md:py-0 "
                  symbolClass="text-[20px] md:[42px]"
                  textClass="font-normal text-start text-[14px]  md:text-[20px]"
               /> */}
            </div>
            <OverViewBanner className="order-1  lg:order-2" />
         </div>
      </div>
   );
};

export default MobileAppOverViewSection;
