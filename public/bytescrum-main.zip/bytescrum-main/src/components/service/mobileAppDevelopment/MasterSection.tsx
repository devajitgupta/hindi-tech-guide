"use client";
import React, { useRef } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "./mobileDev.css";
import { EffectCreative, Autoplay } from "swiper/modules";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import { motion, useScroll, useTransform, useSpring } from "framer-motion";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import Text from "@/components/Text";
import { Icon } from "@iconify/react/dist/iconify.js";

interface IProps {
   className?: string;
   data?: any;
}

const MasterSection = ({ className, data }: IProps) => {
   const ref = useRef(null);
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth <= 430;

   const { scrollYProgress } = useScroll({
      target: ref,
      offset: ["center end", "end start"],
   });

   const smoothScrollYProgress = useSpring(scrollYProgress, {
      damping: 20,
      stiffness: 100,
   });

   const imgY = useTransform(scrollYProgress, [0, 1], ["0%", "20%"]);
   const colY = useTransform(smoothScrollYProgress, [0, 1], ["15%", "0%"]);

   return (
      <div className={twMerge(clsx(className))}>
         <div
            className="grid lg:grid-cols-11  px-6 md:gap-24 xl:gap-10 items-center justify-center  overflow-hidden pb-20 "
            ref={ref}
         >
            <motion.div
               className="m-auto  md:pe-1 lg:col-span-5"
               style={{ y: imgY }}
            >
               <div className="relative transition-all duration-[50s] hidden lg:block">
                  <Swiper
                     grabCursor={true}
                     effect={"creative"}
                     creativeEffect={{
                        prev: {
                           shadow: true,
                           origin: "left center",
                           translate: ["-5%", 0, -200],
                           rotate: [0, 100, 0],
                        },
                        next: {
                           origin: "right center",
                           translate: ["5%", 0, -200],
                           rotate: [0, -100, 0],
                        },
                     }}
                     modules={[EffectCreative, Autoplay]}
                     autoplay={{
                        delay: 1000,
                        disableOnInteraction: true,
                     }}
                     speed={1700}
                     loop={true}
                     pagination={true}
                     className="mySwiper6 "
                  >
                     {swipperCardData.map((item) => (
                        <SwiperSlide key={item.icon}>
                           <div className="p-8 border border-[#262626] bg-[#0f0f0f] space-y-3">
                              <Icon
                                 icon={item.icon}
                                 className="m-auto text-9xl"
                              />
                              <div className="space-y-2 ">
                                 <SectionSubtitle
                                    textSize="xl"
                                    className="text-start "
                                 >
                                    {item.title}
                                 </SectionSubtitle>
                                 <Text className="text-start">
                                    {item.text}.
                                 </Text>
                              </div>
                           </div>
                        </SwiperSlide>
                     ))}
                  </Swiper>
               </div>
            </motion.div>
            <div className="  lg:col-span-6 max-w-[650px] ">
               <motion.div
                  className=" space-y-5  "
                  style={!matches ? { y: colY } : {}}
               >
                  <SectionSubtitle
                     textSize="sm"
                     className=" tracking-widest  border border-[#262626] w-fit m-auto lg:m-0 px-5 py-1 rounded-full bg-[#1a1a1a]/65  "
                  >
{data.title}                  </SectionSubtitle>
                  <SectionTitle className="group lg:text-start flex lg:justify-start items-center max-w-[346px] md:max-w-[712px]  m-auto lg:m-none ">
                     {" "}
{data.titleOne}                  </SectionTitle>
                  <div className="lg:hidden px-4">
                     <Swiper
                        grabCursor={true}
                        effect={"creative"}
                        creativeEffect={{
                           prev: {
                              shadow: true,
                              origin: "left center",
                              translate: ["-5%", 0, -200],
                              rotate: [0, 100, 0],
                           },
                           next: {
                              origin: "right center",
                              translate: ["5%", 0, -200],
                              rotate: [0, -100, 0],
                           },
                        }}
                        modules={[EffectCreative, Autoplay]}
                        autoplay={{
                           delay: 1000,
                           disableOnInteraction: true,
                        }}
                        speed={1700}
                        loop={true}
                        pagination={true}
                     >
                        {swipperCardData.map((item) => (
                           <SwiperSlide key={item.icon}>
                              <div className="p-5 md:p-8 border border-[#262626] bg-[#0f0f0f] space-y-3 min-h-[400px]">
                                 <Icon
                                    icon={item.icon}
                                    className="m-auto text-9xl"
                                 />
                                 <div className="space-y-2 ">
                                    <SectionSubtitle
                                       textSize="xl"
                                       className="text-start "
                                    >
                                       {item.title}
                                    </SectionSubtitle>
                                    <Text className="text-start">
                                       {item.text}.
                                    </Text>
                                 </div>
                              </div>
                           </SwiperSlide>
                        ))}
                     </Swiper>
                  </div>
                  <Text className="text-start">
                  {data.description}
                  </Text>
               </motion.div>
            </div>
         </div>
      </div>
   );
};

export default MasterSection;

const swipperCardData = [
   {
      icon: "fa6-brands:app-store-ios",
      title: "iOS Development",
      text: "iOS development creates native applications for Apple devices using Swift or Objective-C, delivering exceptional user experiences on iPhones and iPads.",
   },
   {
      icon: "fa6-brands:android",
      title: "Android Development",
      text: "Android development creating apps for Android devices using Java or Kotlin with Android Studio, targeting diverse users on the popular platform.",
   },
   {
      icon: "fa6-brands:windows",
      title: "Windows App Development",
      text: "Windows app development creating native applications using C# or C++, targeting diverse Windows devices with user-friendly experiences.",
   },
   {
      icon: "fa-solid:mobile-alt",
      title: "Hybrid App Development",
      text: "creating cross-platform apps using web technologies for efficient and versatile development. These apps combine the benefits of web and native apps.",
   },
];
