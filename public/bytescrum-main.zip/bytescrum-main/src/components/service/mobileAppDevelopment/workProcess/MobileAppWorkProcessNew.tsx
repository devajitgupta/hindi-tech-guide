"use client";
import { motion } from "framer-motion";
import MobileAppProcessTimeline from "./MobileAppProcessTimeline";

const MobileAppWorkProcessNew = () => {
   return (
      <section className="py-20 bg-black">
         <div className="container mx-auto px-4">
            <motion.div
               className="text-center max-w-3xl mx-auto mb-16"
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               transition={{ duration: 0.5 }}
            >
               <h2 className="text-4xl font-bold mb-6">Our Work Process</h2>
               <p className="text-gray-300">
                  ByteScrum delivers innovative apps with confidence, exceeding
                  expectations and helping clients achieve their goals.
               </p>
            </motion.div>

            <MobileAppProcessTimeline />
         </div>
      </section>
   );
};

export default MobileAppWorkProcessNew;
