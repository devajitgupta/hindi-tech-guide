"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";

export default function MobileAppBackgroundAnimation() {
   const containerRef = useRef<HTMLDivElement>(null);
   const [windowSize, setWindowSize] = useState({ width: 0, height: 0 });
   // const [windowHeight, setWindHeight] = useState<number>(720);
   // const [windowWidth, setWindWidth] = useState<number>(1080);
   const [iconPositions, setIconPositions] = useState<
      { id: number; x: number; y: number }[]
   >([]);

   // useEffect(() => {
   //    if (typeof window !== "undefined") {
   //       const width = window.innerWidth;
   //       const height = window.innerHeight;
   //       setWindWidth(width);
   //       setWindHeight(height);
   //    }
   // }, []);

   useEffect(() => {
      if (typeof window !== "undefined") {
         setWindowSize({
            width: window.innerWidth,
            height: window.innerHeight,
         });

         const handleResize = () => {
            setWindowSize({
               width: window.innerWidth,
               height: window.innerHeight,
            });
         };

         window.addEventListener("resize", handleResize);
         return () => window.removeEventListener("resize", handleResize);
      }
   }, []);

   useEffect(() => {
      const handleResize = () => {
         setWindowSize({
            width: window.innerWidth,
            height: window.innerHeight,
         });
      };

      // Set initial window size
      handleResize();

      window.addEventListener("resize", handleResize);

      // Cleanup function to remove event listener on unmount
      return () => {
         window.removeEventListener("resize", handleResize);
      };
   }, []); // Empty dependency array ensures it runs only once on mount

   // Mobile app development icons and elements
   const devElements = [
      { icon: "📱", name: "Mobile UI", desc: "User-friendly interface" },
      { icon: "🖥️", name: "Backend", desc: "API & database integration" },
      { icon: "⚙️", name: "App Logic", desc: "Seamless performance" },
      { icon: "☁️", name: "Cloud Sync", desc: "Real-time data storage" },
      { icon: "📲", name: "Push Notifications", desc: "User engagement" },
      { icon: "💡", name: "App Design", desc: "Creative UI/UX" },
      { icon: "🚀", name: "Performance", desc: "Optimized speed" },
      { icon: "🔒", name: "Security", desc: "Data protection" },
   ];

   const mobileAppDevelopmentSnippets = [
      `import React from 'react';\n\nconst App = () => {\n   return <h1>Hello, Mobile App Development!</h1>;\n};\n\nexport default App;`,
      `import { useState } from 'react';\n\nconst Counter = () => {\n   const [count, setCount] = useState(0);\n   return <button onClick={() => setCount(count + 1)}>Count: {count}</button>;\n};`,
      `const fetchData = async () => {\n   const response = await fetch('https://api.example.com/data');\n   const data = await response.json();\n   console.log(data);\n};`,
      `import { StyleSheet, Text, View } from 'react-native';\n\nconst styles = StyleSheet.create({\n   container: {\n      flex: 1,\n      justifyContent: 'center',\n      alignItems: 'center',\n   },\n});`,
      `const App = () => {\n   return (\n      <View style={styles.container}>\n         <Text>Welcome to Mobile App Development!</Text>\n      </View>\n   );\n};`,
   ];

   return (
      <div className="absolute inset-0 z-0 overflow-hidden bg-black">
         <div className="absolute inset-0 perspective-1000">
            {/* Floating Development Cards */}
            {/* {Array.from({ length: 8 }).map((_, index) => {
               const size = Math.random() * 150 + 100;
               const element =
                  devElements[Math.floor(Math.random() * devElements.length)];
               const depth = Math.random() * 500 - 250;

               return (
                  <motion.div
                     key={`dev-card-${index}`}
                     className="absolute flex flex-col items-center justify-center bg-black/80 backdrop-blur-sm rounded-lg border border-blue-500/30 p-3"
                     style={{
                        width: size,
                        height: size * 1.2,
                        transformStyle: "preserve-3d",
                        transform: `translateZ(${depth}px)`,
                     }}
                     initial={{
                        x: Math.random() * windowWidth,
                        y: Math.random() * windowHeight,
                        opacity: 0,
                     }}
                     animate={{
                        x: [
                           Math.random() * windowWidth,
                           Math.random() * windowWidth,
                        ],
                        y: [
                           Math.random() * windowHeight,
                           Math.random() * windowHeight,
                        ],
                        opacity: [0, 0.9, 0],
                     }}
                     transition={{
                        duration: Math.random() * 30 + 20,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "loop",
                     }}
                  >
                     <span className="text-4xl mb-2">{element.icon}</span>
                     <div className="text-white font-semibold">
                        {element.name}
                     </div>
                     <div className="text-blue-400 text-xs">{element.desc}</div>
                  </motion.div>
               );
            })} */}

            {/* Floating Mobile Development Icons */}
            {Array.from({ length: 25 }).map((_, index) => {
               const size = Math.random() * 40 + 30;
               const devElement =
                  devElements[Math.floor(Math.random() * devElements.length)];
               const depth = Math.random() * 300 - 150;

               return (
                  <motion.div
                     key={`icon-${index}`}
                     className="absolute flex items-center justify-center"
                     style={{
                        width: size,
                        height: size,
                        fontSize: size * 0.6,
                        transformStyle: "preserve-3d",
                        transform: `translateZ(${depth}px)`,
                     }}
                     initial={{
                        x: Math.random() * windowSize.width,
                        y: Math.random() * windowSize.height,
                        opacity: 0,
                     }}
                     animate={{
                        x: [
                           Math.random() * windowSize.width,
                           Math.random() * windowSize.width,
                        ],
                        y: [
                           Math.random() * windowSize.height,
                           Math.random() * windowSize.height,
                        ],
                        opacity: [0, 0.5, 0],
                     }}
                     transition={{
                        duration: Math.random() * 20 + 15,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "loop",
                     }}
                  >
                     {devElement.icon}
                  </motion.div>
               );
            })}
            {/* Code Blocks */}
            {Array.from({ length: 4 }).map((_, index) => {
               const size = Math.random() * 200 + 200;
               const snippet =
                  mobileAppDevelopmentSnippets[
                     Math.floor(
                        Math.random() * mobileAppDevelopmentSnippets.length
                     )
                  ];

               return (
                  <motion.div
                     key={`code-${index}`}
                     className="absolute rounded-lg   bg-black/80 backdrop-blur-sm p-4 text-sm opacity-50 text-green-300/20 font-mono overflow-hidden"
                     style={{
                        width: size,
                        height: size * 0.8,
                     }}
                     initial={{
                        x: Math.random() * windowSize.width,
                        y: Math.random() * windowSize.height,
                        opacity: 0,
                        rotateX: Math.random() * 20 - 10,
                        rotateY: Math.random() * 20 - 10,
                        rotateZ: Math.random() * 10 - 5,
                     }}
                     animate={{
                        x: [
                           Math.random() * windowSize.width,
                           Math.random() * windowSize.width,
                        ],
                        y: [
                           Math.random() * windowSize.height,
                           Math.random() * windowSize.height,
                        ],
                        opacity: [0, 0.8, 0],
                        rotateX: [
                           Math.random() * 20 - 10,
                           Math.random() * 20 - 10,
                        ],
                        rotateY: [
                           Math.random() * 20 - 10,
                           Math.random() * 20 - 10,
                        ],
                        rotateZ: [
                           Math.random() * 10 - 5,
                           Math.random() * 10 - 5,
                        ],
                     }}
                     transition={{
                        duration: Math.random() * 30 + 20,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "loop",
                     }}
                  >
                     <pre>{snippet}</pre>
                  </motion.div>
               );
            })}
            {Array.from({ length: 25 }).map((_, index) => {
               const symbols = [
                  "create",
                  "update",
                  "delete",
                  "fetch",
                  "navigate",
                  "render",
                  "component",
                  "state",
                  "props",
                  "useEffect",
                  "useState",
                  "context",
                  "provider",
                  "hook",
                  "event",
                  "listener",
                  "route",
                  "screenshot",
                  "animation",
                  "transition",
                  "API",
                  "response",
                  "promise",
                  "async",
                  "await",
               ];
               const symbol =
                  symbols[Math.floor(Math.random() * symbols.length)];
               const size = Math.random() * 20 + 14;

               return (
                  <motion.div
                     key={`symbol-${index}`}
                     className="absolute font-mono text-red-400/60"
                     style={{
                        fontSize: size,
                     }}
                     initial={{
                        x: Math.random() * windowSize.width,
                        y: Math.random() * windowSize.height,
                        opacity: 0,
                        rotate: Math.random() * 20 - 10,
                     }}
                     animate={{
                        opacity: [0, 0.7, 0],
                        rotate: [
                           Math.random() * 20 - 10,
                           Math.random() * 20 - 10,
                        ],
                        x: [
                           Math.random() * windowSize.width * 0.8,
                           Math.random() * windowSize.width * 0.8,
                           Math.random() * windowSize.width * 0.8,
                           Math.random() * windowSize.width * 0.8,
                           Math.random() * windowSize.width * 0.8,
                        ],
                        y: [
                           Math.random() * windowSize.height * 0.8,
                           Math.random() * windowSize.height * 0.8,
                           Math.random() * windowSize.height * 0.8,
                           Math.random() * windowSize.height * 0.8,
                           Math.random() * windowSize.height * 0.8,
                        ],
                        scale: [0.5, 0.9, 0.7],
                     }}
                     transition={{
                        duration: Math.random() * 15 + 10,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "loop",
                        repeatDelay: Math.random() * 5,
                     }}
                  >
                     {symbol}
                  </motion.div>
               );
            })}
            <AnimatedLines
               count={15}
               windowSize={windowSize}
               iconPositions={iconPositions}
            />
            {Array.from({ length: 5 }).map((_, index) => {
               const startX = Math.random() * windowSize.width;
               const startY = Math.random() * windowSize.height;
               const endX = Math.random() * windowSize.width;
               const endY = Math.random() * windowSize.height;

               return (
                  <motion.line
                     key={`line-${index}`}
                     x1={startX}
                     y1={startY}
                     x2={endX}
                     y2={endY}
                     stroke="#8B5CF6"
                     strokeWidth="4"
                     initial={{ opacity: 0 }}
                     animate={{
                        opacity: [0, 1, 0],
                        x1: [startX, endX],
                        y1: [startY, endY],
                        x2: [endX, startX],
                        y2: [endY, startY],
                     }}
                     transition={{
                        duration: Math.random() * 10 + 5,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "loop",
                     }}
                  />
               );
            })}

            {/* Animated code snippets */}
            <AnimatePresence>
               {mobileAppDevelopmentSnippets.map((snippet, index) => {
                  return (
                     <motion.div
                        key={`snippet-${index}`}
                        className="absolute max-w-xs md:max-w-sm bg-black-500/10 backdrop-blur-xs rounded-lg p-3 text-xs md:text-sm font-mono text-green-500/50 opacity-20 shadow-lg"
                        initial={{ opacity: 0 }}
                        animate={{
                           opacity: [0, 0.9, 0.7, 0.9, 0],
                           x: [
                              Math.random() * windowSize.width * 0.7,
                              Math.random() * windowSize.width * 0.7,
                              Math.random() * windowSize.width * 0.7,
                           ],
                           y: [
                              Math.random() * windowSize.height * 0.7,
                              Math.random() * windowSize.height * 0.7,
                              Math.random() * windowSize.height * 0.7,
                           ],
                        }}
                        exit={{ opacity: 0 }}
                        transition={{
                           duration: 20,
                           repeat: Number.POSITIVE_INFINITY,
                           delay: index * 3,
                           repeatType: "loop",
                           times: [0, 0.4, 0.8, 0.9, 1],
                        }}
                     >
                        <TypewriterText text={snippet} />
                     </motion.div>
                  );
               })}
            </AnimatePresence>

            {/* Animated particles */}
            <div className="absolute w-full h-full inset-0">
               {[...Array(150)].map((_, index) => (
                  <motion.div
                     key={`particle-${index}`}
                     className={twMerge(
                        clsx(
                           "absolute rounded-full ",
                           index % 2 === 1
                              ? "w-2 h-2 bg-[#1463fd] shadow-[0_0_8px_#1463fd] "
                              : index % 3 !== 0
                              ? "w-1 h-1 bg-green-500 shadow-[0_0_8px_#ff0000]"
                              : "w-3 h-3 bg-purple-700  shadow-[0_0_80px_#8000ff]"
                        )
                     )}
                     initial={{
                        x: Math.random() * windowSize.width,
                        y: Math.random() * windowSize.height,
                        opacity: 0,
                        scale: 0,
                     }}
                     animate={{
                        x: [
                           Math.random() * windowSize.width,
                           Math.random() * windowSize.width,
                           Math.random() * windowSize.width,
                        ],
                        y: [
                           Math.random() * windowSize.height,
                           Math.random() * windowSize.height,
                           Math.random() * windowSize.height,
                        ],
                        opacity: [0, 0.8, 0],
                        scale: [0, 1, 0],
                     }}
                     transition={{
                        duration: Math.random() * 10 + 10,
                        delay: Math.random() * 5,
                        repeat: Number.POSITIVE_INFINITY,
                        ease: "easeInOut",
                     }}
                  />
               ))}
            </div>

            {/* Data Visualization Elements */}
            <svg className="absolute inset-0 w-full h-full opacity-20">
               {/* App Usage Statistics */}
               <motion.g
                  transform={`translate(${windowSize.width * 0.2}, ${
                     windowSize.height * 0.97
                  })`}
               >
                  {Array.from({ length: 5 }).map((_, i) => {
                     const height = Math.random() * 100 + 50;

                     return (
                        <motion.rect
                           key={`usage-bar-${i}`}
                           x={i * 30}
                           y={-height}
                           width="20"
                           height={height}
                           fill="#3B82F6"
                           initial={{ opacity: 0, scaleY: 0 }}
                           animate={{
                              opacity: [0, 0.7, 0],
                              scaleY: [0, 1, 0],
                           }}
                           transition={{
                              duration: 10,
                              delay: i * 0.5,
                              repeat: Number.POSITIVE_INFINITY,
                              repeatType: "loop",
                           }}
                        />
                     );
                  })}
               </motion.g>

               {/* User Growth Line Chart */}
               <motion.g
                  transform={`translate(${windowSize.width * 0.6}, ${
                     windowSize.height * 0.3
                  })`}
               >
                  {(() => {
                     const points = Array.from({ length: 10 }).map((_, i) => ({
                        x: i * 30,
                        y: Math.random() * 100,
                     }));

                     const pathData =
                        `M ${points[0].x} ${points[0].y} ` +
                        points
                           .slice(1)
                           .map((p) => `L ${p.x} ${p.y}`)
                           .join(" ");

                     return (
                        <motion.path
                           d={pathData}
                           fill="none"
                           stroke="#8B5CF6"
                           strokeWidth="3"
                           initial={{ pathLength: 0, opacity: 0 }}
                           animate={{
                              pathLength: [0, 10],
                              opacity: [0, 1, 0],
                           }}
                           transition={{
                              duration: 15,
                              repeat: Number.POSITIVE_INFINITY,
                              repeatType: "loop",
                           }}
                        />
                     );
                  })()}
               </motion.g>
            </svg>
         </div>
      </div>
   );
}

// Typewriter effect component
function TypewriterText({ text }: { text: string }) {
   const [displayedText, setDisplayedText] = useState("");

   useEffect(() => {
      let currentIndex = 0;
      const interval = setInterval(() => {
         if (currentIndex <= text.length) {
            setDisplayedText(text.substring(0, currentIndex));
            currentIndex++;
         } else {
            clearInterval(interval);
         }
      }, 50);

      return () => clearInterval(interval);
   }, [text]);

   return (
      <div>
         {displayedText}
         <span className="animate-pulse opacity-35 ">|</span>
      </div>
   );
}

// Animated lines component
function AnimatedLines({
   count,
   windowSize,
   iconPositions,
}: {
   count: number;
   windowSize: { width: number; height: number };
   iconPositions: { id: number; x: number; y: number }[];
}) {
   return (
      <>
         {Array.from({ length: count }).map((_, index) => {
            const startX = Math.random() * windowSize.width;
            const startY = Math.random() * windowSize.height;
            const endX = Math.random() * windowSize.width;
            const endY = Math.random() * windowSize.height;

            return (
               <motion.div
                  key={`line-${index}`}
                  className="absolute top-0 left-0 w-full h-full pointer-events-none"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0, 0.2, 0.1, 0.3, 0] }}
                  transition={{
                     duration: 10 + Math.random() * 10,
                     repeat: Number.POSITIVE_INFINITY,
                     delay: index * 0.1,
                     repeatType: "loop",
                  }}
               >
                  <svg className="absolute top-0 left-0 w-full h-full">
                     <motion.path
                        d={`M ${startX} ${startY} Q ${
                           (startX + endX) / 2 + Math.random() * 100 - 50
                        } ${
                           (startY + endY) / 2 + Math.random() * 100 - 50
                        } ${endX} ${endY}`}
                        stroke={`hsl(${Math.random() * 360}, 70%, 70%)`}
                        strokeWidth="1"
                        fill="none"
                        initial={{ pathLength: 0 }}
                        animate={{ pathLength: [0, 1, 0] }}
                        transition={{
                           duration: 15 + Math.random() * 10,
                           repeat: Number.POSITIVE_INFINITY,
                           ease: "easeInOut",
                        }}
                     />
                  </svg>
               </motion.div>
            );
         })}

         {/* Connect nearby icons with lines */}
         {iconPositions.length > 0 &&
            iconPositions.map((pos1, i) =>
               iconPositions.slice(i + 1).map((pos2, j) => {
                  // Only connect if they're within a reasonable distance
                  const distance = Math.sqrt(
                     Math.pow(pos1.x - pos2.x, 2) + Math.pow(pos1.y - pos2.y, 2)
                  );
                  if (distance < 200) {
                     return (
                        <motion.div
                           key={`connection-${i}-${j}`}
                           className="absolute top-0 left-0 w-full h-full pointer-events-none"
                        >
                           <svg className="absolute top-0 left-0 w-full h-full">
                              <motion.line
                                 x1={pos1.x}
                                 y1={pos1.y}
                                 x2={pos2.x}
                                 y2={pos2.y}
                                 stroke="rgba(255, 255, 255, 0.1)"
                                 strokeWidth="1"
                                 initial={{ opacity: 0 }}
                                 animate={{
                                    opacity: distance < 100 ? 0.3 : 0.1,
                                 }}
                                 transition={{ duration: 0.5 }}
                              />
                           </svg>
                        </motion.div>
                     );
                  }
                  return null;
               })
            )}
      </>
   );
}
