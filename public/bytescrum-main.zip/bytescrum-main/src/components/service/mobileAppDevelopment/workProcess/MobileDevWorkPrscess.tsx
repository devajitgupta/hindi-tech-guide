import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import clsx from "clsx";
import React from "react";
import { twMerge } from "tailwind-merge";
import MobileDevWorkProcessAnimation from "./MobileDevWorkProcessAnimation";
interface IProps {
   className?: string;
   data?: any;
}

export const MobileDevWorkProcess = ({ className, data }: IProps) => {
   return (
      <div className={twMerge(clsx("space-y-16", className))}>
         <div>
            <SectionTitle>Our Work Process</SectionTitle>
            <SectionSubtitle className="text-center m-auto">
               ByteScrum delivers innovative apps with confidence, exceeding
               expectations and helping clients achieve their goals.
            </SectionSubtitle>
         </div>

         <MobileDevWorkProcessAnimation />
      </div>
   );
};
