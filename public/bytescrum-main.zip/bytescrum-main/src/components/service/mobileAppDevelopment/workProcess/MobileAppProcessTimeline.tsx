"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useAnimation, useInView } from "framer-motion";

const processSteps = [
   {
      id: "strategy",
      title: "STRATEGY",
      description:
         "Define objectives, target audience, and competitive analysis",
      icon: "carbon:idea",
      color: "#3B82F6", // blue
   },
   {
      id: "analysis",
      title: "ANALYSIS AND PLANNING",
      description:
         "Detailed roadmap, feature prioritization, and technical specifications",
      icon: "carbon:roadmap",
      color: "#8B5CF6", // purple
   },
   {
      id: "design",
      title: "UI/UX DESIGN",
      description:
         "Wireframes, prototypes, and intuitive user experience design",
      icon: "carbon:pen-fountain",
      color: "#EC4899", // pink
   },
   {
      id: "development",
      title: "APP DEVELOPMENT",
      description:
         "Frontend and backend development with clean, efficient code",
      icon: "carbon:code",
      color: "#10B981", // green
   },
   {
      id: "testing",
      title: "APP TESTING",
      description: "Performance testing, bug fixing, and quality assurance",
      icon: "carbon:debug",
      color: "#F59E0B", // amber
   },
   {
      id: "deployment",
      title: "DEPLOYMENT",
      description: "App store submission, launch, and post-launch support",
      icon: "carbon:rocket",
      color: "#6366F1", // indigo
   },
];

export default function MobileAppProcessTimeline() {
   const [activeStep, setActiveStep] = useState(0);
   const [hoveredStep, setHoveredStep] = useState<number | null>(null);
   const containerRef = useRef<HTMLDivElement>(null);
   const isInView = useInView(containerRef, { once: false, amount: 0.2 });
   const controls = useAnimation();

   // Refs for each step
   const stepRefs = useRef<(HTMLDivElement | null)[]>([]);

   // Set up intersection observers for each step
   useEffect(() => {
      const observers: IntersectionObserver[] = [];

      stepRefs.current.forEach((ref, index) => {
         if (ref) {
            const observer = new IntersectionObserver(
               (entries) => {
                  if (entries[0].isIntersecting) {
                     setActiveStep(index);
                  }
               },
               { threshold: 0.7 }
            );

            observer.observe(ref);
            observers.push(observer);
         }
      });

      return () => {
         observers.forEach((observer) => observer.disconnect());
      };
   }, []);

   // Start animation when in view
   useEffect(() => {
      if (isInView) {
         controls.start("visible");
      }
   }, [isInView, controls]);

   return (
      <div ref={containerRef} className="relative max-w-6xl mx-auto">
         {/* Mobile view (vertical timeline) */}
         <div className="md:hidden">
            <div className="relative">
               {/* Vertical line */}
               <div className="absolute left-8 top-0 bottom-0 w-1 bg-gray-800"></div>

               {/* Animated fill line */}
               <motion.div
                  className="absolute left-8 top-0 w-1 bg-gradient-to-b from-blue-500 via-purple-500 to-indigo-500"
                  initial={{ height: 0 }}
                  animate={{
                     height: `${
                        (activeStep + 1) * (100 / processSteps.length)
                     }%`,
                  }}
                  transition={{ duration: 0.5 }}
               />

               {/* Process steps */}
               {processSteps.map((step, index) => (
                  <motion.div
                     key={step.id}
                     ref={(el) => {
                        stepRefs.current[index] = el;
                     }}
                     className="relative flex mb-16"
                     initial={{ opacity: 0, x: -50 }}
                     animate={controls}
                     custom={index}
                     variants={{
                        visible: (i) => ({
                           opacity: 1,
                           x: 0,
                           transition: { delay: i * 0.2, duration: 0.5 },
                        }),
                     }}
                  >
                     {/* Step circle */}
                     <motion.div
                        className="relative z-10 w-16 h-16 rounded-full border-2 flex items-center justify-center bg-black"
                        style={{
                           borderColor: step.color,
                           boxShadow:
                              activeStep >= index
                                 ? `0 0 15px ${step.color}`
                                 : "none",
                        }}
                        animate={{
                           scale: activeStep === index ? 1.1 : 1,
                           borderWidth: activeStep >= index ? 3 : 2,
                        }}
                     >
                        <motion.div
                           animate={{
                              rotate: activeStep === index ? [0, 360] : 0,
                              scale: activeStep === index ? [1, 1.1, 1] : 1,
                           }}
                           transition={{
                              rotate: {
                                 duration: 3,
                                 repeat: Number.POSITIVE_INFINITY,
                                 ease: "linear",
                              },
                              scale: {
                                 duration: 1.5,
                                 repeat: Number.POSITIVE_INFINITY,
                                 repeatType: "reverse",
                              },
                           }}
                        >
                           <span
                              className="iconify text-2xl"
                              data-icon={step.icon}
                              style={{ color: step.color }}
                           ></span>
                        </motion.div>
                     </motion.div>

                     {/* Step content */}
                     <div className="ml-6 pt-3">
                        <motion.div
                           className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-lg p-4"
                           whileHover={{ scale: 1.03, borderColor: step.color }}
                           animate={{
                              borderColor:
                                 activeStep === index
                                    ? step.color
                                    : "rgb(31, 41, 55)",
                              boxShadow:
                                 activeStep === index
                                    ? `0 0 20px ${step.color}40`
                                    : "none",
                           }}
                        >
                           <h3
                              className="text-lg font-bold mb-2"
                              style={{ color: step.color }}
                           >
                              {step.title}
                           </h3>
                           <p className="text-gray-400">{step.description}</p>
                        </motion.div>
                     </div>
                  </motion.div>
               ))}
            </div>
         </div>

         {/* Desktop view (interactive U-shaped timeline) */}
         <div className="hidden md:block">
            <div className="relative h-[600px]">
               {/* The U-shaped path */}
               <svg
                  className="absolute inset-0 w-full h-full"
                  viewBox="0 0 1200 600"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
               >
                  {/* Background path */}
                  <path
                     d="M100,150 C100,150 300,150 600,150 C900,150 1100,150 1100,150 C1100,150 1100,300 1100,450 C1100,450 900,450 600,450 C300,450 100,450 100,450 C100,450 100,300 100,150"
                     stroke="#1F2937"
                     strokeWidth="4"
                     strokeDasharray="10 10"
                     fill="none"
                  />

                  {/* Animated gradient path */}
                  <motion.path
                     d="M100,150 C100,150 300,150 600,150 C900,150 1100,150 1100,150 C1100,150 1100,300 1100,450 C1100,450 900,450 600,450 C300,450 100,450 100,450 C100,450 100,300 100,150"
                     stroke="url(#gradient)"
                     strokeWidth="4"
                     strokeLinecap="round"
                     fill="none"
                     initial={{ pathLength: 0 }}
                     animate={{
                        pathLength: activeStep / (processSteps.length - 1),
                     }}
                     transition={{ duration: 0.5 }}
                  />

                  {/* Gradient definition */}
                  <defs>
                     <linearGradient
                        id="gradient"
                        x1="0%"
                        y1="0%"
                        x2="100%"
                        y2="0%"
                     >
                        <stop offset="0%" stopColor="#3B82F6" />
                        <stop offset="50%" stopColor="#8B5CF6" />
                        <stop offset="100%" stopColor="#6366F1" />
                     </linearGradient>
                  </defs>
               </svg>

               {/* Top row steps (first 3) */}
               <div className="absolute top-[70px] left-0 right-0 flex justify-between px-16">
                  {processSteps.slice(0, 3).map((step, index) => (
                     <motion.div
                        key={step.id}
                        ref={(el) => {
                           stepRefs.current[index] = el;
                        }}
                        className="relative flex flex-col items-center w-64"
                        initial={{ opacity: 0, y: -50 }}
                        animate={controls}
                        custom={index}
                        variants={{
                           visible: (i) => ({
                              opacity: 1,
                              y: 0,
                              transition: { delay: i * 0.2, duration: 0.5 },
                           }),
                        }}
                        onMouseEnter={() => setHoveredStep(index)}
                        onMouseLeave={() => setHoveredStep(null)}
                     >
                        {/* Step box */}
                        <motion.div
                           className="bg-gray-900/70 backdrop-blur-sm border border-gray-800 rounded-lg p-4 mb-6 w-full"
                           whileHover={{ scale: 1.05, borderColor: step.color }}
                           animate={{
                              borderColor:
                                 activeStep === index
                                    ? step.color
                                    : hoveredStep === index
                                    ? step.color
                                    : "rgb(31, 41, 55)",
                              boxShadow:
                                 activeStep === index
                                    ? `0 0 20px ${step.color}40`
                                    : hoveredStep === index
                                    ? `0 0 15px ${step.color}30`
                                    : "none",
                              y: activeStep === index ? -5 : 0,
                           }}
                        >
                           <h3
                              className="text-lg font-bold mb-2 text-center"
                              style={{ color: step.color }}
                           >
                              {step.title}
                           </h3>
                           <p className="text-gray-400 text-center text-sm">
                              {step.description}
                           </p>
                        </motion.div>

                        {/* Connecting line */}
                        <div className="h-10 w-px bg-gray-800"></div>

                        {/* Step circle */}
                        <motion.div
                           className="relative z-10 w-16 h-16 rounded-full border-2 flex items-center justify-center bg-black"
                           style={{
                              borderColor: step.color,
                              boxShadow:
                                 activeStep >= index
                                    ? `0 0 15px ${step.color}`
                                    : hoveredStep === index
                                    ? `0 0 10px ${step.color}70`
                                    : "none",
                           }}
                           animate={{
                              scale:
                                 activeStep === index
                                    ? 1.1
                                    : hoveredStep === index
                                    ? 1.05
                                    : 1,
                              borderWidth: activeStep >= index ? 3 : 2,
                           }}
                           whileHover={{ scale: 1.1 }}
                        >
                           <motion.div
                              animate={{
                                 rotate: activeStep === index ? [0, 360] : 0,
                                 scale:
                                    activeStep === index
                                       ? [1, 1.1, 1]
                                       : hoveredStep === index
                                       ? [1, 1.05, 1]
                                       : 1,
                              }}
                              transition={{
                                 rotate: {
                                    duration: 3,
                                    repeat: Number.POSITIVE_INFINITY,
                                    ease: "linear",
                                 },
                                 scale: {
                                    duration: 1.5,
                                    repeat: Number.POSITIVE_INFINITY,
                                    repeatType: "reverse",
                                 },
                              }}
                           >
                              <span
                                 className="iconify text-2xl"
                                 data-icon={step.icon}
                                 style={{ color: step.color }}
                              ></span>
                           </motion.div>
                        </motion.div>
                     </motion.div>
                  ))}
               </div>

               {/* Bottom row steps (last 3) */}
               <div className="absolute bottom-[70px] left-0 right-0 flex justify-between px-16">
                  {processSteps.slice(3).map((step, index) => {
                     const actualIndex = index + 3;
                     return (
                        <motion.div
                           key={step.id}
                           ref={(el) => {
                              stepRefs.current[actualIndex] = el;
                           }}
                           className="relative flex flex-col items-center w-64"
                           initial={{ opacity: 0, y: 50 }}
                           animate={controls}
                           custom={actualIndex}
                           variants={{
                              visible: (i) => ({
                                 opacity: 1,
                                 y: 0,
                                 transition: { delay: i * 0.2, duration: 0.5 },
                              }),
                           }}
                           onMouseEnter={() => setHoveredStep(actualIndex)}
                           onMouseLeave={() => setHoveredStep(null)}
                        >
                           {/* Step circle */}
                           <motion.div
                              className="relative z-10 w-16 h-16 rounded-full border-2 flex items-center justify-center bg-black"
                              style={{
                                 borderColor: step.color,
                                 boxShadow:
                                    activeStep >= actualIndex
                                       ? `0 0 15px ${step.color}`
                                       : hoveredStep === actualIndex
                                       ? `0 0 10px ${step.color}70`
                                       : "none",
                              }}
                              animate={{
                                 scale:
                                    activeStep === actualIndex
                                       ? 1.1
                                       : hoveredStep === actualIndex
                                       ? 1.05
                                       : 1,
                                 borderWidth: activeStep >= actualIndex ? 3 : 2,
                              }}
                              whileHover={{ scale: 1.1 }}
                           >
                              <motion.div
                                 animate={{
                                    rotate:
                                       activeStep === actualIndex
                                          ? [0, 360]
                                          : 0,
                                    scale:
                                       activeStep === actualIndex
                                          ? [1, 1.1, 1]
                                          : hoveredStep === actualIndex
                                          ? [1, 1.05, 1]
                                          : 1,
                                 }}
                                 transition={{
                                    rotate: {
                                       duration: 3,
                                       repeat: Number.POSITIVE_INFINITY,
                                       ease: "linear",
                                    },
                                    scale: {
                                       duration: 1.5,
                                       repeat: Number.POSITIVE_INFINITY,
                                       repeatType: "reverse",
                                    },
                                 }}
                              >
                                 <span
                                    className="iconify text-2xl"
                                    data-icon={step.icon}
                                    style={{ color: step.color }}
                                 ></span>
                              </motion.div>
                           </motion.div>

                           {/* Connecting line */}
                           <div className="h-10 w-px bg-gray-800"></div>

                           {/* Step box */}
                           <motion.div
                              className="bg-gray-900/70 backdrop-blur-sm border border-gray-800 rounded-lg p-4 mt-6 w-full"
                              whileHover={{
                                 scale: 1.05,
                                 borderColor: step.color,
                              }}
                              animate={{
                                 borderColor:
                                    activeStep === actualIndex
                                       ? step.color
                                       : hoveredStep === actualIndex
                                       ? step.color
                                       : "rgb(31, 41, 55)",
                                 boxShadow:
                                    activeStep === actualIndex
                                       ? `0 0 20px ${step.color}40`
                                       : hoveredStep === actualIndex
                                       ? `0 0 15px ${step.color}30`
                                       : "none",
                                 y: activeStep === actualIndex ? 5 : 0,
                              }}
                           >
                              <h3
                                 className="text-lg font-bold mb-2 text-center"
                                 style={{ color: step.color }}
                              >
                                 {step.title}
                              </h3>
                              <p className="text-gray-400 text-center text-sm">
                                 {step.description}
                              </p>
                           </motion.div>
                        </motion.div>
                     );
                  })}
               </div>

               {/* Animated particles along the path */}
               {Array.from({ length: 12 }).map((_, index) => {
                  const offset = index * (1 / 12);
                  const isVisible =
                     offset <= activeStep / (processSteps.length - 1);

                  return (
                     <motion.div
                        key={`particle-${index}`}
                        className="absolute w-3 h-3 rounded-full"
                        style={{
                           backgroundColor: isVisible
                              ? index < 4
                                 ? "#3B82F6"
                                 : index < 8
                                 ? "#8B5CF6"
                                 : "#6366F1"
                              : "#1F2937",
                           boxShadow: isVisible
                              ? `0 0 10px ${
                                   index < 4
                                      ? "#3B82F6"
                                      : index < 8
                                      ? "#8B5CF6"
                                      : "#6366F1"
                                }`
                              : "none",
                        }}
                        initial={{ opacity: 0 }}
                        animate={{
                           opacity: isVisible ? 1 : 0.3,
                           scale: isVisible ? [0.8, 1.2, 0.8] : 1,
                        }}
                        transition={{
                           scale: {
                              duration: 2,
                              repeat: Number.POSITIVE_INFINITY,
                              repeatType: "reverse",
                           },
                        }}
                     >
                        <motion.div
                           className="absolute inset-0 rounded-full"
                           initial={{ opacity: 0, scale: 0 }}
                           animate={{
                              opacity: isVisible ? [0, 0.5, 0] : 0,
                              scale: isVisible ? [1, 2, 1] : 0,
                           }}
                           transition={{
                              duration: 2,
                              repeat: Number.POSITIVE_INFINITY,
                              repeatType: "reverse",
                           }}
                           style={{
                              backgroundColor: isVisible
                                 ? index < 4
                                    ? "#3B82F6"
                                    : index < 8
                                    ? "#8B5CF6"
                                    : "#6366F1"
                                 : "transparent",
                           }}
                        />
                     </motion.div>
                  );
               })}

               {/* Animated flying objects */}
               <motion.div
                  className="absolute"
                  animate={{
                     pathOffset: [0, 1],
                     opacity: [0, 1, 0],
                  }}
                  transition={{
                     duration: 8,
                     repeat: Number.POSITIVE_INFINITY,
                     repeatType: "loop",
                     times: [0, 0.5, 1],
                  }}
                  style={{
                     offsetPath:
                        "path('M100,150 C100,150 300,150 600,150 C900,150 1100,150 1100,150 C1100,150 1100,300 1100,450 C1100,450 900,450 600,450 C300,450 100,450 100,450 C100,450 100,300 100,150')",
                  }}
               >
                  <div className="relative">
                     <motion.div
                        className="absolute -left-6 -top-6 w-12 h-12 bg-blue-500/20 rounded-full"
                        animate={{
                           scale: [1, 1.5, 1],
                           opacity: [0.2, 0.5, 0.2],
                        }}
                        transition={{
                           duration: 2,
                           repeat: Number.POSITIVE_INFINITY,
                           repeatType: "reverse",
                        }}
                     />
                     <span
                        className="iconify text-3xl text-blue-500"
                        data-icon="carbon:phone-application"
                     ></span>
                  </div>
               </motion.div>
            </div>
         </div>

         {/* Progress indicator */}
         <div className="mt-8 flex justify-center">
            <div className="bg-gray-800 h-1 rounded-full w-64 overflow-hidden">
               <motion.div
                  className="h-full bg-gradient-to-r from-blue-500 via-purple-500 to-indigo-500"
                  initial={{ width: 0 }}
                  animate={{
                     width: `${
                        (activeStep + 1) * (100 / processSteps.length)
                     }%`,
                  }}
                  transition={{ duration: 0.5 }}
               />
            </div>
         </div>
      </div>
   );
}
