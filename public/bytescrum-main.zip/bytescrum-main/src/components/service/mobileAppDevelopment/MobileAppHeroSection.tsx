import clsx from "clsx";
import React from "react";
import { twMerge } from "tailwind-merge";
import dynamic from "next/dynamic";

const MobileAppBackgroundAnimation = dynamic(
   () => import("./workProcess/MobileAppBackgroundAnimation"),
   {
      ssr: false,
   }
);
interface IProps {
   data?:any;
}
const MobileAppHeroSection = ({data}:IProps) => {
   return (
      <div
         className={twMerge(
            clsx(
               "relative overflow-hidden px-[22px]  md:px-[54px]  items-center justify-normal   z-20"
            )
         )}
      >
         <MobileAppBackgroundAnimation />
         <div className="grid place-items-center py-10 md:py-16 md:gap-[10px]">
            <h1
               className="text-[35px]  md:text-[70px] md:leading-[80px] font-bold  poppins text-center"
               data-aos="zoom-in"
               data-aos-easing="ease-out-cubic"
               data-aos-anchor-placement="top-bottom"
            >
               {data.title}
            </h1>
            <p
               className="poppins text-[#b7b7b7] text-[14px] md:text-[18px]"
               data-aos="fade-up"
               data-aos-delay={500}
               data-aos-easing="ease-out-cubic"
               data-aos-anchor-placement="top-bottom"
            >
               {data.titleTwo}
            </p>
         </div>
      </div>
   );
};

export default MobileAppHeroSection;
