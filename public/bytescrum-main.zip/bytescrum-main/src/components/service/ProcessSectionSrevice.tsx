"use client";
import { Icon } from "@iconify/react/dist/iconify.js";
import clsx from "clsx";
import { motion } from "framer-motion";
import { useState, useRef, useEffect } from "react";
import { twMerge } from "tailwind-merge";
import SectionTitle from "../SectionTitle";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import SectionSubtitle from "../SectionSubtitle";

type Props = {
   steps: any;
   processMarker: any;
   header: any;
};

const ProcessSectionSrevice = ({ header, steps, processMarker }: Props) => {
   const { screenWidth } = useBreakpoints();
   const isMobileScreen = screenWidth <= 490;
   const stepRefs = useRef<(HTMLDivElement | null)[]>([]);
   const [stepInView, setStepInView] = useState(Array(6).fill(false));

   useEffect(() => {
      const observer = new IntersectionObserver(
         (entries) => {
            entries.forEach((entry, index) => {
               setStepInView((prev) => {
                  const newState = [...prev];
                  const target = entry.target as HTMLElement;
                  newState[Number.parseInt(target.dataset.index!)] =
                     entry.isIntersecting;
                  return newState;
               });
            });
         },
         {
            threshold: 0.5,
         }
      );

      stepRefs.current.forEach((ref) => {
         if (ref) {
            observer.observe(ref);
         }
      });

      return () => {
         stepRefs.current.forEach((ref) => {
            if (ref) {
               observer.unobserve(ref);
            }
         });
      };
   }, []);
   return (
      <div className="pb-20">
         <div className=" mx-auto px-6">
            <motion.div
               className="text-center max-w-3xl mx-auto "
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               transition={{ duration: 0.5 }}
            >
               <SectionTitle className="max-w-3xl m-auto">
                  {header.title}
               </SectionTitle>
               <SectionSubtitle className="m-auto">
                  {header.subtitle}
               </SectionSubtitle>
            </motion.div>

            {/* Process flow visualization */}
            <motion.div
               className="my-8 md:my-12 max-w-[85%] md:max-w-4xl mx-auto relative "
               initial={{ opacity: 0 }}
               whileInView={{ opacity: 1 }}
               viewport={{ once: true }}
               transition={{ duration: 0.8, delay: 0.5 }}
            >
               <div className="h-[6px] md:h-2 bg-[#626262] rounded-full overflow-hidden">
                  <motion.div
                     className="h-full bg-gradient-to-r from-[#262626] via-[#ffffff] to-[#fff]"
                     initial={{ width: "0%" }}
                     whileInView={{ width: "100%" }}
                     viewport={{ once: false }}
                     transition={{ duration: 2.5, delay: 0.2, ease: "easeOut" }}
                  />
               </div>

               {/* Process markers */}
               {processMarker.map((item: any, index: any) => (
                  <motion.div
                     key={index}
                     className="absolute top-0 -mt-3 md:-mt-5 "
                     style={{ left: `${item.position}%` }}
                     initial={{ x: -20, opacity: 0 }}
                     whileInView={{ x: -10, opacity: 1 }}
                     viewport={{ once: true }}
                     transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                  >
                     <div
                        className={twMerge(
                           clsx(
                              "w-8 h-8 md:w-12 md:h-12 rounded-full border-2 flex items-center justify-center  border-[#262626]",
                              {
                                 "mr-2": index === 5,
                              }
                           )
                        )}
                        style={{
                           background: `radial-gradient(circle , #565656, #000 )`,
                        }}
                     >
                        <span className="text-[#fff] text-sm">
                           <Icon
                              icon={item.icon}
                              width={isMobileScreen ? "16" : "20"}
                              height={isMobileScreen ? "16" : "20"}
                           />
                        </span>
                     </div>
                  </motion.div>
               ))}
            </motion.div>

            <div className="max-w-6xl mx-auto">
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {steps.map((step: any, index: any) => (
                     <motion.div
                        key={index}
                        className=" backdrop-blur-sm border border-[#565656] rounded-xl p-6 relative overflow-hidden group"
                        initial={{ opacity: 0, y: 30 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.2, delay: index * 0.1 }}
                        whileHover={{
                           y: -5,
                           boxShadow: `0 10px 30px -15px ${step.color}40`,
                        }}
                     >
                        {/* Background gradient */}
                        <div
                           className="absolute inset-0  opacity-5 group-hover:opacity-15 transition-opacity duration-500"
                           //    style={{
                           //       background: `radial-gradient(circle at 50% 0%, ${step.color}, transparent 70%)`,
                           //    }}
                           style={{
                              background: `radial-gradient(circle at 50% 0%, #fff, transparent 70%)`,
                           }}
                        >
                           <Icon
                              icon={step.icon}
                              width="212"
                              height="212"
                              className="absolute -top-1/2 left-1/2 -translate-x-1/2 translate-y-1/3"
                           />
                        </div>

                        {/* Step number */}
                        <div className="absolute -top-4 -right-4 text-8xl font-bold opacity-5 group-hover:opacity-20 transition-opacity duration-500">
                           {index + 1}
                        </div>

                        {/* Icon */}
                        <div
                           className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-5 relative`}
                        >
                           <motion.div
                              initial={{ rotate: 0 }}
                              whileInView={{ rotate: [0, 10, 0, -10, 0] }}
                              viewport={{ once: false, margin: "-100px" }}
                              transition={{
                                 duration: 0.5,
                                 delay: index * 0.1 + 0.5,
                              }}
                           >
                              <Icon icon={step.icon} width="60" height="60" />
                           </motion.div>

                           {/* Animated rings */}
                           <motion.div
                              className="absolute inset-0 rounded-2xl border-2"
                              //   style={{ borderColor: step.color }}
                              initial={{ opacity: 0, scale: 0.8 }}
                              whileInView={{
                                 opacity: [0, 1, 0],
                                 scale: [0.8, 1.2, 1.5],
                              }}
                              viewport={{ once: false, margin: "-100px" }}
                              transition={{
                                 duration: 2,
                                 repeat: Number.POSITIVE_INFINITY,
                                 repeatDelay: 3,
                                 delay: index * 0.5,
                              }}
                           />
                        </div>

                        {/* Content */}
                        <h3 className="text-xl mt-5 poppins font-semibold mb-3 group-hover:text-white transition-colors duration-300">
                           {step.title}
                        </h3>
                        <p className="text-[#d4d4d4] inter group-hover:text-[#fff] transition-colors duration-300">
                           {step.description}
                        </p>

                        {/* Animated arrow */}
                        {index < 5 && (
                           <motion.div
                              className="absolute bottom-4 right-4 opacity-30 group-hover:opacity-100 transition-opacity duration-300"
                              animate={{ x: [0, 5, 0] }}
                              transition={{
                                 duration: 1.5,
                                 repeat: Number.POSITIVE_INFINITY,
                              }}
                           >
                              <span
                                 className="iconify text-xl "
                                 data-icon="carbon:arrow-right"
                              >
                                 <Icon
                                    icon="mingcute:arrow-right-fill"
                                    width="24"
                                    height="24"
                                 />
                              </span>
                           </motion.div>
                        )}
                     </motion.div>
                  ))}
               </div>
            </div>
         </div>
      </div>
   );
};

export default ProcessSectionSrevice;

// const steps = [
//    {
//       title: "Discovery & Planning",
//       description:
//          "We begin by understanding your business goals, target audience, and project requirements through in-depth consultations.",
//       icon: "carbon:document-preliminary",
//       color: "#3b82f6",
//    },
//    {
//       title: "Design & Prototyping",
//       description:
//          "Our designers create intuitive interfaces and prototypes that align with your brand identity and user expectations.",
//       icon: "carbon:pen-fountain",
//       color: "#8b5cf6",
//    },
//    {
//       title: "Development",
//       description:
//          "Our expert developers build your solution using the latest technologies and best practices for optimal performance.",
//       icon: "carbon:code",
//       color: "#ec4899",
//    },
//    {
//       title: "Testing & QA",
//       description:
//          "We conduct thorough testing to ensure your solution is bug-free, secure, and delivers an exceptional user experience.",
//       icon: "carbon:task-complete",
//       color: "#f59e0b",
//    },
//    {
//       title: "Deployment & Launch",
//       description:
//          "We handle the deployment process and ensure a smooth launch, with comprehensive documentation and training.",
//       icon: "carbon:rocket",
//       color: "#10b981",
//    },
//    {
//       title: "Maintenance & Support",
//       description:
//          "We provide ongoing maintenance and support to ensure your solution continues to perform optimally.",
//       icon: "carbon:help",
//       color: "#3b82f6",
//    },
// ];

// const processMarker = [
//    { position: 0, icon: "carbon:document-preliminary" },
//    { position: 18, icon: "carbon:pen-fountain" },
//    { position: 38, icon: "carbon:code" },
//    { position: 58, icon: "carbon:task-complete" },
//    { position: 78, icon: "carbon:rocket" },
//    { position: 98, icon: "carbon:help" },
// ];
