"use client";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import { Icon } from "@iconify/react/dist/iconify.js";
import { Button } from "@nextui-org/react";
import clsx from "clsx";
import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { twMerge } from "tailwind-merge";
type Props = {
   caseStudies: {
      title: string;
      industry: string;
      description: string;
      image: string;
      results: string[];
   }[];
   className: string;
   data:any;
};

const SuccesStories = ({ caseStudies,data, className }: Props) => {
   return (
      <div className={twMerge(clsx("py-10", className))}>
         <div className=" mx-auto px-4">
            <motion.div
               className="text-center max-w-3xl mx-auto mb-16 space-y-3"
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               transition={{ duration: 0.5 }}
            >
               <SectionTitle className="max-w-3xl m-auto">
                  {data.sectionTitle}{" "}
               </SectionTitle>
               <SectionSubtitle className=" m-auto">
            {data.sectionSubtitle}  </SectionSubtitle>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
               {caseStudies.map((study, index) => (
                  <motion.div
                     key={index}
                     className="bg-gray-900/50 border border-gray-800 rounded-xl overflow-hidden"
                     initial={{ opacity: 0, y: 20 }}
                     whileInView={{ opacity: 1, y: 0 }}
                     viewport={{ once: true }}
                     transition={{ duration: 0.5, delay: index * 0.1 }}
                     whileHover={{
                        y: -10,
                        boxShadow: "0 10px 30px -15px rgba(59, 130, 246, 0.5)",
                     }}
                  >
                     <div className="relative h-48">
                        <Image
                           src={study.image || "/placeholder.svg"}
                           alt={study.title}
                           fill
                           className="object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
                        <div className="absolute bottom-4 left-4">
                           <span className="bg-blue-900/70 text-blue-300 text-xs px-2 py-1 rounded">
                              {study.industry}
                           </span>
                        </div>
                     </div>
                     <div className="p-6">
                        <h3 className="text-xl font-semibold mb-3">
                           {study.title}
                        </h3>
                        <p className="text-gray-400 mb-4">
                           {study.description}
                        </p>
                        <h4 className="text-sm font-semibold text-gray-300 mb-2">
{data.results}                        </h4>
                        <ul className="space-y-2">
                           {study.results.map((result, resultIndex) => (
                              <li
                                 key={resultIndex}
                                 className="flex items-center gap-2"
                              >
                                 <span className="text-green-500">✓</span>
                                 <span className="text-gray-400">{result}</span>
                              </li>
                           ))}
                        </ul>
                        {/* <div className="mt-6">
                           <Link
                              href="/case-studies"
                              className="text-blue-400 hover:text-blue-300 transition-colors flex items-center"
                           >
                              Read Full Case Study{" "}
                              <Icon
                                 icon="solar:arrow-right-linear"
                                 className="ml-2 text-s,"
                              />
                           </Link>
                        </div> */}
                     </div>
                  </motion.div>
               ))}
            </div>

            <motion.div
               className="text-center mt-12"
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               transition={{ duration: 0.5, delay: 0.4 }}
            >
               <Link href="/portfolio">
                  <Button className="relative bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-full transition-all duration-300 overflow-hidden w-fit">
                     {/* Button glow effect */}
                     <motion.div
                        className="absolute inset-0 bg-gradient-to-r from-blue-400/0 via-blue-400/70 to-blue-400/0"
                        animate={{
                           x: ["-100%", "100%"],
                        }}
                        transition={{
                           duration: 2,
                           repeat: Number.POSITIVE_INFINITY,
                           ease: "linear",
                        }}
                     />
                     <span className="relative z-10">
{data.viewAll}                     </span>
                  </Button>
               </Link>
            </motion.div>
         </div>
      </div>
   );
};

export default SuccesStories;
