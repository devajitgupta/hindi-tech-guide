"use client";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import { Icon } from "@iconify/react/dist/iconify.js";
import clsx from "clsx";
import { motion } from "framer-motion";
import Link from "next/link";
import { useState } from "react";
import { twMerge } from "tailwind-merge";

type Props = {
   seoServices: { title: string; description: string; icon: string }[];
   socialMediaServices: { title: string; description: string; icon: string }[];
   contentServices: { title: string; description: string; icon: string }[];
   analyticsServices: { title: string; description: string; icon: string }[];
   className: string;
   data:any;
};

const SeoServices = ({
   analyticsServices,
   contentServices,
   seoServices,
   socialMediaServices,
   className,
   data,
}: Props) => {
   const [activeTab, setActiveTab] = useState("seo");
   return (
      <div className={twMerge(clsx("py-10 bg-[#000]", className))}>
         <div className=" mx-auto px-5">
            <motion.div
               className="text-center max-w-3xl mx-auto mb-16 space-y-3"
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               transition={{ duration: 0.5 }}
            >
               <SectionTitle className="max-w-3xl m-auto">
                  {data.title}
               </SectionTitle>
               <SectionSubtitle className=" m-auto">
               {data.description}
               </SectionSubtitle>
            </motion.div>

            <div className="flex justify-center   mb-12 overflow-x-auto pb-4">
               <div className="flex  md:space-x-2 bg-gray-900/50 p-1 rounded-full">
                  {["seo", "social", "content", "analytics"].map((tab) => (
                     <button
                        key={tab}
                        className={`px-4 py-2 rounded-full text-xs md:text-sm font-medium transition-all ${
                           activeTab === tab
                              ? "bg-[#1463fd] text-[#fff]"
                              : "text-gray-400 hover:text-white hover:bg-[#1463fd]/50"
                        }`}
                        onClick={() => setActiveTab(tab)}
                     >
                        {tab === "seo"
                           ? "SEO"
                           : tab === "social"
                           ? "Social Media"
                           : tab.charAt(0).toUpperCase() + tab.slice(1)}
                     </button>
                  ))}
               </div>
            </div>

            <motion.div
               className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               transition={{ duration: 0.5 }}
            >
               {" "}
               {/* Seo */}
               {activeTab === "seo" &&
                  seoServices.map((service, index) => (
                     <motion.div
                        key={index}
                        className="bg-gradient-to-br from-[#565656]/10 to-black border border-[#262626] rounded-xl p-6 hover:border-[#fff]/50 transition-all duration-300 group"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                        whileHover={{
                           scale: 1.01,
                           y: -5,
                           boxShadow: "0 7px 20px -15px rgba(255, 255, 255, )",
                        }}
                     >
                        <div className="w-14 h-14 border-[#262626] border bg-[#000] rounded-full flex items-center justify-center mb-2 group-hover:bg-white transition-all duration-300">
                           <Icon
                              icon={service.icon}
                              width="32"
                              height="32"
                              className="group-hover:text-black"
                           />
                           {/* <span
                              className="iconify text-blue-400 text-2xl"
                              data-icon={service.icon}
                           ></span> */}
                        </div>
                        <SectionSubtitle
                           className=" text-start font-semibold mb-2"
                           textSize="xl"
                        >
                           {service.title}
                        </SectionSubtitle>
                        <Text className="text-start mb-5">
                           {service.description}
                        </Text>
                     </motion.div>
                  ))}
               {/* social */}
               {activeTab === "social" &&
                  socialMediaServices.map((service, index) => (
                     <motion.div
                        key={index}
                        className="bg-gradient-to-br from-[#565656]/10 to-black border border-[#262626] rounded-xl p-6 hover:border-[#fff]/50 transition-all duration-300 group"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                        whileHover={{
                           scale: 1.01,
                           y: -5,
                           boxShadow: "0 7px 20px -15px rgba(255, 255, 255, )",
                        }}
                     >
                        <div className="w-14 h-14 border-[#262626] border bg-[#000] rounded-full flex items-center justify-center mb-2 group-hover:bg-white transition-all duration-300">
                           <Icon
                              icon={service.icon}
                              width="32"
                              height="32"
                              className="group-hover:text-black"
                           />
                           {/* <span
                              className="iconify text-purple-400 text-2xl"
                              data-icon={service.icon}
                           ></span> */}
                        </div>
                        <SectionSubtitle
                           className=" text-start font-semibold mb-2"
                           textSize="xl"
                        >
                           {service.title}
                        </SectionSubtitle>
                        <Text className="text-start mb-5">
                           {service.description}
                        </Text>
                     </motion.div>
                  ))}
               {/* content */}
               {activeTab === "content" &&
                  contentServices.map((service, index) => (
                     <motion.div
                        key={index}
                        className="bg-gradient-to-br from-[#565656]/10 to-black border border-[#262626] rounded-xl p-6 hover:border-[#fff]/50 transition-all duration-300 group"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                        whileHover={{
                           scale: 1.01,
                           y: -5,
                           boxShadow: "0 7px 20px -15px rgba(255, 255, 255, )",
                        }}
                     >
                        <div className="w-14 h-14 border-[#262626] border bg-[#000] rounded-full flex items-center justify-center mb-2 group-hover:bg-white transition-all duration-300">
                           <Icon
                              icon={service.icon}
                              width="32"
                              height="32"
                              className="group-hover:text-black"
                           />
                        </div>
                        <SectionSubtitle
                           className=" text-start font-semibold mb-2"
                           textSize="xl"
                        >
                           {service.title}
                        </SectionSubtitle>
                        <Text className="text-start mb-5">
                           {service.description}{" "}
                        </Text>
                     </motion.div>
                  ))}
               {/* content */}
               {activeTab === "analytics" &&
                  analyticsServices.map((service, index) => (
                     <motion.div
                        key={index}
                        className="bg-gradient-to-br from-[#565656]/10 to-black border border-[#262626] rounded-xl p-6 hover:border-[#fff]/50 transition-all duration-300 group"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                        whileHover={{
                           scale: 1.01,
                           y: -5,
                           boxShadow: "0 7px 20px -15px rgba(255, 255, 255, )",
                        }}
                     >
                        <div className="w-14 h-14 border-[#262626] border bg-[#000] rounded-full flex items-center justify-center mb-2 group-hover:bg-white transition-all duration-300">
                           <Icon
                              icon={service.icon}
                              width="32"
                              height="32"
                              className="group-hover:text-black"
                           />
                        </div>
                        <SectionSubtitle
                           className=" text-start font-semibold mb-2"
                           textSize="xl"
                        >
                           {service.title}
                        </SectionSubtitle>
                        <Text className="text-start mb-5">
                           {service.description}
                        </Text>
                     </motion.div>
                  ))}
            </motion.div>
         </div>
      </div>
   );
};

export default SeoServices;
