"use client";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import { Icon } from "@iconify/react/dist/iconify.js";
import clsx from "clsx";
import { motion } from "framer-motion";
import Link from "next/link";
import { twMerge } from "tailwind-merge";
type Props = {
   platforms: { name: string; icon: string; category: string }[];
   className: string;
   data:any;
};

const DigitalPlatformsSection = ({ className,data, platforms }: Props) => {
   return (
      <div className={twMerge(clsx("py-10 bg-[#000]", className))}>
         <div className=" mx-auto px-4">
            <motion.div
               className="text-center max-w-3xl mx-auto mb-16 space-y-3"
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               transition={{ duration: 0.5 }}
            >
               <SectionTitle className="max-w-3xl m-auto">
{data.title}               </SectionTitle>
               <SectionSubtitle className=" m-auto">
            {data.description}
               </SectionSubtitle>
            </motion.div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
               {platforms.map((platform, index) => (
                  <motion.div
                     key={index}
                     className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 flex flex-col items-center justify-center hover:border-blue-500/30 transition-all duration-300"
                     initial={{ opacity: 0, y: 20, scale: 0.9 }}
                     whileInView={{ opacity: 1, y: 0, scale: 1 }}
                     viewport={{ once: true }}
                     transition={{
                        duration: 0.5,
                        delay: index * 0.05,
                        type: "spring",
                        stiffness: 100,
                     }}
                     whileHover={{
                        y: -10,
                        boxShadow: "0 10px 30px -15px rgba(59, 130, 246, 0.5)",
                        scale: 1.05,
                     }}
                  >
                     <motion.div
                        className="w-16 h-16 mb-3 flex items-center justify-center"
                        whileHover={{ rotate: 360 }}
                        transition={{ duration: 1, type: "spring" }}
                     >
                        <Icon
                           icon={platform.icon}
                           className="iconify text-4xl"
                        />
                        {/* <span
                           className="iconify text-4xl"
                           data-icon={platform.icon}
                        ></span> */}
                     </motion.div>
                     <motion.span
                        className="text-sm font-medium text-center"
                        whileHover={{ scale: 1.1 }}
                     >
                        {platform.name}
                     </motion.span>
                     <span className="text-xs text-gray-500 mt-1 capitalize">
                        {platform.category}
                     </span>
                  </motion.div>
               ))}
            </div>
         </div>
      </div>
   );
};

export default DigitalPlatformsSection;
