"use client";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import { Icon } from "@iconify/react/dist/iconify.js";
import clsx from "clsx";
import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { twMerge } from "tailwind-merge";
type Props = {
   data:any;
   analyticsReporting: {
      metrics: {
         label: string;
         value: string;
         growth: string;
         color: string;
      }[];
      benefits: string[];
      whatMatters: {
         title: string;
         description: string;
         icon: string;
         color: string;
      }[];
   };
   className: string;
};

const AnalyticsReporting = ({data, analyticsReporting, className }: Props) => {
   return (
      <div className={twMerge(clsx("py-10 bg-[#000]", className))}>
         <div className=" mx-auto px-10">
            <motion.div
               className="text-center max-w-3xl mx-auto mb-16 space-y-3"
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               transition={{ duration: 0.5 }}
            >
               <SectionTitle className="max-w-3xl m-auto">
{data.title}               </SectionTitle>
               <SectionSubtitle className=" m-auto">
          {data.description}    </SectionSubtitle>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
               <motion.div
                  className="order-2 lg:order-1"
                  initial={{ opacity: 0, x: -50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
               >
                  <div className="relative">
                     <div
                        // className="bg-gray-900/50 border border-gray-800 rounded-xl p-6 mb-6"
                        className="bg-gradient-to-br from-[#565656]/30 to-black border border-[#262626] rounded-xl p-6 mb-6  "
                     >
                        <SectionSubtitle className=" text-start !text-3xl font-semibold mb-2">
{data.performanceDashboard}                        </SectionSubtitle>
                        <div className="space-y-4">
                           {analyticsReporting.metrics.map((metric, index) => (
                              <motion.div
                                 key={index}
                                 className="flex justify-between items-center"
                                 initial={{ opacity: 0, y: 10 }}
                                 whileInView={{ opacity: 1, y: 0 }}
                                 viewport={{ once: true }}
                                 transition={{
                                    duration: 0.3,
                                    delay: index * 0.1,
                                 }}
                              >
                                 <div>
                                    <Text className=" text-sm">
                                       {metric.label}
                                    </Text>
                                    <Text className="!text-2xl font-bold text-start">
                                       {metric.value}
                                    </Text>
                                 </div>
                                 <div
                                    className={`text-${metric.color}-400 flex items-center`}
                                 >
                                    {metric.growth.startsWith("+") ? (
                                       <Icon
                                          icon="carbon:arrow-up"
                                          className=" mr-1"
                                       />
                                    ) : (
                                       <Icon
                                          icon="carbon:arrow-down"
                                          className=" mr-1"
                                       />
                                    )}
                                    {metric.growth}
                                 </div>
                              </motion.div>
                           ))}
                        </div>
                     </div>

                     <div className="bg-gradient-to-br from-[#565656]/30 to-black border border-[#262626] rounded-xl p-6 ">
                        <SectionSubtitle className=" text-start !text-2xl font-semibold mb-2">
{data.keyBenefits}                        </SectionSubtitle>
                        <div className="space-y-3">
                           {analyticsReporting.benefits.map(
                              (benefit, index) => (
                                 <motion.div
                                    key={index}
                                    className="flex items-center gap-3"
                                    initial={{ opacity: 0, x: -10 }}
                                    whileInView={{ opacity: 1, x: 0 }}
                                    viewport={{ once: true }}
                                    transition={{
                                       duration: 0.3,
                                       delay: index * 0.1,
                                    }}
                                 >
                                    <div className="w-6 h-6 rounded-full bg-green-900/30 flex items-center justify-center flex-shrink-0">
                                       <span
                                          className="iconify text-green-400 text-sm"
                                          data-icon="carbon:checkmark"
                                       ></span>
                                       <Icon
                                          icon="carbon:checkmark"
                                          className=" text-green-400 text-sm"
                                       />
                                    </div>
                                    <Text>{benefit}</Text>
                                 </motion.div>
                              )
                           )}
                        </div>
                     </div>

                     {/* Floating element */}
                     <motion.div
                        className="absolute -top-10 -left-10 bg-gradient-to-br from-blue-900/30 to-purple-900/30 backdrop-blur-sm border border-blue-500/30 rounded-lg p-4"
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={{ once: true }}
                        animate={{
                           y: [-7, -17, -7],
                        }}
                        transition={{
                           y: {
                              duration: 3,
                              repeat: Number.POSITIVE_INFINITY,
                              repeatType: "reverse",
                           },
                        }}
                     >
                        <div className="text-center">
                           <p className="text-blue-400 font-bold text-xl poppins">
{data.dataDriven}                           </p>
                           <p className="text-gray-300 text-sm inter">
{data.decisionMaking}                           </p>
                        </div>
                     </motion.div>
                  </div>
               </motion.div>

               <motion.div
                  className="order-1 lg:order-2"
                  initial={{ opacity: 0, x: 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
               >
                  <SectionSubtitle className=" text-start !text-3xl font-semibold mb-2">
{data.measureWhatMatters}                  </SectionSubtitle>
                  <Text className="text-start  mb-3">
       {data.descriptionOne}          </Text>

                  <div className="space-y-6 mt-5">
                     {analyticsReporting.whatMatters.map((item, index) => (
                        <motion.div
                           key={index}
                           className="flex gap-4"
                           initial={{ opacity: 0, y: 20 }}
                           whileInView={{ opacity: 1, y: 0 }}
                           viewport={{ once: true }}
                           transition={{ duration: 0.3, delay: index * 0.1 }}
                        >
                           <div
                              className={`w-12 h-12 rounded-lg bg-${item.color}-900/30 flex items-center justify-center flex-shrink-0`}
                           >
                              {/* <span
                                 className={`iconify text-${item.color}-400 text-2xl`}
                                 data-icon={item.icon}
                              ></span> */}
                              <Icon icon={item.icon} width="24" height="24" />
                           </div>
                           <div>
                              <SectionSubtitle
                                 className=" text-start !text-xl font-semibold mb-2"
                                 //  textSize="xl"
                              >
                                 {item.title}
                              </SectionSubtitle>
                              <Text className="text-start !text-[14px]">
                                 {item.description}
                              </Text>
                           </div>
                        </motion.div>
                     ))}
                  </div>

                  {/* <motion.div
                     className="mt-8"
                     initial={{ opacity: 0, y: 20 }}
                     whileInView={{ opacity: 1, y: 0 }}
                     viewport={{ once: true }}
                     transition={{ duration: 0.5, delay: 0.4 }}
                  >
                     <Link href="#">
                        <button className="relative bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-full transition-all duration-300 overflow-hidden w-fit">
                           
                           <motion.div
                              className="absolute inset-0 bg-gradient-to-r from-blue-400/0 via-blue-400/70 to-blue-400/0"
                              animate={{
                                 x: ["-100%", "100%"],
                              }}
                              transition={{
                                 duration: 2,
                                 repeat: Number.POSITIVE_INFINITY,
                                 ease: "linear",
                              }}
                           />
                           <span className="relative z-10">
                              Learn More About Analytics
                           </span>
                        </button>
                     </Link>
                  </motion.div> */}
               </motion.div>
            </div>
         </div>
      </div>
   );
};

export default AnalyticsReporting;
