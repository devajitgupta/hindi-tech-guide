import clsx from "clsx";
import React from "react";
import { twMerge } from "tailwind-merge";
import dynamic from "next/dynamic";

const DigitalMarketingAnimation = dynamic(
   () => import("./DigitalMarketingAnimation"),
   {
      ssr: false,
   }
);

const DigitalMarketingHero = ({langText}: {langText?: any}) => {
   return (
      <div
         className={twMerge(
            clsx(
               "relative overflow-hidden px-[22px]  md:px-[54px]  items-center justify-normal  z-20"
            )
         )}
      >
         <DigitalMarketingAnimation />
         <div className="grid place-items-center md:gap-[10px] py-10 md:py-24">
            <h1
               className="text-[35px] md:text-[70px] md:leading-[80px] font-bold  poppins text-center"
               data-aos="fade-up"
               data-aos-delay={300}
               data-aos-easing="ease-out-cubic"
               data-aos-anchor-placement="top-bottom"
            >
               {langText.digitalMarketingTitle}
            </h1>
            <p
               className="max-w-[609px] text-[16px] leading-[28px]  text-center m-auto mt-2"
               data-aos="fade-up"
               data-aos-delay={500}
               data-aos-easing="ease-out-cubic"
               data-aos-anchor-placement="top-bottom"
            >
               {langText.digitalMarketingDescription}
            </p>
         </div>
      </div>
   );
};

export default DigitalMarketingHero;
