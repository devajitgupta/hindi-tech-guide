"use client";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import { Icon } from "@iconify/react/dist/iconify.js";
import clsx from "clsx";
import { motion } from "framer-motion";
import Link from "next/link";
import { twMerge } from "tailwind-merge";
import dynamic from "next/dynamic";

const DigitalMarketingAnimation = dynamic(
   () => import("./DigitalMarketingAnimation"),
   {
      ssr: false,
   }
);

// type Props = {
//    contentMarketing: {
//       services: {
//          title: string;
//          description: string;
//          icon: string;
//          color: string;
//       }[];
//       benefits: {
//          title: string;
//          icon: string;
//          color: string;
//       }[];
//    };
//    className?: string;
// };

type Props={
   contentMarketing:any
   className?: string;
}

const ContentMarketing = ({ contentMarketing, className }: Props) => {
   return (
      <div className=" relative">
         <DigitalMarketingAnimation />
         <div
            className={twMerge(
               clsx(
                  "py-10 border-y border-[#262626] bg-black/20 backdrop-blur-sm z-20 relative ",
                  className
               )
            )}
         >
            <div className=" mx-auto px-4 ">
               <motion.div
                  className="text-center max-w-3xl mx-auto mb-16 space-y-3"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
               >
                  <SectionTitle className="max-w-3xl m-auto">
                    {contentMarketing.sectionTitleOne}
                  </SectionTitle>
                  <SectionSubtitle className=" m-auto">
                    {contentMarketing.sectionSubtitleOne}
                  </SectionSubtitle>
               </motion.div>

               <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-8">
                  <motion.div
                     className="lg:col-span-2 bg-gray-900/10 border border-[#262626] rounded-xl p-6 md:p-8"
                     initial={{ opacity: 0, y: 20 }}
                     whileInView={{ opacity: 1, y: 0 }}
                     viewport={{ once: true }}
                     transition={{ duration: 0.5 }}
                  >
                     <SectionSubtitle className="!text-2xl text-start font-semibold mb-6">
                        {contentMarketing.sectionTitleTwo}
                     </SectionSubtitle>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {contentMarketing.services.map((item:any, index:number) => (
                           <motion.div
                              key={index}
                              className={twMerge(
                                 clsx(
                                    "flex gap-4 p-4 rounded-lg bg-gradient-to-br from-black  border ",
                                    {
                                       "to-pink-900/10 border-pink-900/20":
                                          index === 0,
                                       "to-blue-900/10 border-blue-900/20":
                                          index === 1,
                                       "to-purple-900/10 border-purple-900/20":
                                          index === 2,
                                       "to-green-900/10 border-green-900/20":
                                          index === 3,
                                    }
                                 )
                              )}
                              initial={{ opacity: 0, y: 20 }}
                              whileInView={{ opacity: 1, y: 0 }}
                              viewport={{ once: true }}
                              transition={{ duration: 0.3, delay: index * 0.1 }}
                              whileHover={{
                                 scale: 1.01,
                                 y: -10,
                              }}
                           >
                              <div
                                 className={`w-12 h-12 rounded-lg bg-${item.color}-900/30 flex items-center justify-center flex-shrink-0`}
                              >
                                 <span
                                    className={`iconify text-${item.color}-400 text-2xl`}
                                    data-icon={item.icon}
                                 ></span>
                                 <Icon
                                    icon={item.icon}
                                    className={`group-hover:text-black text-${item.color}-400 text-2xl`}
                                 />
                              </div>
                              <div>
                                 <SectionSubtitle className="text-lg font-semibold  text-start mb-1">
                                    {item.title}
                                 </SectionSubtitle>
                                 <Text className="text-start" textSize="sm">
                                    {item.description}
                                 </Text>
                              </div>
                           </motion.div>
                        ))}
                     </div>
                  </motion.div>

                  <motion.div
                     className=" bg-gray-900/10 border border-[#262626] rounded-xl p-6 md:p-8"
                     initial={{ opacity: 0, y: 20 }}
                     whileInView={{ opacity: 1, y: 0 }}
                     viewport={{ once: true }}
                     transition={{ duration: 0.5, delay: 0.2 }}
                  >
                     <SectionSubtitle className="!text-2xl text-start font-semibold mb-6">
                        {contentMarketing.sectionTitleThree}
                     </SectionSubtitle>
                     <div className="space-y-4">
                        {contentMarketing.benefits.map((benefit:any, index:number) => (
                           <motion.div
                              key={index}
                              className="flex items-center gap-3"
                              initial={{ opacity: 0, x: 20 }}
                              whileInView={{ opacity: 1, x: 0 }}
                              viewport={{ once: true }}
                              transition={{ duration: 0.3, delay: index * 0.1 }}
                           >
                              <div
                                 className={twMerge(
                                    clsx(
                                       "w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0",
                                       {
                                          "bg-blue-900/30": index === 0,
                                          "bg-green-900/30": index === 1,
                                          "bg-purple-900/30": index === 2,
                                          "bg-pink-900/30": index === 3,
                                          "bg-amber-900/30": index === 4,
                                          "bg-indigo-900/30": index === 5,
                                       }
                                    )
                                 )}
                              >
                                 <Icon
                                    icon={benefit.icon}
                                    className={twMerge(
                                       clsx("group-hover:text-black  text-lg", {
                                          "text-blue-400": index === 0,
                                          "text-green-400": index === 1,
                                          "text-purple-400": index === 2,
                                          "text-pink-400": index === 3,
                                          "text-amber-400": index === 4,
                                          "text-indigo-400": index === 5,
                                       })
                                    )}
                                 />
                              </div>
                              <p className="text-gray-300">{benefit.title}</p>
                           </motion.div>
                        ))}
                     </div>

                     {/* <motion.div
                        className="mt-8"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.5, delay: 0.6 }}
                     >
                        <Link href="#">
                           <motion.button
                              className="relative bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-full transition-all duration-300 overflow-hidden w-full"
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              initial={{ opacity: 0, y: 20 }}
                              whileInView={{ opacity: 1, y: 0 }}
                              viewport={{ once: true }}
                              transition={{ duration: 0.5, delay: 0.4 }}
                           >
                              
                              <motion.div
                                 className="absolute inset-0 bg-gradient-to-r from-blue-400/0 via-blue-400/70 to-blue-400/0"
                                 animate={{
                                    x: ["-100%", "100%"],
                                 }}
                                 transition={{
                                    duration: 2,
                                    repeat: Number.POSITIVE_INFINITY,
                                    ease: "linear",
                                 }}
                              />
                              <span className="relative z-10">Learn More</span>
                           </motion.button>
                        </Link>
                     </motion.div> */}
                  </motion.div>
               </div>
            </div>
         </div>
      </div>
   );
};

export default ContentMarketing;
