"use client";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import clsx from "clsx";
import { motion } from "framer-motion";
import { twMerge } from "tailwind-merge";
type Props = {
  strategies: { title: string; description: string; color: string }[];
  className: string;
  data: any;
};

const MarketingStrategies = ({ strategies, data, className }: Props) => {
  return (
    <div className={twMerge(clsx("py-10 bg-[#000]", className))}>
      <div className="container mx-auto ">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-16 space-y-3"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <SectionTitle className="max-w-3xl m-auto">
            {data.title}{" "}
          </SectionTitle>
          <SectionSubtitle className=" m-auto">
            {data.description}{" "}
          </SectionSubtitle>
        </motion.div>

        <div className="grid grid-cols-1 max-w-5xl md:grid-cols-2 gap-8 mx-auto">
          {strategies.map((strategy, index) => (
            <motion.div
              key={index}
              className={twMerge(
                clsx(
                  "bg-gradient-to-br from-black border border-[#262626] rounded-xl p-8 relative overflow-hidden group",
                  {
                    " to-blue-900/20 hover:border-blue-500/40": index === 0,
                    " to-purple-900/20 hover:border-purple-500/40": index === 1,
                    "to-pink-900/20 hover:border-pink-500/40": index === 2,
                    "to-green-900/20 hover:border-green-500/40": index === 3,
                  }
                )
              )}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{
                y: -10,
                boxShadow: `0 10px 30px -15px rgba(var(--${strategy.color}-rgb), 0.5)`,
              }}
            >
              {/* Background number */}
              <div
                className={twMerge(
                  clsx(
                    "absolute -top-8 -right-5 text-9xl font-bold text-[#262626] ",
                    {
                      "group-hover:text-blue-500/20 ": index === 0,
                      "group-hover:text-purple-500/20": index === 1,
                      "group-hover:text-pink-500/20": index === 2,
                      "group-hover:text-green-500/20": index === 3,
                    }
                  )
                )}
              >
                {index + 1}
              </div>
              <SectionSubtitle
                className="mb-3 text-start font-semibold   relative z-10"
                textSize="xl"
              >
                {strategy.title}
              </SectionSubtitle>
              <Text className="text-start mb-5" textSize="md">
                {strategy.description}
              </Text>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MarketingStrategies;
