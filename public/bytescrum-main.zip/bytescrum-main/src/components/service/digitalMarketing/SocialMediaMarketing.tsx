"use client";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import { Icon } from "@iconify/react/dist/iconify.js";
import clsx from "clsx";
import { motion } from "framer-motion";
import Link from "next/link";
import { twMerge } from "tailwind-merge";
type Props = {
   socialMediaMarketing: {
      platformDescription: { title: string; description: string }[];
      platforms: { title: string; icon: string }[];
   };
   className: string;
   data:any;
};

const SocialMediaMarketing = ({ className,data, socialMediaMarketing }: Props) => {
   return (
      <div className={twMerge(clsx("py-10 bg-[#000]", className))}>
         <div className=" mx-auto px-4">
            <div className="mb-10">
               <SectionTitle className="max-w-3xl  !mb-3 m-auto">
{data.title}               </SectionTitle>
               <SectionSubtitle className=" m-auto ">
           {data.description}   </SectionSubtitle>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-y-20 gap-x-10 xl:gap-x-28 items-center">
               <motion.div
                  initial={{ opacity: 0, x: -50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
               >
                  <div className="space-y-6">
                     {socialMediaMarketing.platformDescription.map(
                        (item, index) => (
                           <motion.div
                              key={index}
                              className="flex gap-4"
                              initial={{ opacity: 0, y: 20 }}
                              whileInView={{ opacity: 1, y: 0 }}
                              viewport={{ once: true }}
                              transition={{ duration: 0.3, delay: index * 0.1 }}
                           >
                              <div
                                 className="w-10 h-10 rounded-full bg-purple-900/30 flex items-center justify-center border flex-shrink-0 border-[#262626]"
                                 style={{
                                    background: `radial-gradient(circle , #565656, #000 )`,
                                 }}
                              >
                                 <span className="text-white font-bold">
                                    {index + 1}
                                 </span>
                              </div>
                              <div>
                                 <SectionSubtitle className="text-start !text-xl font-semibold ">
                                    {item.title}
                                 </SectionSubtitle>
                                 <Text className="text-start !leading-6">
                                    {item.description}
                                 </Text>
                              </div>
                           </motion.div>
                        )
                     )}
                  </div>

                  {/* <motion.div
                     className="mt-8"
                     initial={{ opacity: 0, y: 20 }}
                     whileInView={{ opacity: 1, y: 0 }}
                     viewport={{ once: true }}
                     transition={{ duration: 0.5, delay: 0.4 }}
                  >
                     <Link href="#">
                        <button className="relative bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-8 rounded-full transition-all duration-300 overflow-hidden w-fit">
                      
                           <motion.div
                              className="absolute inset-0 bg-gradient-to-r from-blue-400/0 via-blue-400/70 to-blue-400/0"
                              animate={{
                                 x: ["-100%", "100%"],
                              }}
                              transition={{
                                 duration: 2,
                                 repeat: Number.POSITIVE_INFINITY,
                                 ease: "linear",
                              }}
                           />
                           <span className="relative z-10">
                              Learn More About Social Media Marketing
                           </span>
                        </button>
                     </Link>
                  </motion.div> */}
               </motion.div>

               <motion.div
                  className="relative xl:px-16"
                  initial={{ opacity: 0, x: 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
               >
                  <div className="grid grid-cols-3 gap-4 ">
                     {socialMediaMarketing.platforms.map((platform, index) => (
                        <motion.div
                           key={index}
                           className="bg-gray-900/50 border border-gray-800 rounded-lg p-4 flex items-center justify-center"
                           initial={{ opacity: 0, scale: 0.8 }}
                           whileInView={{ opacity: 1, scale: 1 }}
                           viewport={{ once: true }}
                           transition={{ duration: 0.3, delay: index * 0.05 }}
                           whileHover={{
                              scale: 1.05,
                              boxShadow:
                                 "0 10px 30px -15px rgba(139, 92, 246, 0.5)",
                           }}
                        >
                           <div className="text-center">
                              <div className="w-12 h-12 mx-auto mb-2 flex items-center justify-center">
                                 <Icon
                                    icon={platform.icon}
                                    width="48"
                                    height="48"
                                 />
                                 {/* <span
                                    className="iconify text-3xl"
                                    data-icon={`logos:${platform.toLowerCase()}`}
                                 ></span> */}
                              </div>
                              <p className="text-gray-300 text-sm">
                                 {platform.title}
                              </p>
                           </div>
                        </motion.div>
                     ))}
                  </div>

                  {/* Floating social media metrics */}
                  <motion.div
                     className="absolute -top-10 -right-10 bg-gradient-to-br from-purple-900/30 to-pink-900/30 backdrop-blur-sm border border-purple-500/30 rounded-lg p-4 w-40"
                     initial={{ opacity: 0, y: 20 }}
                     whileInView={{ opacity: 1 }}
                     //  viewport={{ once: true }}
                     //  transition={{ duration: 0.5, delay: 0.3 }}
                     animate={{
                        y: [0, -10, 0],
                     }}
                     transition={{
                        y: {
                           duration: 3,
                           repeat: Number.POSITIVE_INFINITY,
                           repeatType: "reverse",
                        },
                     }}
                  >
                     <div className="text-center">
                        <p className="text-purple-400 inter font-bold text-2xl">
                           +245%
                        </p>
                        <p className="text-gray-300 inter text-sm">
{data.engagementRate}                        </p>
                     </div>
                  </motion.div>

                  <motion.div
                     className="absolute -bottom-10 -left-12 bg-gradient-to-br from-blue-900/30 to-purple-900/30 backdrop-blur-sm border border-blue-500/30 rounded-lg p-4 w-40"
                     initial={{ opacity: 0, y: 20 }}
                     whileInView={{ opacity: 1 }}
                     viewport={{ once: true }}
                     //  transition={{ duration: 0.5, delay: 0.4 }}
                     animate={{
                        y: [0, 10, 0],
                     }}
                     transition={{
                        y: {
                           duration: 3,
                           repeat: Number.POSITIVE_INFINITY,
                           repeatType: "reverse",
                        },
                     }}
                  >
                     <div className="text-center">
                        <p className="text-blue-400 inter font-bold text-2xl">
                           +187%
                        </p>
                        <p className="text-gray-300 inter text-sm">
{data.followerGrowth}                        </p>
                     </div>
                  </motion.div>
               </motion.div>
            </div>
         </div>
      </div>
   );
};

export default SocialMediaMarketing;
