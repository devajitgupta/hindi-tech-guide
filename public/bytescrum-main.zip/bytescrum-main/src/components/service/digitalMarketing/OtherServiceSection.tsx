"use client";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import { Icon } from "@iconify/react/dist/iconify.js";
import clsx from "clsx";
import { motion } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { twMerge } from "tailwind-merge";
type Props = {
  data: any;

  otherServices: {
    title: string;
    description: string;
    link: string;
    color: string;
  }[];

  className: string;
};

const OtherServiceSection = ({ otherServices, data, className }: Props) => {
  return (
    <div className={twMerge(clsx("py-10 bg-[#000]", className))}>
      <div className=" mx-auto px-10">
        <motion.div
          className="text-center max-w-3xl mx-auto mb-16 space-y-3"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <SectionTitle className="max-w-3xl m-auto">{data.title}</SectionTitle>
          <SectionSubtitle className=" m-auto">
            {data.description}
          </SectionSubtitle>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {otherServices.map((service, index) => (
            <motion.div
              key={index}
              className={`bg-gradient-to-br from-black to-${service.color}-900/20 border border-gray-800 rounded-xl p-6 hover:border-${service.color}-500/50 transition-all duration-300`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              whileHover={{
                y: -5,
                boxShadow: `0 10px 30px -15px rgba(var(--${service.color}-rgb), 0.5)`,
              }}
            >
              <h3 className="text-xl font-semibold mb-3">{service.title}</h3>
              <p className="text-gray-400 mb-5">{service.description}</p>
              <Link
                href={service.link}
                className={`inline-flex items-center text-${service.color}-400 hover:text-${service.color}-300 transition-colors`}
              >
                {data.learnMore}{" "}
                <Icon
                  icon="solar:arrow-right-outline"
                  className="ml-2 text-sm"
                />
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default OtherServiceSection;
