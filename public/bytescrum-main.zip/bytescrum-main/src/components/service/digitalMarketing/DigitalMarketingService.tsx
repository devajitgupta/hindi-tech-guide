"use client";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import { Icon } from "@iconify/react/dist/iconify.js";
import clsx from "clsx";
import { motion } from "framer-motion";
import Link from "next/link";
import { twMerge } from "tailwind-merge";
type Props = {
   containerVariants: {};
   itemVariants: {};
   langText?: any;
   className: string;
};

const DigitalMarketingService = ({
   containerVariants,
   itemVariants,
   langText,
   className,
}: Props) => {
   const services = langText.services
   return (
      <div className={twMerge(clsx("py-10 bg-[#000]", className))}>
         <div className=" mx-auto px-4">
            <motion.div
               className="text-center max-w-3xl mx-auto mb-16 space-y-3"
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               transition={{ duration: 0.5 }}
            >
               <SectionTitle className="max-w-3xl m-auto">
                  {langText.Title}
               </SectionTitle>
               <SectionSubtitle className=" m-auto">
                  {langText.description}
               </SectionSubtitle>
            </motion.div> 

            <motion.div
               className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
               variants={containerVariants}
               initial="hidden"
               whileInView="visible"
               viewport={{ once: true }}
            >
               {services.map((service: any, index: number) => (
                  <motion.div
                     key={index}
                     className="bg-gradient-to-br from-[#565656]/10 to-black border border-[#262626] rounded-xl p-6 hover:border-[#fff]/50 transition-all duration-300 group"
                     variants={itemVariants}
                     whileHover={{
                        scale: 1.01,
                        y: -5,
                        boxShadow: "0 7px 20px -15px rgba(255, 255, 255, )",
                     }}
                  >
                     <div className="w-14 h-14 border-[#262626] border bg-[#000] rounded-full flex items-center justify-center mb-2 group-hover:bg-white transition-all duration-300">
                        <Icon
                           icon={service.icon}
                           width="32"
                           height="32"
                           className="group-hover:text-black"
                        />
                     </div>
                     <SectionSubtitle
                        className=" text-start font-semibold mb-2"
                        textSize="xl"
                     >
                        {service.title}
                     </SectionSubtitle>
                     <Text className="text-start mb-3">
                        {service.description}
                     </Text>
                     {/* <Link
                        href={service.link}
                        className="inline-flex items-center text-blue-400 hover:text-blue-300 transition-colors"
                     >
                        Learn More
                     </Link> */}
                  </motion.div>
               ))}
            </motion.div>
         </div>
      </div>
   );
};

export default DigitalMarketingService;
