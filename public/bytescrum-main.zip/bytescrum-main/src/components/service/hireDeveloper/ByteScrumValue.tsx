"use client";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import { Accordion, AccordionItem } from "@nextui-org/react";
import "../../aboutUs/aboutUs.css";

interface IProps {
   className: string;
   data: any;
}

const ByteScrumValueSection = ({ className, data }: IProps) => {
   return (
      <div className={twMerge(clsx(className))}>
         <div className="space-y-[40px]">
            <div>
               <h2
                  className="grid text-white text-center poppins text-[24px] md:text-[45px] leading-[30px] md:leading-[60px] m-auto"
                  data-aos="fade-up"
                  data-aos-easing="ease-out-cubic"
                  data-aos-anchor-placement="top-bottom"
               >
                  {data.titleOne}
                  <span className="text-[#909090]"> {data.titleTwo}</span>
               </h2>
            </div>

            <div className="m-auto w-11/12 md:w-9/12 lg:w-7/12 ">
               <Accordion
                  variant="splitted"
                  fullWidth={true}
                  defaultExpandedKeys={[1]}
                  itemClasses={{
                     base: "border border-[#262626] !bg-[#0a0a0a] px-5 rounded-lg ",
                  }}
               >
                  {data.accordions.map((accordion: any, index: number) => (
                     <AccordionItem
                        key={accordion._id}
                        aria-label={accordion.title}
                        title={accordion.title}
                        indicator={({ isOpen }) => (
                           <label className="container group rotate-90">
                              <input
                                 type="checkbox"
                                 checked={isOpen}
                                 readOnly
                              />
                              <div className="line"></div>
                              <div className="line line-indicator"></div>
                           </label>
                        )}
                        classNames={{
                           content: " px-3  flex justify-between  ",
                           heading: " relative  flex justify-between  ",
                           title: "poppins text-[18px] font-bold text-[#ffffff] ",
                           indicator: "text-[#ffffff] absolute  right-0",
                        }}
                        data-aos="fade-up"
                        data-aos-easing="ease-out-cubic"
                        data-aos-delay={index + 1 * 300}
                        data-aos-anchor-placement="top-bottom"
                     >
                        {accordion.text}
                     </AccordionItem>
                  ))}
               </Accordion>
            </div>
         </div>
      </div>
   );
};

export default ByteScrumValueSection;
