"use client";
import ExperienceCard from "./ExperienceCard";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import useRandomNumber from "@/common/hooks/useRandomNumber";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import dynamic from "next/dynamic";

const ExperienceCardSwipper = dynamic(() => import("./ExperienceCardSwipper"), {
   ssr: false,
});

interface IProps {
   className?: string;
   data?: any;
}

const ExperienceSection = ({ className, data }: IProps) => {
   const randomNumber = useRandomNumber(3, 7000);
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth <= 767;
   return (
      <div className={twMerge(clsx(className))}>
         <div className="space-y-[40px] px-5 md:px-[40px]">
            <div>
               <span
                  className="text-[12px] md:text-[16px] text-center m-auto block"
                  data-aos="fade-down"
                  data-aos-easing="ease-out-cubic"
                  data-aos-anchor-placement="top-bottom"
               >
                  {data.subTitle}
               </span>
               <h2
                  className="text-white text-center poppins text-[24px] md:text-[45px] leading-[30px] md:leading-[60px] w-[354px] md:w-[642px] m-auto "
                  data-aos="fade-up"
                  data-aos-easing="ease-out-cubic"
                  data-aos-anchor-placement="top-bottom"
               >
                  {data.titleOne}
                  <span className="text-[#909090]"> {data.titleTwo}</span>
               </h2>
            </div>

            <div className=" hidden md:grid grid-cols-2 xl:grid-cols-3 m-auto w-fit  gap-5">
               {data.experienceCard.map((item: any, index: number) => (
                  <ExperienceCard
                     key={item._id}
                     _id={item._id}
                     icon={item.icon}
                     title={item.title}
                     text={item.text}
                     width={matches ? 45 : item.width}
                     height={matches ? 45 : item.height}
                     className={clsx("m-auto ", {
                        randomBlob: index === randomNumber,
                     })}
                  />
               ))}
            </div>
         </div>

         {/* NOTE: For Mobile Only  */}
         <ExperienceCardSwipper
            className={twMerge(clsx("md:hidden mt-[40px]"))}
            data={data.experienceCard}
         />
      </div>
   );
};

export default ExperienceSection;
