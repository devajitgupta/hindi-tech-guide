import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper/modules";
import { EffectCoverflow } from "swiper/modules";
import { useState } from "react";
import Image from "next/image";
// import "swiper/css";
// import "swiper/css/pagination";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import useBreakpoints from "@/common/hooks/useBreakpoints ";

interface IProps {
   className?: string;
   data?: any;
}

const ExperienceCardSwipper = ({ className, data }: IProps) => {
   const [currentSlide, setCurrentSlide] = useState(0);
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth <= 767;
   return (
      <div
         className={twMerge(
            clsx(
               " transition-transform duration-200 ease-in-out transform ",
               className
            )
         )}
      >
         {" "}
         <Swiper
            spaceBetween={-100}
            autoplay={{
               delay: 3000,
               disableOnInteraction: true,
            }}
            // autoHeight={true}
            pagination={true}
            modules={[Pagination, EffectCoverflow, Autoplay]}
            effect={"coverflow"}
            grabCursor={false}
            centeredSlides={true}
            slidesPerView={"auto"}
            followFinger={true}
            initialSlide={3}
            simulateTouch={true}
            speed={1700}
            roundLengths={true}
            coverflowEffect={{
               rotate: 10,
               stretch: 50,
               depth: 100,
               modifier: 3,
               slideShadows: true,
            }}
            loop={true}
            onSlideChange={(swiper) => setCurrentSlide(swiper.realIndex)}
            className=" workswiper h-[390px] overflow-visible"
         >
            {data.map((item: any, index: number) => (
               <SwiperSlide
                  key={index}
                  className={twMerge(
                     clsx(
                        "border border-[#262626] bg-[#262626]/30 rounded-[16px] px-7 py-10 h-[353px] space-y-[5px] max-w-[300px]  max-h-[353px] ",
                        {
                           " backdrop-blur-md z-[9999] opacity-100":
                              currentSlide === index,
                        },
                        {
                           " backdrop-blur-md z-[-10] ": index - 1,
                        }
                     )
                  )}
               >
                  <div className="space-y-[30px]">
                     <Image
                        src={item.icon}
                        width={matches ? 45 : item.width}
                        height={0}
                        alt={item.icon}
                     />
                     <h3 className="text-[20px] h-auto w-auto font-bold poppins">
                        {" "}
                        {item.title}
                     </h3>
                  </div>
                  <p className="max-w-[300px] text-[14px] leading-[24px] text-[#f5f5f5]">
                     {item.text}
                  </p>
                  {/* </div> */}
               </SwiperSlide>
            ))}
         </Swiper>
      </div>
   );
};

export default ExperienceCardSwipper;
