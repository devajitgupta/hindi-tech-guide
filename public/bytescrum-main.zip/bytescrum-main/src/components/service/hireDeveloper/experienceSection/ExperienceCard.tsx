import Image from "next/image";
import "./experienceCard.css";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";

interface IProps {
   icon: string;
   width: number;
   height: number;
   title: string;
   text: string;
   className: string;
   _id: number;
   cardWrapper?: string;
   cardContentWrapper?: string;
}
const ExperienceCard = ({
   icon,
   width = 50,
   height = 50,
   title,
   text,
   className,
   _id,
   cardWrapper,
   cardContentWrapper,
}: IProps) => {
   return (
      <div
         className={twMerge(
            clsx(
               "experienceCard w-[300px] h-[411px]  lg:w-[390px] lg:h-[391px]",
               { cardWrapper }
            )
         )}
         data-aos="flip-left"
         data-aos-easing="ease-out-cubic"
         // data-aos-delay={(_id ?? 0) * 150}
         data-aos-anchor-placement="top-bottom"
      >
         <div
            className={twMerge(
               clsx(
                  "bg p-[20px] lg:p-[40px] space-y-[30px] w-[294px] h-[405px]  lg:w-[384px] lg:h-[385px] ",
                  { cardContentWrapper }
               )
            )}
         >
            <Image src={icon} width={width} height={height} alt="img" />
            <div className="space-y-[5px] ">
               <h3 className="poppins text-[18px] md:text-[24px] font-bold ">
                  {title}
               </h3>
               <p className="text-[16px] leading-[28px] text-[#f5f5f5] w-full lg:w-[300px]">
                  {text}
               </p>
            </div>
         </div>

         <div className={clsx("blob", className)}></div>
      </div>
   );
};

export default ExperienceCard;
