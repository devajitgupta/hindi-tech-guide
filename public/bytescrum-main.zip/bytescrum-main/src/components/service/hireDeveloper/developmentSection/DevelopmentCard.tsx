import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import "./developmentCard.css";
import Image from "next/image";
import { Button } from "@nextui-org/react";
import { useRouter } from "next/navigation";

interface IProps {
   icon: string;
   width: number;
   height: number;
   title: string;
   text: string;
   path: string;
   className?: string;
}

const DevelopmentCard = ({
   icon,
   width,
   height,
   title,
   text,
   path,
   className,
}: IProps) => {
   const router = useRouter();
   return (
      <div
         className={twMerge(
            clsx(
               "developmentCard border border-red-500 w-[335px] lg:w-[363px] h-[450px overflow-hidden",
               className
            )
         )}
      >
         <div className="developmentCardDetails   px-[28px] py-[38px]">
            <Image src={icon} width={width} height={height} alt="img" />
            <div className=" space-y-[5px] h-[260px]  mt-[30px] ">
               <h3 className="poppins  text-[18px] md:text-[20px] font-bold ">
                  {title}
               </h3>
               <p className="text-[14px] lg:text-[16px] leading-[28px] text-[#f5f5f5] lg:w-[285px]">
                  {text}
               </p>
            </div>
            <Button
               className=" font-medium w-full uppercase mt-5 tracking-wider"
               onPress={() => router.push(path)}
            >
               Hire Now
            </Button>
         </div>
      </div>
   );
};

export default DevelopmentCard;
