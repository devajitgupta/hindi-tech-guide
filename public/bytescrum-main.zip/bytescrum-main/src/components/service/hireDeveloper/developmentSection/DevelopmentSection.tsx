"use client";
import useRandomNumber from "@/common/hooks/useRandomNumber";
import DevelopmentCard from "./DevelopmentCard";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";

interface IProps {
   className: string;
   data: any;
}
const DevelopmentSection = ({ className, data }: IProps) => {
   const randomNumber = useRandomNumber(6);
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth <= 767;
   const isMediumScreen = screenWidth >= 1279;
   return (
      <div className={twMerge(clsx(className))}>
         <div className="space-y-[40px]">
            <div className="overflow-hidden mb-10">
               <h2
                  className="text-white grid text-center poppins text-[24px] md:text-[45px] leading-[30px] md:leading-[60px] w-[354px] md:w-[630px] m-auto "
                  data-aos="fade-up"
                  data-aos-easing="ease-out-cubic"
                  data-aos-anchor-placement="top-bottom"
               >
                  <span className="text-[#909090]"> {data.titleOne}</span>
                  {data.titleTwo}
               </h2>
            </div>
            <div className="grid md:grid-cols-2 xl:grid-cols-3 m-auto w-fit  gap-x-5 md:gap-y-10 gap-y-5 ">
               {data.developmentCard.map((item: any, index: number) => (
                  <DevelopmentCard
                     key={index}
                     icon={item.icon}
                     title={item.title}
                     text={item.text}
                     width={matches ? 45 : item.width}
                     path={item.path}
                     height={0}
                     className={twMerge(
                        clsx(
                           "h-auto",
                           isMediumScreen
                              ? clsx({
                                   "lg:-mb-10": index === 1 || index === 4,

                                   "lg:mt-10":
                                      index !== 0 &&
                                      index !== 2 &&
                                      index !== 3 &&
                                      index !== 5,
                                })
                              : clsx({
                                   "md:-mb-10 ":
                                      index === 1 || index === 3 || index == 5,

                                   "md:mt-10":
                                      index !== 0 && index !== 2 && index !== 4,
                                })
                        )
                     )}
                  />
               ))}
            </div>
         </div>
      </div>
   );
};

export default DevelopmentSection;
