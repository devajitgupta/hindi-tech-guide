"use client";
import { twMerge } from "tailwind-merge";
import SkillSectionCard from "./SkillSectionCard";
import clsx from "clsx";
import useRandomNumber from "@/common/hooks/useRandomNumber";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
interface IProps {
   className: string;
   data: any;
}

const SkillSection = ({ className, data }: IProps) => {
   const randomNumber = useRandomNumber(12);
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth <= 767;
   return (
      <div className={twMerge(clsx(className))}>
         <div className="space-y-[40px]">
            <div className="overflow-hidden">
               <h2
                  className="text-white text-center poppins text-[24px] md:text-[45px] leading-[30px] md:leading-[60px] w-[354px] md:w-[630px] m-auto "
                  data-aos="fade-up"
                  data-aos-easing="ease-out-cubic"
                  data-aos-delay={300}
                  data-aos-anchor-placement="top-bottom"
               >
                  {data.titleOne}
                  <span className="text-[#909090]"> {data.titleTwo}</span>
               </h2>
            </div>
            {/* <div className="max-w-[900px] m-auto border"> */}
            <div className=" grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-[10px] md:gap-5 items-center justify-center   m-auto w-fit ">
               {data.skillCard.map((item: any, index: number) => (
                  <SkillSectionCard
                     key={item._id}
                     icon={item.icon}
                     title={item.title}
                     width={matches ? 45 : item.width}
                     height={matches ? 45 : item.height}
                     // className={clsx("m-auto ", {
                     //    randomFlip: index === randomNumber,
                     // })}
                  />
               ))}
               {/* </div> */}
            </div>
         </div>
      </div>
   );
};

export default SkillSection;
