import Image from "next/image";
import "../hireDeveloper.css";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
interface IProps {
   icon: string;
   title: string;
   className?: string;
   width: number;
   height: number;
}

const SkillSectionCard = ({
   icon,
   title,
   width = 100,
   height = 100,
   className,
}: IProps) => {
   return (
      <div
         className={twMerge(
            clsx(" md:max-w-[210px]  md:max-h-[160px] h-full w-full", className)
         )}
      >
         <div className=" grid place-items-center p-6 rounded-[8px] bg-gradient-to-r h-full from-[#0D0D0D]/35 to-[#2A2A2A]/35 border-[#262626] border">
            <Image
               src={icon}
               width={width}
               height={0}
               alt="svg"
               className=" h-auto"
            />
            <p className="inter text-[#ffffff] mt-[0.625rem] text-sm md:text-[16px] text-center">
               {title}
            </p>
         </div>
      </div>
   );
};

export default SkillSectionCard;
