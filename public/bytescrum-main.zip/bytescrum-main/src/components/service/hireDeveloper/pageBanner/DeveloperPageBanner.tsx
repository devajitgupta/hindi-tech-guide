"use client";
import PageBanner from "../../../PageBanner";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import { usePathname } from "next/navigation";
import Image from "next/image";
import homeData from "../../../../common/data/homeData.json";
import { StatsCountUp } from "../../../home";
import ScrollButton from "../../../home/ScrollButton";
import HireBannerELements from "./HireBannerELements";

interface IProps {
   className?: string;
   data: any;
   countUpData:any
}

const DeveloperPageBanner = ({ className, data, countUpData }: IProps) => {
   const pathName = usePathname();
   console.log(countUpData.heroSection.scrollDownBtn.img)
   const { screenWidth } = useBreakpoints();
   const matches = screenWidth <= 430;
   return (
      <PageBanner
         bgPath={"/hireDev/banner.png"}
         bannerHeight={"h-[32vh ] md:h-[55vh]"}
         className={twMerge(
            clsx(
               "relative overflow-hidden px-[22px] md:px-[54px]  items-center justify-normal "
            )
         )}
      >
         <div className="grid lg:grid-cols-2 gap-y-5  ">
            <div className="grid items-center md:gap-10">
               <div>
                  <p
                     className="poppins text-[#b7b7b7] text-[14px] md:text-[18px]"
                     data-aos="fade-up"
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     {data.links.map((link: any, index: number) => (
                        <span
                           className={clsx(
                              " text-white first:border-r  first:pe-3 last:ps-3 cursor-pointer",
                              {
                                 "first:text-[#b7b7b7]":
                                    pathName !== `/${pathName}`,
                              }
                           )}
                           key={index}
                        >
                           {link}
                        </span>
                     ))}
                  </p>
                  <h1
                     className="text-[35px] md:text-[70px] md:leading-[80px] font-light  poppins text-start"
                     data-aos="fade-up"
                     data-aos-delay={300}
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     {data.titleOne}
                     <br />
                     <span className="font-bold"> {data.titleTwo}</span>
                  </h1>
                  <p
                     className="max-w-[609px] mt-8 text-[16px] leading-[28px]"
                     data-aos="fade-up"
                     data-aos-delay={500}
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     {data.text}
                  </p>
                  <StatsCountUp
                                 langText={countUpData}
                     // statsData={homeData.realvalueSection.statsData}
                     className="flex justify-between    md:gap-[0px] py-0 lg:pt-[60px] w-full gap-0 "
                     wrapper=" [&:nth-child(2)]:hidden  px-0 md:px-0 w-fit"
                     countUpClass=" text-start text-[28px] md:text-[45px] px-0 md:px-0 py-0 md:py-0 "
                     symbolClass="text-[20px] md:[42px]"
                     textClass="font-normal text-start text-[14px]  md:text-[20px]"
                  />
               </div>
            </div>
            <div className="grid place-items-center lg:justify-end  m-auto w-[345px] h-[348px]  sm:min-w-[467px] sm:min-h-[448px]  relative ">
               <div className="absolute top-2 left-24 md:top-5 md:left-32    ">
                  <HireBannerELements
                     width={matches ? 100 : 150}
                     height={matches ? 191 : 226}
                  />
               </div>
               <Image
                  src={
                     matches
                        ? "/hireDev/bannerTwo.png"
                        : "/hireDev/bannerTwo.png"
                  }
                  width={matches ? 351 : 467}
                  height={0}
                  className="h-auto w-auto"
                  alt="BannerImage"
                  data-aos="zoom-in-left"
                  data-aos-delay={300}
                  data-aos-easing="ease-out-cubic"
                  data-aos-anchor-placement="top-bottom"
               />

               <ScrollButton
                  img={countUpData.heroSection.scrollDownBtn.img}
                  link={countUpData.heroSection.scrollDownBtn.link}
                  icon={countUpData.heroSection.scrollDownBtn.icon}
                  className="absolute bottom-10 right-5 md:bottom-9 md:right-5"
                  iconClass="lg:w-[40px] lg:h-[40px] "
                  iconWrapper="lg:w-[65px] lg:h-[65px] top-[49%] left-[50%] md:top-[49%] lg:top-[49%] md:left-[50%] lg:left-[50%]  transform translate-x-[-50%] translate-y-[-50%]"
                  imgClass="lg:w-[110px]"
               />

               {/* 
               <div className="absolute  sm:hidden -bottom-8  right-[6px]">
                  <MobileBannerElement />
               </div> */}
            </div>
         </div>
      </PageBanner>
   );
};

export default DeveloperPageBanner;
