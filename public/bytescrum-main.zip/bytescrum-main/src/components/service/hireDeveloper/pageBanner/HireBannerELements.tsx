import { motion, useAnimation } from "framer-motion";
import { useEffect } from "react";
import clsx from "clsx";

interface IProps {
   width?: number;
   height?: number;
}

const icon = {
   hidden: {
      opacity: 1,
      pathLength: 0,
   },
   visible: {
      opacity: 1,
      pathLength: 1,
   },
};

const circle = {
   hidden: {
      opacity: 0,
      pathLength: 0,
   },
   visible: {
      opacity: 1,
      pathLength: 1,
      fill: "#393939",
   },
};
const useAnimatedLine = (delay: any, repeatDelay: any, duration: any) => {
   const controls = useAnimation();

   useEffect(() => {
      controls.start("visible", {
         // repeat: Infinity,
         repeatType: "loop",
         repeatDelay: repeatDelay,
         duration: duration,
         delay: delay,
         ease: "easeInOut",
      });
   }, [controls, delay, repeatDelay, duration]);

   return controls;
};

const HireBannerELements = ({ width = 224, height = 280 }: IProps) => {
   const color = "#545454";
   const controls1 = useAnimatedLine(0, 0, 2.5);
   const controls2 = useAnimatedLine(0, 0, 5);

   return (
      <motion.svg
         width={width}
         height={height}
         viewBox="0 0 224 280"
         fill="none"
         xmlns="http://www.w3.org/2000/svg"
      >
         <motion.path
            d="M112 56.5H223.5V168C223.5 229.58 173.58 279.5 112 279.5C50.4203 279.5 0.5 229.58 0.5 168C0.5 106.42 50.4203 56.5 112 56.5Z"
            stroke={color}
            variants={icon}
            initial="hidden"
            animate={controls1}
         />
         <motion.rect
            x="178"
            width="46"
            height="46"
            rx="23"
            fill="#393939"
            variants={circle}
            initial="hidden"
            animate={controls2}
         />
      </motion.svg>
   );
};

export default HireBannerELements;
