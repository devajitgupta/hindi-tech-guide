import clsx from "clsx";
import React from "react";
import { twMerge } from "tailwind-merge";

interface IProps {
   className?: string;
   children: React.ReactNode;
   animationVariant?:
      | "default"
      | "fadeRight"
      | "fadeLeft"
      | "fadeUp"
      | "fadeDown"
      | "zoomInUp";
   animationDelay?: string;
   animationDuration?: string;
   useAs?: "h2" | "h3" | "h4" | "h5" | "h6";
}

const SectionTitle = ({
   className,
   children,
   animationVariant = "default",
   animationDelay = "0",
   animationDuration = "500",
   useAs = "h2",
}: IProps) => {
   const aosVariants = {
      fadeRight: "fade-right",
      fadeLeft: "fade-left",
      fadeUp: "fade-up",
      fadeDown: "fade-down",
      zoomInUp: "zoom-in-up",
   };

   const appliedAos =
      animationVariant !== "default" ? aosVariants[animationVariant] : null;

   const Tag = useAs;

   return (
      <Tag
         className={twMerge(
            clsx(
               "text-center text-[24px] md:text-[45px] leading-[30px] md:leading-[60px] text-[#ffffff] poppins",
               className
            )
         )}
         data-aos={appliedAos || undefined}
         data-aos-duration={animationDuration}
         data-aos-anchor-placement="top-bottom"
         data-aos-delay={animationDelay}
      >
         {children}
      </Tag>
   );
};

export default SectionTitle;
