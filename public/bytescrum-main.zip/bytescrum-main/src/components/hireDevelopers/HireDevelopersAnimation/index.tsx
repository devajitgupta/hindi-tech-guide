import FullStackBanner from "./FullStackBanner";
import DesignerAnimation from "./DesignerAnimation";
import LaravelAnimation from "./LaravelAnimation";
import PHPAnimation from "./PHPAnimation";
import ShopifyAnimation from "./ShopifyAnimation";

type Props = {
   animationType: any;
};

const HireDevelopersAnimation = ({ animationType }: Props) => {
   console.log("Animation Type:", animationType);
   switch (animationType) {
      case "full-stack":
         return <FullStackBanner />;
      case "ui-ux-designer":
         return <DesignerAnimation />;
      case "laravel-developer":
         return <LaravelAnimation />;
      case "php-developer":
         return <PHPAnimation />;
      case "shopify-developer":
         return <ShopifyAnimation />;
      default:
         return <FullStackBanner />;
   }
};

export default HireDevelopersAnimation;
