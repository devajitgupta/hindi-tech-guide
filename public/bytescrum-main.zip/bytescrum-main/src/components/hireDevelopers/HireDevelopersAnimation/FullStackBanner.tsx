"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Icon } from "@iconify/react/dist/iconify.js";

const FullStackBanner = () => {
   const containerRef = useRef<HTMLDivElement>(null);
   const [windowSize, setWindowSize] = useState({ width: 0, height: 0 });

   useEffect(() => {
      if (typeof window !== "undefined") {
         setWindowSize({
            width: window.innerWidth,
            height: window.innerHeight,
         });

         const handleResize = () => {
            setWindowSize({
               width: window.innerWidth,
               height: window.innerHeight,
            });
         };

         window.addEventListener("resize", handleResize);
         return () => window.removeEventListener("resize", handleResize);
      }
   }, []);

   return (
      <div className="absolute inset-0  z-0 overflow-hidden bg-black">
         {/* Connected layers visualization */}
         <div className="absolute   inset-0">
            {/* Frontend layer */}
            <motion.div
               className="absolute top-0 left-0 right-0 h-1/3 bg-gradient-to-b from-blue-900/20 to-transparent"
               initial={{ opacity: 0 }}
               animate={{ opacity: [0.1, 0.9, 0.1] }}
               transition={{
                  duration: 8,
                  repeat: Number.POSITIVE_INFINITY,
                  repeatType: "reverse",
               }}
            />

            {/* Backend layer */}
            <motion.div
               className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-green-900/20 to-transparent"
               initial={{ opacity: 0 }}
               animate={{ opacity: [0.1, 0.9, 0.1] }}
               transition={{
                  duration: 8,
                  repeat: Number.POSITIVE_INFINITY,
                  repeatType: "reverse",
                  delay: 1,
               }}
            />

            {/* Database layer (middle) */}
            <motion.div
               className="absolute inset-0 flex items-center justify-center"
               initial={{ opacity: 0 }}
               animate={{ opacity: [0.1, 0.9, 0.1] }}
               transition={{
                  duration: 10,
                  repeat: Number.POSITIVE_INFINITY,
                  repeatType: "reverse",
                  delay: 2,
               }}
            >
               <div className="w-[600px] h-[600px] rounded-full border border-white/20 flex items-center justify-center">
                  <motion.div
                     className="w-[400px] h-[400px] rounded-full border border-white/30"
                     animate={{ rotate: 360 }}
                     transition={{
                        duration: 120,
                        repeat: Number.POSITIVE_INFINITY,
                        ease: "linear",
                     }}
                  >
                     <motion.div
                        className="w-full h-full rounded-full border border-white/20 flex items-center justify-center"
                        animate={{ rotate: -360 }}
                        transition={{
                           duration: 80,
                           repeat: Number.POSITIVE_INFINITY,
                           ease: "linear",
                        }}
                     >
                        <div
                           className="w-[200px] h-[200px] rounded-full  border border-white/40"
                           style={{
                              background: `radial-gradient(circle , #565656, #000 )`,
                           }}
                        />
                     </motion.div>
                  </motion.div>
               </div>
            </motion.div>

            {/* Connecting lines between layers */}
            {Array.from({ length: 15 }).map((_, index) => {
               const startX = Math.random() * 100;
               const startY = 33;
               const endX = Math.random() * 100;
               const endY = 66;

               return (
                  <motion.div
                     key={`line-top-${index}`}
                     className="absolute w-px bg-gradient-to-b from-blue-500/0 via-blue-500/30 to-blue-500/0"
                     style={{
                        left: `${startX}%`,
                        top: `${startY}%`,
                        height: `${endY - startY}%`,
                        transformOrigin: "top",
                     }}
                     initial={{ scaleY: 0, opacity: 0 }}
                     animate={{
                        scaleY: [0, 1, 0],
                        opacity: [0, 0.9, 0],
                     }}
                     transition={{
                        duration: Math.random() * 5 + 5,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "loop",
                        delay: Math.random() * 5,
                     }}
                  />
               );
            })}

            {Array.from({ length: 15 }).map((_, index) => {
               const startX = Math.random() * 100;
               const startY = 36;
               const endX = Math.random() * 100;
               const endY = 100;

               return (
                  <motion.div
                     key={`line-bottom-${index}`}
                     className="absolute w-px bg-gradient-to-b from-purple-500/0 via-purple-500/30 to-green-500/0"
                     style={{
                        left: `${startX}%`,
                        top: `${startY}%`,
                        height: `${endY - startY}%`,
                        transformOrigin: "top",
                     }}
                     initial={{ scaleY: 0, opacity: 0 }}
                     animate={{
                        scaleY: [0, 1, 0],
                        opacity: [0, 0.9, 0],
                     }}
                     transition={{
                        duration: Math.random() * 5 + 5,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "loop",
                        delay: Math.random() * 0.5,
                     }}
                  />
               );
            })}

            {/* Code snippets floating around */}
            {Array.from({ length: 8 }).map((_, index) => {
               const snippets = [
                  `function fetchData() {
  return fetch('/api/data')
    .then(res => res.json());
}`,
                  `const App = () => {
  return (
    <div className="app">
      <Header />
      <Main />
    </div>
  );
}`,
                  `class User {
  constructor(name, email) {
    this.name = name;
    this.email = email;
  }
}`,
                  `CREATE TABLE users (
  id INT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100)
);`,
                  `app.get('/api/users', async (req, res) => {
  const users = await User.find();
  res.json(users);
});`,
               ];

               const snippet = snippets[index % snippets.length];
               const size = Math.random() * 100 + 150;
               const layer = Math.floor(Math.random() * 3);
               const yPos =
                  layer === 0
                     ? Math.random() * 30 + 5
                     : layer === 1
                     ? Math.random() * 30 + 35
                     : Math.random() * 30 + 65;

               return (
                  <motion.div
                     key={`snippet-${index}`}
                     className="absolute rounded-md border border-[#565656] bg-indigo-500/20 backdrop-blur-sm p-3 text-xs font-mono overflow-hidden"
                     style={{
                        width: size,
                        height: size * 0.6,
                        color:
                           layer === 0
                              ? "#60a5fa"
                              : layer === 1
                              ? "#c084fc"
                              : "#4ade80",
                        opacity: 0.4,
                     }}
                     initial={{
                        x: Math.random() * windowSize.width,
                        y: `${yPos}%`,
                        rotate: Math.random() * 20 - 10,
                     }}
                     animate={{
                        x: [
                           Math.random() * windowSize.width,
                           Math.random() * windowSize.width,
                        ],
                        opacity: [0, 0.4, 0],
                        rotate: [
                           Math.random() * 20 - 10,
                           Math.random() * 20 - 10,
                        ],
                     }}
                     transition={{
                        duration: Math.random() * 30 + 20,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "loop",
                     }}
                  >
                     <pre>{snippet}</pre>
                  </motion.div>
               );
            })}

            {/* Tech icons floating */}
            {Array.from({ length: 15 }).map((_, index) => {
               const icons = [
                  "logos:react",
                  "logos:nodejs",
                  "logos:mongodb",
                  "logos:postgresql",
                  "logos:javascript",
                  "logos:typescript",
                  "logos:html-5",
                  "logos:css-3",
                  "logos:sass",
                  "logos:tailwindcss",
                  "logos:redux",
                  "logos:graphql",
                  "logos:docker",
                  "logos:git",
                  "logos:aws",
               ];

               const icon = icons[index % icons.length];
               const size = Math.random() * 30 + 30;
               const layer = Math.floor(Math.random() * 3);
               const yPos =
                  layer === 0
                     ? Math.random() * 30 + 100
                     : layer === 1
                     ? Math.random() * 30 + 300
                     : Math.random() * 30 + 500;

               return (
                  <motion.div
                     key={`icon-${index}`}
                     className="absolute  flex items-center justify-center"
                     style={{
                        width: size,
                        height: size,
                     }}
                     initial={{
                        x: Math.random() * windowSize.width,
                        y: `${yPos}%`,
                        opacity: 0,
                     }}
                     animate={{
                        x: [
                           Math.random() * windowSize.width,
                           Math.random() * windowSize.height,
                        ],
                        y: [`${yPos}%`, `${yPos + (Math.random() * 100 - 5)}%`],
                        opacity: [0, 0.8, 0],
                        rotate: [0, 360],
                     }}
                     transition={{
                        duration: Math.random() * 20 + 20,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "loop",
                        rotate: {
                           duration: Math.random() * 10 + 10,
                           repeat: Number.POSITIVE_INFINITY,
                           ease: "linear",
                        },
                     }}
                  >
                     <Icon icon={icon} width={size} height={size} />
                     {/* <span className="iconify text-3xl" data-icon={icon}></span> */}
                  </motion.div>
               );
            })}

            {/* Connection dots */}
            {Array.from({ length: 30 }).map((_, index) => {
               const size = Math.random() * 4 + 2;
               const layer = Math.floor(Math.random() * 3);
               const yPos =
                  layer === 0
                     ? Math.random() * 30 + 700
                     : layer === 1
                     ? Math.random() * 30 + 5000
                     : Math.random() * 30 + 7000;
               const color =
                  layer === 0 ? "#60a5fa" : layer === 1 ? "#c084fc" : "#4ade80";

               return (
                  <motion.div
                     key={`dot-${index}`}
                     className="absolute rounded-full"
                     style={{
                        width: size,
                        height: size,
                        backgroundColor: color,
                        boxShadow: `0 0 10px ${color}`,
                     }}
                     initial={{
                        x: Math.random() * windowSize.width * index,
                        y: `${yPos}%`,
                        opacity: 0,
                     }}
                     animate={{
                        x: [
                           Math.random() * windowSize.width,
                           Math.random() * windowSize.height,
                        ],
                        y: [`${yPos}%`, `${yPos + (Math.random() * 100 - 5)}%`],
                        opacity: [0, 0.8, 0],
                        scale: [1, 1.5, 1],
                     }}
                     transition={{
                        duration: Math.random() * 15 + 10,
                        repeat: Number.POSITIVE_INFINITY,
                        repeatType: "loop",
                     }}
                  />
               );
            })}
         </div>
      </div>
   );
};

export default FullStackBanner;
