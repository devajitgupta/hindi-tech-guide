// components/developer-page/DeveloperPage.tsx
"use client";

import { motion } from "framer-motion";
import { Icon } from "@iconify/react";
import { useState } from "react";
import Image from "next/image";
import SectionTitle from "@/components/SectionTitle";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import Text from "@/components/Text";
import { Button } from "@nextui-org/react";
import ParallaxBanner from "@/components/ParallaxBanner";
import SectionSubtitle from "@/components/SectionSubtitle";
import { usePathname } from "next/navigation";
import dynamic from "next/dynamic";
// import ContactUs from "@/app/contact-us/page";
import ConnectForm from "../contactUs/ConnectForm";
import FAQSection from "../ui/FaqSection/FAQSection";

const HireDevelopersAnimation = dynamic(
   () => import("./HireDevelopersAnimation"),
   {
      ssr: false,
   }
);

type Props = {
   title: string;
   tagline: string;
   type: any;
   skillSection: {
      title: string;
      subtitle: string;
      skills: {
         title: string;
         key: string;
         data: {
            name: string;
            icon: string;
            level: number;
            description: string;
         }[];
      }[];
   };
   whatWeDo: {
      title: string;
      subtitle: string;
      service: { icon: string; title: string; description: string }[];
   };
   whyHire: {
      title: string;
      subtitle: string;
      reasons: { title: string; description: string; icon: string }[];
   };
   portfolio: {
      title: string;
      subtitle: string;
      projects: {
         title: string;
         description: string;
         image: string;
         technologies: string[];
      }[];
   };
   cta: {
      title: string;
      subTitle: string;
      text: string;
      href: string;
      buttonText: string;
   };
   faq: {
      header: unknown;
      title: string;
      subtitle: string;
      questions: { question: string; answer: string }[];
   };
   className?: string;
   langText: any;
};

export default function Developers({
   title,
   tagline,
   whatWeDo,
   skillSection,
   whyHire,
   portfolio,
   cta,
   className,
   faq,
   type,
   langText,
}: Props) {
   const pathName = usePathname();

   const [activeTab, setActiveTab] = useState<string>(
      skillSection.skills.length > 0 ? skillSection.skills[0].key : ""
   );
   const activeData =
      skillSection.skills.find((s) => s.key === activeTab)?.data || [];

   const containerVariants = {
      hidden: { opacity: 0 },
      visible: {
         opacity: 1,
         transition: {
            staggerChildren: 0.1,
         },
      },
   };

   const itemVariants = {
      hidden: { y: 20, opacity: 0 },
      visible: {
         y: 0,
         opacity: 1,
         transition: {
            type: "spring",
            stiffness: 100,
            damping: 10,
         },
      },
   };

   return (
      <div className={twMerge(clsx("poppins", className))}>
         {/* Hero Section */}
         <div
            className={twMerge(
               clsx(
                  "relative mb-10 md:mb-20 overflow-hidden px-[22px]  md:px-[54px]  items-center justify-normal   z-20"
               )
            )}
         >
            <HireDevelopersAnimation animationType={type} />
            <div className="grid place-items-center py-10 md:py-24 md:gap-[10px]">
               <h1
                  className="text-[35px]  md:text-[70px] md:leading-[80px] font-bold  poppins text-center"
                  data-aos="zoom-in"
                  data-aos-easing="ease-out-cubic"
                  data-aos-anchor-placement="top-bottom"
               >
                  {title}
               </h1>
               <p
                  className="poppins text-[#b7b7b7] text-[14px] md:text-[18px]"
                  data-aos="fade-up"
                  data-aos-delay={500}
                  data-aos-easing="ease-out-cubic"
                  data-aos-anchor-placement="top-bottom"
               >
                  {tagline}
               </p>
            </div>
         </div>

         {/* What We Do Section */}
         <div className="px-5 md:px-[40px] py-10">
            <div className=" mx-auto ">
               <div className="space-y-[10px] mb-10">
                  <SectionTitle className=" m-auto">
                     {whatWeDo.title}
                  </SectionTitle>
                  <SectionSubtitle className="m-auto lg:max-w-3xl mb-6 md:mb-10">
                     {whatWeDo.subtitle}
                  </SectionSubtitle>
               </div>

               <motion.div
                  className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-3"
                  variants={containerVariants}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
               >
                  {whatWeDo.service.map((service, index) => (
                     <motion.div
                        key={index}
                        className={` group overflow-hidden  relative bg-gradient-to-br from-black/10 to-blue-900/20 border border-[#262626] rounded-xl p-6 hover:border-[#565656] transition-all duration-300`}
                        variants={itemVariants}
                        whileHover={{
                           y: -5,
                           boxShadow:
                              "0 10px 30px -15px rgba(255, 255, 255, 0.5)",
                        }}
                     >
                        <div
                           className="w-12 h-12 border rounded-full bg-[#1a1a1a]/65 border-[#262626] 
            transition-all duration-500 ease-in-out transform group-hover:border-gray-300 group-hover:bg-gray-200 flex items-center justify-center mb-5"
                        >
                           <Icon
                              icon={service.icon}
                              width="32"
                              height="32"
                              className={`group-hover:text-black  text-white`}
                           />
                        </div>
                        <h3 className="text-xl font-semibold mb-3">
                           {service.title}
                        </h3>
                        <Text className="text-start">
                           {service.description}
                        </Text>
                     </motion.div>
                  ))}
               </motion.div>
            </div>
         </div>

         <div className=" relative overflow-hidden ">
            <HireDevelopersAnimation animationType={type} />
            {/* <div className="bg-black/50  absolute h-screen w-screen"></div> */}
            <div
               className={twMerge(
                  clsx(
                     "relative z-20 px-5 md:px-[40px] backdrop-blur-md py-10 md:py-10",
                     {
                        "backdrop-blur-[3px]":
                           pathName === "/laravel-developer" ||
                           pathName === "/php-developer",
                        "backdrop-blur-xl":
                           pathName === "/ui-ux-designer" ||
                           pathName === "/shopify-developer",
                     }
                  )
               )}
            >
               {/* Skill Section */}
               <div className="py-10 md:py-10 ">
                  <div className=" mx-auto">
                     <div className="space-y-[10px] mb-10 px-5 md:px-0">
                        {/* Title */}
                        <SectionTitle className="max-w-3xl m-auto">
                           {skillSection.title}
                        </SectionTitle>
                        <SectionSubtitle className="m-auto  ">
                           {skillSection.subtitle}
                        </SectionSubtitle>
                     </div>

                     <div className="mb-5 ">
                        {/* Tabs */}
                        <div className="flex justify-center space-x-1 md:space-x-1 mb-5 md:mb-6 overflow-x-auto bg-[#626262]/20 border border-[#262626]  w-fit m-auto rounded-full p-1">
                           <div className="flex space-x-1 md:space-x-2   rounded-lg ">
                              {skillSection.skills.map((tab, index) => (
                                 <button
                                    key={index}
                                    className={twMerge(
                                       clsx(
                                          "px-3 md:px-8 py-2 rounded-full text-xs md:text-sm font-medium  bg-transparent text-white hover:bg-[#1463fd]/50 transition-all duration-1000 hover:text-white  poppins",
                                          {
                                             "bg-[#1463fd]  text-white":
                                                activeTab === tab.key,
                                          }

                                          // : "text-black hover:text-white hover:bg-[#1463fd]"
                                       )
                                    )}
                                    onClick={() => setActiveTab(tab.key)}
                                 >
                                    {tab.title}
                                 </button>
                              ))}
                           </div>
                        </div>

                        {/* Skills Grid */}
                        <motion.div
                           className="grid  grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4 px-5 md:px-[40px]"
                           initial={{ opacity: 0 }}
                           animate={{ opacity: 1 }}
                           transition={{ duration: 0.5 }}
                        >
                           {activeData.map((skill, index) => (
                              <motion.div
                                 key={index}
                                 className=" gap-x-12 gap-y-4  p-8 border-[#262626] border rounded-lg backdrop-blur-sm bg-black/20 group flex flex-col justify-between"
                                 initial={{ opacity: 0, y: 20 }}
                                 whileInView={{ opacity: 1, y: 0 }}
                                 viewport={{ once: true }}
                                 transition={{
                                    duration: 0.3,
                                    delay: index * 0.05,
                                 }}
                                 variants={itemVariants}
                                 whileHover={{
                                    y: -5,
                                    scale: 1.05,
                                    boxShadow:
                                       "0 10px 30px -15px rgba(255, 255, 255, 0.5)",
                                 }}
                              >
                                 <div>
                                    <div className="flex items-center justify-between mb-5">
                                       <div className="flex items-center  gap-x-2">
                                          <motion.div className="bg-black group-hover:bg-[#fff] group-hover:text-black h-10 w-10 border border-[#262626] rounded-full flex items-center justify-center transition-all duration-1000 ease-in-out">
                                             <Icon
                                                icon={skill.icon}
                                                width="24"
                                                height="24"
                                             />
                                          </motion.div>
                                          <span className="font-medium">
                                             {skill.name}
                                          </span>
                                       </div>
                                       <p className="text-[#1463fd]">
                                          {skill.level}%
                                       </p>
                                    </div>
                                    <Text
                                       className="text-start  mb-5"
                                       textSize="sm"
                                    >
                                       {" "}
                                       {skill.description}
                                    </Text>
                                 </div>
                                 <div className="w-full bg-[#565656] rounded-full h-2">
                                    <motion.div
                                       className="bg-white h-2 rounded-full"
                                       initial={{ width: 0 }}
                                       whileInView={{
                                          width: `${skill.level}%`,
                                       }}
                                       viewport={{ once: true }}
                                       transition={{ duration: 1, delay: 0.1 }}
                                    ></motion.div>
                                 </div>
                              </motion.div>
                           ))}
                        </motion.div>
                     </div>
                  </div>
               </div>

               {/* Why Hire Section */}
               <div className="space-y-[10px] mb-10">
                  <SectionTitle className="max-w-3xl m-auto">
                     {whyHire.title}
                  </SectionTitle>
                  <SectionSubtitle className="m-auto mb-5">
                     {skillSection.subtitle}
                  </SectionSubtitle>
               </div>

               <div className="md:grid-cols-2  mt-10 lg:grid-cols-3 grid gap-y-3 gap-x-6">
                  {whyHire.reasons.map((reason: any, index: number) => (
                     <motion.div
                        key={reason.title}
                        className=" gap-x-12 p-8 border-[#262626] border rounded-lg backdrop-blur-sm bg-black/20"
                        initial={{ opacity: 0, y: 50 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.5, delay: index * 0.2 }}
                     >
                        <div className="flex items-center gap-2 mb-5">
                           <div
                              className="w-12 h-12 border rounded-full bg-[#1a1a1a]/65 border-[#262626] 
                           transition-all duration-500 ease-in-out transform group-hover:border-gray-300 group-hover:bg-gray-200 flex items-center justify-center "
                           >
                              <Icon
                                 icon={reason.icon}
                                 width={"24"}
                                 height={"24"}
                              />
                           </div>
                           <h3 className="text-xl font-semibold ">
                              {reason.title}
                           </h3>
                        </div>
                        <Text className="text-start">{reason.description}</Text>
                     </motion.div>
                  ))}
               </div>
            </div>
         </div>

         {/* Projects Section */}
         <div className="mx-auto px-5 md:px-[40px] py-10 md:py-20">
            <div className="space-y-[10px] mb-16">
               <SectionTitle className="max-w-3xl  m-auto">
                  {portfolio.title}
               </SectionTitle>
               <SectionSubtitle className="max-w-3xl m-auto">
                  {portfolio.subtitle}
               </SectionSubtitle>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
               {portfolio.projects.map((project, index) => (
                  <motion.div
                     key={index}
                     className=" border border-[#262626] rounded-xl overflow-hidden"
                     initial={{ opacity: 0, y: 20 }}
                     whileInView={{ opacity: 1, y: 0 }}
                     viewport={{ once: true }}
                     transition={{ duration: 0.5, delay: index * 0.1 }}
                     whileHover={{
                        y: -10,
                        boxShadow: "0 10px 30px -15px rgba(59, 130, 246, 0.5)",
                     }}
                  >
                     <div className="relative h-48">
                        <Image
                           src={project.image || "/placeholder.svg"}
                           alt={project.title}
                           fill
                           className="object-cover"
                        />
                     </div>
                     <div className="p-6">
                        <h3 className="text-xl font-semibold mb-3">
                           {project.title}
                        </h3>
                        <p className="text-gray-400 mb-4">
                           {project.description}
                        </p>
                        <div className="flex flex-wrap gap-2">
                           {project.technologies.map((tech, techIndex) => (
                              <span
                                 key={techIndex}
                                 className="bg-blue-900/30 text-[#1463fd] text-xs px-2 py-1 rounded"
                              >
                                 {tech}
                              </span>
                           ))}
                        </div>
                     </div>
                  </motion.div>
               ))}
            </div>
         </div>

         <div className="mx-auto px-5 md:px-[40px] py-10 md:py-20 border-b border-[#262626]">
            <ConnectForm langText={langText} />
         </div>
         <div className="mx-auto px-5 md:px-[40px] py-10 md:py-20">
            <FAQSection header={faq.header} data={faq.questions} />
         </div>
      </div>
   );
}
