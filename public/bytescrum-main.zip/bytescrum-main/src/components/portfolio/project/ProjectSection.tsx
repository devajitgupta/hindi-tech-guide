"use client";
import PrevNextBtn from "@/components/buttons/PrevNextBtn";
import { ImplementationIcon, SalutionIcon } from "@/components/Icons";
import ConclusionIcon from "@/components/Icons/ConclusionIcon";
import clsx from "clsx";
import Image from "next/image";
import { twMerge } from "tailwind-merge";
import "aos/dist/aos.css";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import ProjectSwiper from "./ProjectSwiper";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import ParallaxBanner from "@/components/ParallaxBanner";

interface IProps {
   sectionStyle?: string;
   data?: any;
}

const ProjectSection = ({ sectionStyle, data }: IProps) => {
   const { screenWidth } = useBreakpoints();

   const matches = screenWidth < 767;

   return (
      <div>
         {/* NOTE: Overview Section */}
         <div
            className={twMerge(
               clsx("grid items-center justify-center ", sectionStyle)
            )}
         >
            <div className="grid items-center justify-center m-auto gap-5 overflow-hidden">
               <SectionTitle>{data.overviewSection.title}</SectionTitle>
               <SectionSubtitle
                  className="m-auto max-w-full lg:max-w-[861px]"
                  textSize="lg"
               >
                  {data.overviewSection.subTitle}
               </SectionSubtitle>
               <Text className="m-auto">{data.overviewSection.text}</Text>
            </div>
         </div>

         {/* NOTE: Challenges Section */}
         <div
            className={twMerge(
               clsx(
                  "bg-gradient-to-r from-[#040404] to-[#0b0b0b]",
                  sectionStyle
               )
            )}
         >
            <div className="grid items-center md:grid-cols-2 gap-x-[20px] ">
               <div className=" lg:row-span-2">
                  <Image
                     src={data.challengesSection.img}
                     width={550}
                     height={353}
                     alt="Pc Image "
                     data-aos={screenWidth < 767 ? "zoom-in-up" : "fade-right"}
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                     className="m-auto"
                  />
               </div>

               <div className="max-w-[600px]">
                  <SectionTitle className="text-start">
                     {data.challengesSection.title}
                  </SectionTitle>

                  <SectionSubtitle textSize="sm" className="text-start">
                     {data.challengesSection.subTitle}
                  </SectionSubtitle>
               </div>
               <div className="col-span-full lg:col-span-1">
                  <ul className=" ps-5 text-[#f5f5f5]">
                     {data.challengesSection.texts.map(
                        (text: any, index: any) => (
                           <li className="list-disc" key={index}>
                              <Text className="text-start lg:max-w-[599px]">
                                 {text.para}
                              </Text>
                           </li>
                        )
                     )}
                  </ul>
               </div>
            </div>
         </div>

         {/* NOTE: Solution and Implementation Section */}
         <div className={twMerge(clsx(sectionStyle))}>
            <div className="flex flex-col lg:grid grid-cols-2 justify-around gap-y-10 ">
               {/* NOTE: Solution */}
               <div className="md:ps-5 space-y-5">
                  <div className="flex gap-2 md:gap-4">
                     <SalutionIcon varient="leftSide" />
                     <SectionTitle> {data.solutionSection.title}</SectionTitle>
                  </div>
                  <SectionSubtitle
                     className="text-start max-w-[615px]"
                     textSize="sm"
                  >
                     {data.solutionSection.subTitle}
                  </SectionSubtitle>
                  <div className="space-y-10 ">
                     {data.solutionSection.texts.map(
                        (text: any, index: any) => (
                           <div key={index}>
                              <Text textSize="lg" className="text-start">
                                 {" "}
                                 <strong> {text.title}</strong>
                              </Text>
                              <Text
                                 className="text-start   lg:max-w-[615px]"
                                 textSize="md"
                              >
                                 {text.para}
                              </Text>
                           </div>
                        )
                     )}
                  </div>
               </div>
               {/* NOTE: Implementation */}
               <div className="md:ps-5 space-y-5">
                  <div className="flex gap-2 md:gap-4">
                     <ImplementationIcon />
                     <SectionTitle>
                        {" "}
                        {data.implementationSection.title}
                     </SectionTitle>
                  </div>
                  <SectionSubtitle
                     className="text-start max-w-[615px]"
                     textSize="sm"
                  >
                     {data.implementationSection.subTitle}
                  </SectionSubtitle>
                  <div className="space-y-10 ">
                     {data.implementationSection.texts.map(
                        (text: any, index: any) => (
                           <div key={index}>
                              <Text textSize="lg" className="text-start">
                                 {" "}
                                 <strong> {text.title}</strong>
                              </Text>
                              <Text
                                 className="text-start   lg:max-w-[615px]"
                                 textSize="md"
                              >
                                 {text.para}
                              </Text>
                           </div>
                        )
                     )}
                  </div>
               </div>
            </div>
         </div>

         {/* NOTE: Banner Section */}
         <ParallaxBanner
            className={clsx(sectionStyle)}
            desktopBgImage={data.banner.desktopBanner}
            mobileBgImage={data.banner.mobileBanner}
            href="/" sData={data}         />

         {/* NOTE: Result Section */}
         <div className={twMerge(clsx(sectionStyle))}>
            <div className="grid items-center md:grid-cols-2 gap-x-[20px] gap-y-[20px] md:gap-y-0 ">
               <div className=" max-w-[672px] order-2 md:order-1">
                  <SectionTitle className="text-start">
                     {data.resultSection.title}
                  </SectionTitle>
                  <SectionSubtitle textSize="sm" className="text-start ">
                     {" "}
                     {data.resultSection.subTitle}
                  </SectionSubtitle>
               </div>
               <div className="lg:row-span-2 order-1 md:order-2">
                  <Image
                     src={data.resultSection.img}
                     width={550}
                     height={353}
                     alt="Pc Image "
                     data-aos={matches ? "zoom-in-up" : "fade-left"}
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                     className="m-auto"
                  />
               </div>
               <div className="col-span-full lg:col-span-1 order-3">
                  <ul className=" ps-5 text-[#f5f5f5]">
                     {data.resultSection.texts.map((text: any, index: any) => (
                        <li className="list-disc my-2" key={index}>
                           <Text className="text-start lg:max-w-[599px]">
                              {text.para}
                           </Text>
                        </li>
                     ))}
                  </ul>
               </div>
            </div>
         </div>

         {/* NOTE: Technologies Section */}
         <div
            className={twMerge(
               clsx(
                  "bg-gradient-to-r from-[#040404] to-[#0b0b0b]",
                  sectionStyle
               )
            )}
         >
            <div className="flex flex-col md:flex-row items-center justify-center  md:justify-between gap-[5px] gap-y-10  ">
               <SectionTitle className="md:text-start max-w-[259px] md:max-w-[416px]">
                  {data.technologiesSection.title}
               </SectionTitle>

               <div className=" max-w-[315px] sm:max-w-[400px] md:max-w-full md:w-1/2  m-auto md:me-0">
                  <ProjectSwiper
                     swipperData={data.technologiesSection.techData}
                  />
               </div>
            </div>
         </div>

         {/* NOTE: Conclusion Section */}
         <div className={twMerge(clsx(sectionStyle))}>
            <div className="md:ps-5 space-y-5">
               <div className="flex gap-4">
                  <ConclusionIcon />
                  <SectionTitle className="text-start max-w-[259px] md:max-w-[416px]">
                     {data.conclusionSection.title}
                  </SectionTitle>
               </div>

               <div className="space-y-8">
                  {data.conclusionSection.texts.map((text: any, index: any) => (
                     <Text className="text-start lg:max-w-full" key={index}>
                        {text.para}
                     </Text>
                  ))}
               </div>
            </div>
         </div>

         {/* NOTE: Button Section */}
         <div className={twMerge(clsx(sectionStyle))}>
            <div className="flex  items-center justify-between">
               <div className="flex flex-col items-start md:items-center  md:flex-row gap-[10px] md:gap-[20px]">
                  <PrevNextBtn
                     variant="prev"
                     text={data.previousButton.btnTitle}
                  />
                  <span
                     className="poppins text-[16px] md:text-[20px]  font-bold max-w-[133px] md:max-w-[274px]"
                     data-aos="fade-right"
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     {data.previousButton.btnText}
                  </span>
               </div>
               <div className="flex flex-col items-end md:items-center  md:flex-row gap-[10px] md:gap-[20px]">
                  <span
                     className="poppins text-[16px] md:text-[20px] font-bold max-w-[133px] md:max-w-[274px] text-end order-2 md:order-1"
                     data-aos="fade-left"
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     {data.nextButton.btnText}
                  </span>
                  <PrevNextBtn
                     variant="next"
                     text={data.nextButton.btnTitle}
                     className="order-1  md:order-2"
                  />
               </div>
            </div>
         </div>
      </div>
   );
};

export default ProjectSection;
