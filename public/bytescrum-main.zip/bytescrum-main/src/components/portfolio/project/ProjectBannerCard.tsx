import Image from "next/image";
import "./project.css";
import { cn } from "@nextui-org/react";

interface IPorps {
   icon: string;
   title: string;
   subtitle: string;
}

interface CardsProps {
   cards: IPorps[];
}

const ProjectBannerCard = ({ cards }: CardsProps) => {
   return (
      <div className=" rounded-lg border border-[#262626] bg-[#0a0a0a] text-start px-3 py-5 sm:p-5 w-fit m-auto">
         <div className="grid justify-center  lg:flex grid-cols-5 gap-x-2 gap-y-5 w-fit ">
            {cards?.map((card, index) => (
               <div
                  key={index}
                  className="flex md:px-[30px]  border-r last:border-none border-[#262626] bannerCard first:col-span-2"
               >
                  <div className="flex items-center  md:justify-start gap-2  text-white  bg-transparent  ">
                     <div>
                        <Image
                           src={card.icon}
                           width={25}
                           height={25}
                           alt={card.icon}
                           className="min-w-[20px]  "
                        />
                     </div>
                     <div>
                        <div className="text-[16px] md:text-[20px] poppins font-bold md:leading-[18px]">
                           {card.title}
                        </div>
                        <div
                           className={cn(
                              "text-[10px] mt-[3px] md:text-[12px] text-[#b1b1b1] leading-[18px] max-w-60 ",
                              { truncate: card.subtitle.length > 10 }
                           )}
                        >
                           {card.subtitle}
                        </div>
                     </div>
                  </div>
               </div>
            ))}
         </div>
      </div>
   );
};

export default ProjectBannerCard;
