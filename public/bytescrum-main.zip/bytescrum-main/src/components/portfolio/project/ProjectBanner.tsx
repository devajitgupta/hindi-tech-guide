import PageBanner from "@/components/PageBanner";
import ProjectBannerCard from "./ProjectBannerCard";

interface IProps {
   data: any;
}

const ProjectBanner = ({ data }: IProps) => {
   return (
      <div>
         <PageBanner
            bgPath={
               "/portfolio/portfolioPage/projectBanner/projectPageBanner.png"
            }
            bannerHeight="h-[50vh] xs:h-[35vh] md:h-[46vh]"
            className="border-b justify-center border-[#262626]"
         >
            <div className="grid items-center md:gap-y-[5px] ">
               <div className="grid place-items-center md:gap-5px]">
                  {" "}
                  <p
                     className="poppins text-[#b7b7b7] text-[14px] md:text-[18px] uppercase tracking-wider"
                     data-aos="zoom-in"
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     {data.technology}
                  </p>
                  <h1
                     className="text-[35px] md:text-[70px] md:leading-[80px] font-bold  poppins text-center"
                     data-aos="zoom-in"
                     data-aos-easing="ease-out-cubic"
                     data-aos-delay={300}
                     data-aos-anchor-placement="top-bottom"
                  >
                     {data.project}
                     <br />
                  </h1>
               </div>

               <div
                  className="mt-4 md:mt-8 px-4 xs:px-8 md:px-0 overflow-hidden "
                  data-aos="fade-up"
                  data-aos-easing="ease-out-cubic"
                  data-aos-delay={500}
                  data-aos-anchor-placement="top-bottom"
               >
                  <ProjectBannerCard cards={data.cardData} />
               </div>
            </div>
         </PageBanner>
      </div>
   );
};

export default ProjectBanner;
