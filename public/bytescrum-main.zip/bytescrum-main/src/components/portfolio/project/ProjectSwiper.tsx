"use client";

import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";

import { A11y, Autoplay, Pagination } from "swiper/modules";
import { useState } from "react";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import "./project.css";
import Image from "next/image";

interface IProps {
   className?: string;
   swipperData: any;
}

const ProjectSwiper = ({ className, swipperData }: IProps) => {
   const [activeIndex, setActiveIndex] = useState(0);
   const [realIndex, setRealIndex] = useState(0);

   return (
      <div
         className={twMerge(
            clsx(
               " transition-transform duration-200 ease-in-out transform ",
               className
            )
         )}
      >
         <Swiper
            modules={[Pagination, A11y, Autoplay]}
            slidesPerView={3}
            slidesPerGroup={1}
            loop={true}
            navigation
            pagination={{
               clickable: true,
            }}
            scrollbar={{ draggable: true }}
            className="space-y-10 "
            followFinger={true}
            autoplay={{
               delay: 3000,
               disableOnInteraction: false,
            }}
            speed={1100}
            breakpoints={{
               0: {
                  slidesPerView: 2,
                  spaceBetween: 10,
                  slidesPerGroup: 2,
               },
               1024: {
                  slidesPerView: 3,
                  spaceBetween: 30,
                  slidesPerGroup: 3,
               },
            }}
         >
            <div className=" grid md:grid-cols-3 items-center justify-center md:px-0  ">
               {swipperData.map((tech: any, index: number) => (
                  <SwiperSlide key={tech._Id}>
                     <div
                        className={clsx(
                           "grid place-items-center  py-4 border border-[#262626] rounded-xl bg-gradient-to-r from-[#040404] to-[#0b0b0b] cursor-pointer h-[150px]  "
                        )}
                     >
                        <div className="grid place-items-center  gap-[10px]  ">
                           <div className="max-w-[84px] max-h-[77px] m-auto  ">
                              <Image
                                 src={tech.icon}
                                 width={84}
                                 height={77}
                                 alt={tech.title}
                                 loading="lazy"
                                 layout="intrinsic"
                                 className={`techIcon w-${tech.width} !max-h-${tech.height} m-auto `}
                              />
                           </div>
                           <p className=" inter text-center text-[14px] md:text-[16px] leading-[24px] md:leading-[28px] text-[#fff]">
                              {tech.title}
                           </p>
                        </div>
                     </div>
                  </SwiperSlide>
               ))}
            </div>
            {/* </div> */}
         </Swiper>
      </div>
   );
};

export default ProjectSwiper;
