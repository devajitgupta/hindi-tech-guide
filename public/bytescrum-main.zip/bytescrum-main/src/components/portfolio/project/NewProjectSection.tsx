import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import { Icon } from "@iconify/react/dist/iconify.js";
import { cn, Divider } from "@nextui-org/react";
import { AnimatePresence, motion, useInView } from "framer-motion";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import homeData from "../../../common/data/homeData.json";
import useBreakpoints from "@/common/hooks/useBreakpoints ";
import Text from "@/components/Text";
import { ImplementationStep } from "@/components/ui";
import PortfolioCardTwo from "@/components/home/PortfolioSection/PortfolioCardTwo";
import OurPortfolio from "@/components/home/PortfolioSection";

type Props = {
   data: any;
   portfolioSection: any;
};

const NewProjectSection = ({ data, portfolioSection }: Props) => {
   const ref = useRef<HTMLDivElement>(null);
   const challengesSolutionsRef = useRef<HTMLDivElement>(null);
   const { screenWidth } = useBreakpoints();
   const isMobile = screenWidth < 567;
   const [relatedProjects, setRelatedProjects] = useState<any[]>([]);
   const [currentImageIndex, setCurrentImageIndex] = useState(0);
   const [activeChallenge, setActiveChallenge] = useState<number>(1);
   const portfolioData = homeData.portfolioSection.portfolioData;
   const isInView = useInView(ref, { once: true, margin: "-100px" });
   const challengesSolutionsIsInView = useInView(challengesSolutionsRef, {
      once: true,
      margin: "-100px",
   });

   const containerVariants = {
      hidden: { opacity: 0 },
      visible: {
         opacity: 1,
         transition: {
            staggerChildren: 0.3,
         },
      },
   };

   useEffect(() => {
      // Filter projects with same category, excluding the current project
      const related = portfolioData.filter((project) => {
         return project._id !== data._id && project.category === data.category;
      });

      // Shuffle the array randomly and take first 3 items
      const shuffled = related.sort(() => 0.5 - Math.random());
      setRelatedProjects(shuffled.slice(0, 3));
   }, [data._id, data.category, portfolioData]);

   useEffect(() => {
      const interval = setInterval(() => {
         if (data && data.gallery && data.gallery.length > 0) {
            setCurrentImageIndex((prevIndex) =>
               prevIndex === data.gallery.length - 1 ? 0 : prevIndex + 1
            );
         }
      }, 3000);

      return () => clearInterval(interval);
   }, [data.gallery]);

   function formatProjectId(projectId: string): string {
      const parts = projectId.split("-");
      return parts
         .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
         .join(" ");
   }

   // References for scroll animations
   const heroRef = useRef(null);
   const featuresRef = useRef(null);

   // Check if sections are in view
   const featuresInView = useInView(featuresRef, { once: false, amount: 0.2 });

   const prevImage = () => {
      if (data && data.gallery && data.gallery.length > 0) {
         setCurrentImageIndex((prev) =>
            prev === 0 ? data.gallery.length - 1 : prev - 1
         );
      }
   };

   const nextImage = () => {
      if (data && data.gallery && data.gallery.length > 0) {
         setCurrentImageIndex((prev) =>
            prev === data.gallery.length - 1 ? 0 : prev + 1
         );
      }
   };

   const itemVariants = {
      hidden: { y: 50, opacity: 0.5 },
      visible: {
         y: 0,
         opacity: 1,
         transition: {
            duration: 0.6,
            ease: "easeOut",
            type: "spring",
            stiffness: 100,
            damping: 15,
         },
      },
   };

   return (
      <>
         <section
            id="overview"
            className="relative  pt-20   px-5 md:px-[40px] py-[40px] md:py-[60px]  gap-[40px] bg-[#000000] overflow-hidden"
            ref={heroRef}
         >
            <div className="  relative z-10">
               <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                  <div>
                     <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                        className="mb-4"
                     >
                        <span className="px-3 py-1 text-sm font-medium bg-[#0a0a0a] text-#fff rounded-full border primaryBorder">
                           {data.technology}
                        </span>
                     </motion.div>

                     <motion.h1
                        className="text-4xl md:text-6xl font-bold mb-6"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.2 }}
                     >
                        {data.title}
                     </motion.h1>

                     <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.4 }}
                     >
                        <Text className="inter text-[12px] md:text-[16px] leading-0 md:leading-[28px] max-w-full text-start lg:max-w-[743px]">
                           {data.overviewSection.subTitle}
                        </Text>
                     </motion.div>

                     <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.4 }}
                        className="mt-4"
                     >
                        <Text className="inter text-start text-[12px] md:text-[16px] leading-0 md:leading-[28px] max-w-full lg:max-w-[743px]">
                           {data.overviewSection.text}
                        </Text>
                     </motion.div>

                     <motion.div
                        className="flex flex-wrap gap-4 mt-5 mb-8"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.6 }}
                     >
                        <div className="secondaryBg backdrop-blur-sm px-4 py-2 rounded-lg border primaryBorder">
                           <span className="textColorSecondary text-sm">
                              Client:
                           </span>
                           <span className="ml-2 font-medium ">
                              {data.client}
                           </span>
                        </div>

                        <div className="secondaryBg backdrop-blur-sm px-4 py-2 rounded-lg border primaryBorder">
                           <span className="textColorSecondary text-sm">
                              Industry:
                           </span>
                           <span className="ml-2 font-medium">
                              {data.industry}
                           </span>
                        </div>
                     </motion.div>

                     <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8, delay: 0.8 }}
                     >
                        <motion.button
                           className="bg-white text-black font-semibold py-3 px-8 rounded-full transition-all duration-300 flex items-center gap-2"
                           whileHover={{
                              scale: 1.05,
                              boxShadow: `0 0 20px rgba(245, 245, 245, 0.5)`,
                           }}
                           whileTap={{ scale: 0.95 }}
                           onClick={() => {
                              const featuresElement =
                                 document.getElementById("features");
                              if (featuresElement) {
                                 featuresElement.scrollIntoView({
                                    behavior: "smooth",
                                 });
                              }
                           }}
                        >
                           Explore Features
                           <Icon icon="mdi:arrow-down" className="text-xl" />
                        </motion.button>
                     </motion.div>
                  </div>

                  <motion.div
                     className="relative group"
                     initial={{ opacity: 0, scale: 0.9 }}
                     animate={{ opacity: 1, scale: 1 }}
                     transition={{ duration: 1, delay: 0.5 }}
                  >
                     <div className="relative rounded-xl overflow-hidden border primaryBorder shadow-lg shadow-[#fff]/20">
                        <div className="aspect-video relative">
                           <Image
                              src={data.src || "/placeholder.svg"}
                              alt={data.title}
                              fill
                              priority={true}
                              className="object-cover group-hover:scale-125 transition-all duration-1000 delay-300  ease-soft-spring"
                           />
                           <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                        </div>

                        {/* Floating elements */}
                        {data.id === "cmd-forward" && (
                           <>
                              <motion.div
                                 className="absolute top-4 right-4  backdrop-blur-sm border primaryBorder rounded-lg p-3"
                                 initial={{ opacity: 0, y: -20 }}
                                 animate={{ opacity: 1, y: 0 }}
                                 transition={{ duration: 0.5, delay: 1 }}
                              >
                                 <Icon
                                    icon="mdi:shield-check"
                                    className={`textColorSecondary text-2xl`}
                                 />
                              </motion.div>

                              <motion.div
                                 className="absolute bottom-4 left-4 primaryBorder backdrop-blur-sm border rounded-lg p-3 flex items-center gap-2"
                                 initial={{ opacity: 0, y: 20 }}
                                 animate={{ opacity: 1, y: 0 }}
                                 transition={{ duration: 0.5, delay: 1.2 }}
                              >
                                 <Icon
                                    icon="mdi:ethereum"
                                    className=" text-xl"
                                 />
                                 <span className=" font-medium">Ethereum</span>
                              </motion.div>
                           </>
                        )}
                     </div>

                     {/* Floating stats - customize based on case study */}
                     {data.results && data.results.length >= 2 && (
                        <>
                           <motion.div
                              className="absolute -top-6 -left-6  backdrop-blur-sm border primaryBorder rounded-lg p-4"
                              initial={{ opacity: 0, scale: 0.8 }}
                              animate={{ opacity: 1, scale: 1, y: [0, -10, 0] }}
                              transition={{
                                 duration: 0.5,
                                 delay: 1.4,
                                 y: {
                                    duration: 1.5,
                                    repeat: Number.POSITIVE_INFINITY,
                                    repeatType: "reverse",
                                 },
                              }}
                           >
                              <div className="text-center">
                                 <Text className=" font-bold text-2xl">
                                    {data.results[0].value}
                                 </Text>
                                 <Text className=" text-sm">
                                    {data.results[0].label}
                                 </Text>
                              </div>
                           </motion.div>

                           <motion.div
                              className="absolute -bottom-6 -right-6  backdrop-blur-sm border primaryBorder rounded-lg p-4"
                              initial={{ opacity: 0, scale: 0.8 }}
                              animate={{ opacity: 1, scale: 1, y: [0, 10, 0] }}
                              transition={{
                                 duration: 0.5,
                                 delay: 1.6,
                                 y: {
                                    duration: 1.5,
                                    repeat: Number.POSITIVE_INFINITY,
                                    repeatType: "reverse",
                                 },
                              }}
                           >
                              <div className="text-center">
                                 <Text className=" font-bold text-2xl">
                                    {data.results[1].value}
                                 </Text>
                                 <Text className=" text-sm">
                                    {data.results[1].label}
                                 </Text>
                              </div>
                           </motion.div>
                        </>
                     )}
                  </motion.div>
               </div>
            </div>

            {/* Scroll indicator */}
            <motion.div
               className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
               initial={{ opacity: 0, y: -20 }}
               animate={{ opacity: 1, y: [0, 10, 0] }}
               transition={{
                  delay: 2,
                  duration: 0.5,
                  y: {
                     duration: 2,
                     repeat: Number.POSITIVE_INFINITY,
                     repeatType: "reverse",
                  },
               }}
            >
               <Icon
                  icon="mdi:chevron-down"
                  className="textColorSecondary text-3xl"
               />
            </motion.div>
         </section>

         {/* Challenge and Solution */}
         {data.projectDescription && (
            <section className="py-20 px-5 md:px-[40px]  relative">
               <div className=" mx-auto ">
                  <motion.div
                     className="text-center mb-16"
                     initial={{ opacity: 0, y: 20 }}
                     whileInView={{ opacity: 1, y: 0 }}
                     viewport={{ once: true, margin: "-100px" }}
                     transition={{ duration: 0.6 }}
                  >
                     <SectionTitle className=" mb-4">
                        Challenges & Solutions
                     </SectionTitle>
                     <SectionSubtitle className="m-auto">
                        Discover how Cordly addresses common trading challenges
                        with innovative solutions
                     </SectionSubtitle>
                  </motion.div>

                  <div className="grid lg:grid-cols-2 gap-12 items-center">
                     {/* Left side: Challenge selection */}
                     <motion.div
                        ref={challengesSolutionsRef}
                        className="space-y-4"
                        variants={containerVariants}
                        initial="hidden"
                        animate={
                           challengesSolutionsIsInView ? "visible" : "hidden"
                        }
                     >
                        {data.projectDescription.challengesSection.map(
                           (challenge: any, index: number) => (
                              <motion.div
                                 key={challenge.id}
                                 variants={itemVariants}
                                 className={`p-4 md:p-6 rounded-xl cursor-pointer transition-all duration-300 border border-l-4  ${
                                    activeChallenge === challenge.id
                                       ? " bg-gradient-to-tl from-[#0a0a0a] to-[#676767]/20 shadow-lg border-[#676767]"
                                       : "bg-gradient-to-br from-[#0a0a0a] to-[#676767]/0 hover:bg-gradient-to-br hover:from-[#0a0a0a] hover:to-[#676767]/30 hover:shadow-md  primaryBorder"
                                 }`}
                                 onClick={() =>
                                    setActiveChallenge(challenge.id)
                                 }
                              >
                                 <div className="flex items-center">
                                    <div
                                       className={`p-3 rounded-full mr-4 ${
                                          activeChallenge === challenge.id
                                             ? " bg-gradient-radial from-[#0a0a0a] via-[#0a0a0a] to-[#676767]"
                                             : "bg-gradient-radial from-[#676767] via-[#676767] to-[#0a0a0a] text-black"
                                       }`}
                                    >
                                       <Icon
                                          icon={challenge.icon}
                                          width="24"
                                          height="24"
                                       />
                                    </div>
                                    <div>
                                       <h3 className="text-lg font-semibold mb-1">
                                          {challenge.title}
                                       </h3>
                                       {/* <Text className="text-start">
                                                {challenge.challenge}
                                             </Text> */}
                                    </div>
                                 </div>
                              </motion.div>
                           )
                        )}
                     </motion.div>

                     {/* Right side: Solution visualization */}
                     <div className=" rounded-2xl shadow-xl overflow-hidden border primaryBorder min-h-[32em] ">
                        <AnimatePresence mode="popLayout">
                           {data.projectDescription.challengesSection
                              .filter(
                                 (challenge: any) =>
                                    challenge.id === activeChallenge
                              )
                              .map((challenge: any) => (
                                 <motion.div
                                    key={challenge.id}
                                    initial={{ opacity: 0, y: 500 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{
                                       opacity: 0,
                                       y: -20,
                                       // zIndex: -10,
                                    }}
                                    transition={{
                                       type: "spring",
                                       duration: 0.5,
                                       stiffness: 100,
                                       damping: 30,
                                    }}
                                    className=" p-4 md:p-8 overflow-hidden"
                                 >
                                    <div className="flex items-start md:items-center mb-6 ">
                                       <div className="w-9 h-9 md:w-12 hidden  md:h-12 rounded-full bg-gradient-radial from-red-500/20 vai-red-500/10 to-[#0a0a0a] md:flex items-center justify-center text-red-500 mr-2 md:mr-4">
                                          <Icon
                                             icon="simple-line-icons:close"
                                             className="text-lg md:text-3xl"
                                          />
                                       </div>
                                       <div className="flex-1 bg-gradient-to-tl to-red-500/10 via-red-500/5 from-[#0a0a0a] rounded-lg p-3 border-red-500/20 border">
                                          <h4 className="font-semibold  text-red-700 mb-1">
                                             The Challenge
                                          </h4>
                                          <Text className="text-start">
                                             {challenge.challenge}
                                          </Text>
                                       </div>
                                    </div>

                                    <motion.div
                                       className="my-6 flex justify-center"
                                       animate={{
                                          y: [0, -10, 0],
                                       }}
                                       transition={{
                                          duration: 0.5,
                                          repeat: Number.POSITIVE_INFINITY,
                                          repeatType: "reverse",
                                       }}
                                    >
                                       <Icon
                                          icon="formkit:arrowright"
                                          className="h-8 w-8  transform textColorSecondary rotate-90"
                                       />
                                    </motion.div>

                                    <div className="flex items-center">
                                       <div className="w-9 h-9 md:w-12 hidden md:h-12  rounded-full bg-gradient-radial from-green-500/40 via-gray-500/20 to-[#0a0a0a] md:flex items-center justify-center text-green-500 mr-2 md:mr-4">
                                          <Icon
                                             icon="gg:check-o"
                                             className="text-lg md:text-3xl"
                                          />
                                       </div>
                                       <div className="flex-1 bg-gradient-to-tl to-green-500/10 via-green-500/5 from-[#0a0a0a] rounded-lg p-3 border-green-500/20 border">
                                          <h4 className="font-semibold text-green-700 mb-1">
                                             Our Solution
                                          </h4>
                                          <Text className="text-start">
                                             {challenge.solution}
                                          </Text>
                                       </div>
                                    </div>

                                    <motion.div
                                       className="mt-8 p-4  secondaryBg rounded-lg border primaryBorder flex items-center"
                                       initial={{
                                          scale: 0.9,
                                          opacity: 0,
                                       }}
                                       animate={{
                                          scale: 1,
                                          opacity: 1,
                                       }}
                                       transition={{ delay: 0.3 }}
                                    >
                                       <Icon
                                          icon="lucide:zap"
                                          className="h-6 w-6 text-blue-500 mr-3"
                                       />

                                       <p className="text-blue-700 font-medium">
                                          Join thousands of traders who have
                                          overcome this challenge with Cordly
                                       </p>
                                    </motion.div>
                                 </motion.div>
                              ))}
                        </AnimatePresence>
                     </div>
                  </div>
               </div>
            </section>
         )}

         <section className=" m-auto max-w-[1320px] py-0 md:py-20 px-5 md:px-[40px]  relative">
            <div>
               <motion.div
                  className="text-center mb-6 space-y-3"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 0.6 }}
               >
                  <SectionTitle>
                     {data.projectDescription.implementationSection.title}
                  </SectionTitle>
                  <SectionSubtitle className="m-auto lg:max-w-5xl">
                     {data.projectDescription.implementationSection.subTitle}
                  </SectionSubtitle>
               </motion.div>

               <motion.div
                  ref={ref}
                  className="grid  lg:grid-cols-5 gap-3 md:gap-6"
                  variants={containerVariants}
                  initial="hidden"
                  animate={isInView ? "visible" : "hidden"}
               >
                  {data.projectDescription.implementationSection.texts.map(
                     (step: any, index: number) => (
                        <ImplementationStep
                           key={index}
                           number={index + 1}
                           title={step.title}
                           description={step.para}
                           index={index}
                           // className={cn({
                           //    "col-span-3 ":
                           //       index === 0 || index === 3 || index === 4,
                           //    "col-span-2": index === 1 || index === 2,
                           // })}
                           className={cn({
                              "lg:col-span-3": [0, 3, 4, 7, 21, 22].includes(
                                 index
                              ),
                              "lg:col-span-2": [1, 2, 5, 6, 23, 24].includes(
                                 index
                              ),
                              "col-span-1": ![
                                 0, 1, 2, 3, 4, 5, 6, 7, 21, 22, 23, 24,
                              ].includes(index),
                              "last:col-span-full":
                                 data.projectDescription.implementationSection
                                    .texts.length %
                                    2 ===
                                 1,
                           })}
                        />
                     )
                  )}
               </motion.div>
            </div>
         </section>

         {data.results && data.results.length > 0 && (
            <section className="py-10 mt-5 md:py-20 px-5 md:px-[40px] relative space-y-10 md:space-y-20 secondaryBg">
               {/* <div className="absolute inset-0 secondaryBg  z-0"></div> */}

               <div className=" mx-auto relative z-10">
                  <SectionTitle className="mb-10">
                     <motion.h2
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8 }}
                     >
                        Key Results
                     </motion.h2>
                  </SectionTitle>

                  <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-2 md:gap-6">
                     {data.results.map((result: any, i: number) => (
                        <motion.div
                           key={i}
                           className=" backdrop-blur-sm p-6 rounded-xl text-center border primaryBorder bg-[#000] relative overflow-hidden group hover:border-[#626262]/50"
                           initial={{ opacity: 0, y: 20 }}
                           whileInView={{ opacity: 1, y: 0 }}
                           viewport={{ once: true }}
                           transition={{ duration: 0.3, delay: i * 0.1 }}
                           whileHover={{
                              y: -5,
                              boxShadow: `0 10px 30px -15px rgba(245, 245, 253, 0.3)`,
                           }}
                        >
                           {/* Background glow */}
                           <motion.div
                              className="absolute inset-0 bg-[#626262]/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                              animate={{
                                 scale: [1, 1.2, 1],
                              }}
                              transition={{
                                 duration: 3,
                                 repeat: Number.POSITIVE_INFINITY,
                                 repeatType: "reverse",
                              }}
                           />

                           <motion.div
                              className="text-4xl font-bold mb-2 text-[#1463fd] "
                              initial={{ scale: 0.8 }}
                              whileInView={{ scale: 1 }}
                              viewport={{ once: true }}
                              transition={{
                                 duration: 0.5,
                                 delay: i * 0.1 + 0.3,
                              }}
                           >
                              {result.value}
                           </motion.div>
                           <div className="text-gray-300">{result.label}</div>
                        </motion.div>
                     ))}
                  </div>
               </div>
               {/* {data.projectDescription.resultsOutcomes && (
                  <motion.div
                     initial={{ opacity: 0, y: 20 }}
                     whileInView={{ opacity: 1, y: 0 }}
                     viewport={{ once: true }}
                     transition={{ duration: 0.8 }}
                     className="secondaryBg backdrop-blur-sm p-3 md:p-5 lg:p-8 rounded-xl border primaryBorder relative overflow-hidden lg:col-span-2"
                  >
                     <div className="absolute top-0 left-0 w-full h-1 bg-[#1463fd] "></div>

                     <h3 className="text-xl md:text-2xl font-bold mb-3 flex items-center gap-1.5 md:gap-3">
                        <div className=" bg-black  border primaryBorder p-1 md:p-2 rounded-lg">
                           <Icon
                              icon="pajamas:search-results"
                              className=" text-xl"
                           />
                        </div>
                        {data.projectDescription.resultsOutcomes.title}
                     </h3>

                     <Text
                        className="text-start lg:max-w-full  font-semibold relative z-10 mb-6"
                        textSize="lg"
                     >
                        {data.projectDescription.resultsOutcomes.subTitle}
                     </Text>

                     <div className=" lg:grid-cols-1 grid gap-y-3 gap-x-5  lg:gap-x-16">
                        {data.projectDescription.resultsOutcomes.texts.map(
                           (item: any, index: number) => (
                              <div
                                 className={cn("space-y-2", {
                                    "last:col-span-full":
                                       data.projectDescription.resultsOutcomes
                                          .texts.length %
                                          2 ===
                                       1,
                                 })}
                              >
                                 <div className="flex relative ">
                                    {!item.title && (
                                       <span className="text-2xl font-bold opacity-50 absolute -top-1 textColorSecondary ">
                                          0{index + 1}.
                                       </span>
                                    )}
                                    <Text
                                       className={cn(
                                          " text-justify lg:max-w-full relative z-10",
                                          {
                                             "ps-10":
                                                data.projectDescription
                                                   .resultsOutcomes.texts
                                                   .length > 1,
                                          }
                                       )}
                                    >
                                       {item.para}
                                    </Text>
                                 </div>
                              </div>
                           )
                        )}
                     </div>

                     
                     <div className="absolute -bottom-10 -right-10 text-9xl opacity-5">
                        <Icon icon="pajamas:search-results" />
                     </div>
                  </motion.div>
               )} */}
            </section>
         )}

         {/* Key Features */}
         {data.keyFeatures && data.keyFeatures.length > 0 && (
            <section
               id="features"
               className=" py-10 md:py-20 relative px-5 md:px-[40px] space-y-20"
               ref={featuresRef}
            >
               {/* <div className="absolute  z-0"></div> */}

               <div className=" relative z-10">
                  <motion.div
                     className="text-center max-w-7xl mx-auto mb-6 space-y-2"
                     initial={{ opacity: 0, y: 20 }}
                     animate={{
                        opacity: featuresInView ? 1 : 0,
                        y: featuresInView ? 0 : 20,
                     }}
                     transition={{ duration: 0.8 }}
                  >
                     <SectionTitle>Key Features</SectionTitle>
                     <SectionSubtitle className=" m-auto">
                        {`Our ${data.category.toLowerCase()} solution delivers exceptional features designed to meet the specific needs of ${
                           data.client
                        }.`}
                     </SectionSubtitle>
                  </motion.div>

                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-2 m-auto">
                     {data.keyFeatures.map((feature: any, i: number) => (
                        <motion.div
                           key={i}
                           className="bg-gradient-to-br from-[#000] to-[#626262]/10 backdrop-blur-sm p-6 rounded-xl border primaryBorder  transition-all duration-300 group relative overflow-hidden"
                           initial={{ opacity: 0, y: 20 }}
                           animate={{
                              opacity: featuresInView ? 1 : 0,
                              y: featuresInView ? 0 : 20,
                           }}
                           transition={{ duration: 0.1, delay: i * 0.1 }}
                           whileHover={{
                              y: -5,
                              boxShadow: `0 10px 30px -15px rgba(245, 245, 245, 0.5)`,
                           }}
                        >
                           {/* Hover effect */}
                           <motion.div className="absolute inset-0 bg-gradient-to-r from-[#626262]/10 to-[#000] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                           <div className="flex items-start gap-4 relative z-10">
                              <div className="bg-gradient-to-br from-[#000] to-[#626262]/20 p-3 rounded-lg flex-shrink-0">
                                 <Icon
                                    icon={feature.icon}
                                    className="text-2xl"
                                 />
                              </div>

                              <div>
                                 <h3 className="text-xl font-semibold mb-2">
                                    {feature.title}
                                 </h3>
                                 <Text className="text-start">
                                    {feature.description}
                                 </Text>
                              </div>
                           </div>

                           {/* Corner accent */}
                           <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-gradient-to-tl from-[#626262]/30 to-transparent rounded-tl-xl"></div>
                        </motion.div>
                     ))}
                  </div>
               </div>

               {/* {data.projectDescription.featuresandFunctionalities && (
                  <motion.div
                     initial={{ opacity: 0, y: 20 }}
                     whileInView={{ opacity: 1, y: 0 }}
                     viewport={{ once: true }}
                     transition={{ duration: 0.8 }}
                     className="secondaryBg backdrop-blur-sm p-8 rounded-xl border primaryBorder relative overflow-hidden lg:col-span-2"
                  >
                     <div className="absolute top-0 left-0 w-full h-1 bg-[#1463fd] "></div>

                     <h3 className="text-2xl font-bold mb-3 flex items-center gap-3">
                        <div className=" bg-black  border primaryBorder p-2 rounded-lg">
                           <Icon
                              icon="ri:function-add-line"
                              className=" text-xl"
                           />
                        </div>
                        {
                           data.projectDescription.featuresandFunctionalities
                              .title
                        }
                     </h3>

                     <Text className="text-start lg:max-w-full relative mb-6 z-10">
                        {
                           data.projectDescription.featuresandFunctionalities
                              .subTitle
                        }
                     </Text>

                     <div className=" lg:grid-cols-1 grid gap-y-3 gap-x-5 mt-5 lg:gap-x-16">
                        {data.projectDescription.featuresandFunctionalities.texts.map(
                           (item: any, index: number) => (
                              <div
                                 className={cn("space-y-2 ", {
                                    "last:col-span-full":
                                       data.prjectDescription
                                          .featuresandFunctionalities.texts
                                          .length %
                                          2 ===
                                       1,
                                 })}
                              >
                                 {item.title && (
                                    <div className="flex relative " key={index}>
                                       <span className="text-4xl font-bold opacity-50 absolute -top-1.5 textColorSecondary ">
                                          0{index + 1}.
                                       </span>
                                       <h3 className=" relative text-2xl z-10 ps-14">
                                          {item.title}
                                       </h3>
                                    </div>
                                 )}
                                 <div className="flex relative " key={index}>
                                    {!item.title && (
                                       <span className="text-2xl font-bold opacity-50 absolute -top-1 textColorSecondary ">
                                          0{index + 1}.
                                       </span>
                                    )}
                                    <Text
                                       className={cn(
                                          " text-justify lg:max-w-full relative z-10",
                                          { " ps-10": !item.title }
                                       )}
                                    >
                                       {item.para}
                                    </Text>
                                 </div>
                              </div>
                           )
                        )}
                     </div>

                     <div className="absolute -bottom-10 -right-10 text-9xl opacity-5">
                        <Icon icon="ri:function-add-line" />
                     </div>
                  </motion.div>
               )} */}
            </section>
         )}

         {/* Development Process */}
         {data.process && data.process.length > 0 && (
            <section className="py-10 md:py-20 mt-20 px-10 relative secondaryBg">
               <div className="absolute inset-0 "></div>

               <div className=" mx-auto relative z-10">
                  <SectionTitle className="mb-10">
                     <motion.h2
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8 }}
                     >
                        Development Process
                     </motion.h2>
                  </SectionTitle>

                  <div className="relative ">
                     {/* Vertical line */}
                     <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-px bg-[#646464] transform md:translate-x-[-0.5px]"></div>

                     {/* {data.process.map((step: any, i: number) => (
                        <motion.div
                           key={i}
                           className={cn(
                              "flex flex-col md:flex-row items-start md:items-center gap-2 md:gap-8 mb-6 md:mb-12 relative",
                              {
                                 "md:flex-row": i % 2 === 0,
                                 "md:flex-row-reverse": i % 2 !== 0,
                              }
                           )}
                           initial={{ opacity: 0, y: 20 }}
                           whileInView={{ opacity: 1, y: 0 }}
                           viewport={{ once: true }}
                           transition={{ duration: 0.5, delay: i * 0.1 }}
                        >
                           <div
                              className={cn("flex-1 ", {
                                 "md:text-right": i % 2 === 0,
                              })}
                           >
                              <div
                                 className={cn(
                                    "inline-block ml-4 px-3 py-1 text-sm font-medium bg-[#fff] text-black rounded-full mb-2 border primaryBorder",
                                    {
                                       "md:ml-auto ": i % 2 === 0,
                                    }
                                 )}
                              >
                                 Step {i + 1}
                              </div>
                              <Text
                                 textSize="lg"
                                 className={cn(
                                    "text-lg  max-w-md lg:max-w-md text-start ps-8 md:ps-0",
                                    {
                                       "md:ml-auto md:text-end ": i % 2 === 0,
                                    }
                                 )}
                              >
                                 {step}
                              </Text>
                           </div>

                           <div className="absolute left-0 md:left-1/2 top-0 transform translate-x-[-50%] md:translate-y-[0%]">
                              <motion.div
                                 className={cn(
                                    "w-8 h-8 rounded-full bg-gradient-to-r from-[#1463fd]/30 to-[#1463fd] flex items-center justify-center",
                                    {
                                       "bg-gradient-to-l ": i % 2 === 0,
                                    }
                                 )}
                                 whileHover={{ scale: 1.2 }}
                                 transition={{
                                    type: "spring",
                                    stiffness: 400,
                                    damping: 10,
                                 }}
                              >
                                 <span className="text-sm font-bold ">
                                    {i + 1}
                                 </span>
                              </motion.div>
                           </div>

                           <div className="flex-1"></div>
                        </motion.div>
                     ))} */}
                     <div className=" mx-auto  ">
                        <div className="relative ">
                           <div className="hidden md:block absolute left-1/2 top-0 h-full w-0.5 bg-[#333333] transform -translate-x-1/2"></div>

                           <div className="space-y-16  md:space-y-10 ">
                              {data.process.map((step: any, index: number) => (
                                 <motion.div
                                    key={index}
                                    initial={{
                                       opacity: 0,
                                       x: index % 2 === 0 ? -50 : 50,
                                    }}
                                    whileInView={{ opacity: 1, x: 0 }}
                                    transition={{
                                       duration: 0.6,
                                       delay: index * 0.1,
                                    }}
                                    viewport={{ once: true, amount: 0.5 }}
                                    className={`relative flex flex-col md:flex-row items-center gap-y-10 ${
                                       index % 2 === 0
                                          ? "md:flex-row"
                                          : "md:flex-row-reverse"
                                    } mb-8`}
                                 >
                                    <div
                                       className={cn(
                                          "flex-1  order-1 md:order-none",
                                          {
                                             "md:pr-0 md:mr-12 md:text-right ml-auto":
                                                index % 2 === 0,
                                             "md:pl-12 md:text-left ":
                                                index % 2 === 1,
                                          }
                                       )}
                                    >
                                       <h3 className="text-2xl mt-4 font-bold  mb-2">
                                          {step.title}
                                       </h3>
                                       <p
                                          className={cn(
                                             "text-white/70 max-w-lg ",
                                             {
                                                "ml-auto": index % 2 === 0,
                                             }
                                          )}
                                       >
                                          {step.description}
                                       </p>
                                    </div>
                                    <div className="w-16 h-16 rounded-full bg-black border-4 primaryBorder flex items-center justify-center shadow-md mb-4 md:mb-0 relative z-10">
                                       <Icon
                                          icon={step.icon}
                                          className="w-8 h-8 text-white"
                                       />
                                       <span className="absolute -bottom-8  bg-white text-black font-secondary text-sm font-bold rounded-full w-8 h-8 flex items-center justify-center">
                                          {index + 1}
                                       </span>
                                    </div>
                                    <div
                                       className={`flex-1 ${
                                          index % 2 === 0
                                             ? "md:pl-12 "
                                             : "md:pr-12"
                                       } order-3`}
                                    ></div>
                                 </motion.div>
                              ))}
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
         )}

         {/* Project Timeline - only show if it exists */}
         {data.timeline && data.timeline.length > 0 && (
            <section className="my-20 px-5 md:px-[40px] relative">
               <div className="absolute inset-0 z-0"></div>

               <div className=" mx-auto relative z-10">
                  <motion.div
                     initial={{ opacity: 0 }}
                     whileInView={{ opacity: 1 }}
                     viewport={{ once: true }}
                     transition={{ duration: 0.8 }}
                     className="mb-6"
                  >
                     <SectionTitle>Project Timeline</SectionTitle>
                  </motion.div>

                  <div
                     className={cn("relative ", {
                        projectTimeline: !isMobile,
                        projectTimelineMobile: isMobile,
                     })}
                  >
                     {/* Horizontal line */}
                     <motion.div className="absolute left-0 right-0 top-12 h-1 bg-[#1463fd] rounded-full md:block hidden" />
                     <div className="absolute left-1/2  -translate-x-1/2  h-[100%] w-1 bg-[#1463fd] rounded-full  md:hidden"></div>

                     <div
                        className={cn(
                           "flex gap-x-5 min-w-full max-h-[100dvh]  overflow-hidden",
                           {
                              "flex-col ": isMobile,
                           }
                        )}
                     >
                        {[
                           ...data.timeline,
                           ...data.timeline,
                           ...data.timeline,
                           ...data.timeline,
                        ].map((phase: any, i: number) => (
                           <motion.div
                              key={i}
                              className=" pt-16 relative min-w-72"
                              initial={{
                                 opacity: 1,
                                 x: 0,
                                 marginRight: 10,
                              }}
                              animate={{
                                 opacity: 1,
                                 x: isMobile ? 0 : -data.timeline.length * 264,
                                 y: isMobile ? -data.timeline.length * 264 : 0,
                                 marginRight: isMobile ? 0 : 10,
                              }}
                              transition={{
                                 duration: data.timeline.length * 10,
                                 repeat: Infinity,
                                 repeatType: "loop",
                                 ease: "linear",
                              }}
                           >
                              {/* Timeline node */}
                              <div className="absolute top-12 left-1/2 transform -translate-x-1/3 md:-translate-x-1/2 -translate-y-1/2 ">
                                 <motion.div
                                    className={cn(
                                       "w-8 h-8 rounded-full flex items-center justify-center border-4 primaryBorder  ",
                                       {
                                          "bg-gradient-to-r from-[#1463fd] from-0% to-cyan-500 to-95%":
                                             phase.status === "completed" ||
                                             phase.status === "completado",
                                          "bg-gradient-to-r from-green-500 to-emerald-400":
                                             phase.status === "active" ||
                                             phase.status === "activo",
                                          "bg-gradient-to-r from-yellow-500 to-yellow-400":
                                             phase.status === "pending" ||
                                             phase.status === "pendiente",
                                       }
                                    )}
                                    whileHover={{ scale: 1.2 }}
                                    transition={{
                                       type: "spring",
                                       stiffness: 400,
                                       damping: 10,
                                    }}
                                 >
                                    {(phase.status === "completed" ||
                                       phase.status === "completado") && (
                                       <Icon
                                          icon="mdi:check"
                                          className="text-white text-sm"
                                       />
                                    )}
                                    {(phase.status === "active" ||
                                       phase.status === "activo") && (
                                       <Icon
                                          icon="mdi:play"
                                          className="text-white text-sm"
                                       />
                                    )}
                                    {(phase.status === "pending" ||
                                       phase.status === "pendiente") && (
                                       <Icon
                                          icon="mdi:clock-outline"
                                          className="text-white text-sm"
                                       />
                                    )}
                                 </motion.div>
                              </div>

                              <div className="bg-gradient-to-br from-[#0a0a0a] to-[#1463fd]/10 backdrop-blur-sm p-3 rounded-xl border  border-[#1463fd]/15 hover:border-[#1463fd]/30 transition-all duration-300 relative">
                                 <h3 className="text-lg font-semibold mb-2">
                                    {phase.phase}
                                 </h3>
                                 <span
                                    className={cn(
                                       " absolute top-2 md:-top-4 -right-2 md:-right-4 font-bold text-3xl text-[#1463fd] opacity-50 -z-10",
                                       {
                                          " text-blue-300":
                                             phase.status === "completed" ||
                                             phase.status === "completado",
                                          " text-green-300":
                                             phase.status === "active" ||
                                             phase.status === "activo",
                                          " text-yellow-300":
                                             phase.status === "pending" ||
                                             phase.status === "pendiente",
                                       }
                                    )}
                                 >
                                    {phase.id}
                                 </span>

                                 <div className="flex justify-between items-center">
                                    <span className="text-gray-400 text-sm">
                                       {phase.duration}
                                    </span>
                                    <span
                                       className={cn(
                                          "text-xs px-4 py-1 rounded-full text-gray-400",
                                          {
                                             "bg-[#1463fd]/10 text-blue-300":
                                                phase.status === "completed" ||
                                                phase.status === "completado",
                                             "bg-green-900/50 text-green-300":
                                                phase.status === "active" ||
                                                phase.status === "activo",
                                             "bg-green-900/50 text-yellow-300":
                                                phase.status === "pending" ||
                                                phase.status === "pendiente",
                                          }
                                       )}
                                    >
                                       {phase.status.charAt(0).toUpperCase() +
                                          phase.status.slice(1)}
                                    </span>
                                 </div>
                              </div>
                           </motion.div>
                        ))}
                     </div>
                  </div>
               </div>
            </section>
         )}

         {/* Team */}
         {data.team && data.team.length > 0 && (
            <section className="py-20 px-4 relative">
               <div className="absolute inset-0  z-0"></div>

               <div className="max-w-7xl mx-auto relative z-10">
                  <SectionTitle className="mb-6">
                     <motion.h2
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8 }}
                     >
                        Project Team
                     </motion.h2>
                  </SectionTitle>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                     {data.team.map((member: any, i: number) => (
                        <motion.div
                           key={i}
                           className="bg-gradient-to-br from-[#626262]/20 to-[#000]/10 backdrop-blur-sm p-6 rounded-xl border primaryBorder hover:border-white/30 transition-all duration-300 group"
                           initial={{ opacity: 0, y: 20 }}
                           whileInView={{ opacity: 1, y: 0 }}
                           viewport={{ once: true }}
                           transition={{ duration: 0.1, delay: i * 0.1 }}
                           whileHover={{
                              y: -5,
                              boxShadow: `0 10px 30px -15px rgba(245, 245, 245, 0.5)`,
                           }}
                        >
                           <div className="flex items-center gap-4 mb-4">
                              <div className="bg-gradient-to-br from-${colorScheme.secondary}-900/50 to-${colorScheme.accent}-900/50 p-3 rounded-full">
                                 <Icon
                                    icon="mdi:account"
                                    className="text-${colorScheme.secondary}-400 text-2xl"
                                 />
                              </div>
                              <h3 className="text-xl font-semibold">
                                 {member.role}
                              </h3>
                           </div>
                           <div className="bg-${colorScheme.secondary}-900/20 px-3 py-1 rounded-full inline-block">
                              <span className="text-${colorScheme.secondary}-300 text-sm">
                                 {member.expertise}
                              </span>
                           </div>
                        </motion.div>
                     ))}
                  </div>
               </div>
            </section>
         )}

         {/* Technologies */}
         {data.technologiesSection && (
            <section className="py-20 px-4 relative secondaryBg">
               <div className="absolute inset-0  z-0"></div>

               <div className=" mx-auto relative z-10">
                  <motion.div
                     className="mb-6"
                     initial={{ opacity: 0.5 }}
                     whileInView={{ opacity: 1 }}
                     viewport={{ once: true }}
                     transition={{ duration: 0.8 }}
                  >
                     <SectionTitle>
                        {data.technologiesSection.title}
                     </SectionTitle>
                  </motion.div>

                  <div className="flex flex-wrap justify-center gap-3 md:gap-6">
                     {data.technologiesSection.techData.map(
                        (tech: any, i: number) => (
                           <motion.div
                              key={i}
                              className="px-3 md:px-6 py-2 md:py-4 rounded-xl border primaryBorder  transition-all duration-300 w-32 md:w-48  cursor-pointer"
                              initial={{ opacity: 0, scale: 0.8 }}
                              whileInView={{ opacity: 1, scale: 1 }}
                              viewport={{ once: true }}
                              transition={{ duration: 0.1, delay: i * 0.1 }}
                              whileHover={{
                                 scale: 1.05,
                                 boxShadow: `0 10px 30px -15px rgba(245, 245, 245, 0.5)`,
                                 y: -5,
                              }}
                           >
                              <div className="flex items-center flex-col text-center justify-between min-h-20 max-h-28 md:max-h-40 ">
                                 <Icon
                                    icon={tech.icon}
                                    className={cn(tech.size)}
                                 />

                                 <h3 className="font-medium justify-self-end-end">
                                    {tech.title}
                                 </h3>
                              </div>
                           </motion.div>
                        )
                     )}
                  </div>
               </div>
            </section>
         )}

         {/* Gallery */}
         {/* {data.gallery && data.gallery.length > 0 && (
            <section className="py-10 md:py-20 px-5 md:px-[40px]  relative">
               <div className="absolute inset-0  z-0"></div>

               <div className="  relative z-10">
                  <SectionTitle className="mb-6">
                     <motion.h2
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8 }}
                     >
                        Project Gallery
                     </motion.h2>
                  </SectionTitle>

                  <div className="relative  m-auto grid lg:grid-cols-12 gap-x-2 xl:gap-x-4 lg:h-[38rem]">
                     <motion.div
                        className="relative rounded-xl overflow-hidden border primaryBorder shadow-lg shadow-[#1463fd]/20 lg:col-span-10"
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.5 }}
                     >
                        <div className="aspect-video relative">
                           <Image
                              src={
                                 data.gallery[currentImageIndex] ||
                                 "/placeholder.svg"
                              }
                              alt={`${data.title} gallery image ${
                                 currentImageIndex + 1
                              }`}
                              fill
                              className="object-cover"
                           />
                        </div>

                        {/* Navigation controls 
                        <motion.button
                           className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 backdrop-blur-sm p-2 rounded-full"
                           onClick={prevImage}
                           whileHover={{ scale: 1.1 }}
                           whileTap={{ scale: 0.9 }}
                        >
                           <Icon
                              icon="mdi:chevron-left"
                              className="text-white text-2xl"
                           />
                        </motion.button>

                        <motion.button
                           className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 backdrop-blur-sm p-2 rounded-full"
                           onClick={nextImage}
                           whileHover={{ scale: 1.1 }}
                           whileTap={{ scale: 0.9 }}
                        >
                           <Icon
                              icon="mdi:chevron-right"
                              className="text-white text-2xl"
                           />
                        </motion.button>

                        {/* Image indicators 
                        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                           {data.gallery.map((_: any, i: number) => (
                              <button
                                 key={i}
                                 className={`w-3 h-3 rounded-full ${
                                    i === currentImageIndex
                                       ? "bg-[#1463fd]"
                                       : "bg-gray-500/50"
                                 }`}
                                 onClick={() => setCurrentImageIndex(i)}
                              />
                           ))}
                        </div>
                     </motion.div>

                     {/* Thumbnail preview 
                     <div className="lg:col-span-2 lg:max-h-[28.8rem]  xl:max-h-[38rem] overflow-auto p-3">
                        <div className="flex lg:flex-col  gap-y-2 justify-center  space-x-1 lg:space-x-0">
                           {data.gallery.map((image: string, i: number) => (
                              <motion.button
                                 key={i}
                                 className={` relative rounded-md overflow-hidden border-2 ${
                                    i === currentImageIndex
                                       ? "border-[#1463fd]"
                                       : "border-transparent"
                                 }`}
                                 onClick={() => setCurrentImageIndex(i)}
                                 whileHover={{ scale: 1.05 }}
                                 whileTap={{ scale: 0.95 }}
                              >
                                 <div className="w-16 lg:w-full h-12 lg:h-[72px] xl:h-[6.7rem] relative">
                                    <Image
                                       src={image || "/placeholder.svg"}
                                       alt={`Thumbnail ${i + 1}`}
                                       fill
                                       className="object-cover"
                                    />
                                 </div>
                              </motion.button>
                           ))}
                        </div>
                     </div>
                  </div>
               </div>
            </section>
         )} */}

         {data.gallery && data.gallery.length > 0 && (
            <section className="py-10 md:py-20 px-5 md:px-[40px]  relative">
               <div className="absolute inset-0  z-0"></div>

               <div className="  relative z-10">
                  <SectionTitle className="mb-6">
                     <motion.h2
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8 }}
                     >
                        Project Gallery
                     </motion.h2>
                  </SectionTitle>

                  <div className="relative  m-auto gap-2 md:gap-4 lg:gap-y-4 lg:gap-x-6  grid grid-cols-6 max-w-6xl">
                     {data.gallery.map((image: string, index: number) => (
                        <motion.div
                           className={cn(
                              "relative rounded-lg md:rounded-xl overflow-hidden border primaryBorder shadow-sm md:shadow-lg shadow-[#1463fd]/20",
                              {
                                 "col-span-4 row-span-2":
                                    data.gallery.length > 5 && index === 0,
                                 "col-span-3":
                                    data.gallery.length <= 5 &&
                                    (index === 0 || index === 1) &&
                                    data.gallery.length !== 3,
                                 "col-span-2":
                                    (data.gallery.length > 5 && index !== 0) ||
                                    (data.gallery.length <= 5 && index > 1) ||
                                    data.gallery.length === 3,
                              }
                           )}
                           initial={{ opacity: 0, y: 20 }}
                           whileInView={{ opacity: 1, y: 0 }}
                           whileHover={{ scale: 1.05, zIndex: 100 }}
                           viewport={{ once: true }}
                           transition={{ duration: 0.5 }}
                        >
                           <motion.div className="aspect-video relative">
                              {/* <Image
                              src={
                                 data.gallery[currentImageIndex] ||
                                 "/placeholder.svg"
                              }
                              alt={`${data.title} gallery image ${
                                 currentImageIndex + 1
                              }`}
                              fill
                              className="object-cover"
                           /> */}
                              <Image
                                 src={image}
                                 alt={`${data.title} gallery image ${
                                    currentImageIndex + 1
                                 }`}
                                 fill
                                 priority={true}
                                 className={cn(
                                    "object-cover hover:scale-110 transition-transform duration-300"
                                 )}
                              />
                           </motion.div>
                        </motion.div>
                     ))}
                  </div>
               </div>
            </section>
         )}

         {/* conclusionSection */}
         {data.conclusionSection && (
            <section className="py-10 md:py-20 relative">
               <div className="absolute inset-0 "></div>

               <div className="mx-auto px-5 md:px-[40px]  relative z-10">
                  <motion.div
                     initial={{ opacity: 0, y: 20 }}
                     whileInView={{ opacity: 1, y: 0 }}
                     viewport={{ once: true }}
                     transition={{ duration: 0.8 }}
                     className="secondaryBg backdrop-blur-sm p-4 md:p-8 rounded-xl border primaryBorder relative overflow-hidden "
                  >
                     <div className="absolute top-0 left-0 w-full h-1 bg-[#626262] "></div>

                     <h3 className="text-2xl font-bold mb-3 flex items-center gap-3">
                        <div className=" bg-black  border primaryBorder p-2 rounded-lg">
                           <Icon
                              icon="line-md:check-list-3"
                              className=" text-xl"
                           />
                        </div>
                        {data.conclusionSection.title}
                     </h3>

                     <Text
                        className="text-start lg:max-w-full relative z-10 mb-6 font-semibold"
                        textSize="lg"
                     >
                        {data.conclusionSection.subTitle}
                     </Text>

                     <div className=" lg:grid-cols-1 grid gap-0 gap-y-3 md:gap-x-12">
                        {data.conclusionSection.texts.map(
                           (item: any, index: number) => (
                              <div
                                 className={cn({
                                    "last:col-span-full":
                                       data.conclusionSection.texts.length %
                                          2 ===
                                       1,
                                 })}
                              >
                                 <h3 className="text-gray-300 relative text-2xl z-10">
                                    {item.title}
                                 </h3>
                                 <Text className="text-justify lg:max-w-full relative z-10">
                                    {item.para}
                                 </Text>
                              </div>
                           )
                        )}
                     </div>

                     <div className="absolute -bottom-10 -right-10 text-9xl opacity-5">
                        <Icon icon="line-md:check-list-3" />
                     </div>
                  </motion.div>
               </div>
            </section>
         )}

         <Divider className="bg-[#262626] mt-5" />
         {/* Related Projects - only show if they exist */}

         <section className="py-10 px-4 md:py-20 relative">
            <div className="absolute inset-0  z-0"></div>

            <div className=" mx-auto relative z-10 ">
               <motion.div
                  className="mb-6"
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8 }}
               >
                  <SectionTitle>More Projects</SectionTitle>
               </motion.div>

               <div className="grid gap-4 lg:gap-8 ">
                  <OurPortfolio langText={portfolioSection} />
               </div>
            </div>
         </section>
      </>
   );
};

export default NewProjectSection;
