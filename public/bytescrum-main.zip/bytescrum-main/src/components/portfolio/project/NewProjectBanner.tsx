"use client";
import { PortfolioBackgroundAnimation } from "@/components/ui";
import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import ProjectBannerCard from "./ProjectBannerCard";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import { cn } from "@nextui-org/react";

interface IProps {
   data: any;
}

const NewProjectBanner = ({ data }: IProps) => {

   const [windowSize, setWindowSize] = useState({ width: 0, height: 0 });
   useEffect(() => {
      if (typeof window !== "undefined") {
         setWindowSize({
            width: window.innerWidth,
            height: window.innerHeight,
         });

         const handleResize = () => {
            setWindowSize({
               width: window.innerWidth,
               height: window.innerHeight,
            });
         };

         window.addEventListener("resize", handleResize);
         return () => window.removeEventListener("resize", handleResize);
      }
   }, []);
   // NOTE: for tailwind v-4
   // const getBgClass = (index: number) => {
   //    switch (index % 4) {
   //       case 0:
   //          return " bg-radial from-[#759ff0] from-0% to-[#1463fd] to-70% ";
   //       case 1:
   //          return " bg-radial from-[#87f542] from-0% to-[#9eeb6e] to-70% ";
   //       case 2:
   //          return "bg-radial from-[#cc84f5] from-0% to-[#a203ff] to-70%";
   //       default:
   //          return " bg-radial from-[#89d6f0] from-0% to-[#05bdfa] to-70%";
   //    }
   // };
   const getBgClass = (index: number) => {
      switch (index % 4) {
         case 0:
            return "bg-[radial-gradient(circle,#759ff0_0%,#1463fd_70%)]  ";
         case 1:
            return "bg-[radial-gradient(circle,#87f542_0%,#9eeb6e_70%)] ";
         case 2:
            return "bg-[radial-gradient(circle,#cc84f5_0%,#a203ff_70%)] ";
         default:
            return "bg-[radial-gradient(circle,#89d6f0_0%,#05bdfa_70%)] ";
      }
   };

   return (
      <div
         className={twMerge(
            clsx(
               "relative overflow-hidden px-[22px]  md:px-[54px]  items-center justify-normal   z-20"
            )
         )}
      >
         <PortfolioBackgroundAnimation data={data} />

         {/* Floating particles */}
         {Array.from({ length: 50 }).map((_, index) => {
            const elementSize = Math.random() * 30 + 5;
            return (
               <motion.div
                  key={`particle-${index}`}
                  initial={{
                     x: Math.random() * windowSize.width,
                     y: Math.random() * windowSize.height,
                     scale: Math.random() * 0.1 + 0.1,
                     opacity: Math.random() * 0.5,
                  }}
                  animate={{
                     x: [
                        Math.random() * windowSize.width,
                        Math.random() * windowSize.width,
                        Math.random() * windowSize.width,
                     ],
                     y: [
                        Math.random() * windowSize.height,
                        Math.random() * windowSize.height,
                        Math.random() * windowSize.height,
                     ],
                     opacity: [
                        Math.random() * 0.5,
                        Math.random() * 1,
                        Math.random() * 0.5,
                     ],
                     scale: [
                        Math.random() * 0.1 + 0.1,
                        Math.random() * 0.9 + 0.9,
                        Math.random() * 0.1 + 0.1,
                     ],
                     boxShadow: `0 0 ${
                        index % 4 === 0 ? 10 : 20
                     }px rgba(20, 99, 253, 0.5)`,
                  }}
                  transition={{
                     duration: Math.random() * 20 + 10,
                     repeat: Number.POSITIVE_INFINITY,
                     repeatType: "reverse",
                  }}
                  className={cn("absolute rounded-full ", getBgClass(index))}
                  style={{
                     width: elementSize,
                     height: elementSize,

                     // background:
                     //    index % 4 === 0
                     //       ? "radial-gradient(circle, rgba(244,114,182,0.2) 0%, rgba(244,114,182,0) 70%)"
                     //       : index % 4 === 1
                     //       ? "radial-gradient(circle, rgba(96,165,250,0.2) 0%, rgba(96,165,250,0) 70%)"
                     //       : index % 4 === 2
                     //       ? "radial-gradient(circle, rgba(52,211,153,0.2) 0%, rgba(52,211,153,0) 70%)"
                     //       : "radial-gradient(circle, rgba(251,146,60,0.2) 0%, rgba(251,146,60,0) 70%)",
                  }}
               />
            );
         })}

         <div className="grid place-items-center py-10 md:py-14 md:gap-[10px]">
            <p
               className="poppins text-[#b7b7b7] text-[14px] md:text-[18px] uppercase tracking-wider"
               data-aos="zoom-in"
               data-aos-easing="ease-out-cubic"
               data-aos-anchor-placement="top-bottom"
            >
               {data.technology}
            </p>
            <h1
               className="text-[35px] md:text-[70px] md:leading-[80px] font-light  poppins text-center "
               data-aos="zoom-in"
               data-aos-delay={300}
               data-aos-easing="ease-out-cubic"
               data-aos-anchor-placement="top-bottom"
            >
               <span className="font-bold ">{data.project}</span>
            </h1>
            <div
               className="mt-4  px-4 xs:px-8 md:px-0 overflow-hidden "
               data-aos="fade-up"
               data-aos-easing="ease-out-cubic"
               data-aos-delay={500}
               data-aos-anchor-placement="top-bottom"
            >
               <ProjectBannerCard cards={data.cardData} />
            </div>
         </div>
      </div>
   );
};

export default NewProjectBanner;
