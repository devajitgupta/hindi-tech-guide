import { motion, useAnimation } from "framer-motion";
import { useEffect } from "react";
import { useMediaQueries } from "@react-hook/media-query";
import clsx from "clsx";

interface SvgAttributes {
   svgWidth: string;
   svgHeight: string;
   border: string;
}

const useSvgAttributes = (): SvgAttributes => {
   const { matches } = useMediaQueries({
      sm: "only screen and (min-width: 319.99px) and (max-width: 375.99px)",
      md: "only screen and (min-width: 376px) and (max-width: 639.99px)",
      lg: "only screen and (min-width: 640px) and (max-width: 767.99px)",
      xl: "only screen and (min-width: 768px) and (max-width: 1024px)",
      xxl: "only screen and (min-width: 1024px) and (max-width: 1200px) ",
      //   xxl: "only screen and (min-width: 1536px)",
   });

   const activeQuery = matches.md
      ? "sm"
      : matches.sm
      ? "md"
      : matches.lg
      ? "lg"
      : matches.xl
      ? "xl"
      : matches.xxl
      ? "xxl"
      : "default";

   //    let svgWidth, svgHeight, border;

   const getSvgAttributes = (query: typeof activeQuery): SvgAttributes => {
      switch (activeQuery) {
         case "sm":
            return {
               svgWidth: "100",
               svgHeight: "160",
               border: "border border-orange-500",
            };
         case "md":
            return {
               svgWidth: "100",
               svgHeight: "160",
               border: "border border-yellow-500",
            };

         case "lg":
            return {
               svgWidth: "120",
               svgHeight: "190",
               border: "border border-green-500",
            };

         case "xl":
            return {
               svgWidth: "120",
               svgHeight: "190",
               border: "border border-red-500",
            };
         case "xxl":
            return {
               svgWidth: "170",
               svgHeight: "250",
               border: "border border-blue-500",
            };
         default:
            return {
               svgWidth: "200",
               svgHeight: "280",
               border: "border border-white-500",
            };
      }
   };

   return getSvgAttributes(activeQuery);
};

const icon = {
   hidden: {
      opacity: 1,
      pathLength: 0,
   },
   visible: {
      opacity: 1,
      pathLength: 1,
   },
};

const useAnimatedLine = (delay: any, repeatDelay: any, duration: any) => {
   const controls = useAnimation();

   useEffect(() => {
      controls.start("visible", {
         // repeat: Infinity,
         repeatType: "loop",
         repeatDelay: repeatDelay,
         duration: duration,
         delay: delay,
         ease: "easeInOut",
      });
   }, [controls, delay, repeatDelay, duration]);

   return controls;
};

interface Iprops {
   className: string;
}

const BannerElement = ({ className }: Iprops) => {
   const strokeColor = "#474747";
   const controls1 = useAnimatedLine(0, 0, 1.5);
   const { svgHeight = 260, svgWidth = 340 } = useSvgAttributes();

   return (
      <motion.svg
         width={svgWidth}
         height={svgHeight}
         viewBox="0 0 336 390"
         fill="none"
         xmlns="http://www.w3.org/2000/svg"
         animate={{ rotate: 360, scale: [1.2, 1, 1.2] }}
         transition={{
            duration: 100,

            mass: 100,
            repeat: Infinity,
            repeatType: "mirror",
            ease: "easeInOut",
         }}
         className={clsx(className)}
      >
         <motion.path
            d="M20 67.5L335 1"
            strokeWidth="3"
            strokeLinecap="round"
            stroke={strokeColor}
            variants={icon}
            initial="hidden"
            animate={controls1}
         />
         <motion.path
            d="M110.5 98.5L335 1"
            strokeWidth="3"
            strokeLinecap="round"
            stroke={strokeColor}
            variants={icon}
            initial="hidden"
            animate={controls1}
         />
         <motion.path
            d="M227 199L335 1L306 313"
            strokeWidth="3"
            strokeLinecap="round"
            stroke={strokeColor}
            variants={icon}
            initial="hidden"
            animate={controls1}
         />
         <motion.path
            d="M227 199L1 389L306 313"
            strokeWidth="3"
            strokeLinecap="round"
            stroke={strokeColor}
            variants={icon}
            initial="hidden"
            animate={controls1}
         />
         <motion.path
            d="M20 67.5L1 389L110.5 98.5"
            strokeWidth="3"
            strokeLinecap="round"
            stroke={strokeColor}
            variants={icon}
            initial="hidden"
            animate={controls1}
         />
         <motion.path
            d="M20 67.5L110 98.5L226.5 199L306 313"
            strokeWidth="3"
            strokeLinecap="round"
            stroke={strokeColor}
            variants={icon}
            initial="hidden"
            animate={controls1}
         />
      </motion.svg>
   );
};

export default BannerElement;
