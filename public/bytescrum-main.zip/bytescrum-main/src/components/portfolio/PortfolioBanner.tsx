"use client";
import PageBanner from "../PageBanner";
import clsx from "clsx";
import { usePathname } from "next/navigation";
import dynamic from "next/dynamic";
import { TLocale } from "@/i18n-config";
const BannerElement = dynamic(() => import("./BannerElement"), {
   ssr: false,
});
interface Iprops {
   langText: any;
}

const PortfolioBanner = ({ langText }: Iprops) => {
   const pathName = usePathname();
   return (
      <PageBanner
         bgPath={"portfolio/portfolioPage/banner.png"}
         className="relative overflow-hidden"
      >
         <BannerElement className=" absolute -left-10 -bottom-[38px] md:-left-16 md:-bottom-5" />
         <BannerElement className=" absolute -right-5 -top-[70px] md:-right-5 md:-top-24" />
         <div className="grid place-items-center md:gap-[10px]">
            <h1
               className="text-[35px] md:text-[70px] md:leading-[80px] font-bold  poppins text-center"
               data-aos="zoom-in"
               data-aos-easing="ease-out-cubic"
               data-aos-anchor-placement="top-bottom"
            >
               {langText.portfolio.pageTitleLineOne} <br />
               <span className="font-light">
                  {" "}
                  {langText.portfolio.pageTitleLineTwo}
               </span>
            </h1>
            <p
               className="poppins text-[#b7b7b7] text-[14px] md:text-[18px]"
               data-aos="zoom-in"
               data-aos-easing="ease-out-cubic"
               data-aos-delay={500}
               data-aos-anchor-placement="top-bottom"
            >
               {langText.portfolio.links.map((link: any, index: any) => (
                  <span
                     className={clsx(
                        "text-white first:border-r first:px-3 px-2 cursor-pointer",
                        {
                           "first:text-[#b7b7b7]": pathName !== `/${pathName}`,
                        }
                     )}
                     key={index}
                  >
                     {link}
                  </span>
               ))}
            </p>
         </div>
      </PageBanner>
   );
};

export default PortfolioBanner;
