import { TLocale } from "./i18n-config";

let customJson;
// customJson = cookies().get("customJson");
if (typeof window !== "undefined") {
   customJson = localStorage.getItem("customJson");
}

let dictionaries: any;

if (customJson) {
   dictionaries = {
      en: () =>
         import("./app/dictionaries/en.json").then((module) => module.default),
      es: () =>
         import("./app/dictionaries/es.json").then((module) => module.default),
      nl: () =>
         import("./app/dictionaries/nl.json").then((module) => module.default),
       fr: () =>
         import("./app/dictionaries/fr.json").then((module) => module.default),
   };
} else {
   dictionaries = {
      en: () =>
         import("./app/dictionaries/en.json").then((module) => module.default),
      es: () =>
         import("./app/dictionaries/es.json").then((module) => module.default),
      nl: () =>
         import("./app/dictionaries/nl.json").then((module) => module.default),
        fr: () =>
         import("./app/dictionaries/fr.json").then((module) => module.default),
   };
}

export const getDictionary = async (locale: TLocale) =>
   dictionaries[locale]?.() ?? dictionaries.en();
