export const jsonLDPage = {
   aboutUs: {
      "@context": "https://schema.org",
      "@type": "AboutPage",
      name: "About Us | ByteScrum Technologies",
      url: "https://www.bytescrum.com/about-us",

      about: {
         "@type": "CreativeWork",
         name: "Empowering Tech, Simplifying Lives",
         description:
            "ByteScrum Technologies is dedicated to driving innovation and delivering exceptional web and software development services.",
      },
   },

   services: {
      "@context": "https://schema.org",
      "@type": "Service",
      provider: {
         "@type": "Organization",
         name: "ByteScrum",
         url: "https://bytescrum.vercel.app",
      },
      serviceType: "Software Development Services",
      areaServed: {
         "@type": "Place",
         name: "Global",
      },
      hasOfferCatalog: {
         "@type": "OfferCatalog",
         name: "Service Offerings",
         itemListElement: [
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "Mobile App Development",
                  description:
                     "iOS & Android native/hybrid apps with secure backend integration.",
               },
            },
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "Blockchain Development",
                  description:
                     "Smart contract & decentralized application development.",
               },
            },
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "Custom Software Solutions",
                  description: "Tailored software to meet your business needs.",
               },
            },
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "Web Development",
                  description:
                     "Modern, scalable web applications and websites.",
               },
            },
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "E-commerce Development",
                  description:
                     "Full-featured online stores with secure checkout & admin panels.",
               },
            },
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "QA & Testing",
                  description:
                     "Robust manual and automated testing to ensure product quality.",
               },
            },
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "Python Developer Hiring",
                  description:
                     "Dedicated Python developers for scalable solutions.",
               },
            },
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "Recover Hacked Website",
                  description:
                     "Immediate malware cleanup and security hardening services.",
               },
            },
         ],
      },
   },
};
