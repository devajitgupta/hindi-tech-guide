export const developerData = {
   "full-stack-developer": {
      title: "Full Stack Developer",
      tagline: "Home | Full-Stack-Developer",
      description:
         "Our Full Stack Developers are experts in both front-end and back-end technologies, delivering seamless, scalable, and high-performance web applications tailored to your business needs.",
      icon: "carbon:code",
      color: "#3B82F6",
      whatWeDo: {
         title: "What Our Full Stack Developers Do",
         subtitle:
            "Our team specializes in delivering comprehensive solutions that encompass both front-end and back-end development, ensuring a seamless user experience.",
         service: [
            {
               icon: "carbon:application-web",
               title: "Web Application Development",
               description:
                  "Build responsive, high-performance web applications using modern frameworks and technologies.",
            },
            {
               icon: "carbon:api",
               title: "API Development",
               description:
                  "Design and implement robust, scalable APIs that connect your frontend and backend systems.",
            },
            {
               icon: "carbon:cloud-service-management",
               title: "Database Design & Management",
               description:
                  "Create efficient database structures and implement optimized data access patterns.",
            },
            {
               icon: "carbon:development",
               title: "Frontend Development",
               description:
                  "Craft intuitive user interfaces with modern JavaScript frameworks like React, Vue, and Angular.",
            },
            {
               icon: "healthicons:emergency-operations-center-outline",
               title: "Backend Development",
               description:
                  "Build robust server-side applications using Node.js, Python, PHP, and other technologies.",
            },
            {
               icon: "ic:outline-cloud",
               title: "DevOps & Deployment",
               description:
                  "Implement CI/CD pipelines and manage cloud infrastructure for seamless deployment.",
            },
         ],
      },
      skillSection: {
         title: "Technical Expertise",
         subtitle:
            "Discover the key skills and technologies that define our expertise.",
         skills: [
            {
               title: "Frontend",
               key: "frontend",
               data: [
                  {
                     name: "React",
                     icon: "logos:react",
                     level: 95,
                     description:
                        "A popular JavaScript library for building user interfaces, particularly single-page applications.",
                  },
                  {
                     name: "Next.js",
                     icon: "logos:nextjs-icon",
                     level: 90,
                     description:
                        "A React framework that enables server-side rendering and static site generation for faster performance.",
                  },
                  {
                     name: "Vue.js",
                     icon: "logos:vue",
                     level: 85,
                     description:
                        "A progressive JavaScript framework for building user interfaces, known for its flexibility and ease of integration.",
                  },
                  {
                     name: "Angular",
                     icon: "logos:angular-icon",
                     level: 80,
                     description:
                        "A platform for building mobile and desktop web applications, known for its powerful features and robust architecture.",
                  },
                  {
                     name: "TypeScript",
                     icon: "logos:typescript-icon",
                     level: 90,
                     description:
                        "A superset of JavaScript that adds static types, enhancing code quality and maintainability.",
                  },
                  {
                     name: "Tailwind CSS",
                     icon: "logos:tailwindcss-icon",
                     level: 95,
                     description:
                        "A utility-first CSS framework for creating custom designs without having to leave your HTML.",
                  },
               ],
            },
            {
               title: "Backend",
               key: "backend",
               data: [
                  {
                     name: "Node.js",
                     icon: "logos:nodejs-icon",
                     level: 90,
                     description:
                        "A JavaScript runtime built on Chrome's V8 engine, allowing for server-side scripting.",
                  },
                  {
                     name: "Express",
                     icon: "simple-icons:express",
                     level: 85,
                     description:
                        "A minimal and flexible Node.js web application framework that provides a robust set of features for web and mobile applications.",
                  },
                  {
                     name: "Python",
                     icon: "logos:python",
                     level: 80,
                     description:
                        "A high-level programming language known for its readability and versatility, widely used in web development and data science.",
                  },
                  {
                     name: "Django",
                     icon: "vscode-icons:file-type-django",
                     level: 75,
                     description:
                        "A high-level Python web framework that encourages rapid development and clean, pragmatic design.",
                  },
                  {
                     name: "PHP",
                     icon: "logos:php",
                     level: 70,
                     description:
                        "A popular general-purpose scripting language that is especially suited to web development.",
                  },
                  {
                     name: "Laravel",
                     icon: "logos:laravel",
                     level: 75,
                     description:
                        "A PHP framework for web artisans, providing an elegant syntax and powerful tools for building web applications.",
                  },
               ],
            },
            {
               title: "Database",
               key: "database",
               data: [
                  {
                     name: "MongoDB",
                     icon: "logos:mongodb-icon",
                     level: 90,
                     description:
                        "A NoSQL database that uses a document-oriented data model, ideal for handling large volumes of unstructured data.",
                  },
                  {
                     name: "PostgreSQL",
                     icon: "logos:postgresql",
                     level: 85,
                     description:
                        "An advanced, open-source relational database that supports both SQL and JSON querying.",
                  },
                  {
                     name: "MySQL",
                     icon: "logos:mysql",
                     level: 80,
                     description:
                        "The world's most popular open-source database, known for its reliability and ease of use.",
                  },
               ],
            },
            {
               title: "DevOps",
               key: "devops",
               data: [
                  {
                     name: "Docker",
                     icon: "logos:docker-icon",
                     level: 85,
                     description:
                        "A platform for developing, shipping, and running applications in containers, ensuring consistency across environments.",
                  },
                  {
                     name: "Kubernetes",
                     icon: "logos:kubernetes",
                     level: 75,
                     description:
                        "An open-source system for automating the deployment, scaling, and management of containerized applications.",
                  },
                  {
                     name: "AWS",
                     icon: "logos:aws",
                     level: 80,
                     description:
                        "Amazon Web Services, a comprehensive cloud platform offering computing power, storage options, and networking capabilities.",
                  },
                  {
                     name: "CI/CD",
                     icon: "logos:github-actions",
                     level: 85,
                     description:
                        "Continuous Integration and Continuous Deployment practices that automate the software delivery process.",
                  },
                  {
                     name: "Git",
                     icon: "logos:git-icon",
                     level: 95,
                     description:
                        "A distributed version control system that allows teams to track changes in source code during software development.",
                  },
                  {
                     name: "Linux",
                     icon: "logos:linux-tux",
                     level: 85,
                     description:
                        "An open-source operating system that is widely used for servers and development environments due to its stability and security.",
                  },
               ],
            },
         ],
      },
      whyHire: {
         title: "Why Hire Our FuLL Stack Developer?",
         subtitle:
            "Our Full Stack Developers are equipped with the latest technologies and methodologies, ensuring they deliver high-quality solutions tailored to your specific needs. Their commitment to excellence and continuous learning makes them the perfect choice for your next project.",
         reasons: [
            {
               title: "Versatile Expertise",
               description:
                  "Our Full Stack Developers excel in both front-end and back-end development, creating integrated web applications that meet diverse business needs. Their comprehensive skills ensure a seamless user experience, making them invaluable assets capable of tackling complex challenges effectively.",
               icon: "carbon:user-multiple",
            },
            {
               title: "Scalable Solutions",
               description:
                  "We build scalable solutions that grow with your business. Our Full Stack Developers design applications to handle increasing user demands and data loads, ensuring performance remains uncompromised while providing a solid foundation for future innovations.",
               icon: "carbon:growth",
            },
            {
               title: "Efficient Workflow",
               description:
                  "Our streamlined development process enhances efficiency with a single point of contact, simplifying communication and project management. This approach leads to quicker decision-making, faster turnaround times, and higher quality outcomes, ensuring projects are delivered on time.",
               icon: "carbon:flow",
            },
         ],
      },
      portfolio: {
         title: "Featured Projects",
         subtitle:
            "Explore our impressive portfolio showcasing a diverse range of projects that highlight our expertise and commitment to excellence in every endeavor.",
         projects: [
            {
               title: "E-commerce Platform",
               description:
                  "A full-featured e-commerce platform with payment integration, inventory management, and analytics.",
               technologies: ["React", "Node.js", "MongoDB", "Stripe", "AWS"],
               image: "/portfolio/portfolioPage/talentSuite/talent_manger.webp",
            },
            {
               title: "Healthcare Management System",
               description:
                  "A comprehensive healthcare management system for hospitals and clinics.",
               technologies: [
                  "Angular",
                  "Express",
                  "PostgreSQL",
                  "Docker",
                  "Azure",
               ],
               image: "/portfolio/portfolioPage/expenseMeter/expenseMeter-ss-04.webp",
            },
            {
               title: "Real Estate Marketplace",
               description:
                  "A platform connecting property buyers, sellers, and agents with advanced search capabilities.",
               technologies: [
                  "Next.js",
                  "GraphQL",
                  "Firebase",
                  "Google Maps API",
                  "Vercel",
               ],
               image: "/portfolio/portfolioPage/cordly/cordly-ss-04.webp",
            },
         ],
      },
      cta: {
         title: "Ready to Hire a Full Stack Developer",
         subTitle:
            "Let's bring your vision to life with our expert full stack developer",
         text: "Our dedicated team is ready to collaborate with you, ensuring your project meets all your expectations and delivers outstanding results.",
         href: "/contact-us",
         buttonText: "Hire Full Stack Developer",
      },
      faq: {
         title: "Frequently Asked Questions",
         subtitle:
            "Find answers to common questions about our Full Stack Web Developer.",
         questions: [
            {
               question:
                  "What services do you offer as a Full Stack Web Developer?",
               answer:
                  "We offer a comprehensive range of services including front-end and back-end development, API integration, database management, and ongoing support.",
            },
            {
               question:
                  "How long does it take to develop a full stack application?",
               answer:
                  "The timeline for developing a full stack application varies based on the complexity of the project, but typically it takes between 6 to 14 weeks.",
            },
            {
               question:
                  "Can you help with migrating my existing application to a full stack solution?",
               answer:
                  "Yes, we provide migration services to help you seamlessly transition your existing application to a full stack architecture.",
            },
            {
               question: "What is your pricing model?",
               answer:
                  "Our pricing model is flexible and can be tailored to fit your project needs, whether it's a fixed price or hourly rate.",
            },
            {
               question:
                  "Do you provide ongoing support after the application is launched?",
               answer:
                  "Absolutely! We offer ongoing support and maintenance services to ensure your application runs smoothly and stays updated.",
            },
         ],
      },
   },
   "ui-ux-designer": {
      title: "UI/UX Designer",
      tagline: "Home | UI-UX-Designer",
      description:
         "Our UI/UX Designers create visually appealing and user-friendly interfaces that enhance user engagement and satisfaction, ensuring your product stands out.",
      icon: "carbon:pen-fountain",
      color: "#EC4899",
      whatWeDo: {
         title: "Our UI/UX Design Services",
         subtitle:
            "We craft exceptional digital experiences through strategic design thinking and innovative user-centered approaches.",
         service: [
            {
               icon: "heroicons:users",
               title: "User Experience Strategy",
               description:
                  "Develop comprehensive UX strategies that align business objectives with user goals, creating roadmaps for exceptional digital experiences.",
            },
            {
               icon: "lucide:layers",
               title: "Interface Architecture",
               description:
                  "Structure intuitive information architectures and navigation systems that guide users seamlessly through complex digital environments.",
            },
            {
               icon: "tabler:palette",
               title: "Visual Design",
               description:
                  "Create compelling visual identities and design languages that communicate brand values while enhancing user engagement and interaction.",
            },
            {
               icon: "material-symbols:devices",
               title: "Responsive Design",
               description:
                  "Design adaptive interfaces that deliver consistent experiences across all devices, from mobile phones to desktop displays.",
            },
            {
               icon: "ph:chart-line",
               title: "Performance Analytics",
               description:
                  "Analyze user behavior data and design metrics to continuously optimize interfaces and improve conversion rates.",
            },
            {
               icon: "fluent:people-team-16-regular",
               title: "Collaborative Workshops",
               description:
                  "Facilitate design thinking workshops and stakeholder sessions to align teams and generate innovative solutions collaboratively.",
            },
         ],
      },
      skillSection: {
         title: "Core Competencies",
         subtitle: "Our design team excels in these specialized areas:",
         skills: [
            {
               title: "UI/UX Design",
               key: "ui-ux-design",
               data: [
                  {
                     name: "Experience Strategy",
                     icon: "et:strategy",
                     level: 88,
                     description:
                        "Crafting holistic user experience strategies that bridge business requirements with user expectations through strategic planning.",
                  },
                  {
                     name: "Information Architecture",
                     icon: "carbon:tree-view",
                     level: 91,
                     description:
                        "Organizing complex information structures and content hierarchies to create logical, navigable digital experiences for users.",
                  },
                  {
                     name: "Visual Systems",
                     icon: "carbon:color-palette",
                     level: 93,
                     description:
                        "Developing cohesive visual languages and brand expressions that communicate effectively while maintaining aesthetic excellence throughout.",
                  },
                  {
                     name: "Interaction Design",
                     icon: "carbon:touch-interaction",
                     level: 86,
                     description:
                        "Designing meaningful interactions and micro-animations that enhance user engagement while providing clear feedback and guidance.",
                  },
                  {
                     name: "Design Research",
                     icon: "game-icons:archive-research",
                     level: 89,
                     description:
                        "Conducting ethnographic studies and behavioral analysis to uncover deep user insights that drive informed design decisions.",
                  },
                  {
                     name: "Service Design",
                     icon: "carbon:flow",
                     level: 84,
                     description:
                        "Mapping end-to-end service journeys and touchpoints to create seamless experiences across multiple channels and platforms.",
                  },
               ],
            },
         ],
      },
      whyHire: {
         title: "Why Hire Our UI/UX Designer?",
         subtitle:
            "Our UI/UX Designers are equipped with the latest design tools and methodologies, ensuring they create high-quality user experiences tailored to your specific needs. Their commitment to excellence and continuous learning makes them the perfect choice for your next project.",
         reasons: [
            {
               title: "User-Centric Approach",
               description:
                  "Our UI/UX Designers prioritize user needs and behaviors, creating intuitive designs that enhance user satisfaction and engagement.",
               icon: "carbon:user-multiple",
            },
            {
               title: "Innovative Design Solutions",
               description:
                  "We develop innovative design solutions that not only meet current trends but also anticipate future user needs, ensuring your product remains relevant and competitive.",
               icon: "carbon:growth",
            },
            {
               title: "Collaborative Process",
               description:
                  "Our collaborative design process involves close communication with clients and stakeholders, leading to designs that align perfectly with business goals and user expectations.",
               icon: "carbon:flow",
            },
         ],
      },
      portfolio: {
         title: "Featured Projects",
         subtitle:
            "Explore our impressive portfolio showcasing a diverse range of design projects that highlight our expertise and commitment to excellence in every endeavor.",

         projects: [
            {
               title: "E-commerce Platform",
               description:
                  "A full-featured e-commerce platform with user-friendly design and seamless navigation.",
               technologies: ["Figma", "Adobe XD", "Sketch"],
               image: "/portfolio/portfolioPage/talentSuite/talent_manger.webp",
            },
            {
               title: "Healthcare Management System",
               description:
                  "A comprehensive healthcare management system with a focus on user accessibility and ease of use.",
               technologies: ["Figma", "InVision", "Adobe Illustrator"],
               image: "/portfolio/portfolioPage/expenseMeter/expenseMeter-ss-04.webp",
            },
            {
               title: "Real Estate Marketplace",
               description:
                  "A platform connecting property buyers, sellers, and agents with an intuitive interface and advanced search capabilities.",
               technologies: ["Figma", "Adobe XD", "Webflow"],
               image: "/portfolio/portfolioPage/cordly/cordly-ss-04.webp",
            },
         ],
      },
      cta: {
         title: "Ready to Hire a UI/UX Designer",
         subTitle:
            "Let's bring your vision to life with our expert UI/UX designer",
         text: "Our dedicated team is ready to collaborate with you, ensuring your project meets all your expectations and delivers outstanding results.",
         href: "/contact-us",
         buttonText: "Hire UI/UX Designer",
      },
      faq: {
         title: "Frequently Asked Questions",
         subtitle: "Find answers to common questions about our UI/UX designer.",
         questions: [
            {
               question: "What services do you offer as a UI/UX designer?",
               answer:
                  "We offer a range of services including user research, wireframing, prototyping, UI design, and usability testing.",
            },
            {
               question: "How do you ensure the designs meet user needs?",
               answer:
                  "We conduct thorough user research and usability testing to gather insights and iterate on designs based on user feedback.",
            },
            {
               question: "What design tools do you use?",
               answer:
                  "Our designers are proficient in tools like Figma, Adobe XD, Sketch, and InVision to create high-quality designs.",
            },
            {
               question: "Can you work with existing branding guidelines?",
               answer:
                  "Absolutely! We can adapt our designs to align with your existing branding guidelines to ensure consistency across your products.",
            },
            {
               question: "What is your design process?",
               answer:
                  "Our design process involves understanding user needs, creating wireframes and prototypes, gathering feedback, and iterating until we achieve the best results.",
            },
         ],
      },
   },
   "laravel-developer": {
      title: "Laravel Developer",
      tagline: "Robust Backend Solutions with Laravel",
      description:
         "Hire our Laravel Developers to build secure, scalable, and high-performance backend systems using the power of Laravel, tailored to your business requirements.",
      icon: "carbon:rocket",
      color: "#F59E0B", // Amber
      whatWeDo: {
         title: "What Our Laravel Developers Do",
         subtitle:
            "Our team specializes in delivering comprehensive backend solutions using Laravel, ensuring a seamless integration with your existing systems.",
         service: [
            {
               icon: "carbon:application-web",
               title: "Web Application Development",
               description:
                  "Build responsive, high-performance web applications using Laravel and modern technologies.",
            },
            {
               icon: "carbon:api",
               title: "API Development",
               description:
                  "Design and implement robust, scalable APIs that connect your frontend and backend systems using Laravel.",
            },
            {
               icon: "carbon:cloud-service-management",
               title: "Database Design & Management",
               description:
                  "Create efficient database structures and implement optimized data access patterns with Laravel's Eloquent ORM.",
            },
            {
               icon: "carbon:development",
               title: "Backend Development",
               description:
                  "Build robust server-side applications using Laravel, ensuring high performance and security.",
            },
            {
               icon: "ic:outline-cloud",
               title: "DevOps & Deployment",
               description:
                  "Implement CI/CD pipelines and manage cloud infrastructure for seamless deployment of Laravel applications.",
            },
         ],
      },
      skillSection: {
         title: "Technical Expertise",
         subtitle:
            "Discover the key skills and technologies that define our Laravel expertise.",
         skills: [
            {
               title: "Backend",
               key: "backend",
               data: [
                  {
                     name: "PHP",
                     icon: "logos:php",
                     level: 90,
                     description:
                        "A popular general-purpose scripting language that is especially suited to web development.",
                  },
                  {
                     name: "Laravel",
                     icon: "logos:laravel",
                     level: 90,
                     description:
                        "A PHP framework for web artisans, providing an elegant syntax and powerful tools for building web applications.",
                  },
               ],
            },
            {
               title: "Database",
               key: "database",
               data: [
                  {
                     name: "MySQL",
                     icon: "logos:mysql",
                     level: 85,
                     description:
                        "The world's most popular open-source database, known for its reliability and ease of use.",
                  },
                  {
                     name: "PostgreSQL",
                     icon: "logos:postgresql",
                     level: 80,
                     description:
                        "An advanced, open-source relational database that supports both SQL and JSON querying.",
                  },
               ],
            },
            {
               title: "DevOps",
               key: "devops",
               data: [
                  {
                     name: "Docker",
                     icon: "logos:docker-icon",
                     level: 85,
                     description:
                        "A platform for developing, shipping, and running applications in containers, ensuring consistency across environments.",
                  },
                  {
                     name: "AWS",
                     icon: "logos:aws",
                     level: 80,
                     description:
                        "Amazon Web Services, a comprehensive cloud platform offering computing power, storage options, and networking capabilities.",
                  },
               ],
            },
         ],
      },
      whyHire: {
         title: "Why Hire Our Laravel Developer?",
         subtitle:
            "Our Laravel Developers are equipped with the latest technologies and methodologies, ensuring they deliver high-quality backend solutions tailored to your specific needs.",
         reasons: [
            {
               title: "Expertise in Laravel",
               description:
                  "Our Laravel Developers excel in building secure and scalable applications, leveraging the full power of the Laravel framework.",
               icon: "carbon:user-multiple",
            },
            {
               title: "Scalable Solutions",
               description:
                  "We build scalable backend solutions that grow with your business, ensuring performance remains uncompromised.",
               icon: "carbon:growth",
            },
            {
               title: "Efficient Workflow",
               description:
                  "Our streamlined development process enhances efficiency with a single point of contact, simplifying communication and project management.",
               icon: "carbon:flow",
            },
         ],
      },
      portfolio: {
         title: "Featured Projects",
         subtitle:
            "Explore our impressive portfolio showcasing a diverse range of Laravel projects that highlight our expertise and commitment to excellence.",
         projects: [
            {
               title: "E-commerce Platform",
               description:
                  "A full-featured e-commerce platform built with Laravel, featuring payment integration and inventory management.",
               technologies: ["Laravel", "MySQL", "Vue.js"],
               image: "/portfolio/portfolioPage/talentSuite/talent_manger.webp",
            },
            {
               title: "Healthcare Management System",
               description:
                  "A comprehensive healthcare management system built with Laravel, focusing on user accessibility and data security.",
               technologies: ["Laravel", "PostgreSQL", "Vue.js"],
               image: "/portfolio/portfolioPage/expenseMeter/expenseMeter-ss-04.webp",
            },
            {
               title: "Real Estate Marketplace",
               description:
                  "A platform connecting property buyers, sellers, and agents, developed using Laravel for robust backend support.",
               technologies: ["Laravel", "MySQL", "React"],
               image: "/portfolio/portfolioPage/cordly/cordly-ss-04.webp",
            },
         ],
      },
      cta: {
         title: "Ready to Hire a Laravel Developer",
         subTitle:
            "Let's bring your vision to life with our expert Laravel developer",
         text: "Our dedicated team is ready to collaborate with you, ensuring your project meets all your expectations and delivers outstanding results.",
         href: "/contact-us",
         buttonText: "Hire Laravel Developer",
      },
      faq: {
         title: "Frequently Asked Questions",
         subtitle:
            "Find answers to common questions about our Laravel developer.",
         questions: [
            {
               question: "What services do you offer as a Laravel developer?",
               answer:
                  "We offer a range of services including Laravel web development, API development, CMS integration, and ongoing support.",
            },
            {
               question:
                  "How long does it take to develop a Laravel application?",
               answer:
                  "The timeline for developing a Laravel application varies based on the complexity of the project, but typically it takes between 4 to 12 weeks.",
            },
            {
               question:
                  "Can you help with migrating my existing application to Laravel?",
               answer:
                  "Yes, we provide migration services to help you seamlessly transition your existing application to a Laravel-based solution.",
            },
            {
               question: "What is your pricing model?",
               answer:
                  "Our pricing model is flexible and can be tailored to fit your project needs, whether it's a fixed price or hourly rate.",
            },
            {
               question:
                  "Do you provide ongoing support after the application is launched?",
               answer:
                  "Absolutely! We offer ongoing support and maintenance services to ensure your application runs smoothly and stays updated.",
            },
         ],
      },
   },
   "php-developer": {
      title: "PHP Developer",
      tagline: "Dynamic Web Solutions with PHP",
      description:
         "Our PHP Developers create dynamic, secure, and efficient web applications using PHP, ensuring your business gets the best digital solutions.",
      icon: "carbon:debug",
      color: "#10B981", // Green
      whatWeDo: {
         title: "What Our PHP Developers Do",
         subtitle:
            "Our team specializes in delivering comprehensive solutions that encompass both front-end and back-end development, ensuring a seamless user experience.",
         service: [
            {
               icon: "carbon:application-web",
               title: "Web Application Development",
               description:
                  "Build responsive, high-performance web applications using modern frameworks and technologies.",
            },
            {
               icon: "carbon:api",
               title: "API Development",
               description:
                  "Design and implement robust, scalable APIs that connect your frontend and backend systems.",
            },
            {
               icon: "carbon:cloud-service-management",
               title: "Database Design & Management",
               description:
                  "Create efficient database structures and implement optimized data access patterns.",
            },
            {
               icon: "carbon:development",
               title: "Frontend Development",
               description:
                  "Craft intuitive user interfaces with modern JavaScript frameworks like React, Vue, and Angular.",
            },
            {
               icon: "healthicons:emergency-operations-center-outline",
               title: "Backend Development",
               description:
                  "Build robust server-side applications using PHP and other technologies.",
            },
            {
               icon: "ic:outline-cloud",
               title: "DevOps & Deployment",
               description:
                  "Implement CI/CD pipelines and manage cloud infrastructure for seamless deployment.",
            },
         ],
      },
      skillSection: {
         title: "Technical Expertise",
         subtitle:
            "Discover the key skills and technologies that define our expertise.",
         skills: [
            {
               title: "Frontend",
               key: "frontend",
               data: [
                  {
                     name: "HTML",
                     icon: "logos:html-5",
                     level: 95,
                     description:
                        "The standard markup language for creating web pages, essential for structuring content on the web.",
                  },
                  {
                     name: "CSS",
                     icon: "logos:css-3",
                     level: 90,
                     description:
                        "A style sheet language used for describing the presentation of a document written in HTML or XML.",
                  },
                  {
                     name: "JavaScript",
                     icon: "logos:javascript",
                     level: 90,
                     description:
                        "A high-level, dynamic, untyped, and interpreted programming language, widely used for web development.",
                  },
                  {
                     name: "Bootstrap",
                     icon: "logos:bootstrap",
                     level: 85,
                     description:
                        "A front-end framework for developing responsive and mobile-first websites quickly and easily.",
                  },
                  {
                     name: "Tailwind CSS",
                     icon: "logos:tailwindcss-icon",
                     level: 95,
                     description:
                        "A utility-first CSS framework for creating custom designs without having to leave your HTML.",
                  },
                  {
                     name: "jQuery",
                     icon: "logos:jquery",
                     level: 80,
                     description:
                        "A fast, small, and feature-rich JavaScript library that simplifies things like HTML document traversal and manipulation.",
                  },
               ],
            },
            {
               title: "Backend",
               key: "backend",
               data: [
                  {
                     name: "PHP",
                     icon: "logos:php",
                     level: 90,
                     description:
                        "A popular general-purpose scripting language that is especially suited to web development.",
                  },
                  {
                     name: "Laravel",
                     icon: "logos:laravel",
                     level: 85,
                     description:
                        "A PHP framework for web artisans, providing an elegant syntax and powerful tools for building web applications.",
                  },
                  {
                     name: "MySQL",
                     icon: "logos:mysql",
                     level: 90,
                     description:
                        "The world's most popular open-source database, known for its reliability and ease of use.",
                  },
                  {
                     name: "PostgreSQL",
                     icon: "logos:postgresql",
                     level: 80,
                     description:
                        "An advanced, open-source relational database that supports both SQL and JSON querying.",
                  },
                  {
                     name: "Node.js",
                     icon: "logos:nodejs-icon",
                     level: 75,
                     description:
                        "A JavaScript runtime built on Chrome's V8 engine, allowing for server-side scripting.",
                  },
                  {
                     name: "Express",
                     icon: "simple-icons:express",
                     level: 70,
                     description:
                        "A minimal and flexible Node.js web application framework that provides a robust set of features for web and mobile applications.",
                  },
               ],
            },
            {
               title: "Database",
               key: "database",
               data: [
                  {
                     name: "MongoDB",
                     icon: "logos:mongodb-icon",
                     level: 85,
                     description:
                        "A NoSQL database that uses a document-oriented data model, ideal for handling large volumes of unstructured data.",
                  },
                  {
                     name: "SQLite",
                     icon: "logos:sqlite",
                     level: 80,
                     description:
                        "A C-language library that implements a small, fast, self-contained, high-reliability, full-featured, SQL database engine.",
                  },
                  {
                     name: "Redis",
                     icon: "logos:redis",
                     level: 75,
                     description:
                        "An open-source, in-memory data structure store, used as a database, cache, and message broker.",
                  },
               ],
            },
            {
               title: "DevOps",
               key: "devops",
               data: [
                  {
                     name: "Docker",
                     icon: "logos:docker-icon",
                     level: 85,
                     description:
                        "A platform for developing, shipping, and running applications in containers, ensuring consistency across environments.",
                  },
                  {
                     name: "Kubernetes",
                     icon: "logos:kubernetes",
                     level: 75,
                     description:
                        "An open-source system for automating the deployment, scaling, and management of containerized applications.",
                  },
                  {
                     name: "AWS",
                     icon: "logos:aws",
                     level: 80,
                     description:
                        "Amazon Web Services, a comprehensive cloud platform offering computing power, storage options, and networking capabilities.",
                  },
                  {
                     name: "Git",
                     icon: "logos:git-icon",
                     level: 95,
                     description:
                        "A distributed version control system that allows teams to track changes in source code during software development.",
                  },
                  {
                     name: "Linux",
                     icon: "logos:linux-tux",
                     level: 85,
                     description:
                        "An open-source operating system that is widely used for servers and development environments due to its stability and security.",
                  },
               ],
            },
         ],
      },
      whyHire: {
         title: "Why Hire Our PHP Developer?",
         subtitle:
            "Our PHP Developers leverage cutting-edge technologies and best practices to deliver high-quality, customized solutions that meet your unique requirements. Their dedication to excellence and ongoing professional development makes them the ideal choice for your upcoming project.",
         reasons: [
            {
               title: "Comprehensive Skill Set",
               description:
                  "Our PHP Developers are proficient in both front-end and back-end development, enabling them to create cohesive web applications that address a wide range of business needs. Their diverse skill set guarantees a smooth user experience, making them essential team members capable of overcoming complex challenges.",
               icon: "carbon:user-multiple",
            },
            {
               title: "Future-Proof Solutions",
               description:
                  "We design scalable solutions that evolve alongside your business. Our PHP Developers build applications that can accommodate growing user demands and data volumes, ensuring optimal performance while laying a strong foundation for future enhancements.",
               icon: "carbon:growth",
            },
            {
               title: "Streamlined Development Process",
               description:
                  "Our efficient development workflow simplifies communication and project management by providing a single point of contact. This methodology fosters quicker decision-making, faster delivery times, and superior quality outcomes, ensuring that projects are completed on schedule.",
               icon: "carbon:flow",
            },
         ],
      },
      portfolio: {
         title: "Featured Projects",
         subtitle:
            "Explore our impressive portfolio showcasing a diverse range of projects that highlight our expertise and commitment to excellence in every endeavor.",
         projects: [
            {
               title: "E-commerce Platform",
               description:
                  "A full-featured e-commerce platform with payment integration, inventory management, and analytics.",
               technologies: ["React", "Node.js", "MongoDB", "Stripe", "AWS"],
               image: "/portfolio/portfolioPage/talentSuite/talent_manger.webp",
            },
            {
               title: "Healthcare Management System",
               description:
                  "A comprehensive healthcare management system for hospitals and clinics.",
               technologies: [
                  "Angular",
                  "Express",
                  "PostgreSQL",
                  "Docker",
                  "Azure",
               ],
               image: "/portfolio/portfolioPage/expenseMeter/expenseMeter-ss-04.webp",
            },
            {
               title: "Real Estate Marketplace",
               description:
                  "A platform connecting property buyers, sellers, and agents with advanced search capabilities.",
               technologies: [
                  "Next.js",
                  "GraphQL",
                  "Firebase",
                  "Google Maps API",
                  "Vercel",
               ],
               image: "/portfolio/portfolioPage/cordly/cordly-ss-04.webp",
            },
         ],
      },
      cta: {
         title: "Ready to Hire a PHP Developer",
         subTitle:
            "Let's bring your vision to life with our expert PHP developer",
         text: "Our dedicated team is ready to collaborate with you, ensuring your project meets all your expectations and delivers outstanding results.",
         href: "/contact-us",
         buttonText: "Hire PHP Developer",
      },
      faq: {
         title: "Frequently Asked Questions",
         subtitle: "Find answers to common questions about our PHP developer.",
         questions: [
            {
               question: "What services do you offer as a PHP developer?",
               answer:
                  "We offer a range of services including PHP web development, API development, CMS integration, and ongoing support.",
            },
            {
               question: "How long does it take to develop a PHP application?",
               answer:
                  "The timeline for developing a PHP application varies based on the complexity of the project, but typically it takes between 4 to 12 weeks.",
            },
            {
               question:
                  "Can you help with migrating my existing application to PHP?",
               answer:
                  "Yes, we provide migration services to help you seamlessly transition your existing application to a PHP-based solution.",
            },
            {
               question: "What is your pricing model?",
               answer:
                  "Our pricing model is flexible and can be tailored to fit your project needs, whether it's a fixed price or hourly rate.",
            },
            {
               question:
                  "Do you provide ongoing support after the application is launched?",
               answer:
                  "Absolutely! We offer ongoing support and maintenance services to ensure your application runs smoothly and stays updated.",
            },
         ],
      },
   },
   "shopify-developer": {
      title: "Shopify Developer",
      tagline: "Stunning E-Commerce Stores with Shopify",
      description:
         "Hire our Shopify Developers to build custom, high-converting e-commerce stores with seamless functionality and stunning designs.",
      icon: "carbon:shopping-cart",
      color: "#6366F1", // Indigo
      whatWeDo: {
         title: "What Our Shopify Developers Do",
         subtitle:
            "Our team specializes in creating tailored e-commerce solutions that enhance user experience and drive sales.",
         service: [
            {
               icon: "carbon:application-web",
               title: "Shopify Store Development",
               description:
                  "Build responsive and visually appealing Shopify stores that cater to your business needs.",
            },
            {
               icon: "carbon:api",
               title: "Shopify App Development",
               description:
                  "Design and implement custom Shopify apps to extend the functionality of your online store.",
            },
            {
               icon: "carbon:cloud-service-management",
               title: "Theme Customization",
               description:
                  "Customize Shopify themes to align with your brand identity and improve user engagement.",
            },
            {
               icon: "carbon:development",
               title: "Payment Gateway Integration",
               description:
                  "Integrate secure payment gateways to facilitate smooth transactions for your customers.",
            },
            {
               icon: "healthicons:emergency-operations-center-outline",
               title: "SEO Optimization",
               description:
                  "Optimize your Shopify store for search engines to increase visibility and attract more customers.",
            },
            {
               icon: "ic:outline-cloud",
               title: "Analytics & Reporting",
               description:
                  "Implement analytics tools to track performance and gain insights into customer behavior.",
            },
         ],
      },
      skillSection: {
         title: "Technical Expertise",
         subtitle:
            "Discover the key skills and technologies that define our Shopify development expertise.",
         skills: [
            {
               title: "Frontend",
               key: "frontend",
               data: [
                  {
                     name: "Liquid",
                     icon: "logos:shopify",
                     level: 95,
                     description:
                        "Shopify's templating language for building dynamic and customizable storefronts.",
                  },
                  {
                     name: "HTML/CSS",
                     icon: "logos:html-5",
                     level: 90,
                     description:
                        "The foundational technologies for creating and styling web pages.",
                  },
                  {
                     name: "JavaScript",
                     icon: "logos:javascript",
                     level: 85,
                     description:
                        "A programming language that enables interactive web features and enhances user experience.",
                  },
                  {
                     name: "React",
                     icon: "logos:react",
                     level: 80,
                     description:
                        "A JavaScript library for building user interfaces, particularly for dynamic web applications.",
                  },
                  {
                     name: "Shopify Polaris",
                     icon: "logos:shopify",
                     level: 90,
                     description:
                        "A design system that helps create a consistent user experience across Shopify applications.",
                  },
               ],
            },
            {
               title: "Backend",
               key: "backend",
               data: [
                  {
                     name: "Node.js",
                     icon: "logos:nodejs-icon",
                     level: 85,
                     description:
                        "A JavaScript runtime for building scalable network applications.",
                  },
                  {
                     name: "Shopify API",
                     icon: "logos:shopify",
                     level: 90,
                     description:
                        "Utilize Shopify's API to integrate and manage store data effectively.",
                  },
                  {
                     name: "GraphQL",
                     icon: "logos:graphql",
                     level: 80,
                     description:
                        "A query language for APIs that allows clients to request only the data they need.",
                  },
               ],
            },
            {
               title: "DevOps",
               key: "devops",
               data: [
                  {
                     name: "Git",
                     icon: "logos:git-icon",
                     level: 95,
                     description:
                        "A version control system for tracking changes in code during development.",
                  },
                  {
                     name: "CI/CD",
                     icon: "logos:github-actions",
                     level: 85,
                     description:
                        "Continuous Integration and Continuous Deployment practices to automate the development workflow.",
                  },
                  {
                     name: "AWS",
                     icon: "logos:aws",
                     level: 80,
                     description:
                        "Amazon Web Services for hosting and managing applications in the cloud.",
                  },
               ],
            },
         ],
      },
      whyHire: {
         title: "Why Hire Our Shopify Developers?",
         subtitle:
            "Our Shopify Developers are dedicated to delivering high-quality e-commerce solutions that drive results.",
         reasons: [
            {
               title: "E-Commerce Expertise",
               description:
                  "Our developers have extensive experience in building and optimizing Shopify stores, ensuring your business thrives online.",
               icon: "carbon:user-multiple",
            },
            {
               title: "Custom Solutions",
               description:
                  "We provide tailored solutions that meet your unique business requirements and enhance customer satisfaction.",
               icon: "carbon:growth",
            },
            {
               title: "Ongoing Support",
               description:
                  "Our team offers continuous support and maintenance to ensure your Shopify store runs smoothly.",
               icon: "carbon:flow",
            },
         ],
      },
      portfolio: {
         title: "Featured Shopify Projects",
         subtitle:
            "Explore our impressive portfolio showcasing successful Shopify stores we've developed.",

         projects: [
            {
               title: "Fashion E-Commerce Store",
               description:
                  "A stylish online store featuring a wide range of fashion products with seamless shopping experience.",
               technologies: ["Shopify", "Liquid", "JavaScript", "HTML", "CSS"],
               image: "/portfolio/portfolioPage/talentSuite/talent_manger.webp",
            },
            {
               title: "Electronics Store",
               description:
                  "An e-commerce platform for electronics with advanced filtering and payment options.",
               technologies: ["Shopify", "Node.js", "GraphQL"],
               image: "/portfolio/portfolioPage/expenseMeter/expenseMeter-ss-04.webp",
            },
            {
               title: "Health & Wellness Store",
               description:
                  "A comprehensive online store for health and wellness products with user-friendly navigation.",
               technologies: ["Shopify", "Liquid", "React"],
               image: "/portfolio/portfolioPage/cordly/cordly-ss-04.webp",
            },
         ],
      },
      cta: {
         title: "Ready to Hire a Shopify Developer?",
         subTitle:
            "Let's create a stunning e-commerce store that elevates your business.",
         text: "Our dedicated team is ready to collaborate with you, ensuring your Shopify store meets all your expectations and delivers outstanding results.",
         href: "/contact-us",
         buttonText: "Hire Shopify Developer",
      },
      faq: {
         title: "Frequently Asked Questions",
         subtitle:
            "Find answers to common questions about our shopify developer.",
         questions: [
            {
               question: "What services do you offer as a Shopify developer?",
               answer:
                  "We offer a range of services including Shopify store development, app development, theme customization, payment gateway integration, SEO optimization, and ongoing support.",
            },
            {
               question: "How long does it take to develop a Shopify store?",
               answer:
                  "The timeline for developing a Shopify store varies based on the complexity of the project, but typically it takes between 4 to 8 weeks.",
            },
            {
               question:
                  "Can you help with migrating my existing store to Shopify?",
               answer:
                  "Yes, we provide migration services to help you seamlessly transition your existing store to the Shopify platform.",
            },
            {
               question: "What is your pricing model?",
               answer:
                  "Our pricing model is flexible and can be tailored to fit your project needs, whether it's a fixed price or hourly rate.",
            },
            {
               question:
                  "Do you provide ongoing support after the store is launched?",
               answer:
                  "Absolutely! We offer ongoing support and maintenance services to ensure your store runs smoothly and stays updated.",
            },
         ],
      },
   },
};
