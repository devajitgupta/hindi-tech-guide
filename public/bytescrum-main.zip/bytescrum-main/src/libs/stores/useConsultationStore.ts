import { create } from "zustand";

type Store = {
   isOpen: boolean;
   formType: "consultation" | "emergency";
   openModel: (type: "consultation" | "emergency") => void;
   closeModel: () => void;
};

const useConsultationStore = create<Store>()((set) => ({
   isOpen: false,
   formType: "consultation",

   openModel: (type) => set({ isOpen: true, formType: type }),
   closeModel: () => set(() => ({ isOpen: false })),
}));

export default useConsultationStore;
