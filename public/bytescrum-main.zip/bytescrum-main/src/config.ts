const API_CONFIG = {
  BASE_URL: process.env.NEXT_PUBLIC_API_BASE_URL,
  ENDPOINTS: {
    CONTACT_FORMS: "/contact-forms"
  }
};

export default API_CONFIG;
