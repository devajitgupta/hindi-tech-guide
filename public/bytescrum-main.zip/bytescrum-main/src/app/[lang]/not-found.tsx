"use client";
import {
   motion,
   useAnimation,
   useMotionValue,
   useTransform,
} from "framer-motion";
import { useEffect, useState } from "react";
import Link from "next/link";
// import {
//    Home,
//    ArrowLeft,
//    Zap,
//    Star,
//    Circle,
//    Triangle,
//    Square,
// } from "lucide-react";

export default function NotFound() {
   const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
   const [isHovered, setIsHovered] = useState(false);
   const controls = useAnimation();

   const mouseX = useMotionValue(0);
   const mouseY = useMotionValue(0);

   const rotateX = useTransform(mouseY, [-300, 300], [30, -30]);
   const rotateY = useTransform(mouseX, [-300, 300], [-30, 30]);

   useEffect(() => {
      const handleMouseMove = (e: MouseEvent) => {
         const { clientX, clientY } = e;
         const { innerWidth, innerHeight } = window;
         const x = (clientX - innerWidth / 2) / innerWidth;
         const y = (clientY - innerHeight / 2) / innerHeight;

         setMousePosition({ x: clientX, y: clientY });
         mouseX.set(x * 300);
         mouseY.set(y * 300);
      };

      window.addEventListener("mousemove", handleMouseMove);
      return () => window.removeEventListener("mousemove", handleMouseMove);
   }, [mouseX, mouseY]);

   useEffect(() => {
      controls.start({
         rotate: 360,
         transition: {
            duration: 20,
            repeat: Number.POSITIVE_INFINITY,
            ease: "linear",
         },
      });
   }, [controls]);

   const glitchVariants = {
      initial: { x: 0, y: 0, opacity: 1 },
      glitch: {
         x: [0, -5, 5, -3, 3, 0],
         y: [0, 2, -2, 1, -1, 0],
         opacity: [1, 0.8, 1, 0.9, 1],
         transition: {
            duration: 0.3,
            repeat: Number.POSITIVE_INFINITY,
            repeatDelay: 2,
         },
      },
   };

   const floatingShapes = Array.from({ length: 15 }, (_, i) => ({
      id: i,
      size: Math.random() * 60 + 20,
      x: Math.random() * 100,
      y: Math.random() * 100,
      duration: Math.random() * 10 + 10,
      delay: Math.random() * 5,
      // shape: [Circle, Triangle, Square, Star][Math.floor(Math.random() * 4)],
   }));

   return (
      <div className="min-h-screen bg-black text-white overflow-hidden relative">
         {/* Animated Background Grid */}
         <div className="absolute inset-0 opacity-10">
            <div
               className="absolute inset-0"
               style={{
                  backgroundImage: `linear-gradient(rgba(20, 99, 253, 0.1) 1px, transparent 1px),
                                linear-gradient(90deg, rgba(20, 99, 253, 0.1) 1px, transparent 1px)`,
                  backgroundSize: "50px 50px",
               }}
            />
         </div>

         {/* Floating Geometric Shapes */}
         {floatingShapes.map((shape) => {
            // const ShapeIcon = shape.shape;
            return (
               <motion.div
                  key={shape.id}
                  className="absolute text-[#1463fd] opacity-20"
                  style={{
                     left: `${shape.x}%`,
                     top: `${shape.y}%`,
                  }}
                  animate={{
                     y: [0, -30, 0],
                     rotate: [0, 180, 360],
                     scale: [1, 1.2, 1],
                  }}
                  transition={{
                     duration: shape.duration,
                     delay: shape.delay,
                     repeat: Number.POSITIVE_INFINITY,
                     ease: "easeInOut",
                  }}
               >
                  {/* <ShapeIcon size={shape.size} /> */}
               </motion.div>
            );
         })}

         {/* Particle System */}
         <div className="absolute inset-0">
            {Array.from({ length: 50 }).map((_, i) => (
               <motion.div
                  key={i}
                  className="absolute w-1 h-1 bg-[#1463fd] rounded-full"
                  style={{
                     left: `${Math.random() * 100}%`,
                     top: `${Math.random() * 100}%`,
                  }}
                  animate={{
                     opacity: [0, 1, 0],
                     scale: [0, 1, 0],
                  }}
                  transition={{
                     duration: Math.random() * 3 + 2,
                     delay: Math.random() * 5,
                     repeat: Number.POSITIVE_INFINITY,
                  }}
               />
            ))}
         </div>

         {/* Main Content */}
         <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4">
            {/* Animated 404 Text */}
            <motion.div
               className="text-center mb-8"
               style={{
                  perspective: 1000,
                  rotateX,
                  rotateY,
               }}
            >
               <motion.h1
                  className="text-8xl md:text-9xl lg:text-[12rem] font-black mb-4 relative"
                  variants={glitchVariants}
                  initial="initial"
                  animate="glitch"
               >
                  <span className="relative inline-block">
                     4
                     <motion.span
                        className="absolute inset-0 text-[#1463fd]"
                        animate={{
                           x: [0, 2, -2, 0],
                           opacity: [0, 0.7, 0],
                        }}
                        transition={{
                           duration: 0.2,
                           repeat: Number.POSITIVE_INFINITY,
                           repeatDelay: 3,
                        }}
                     >
                        4
                     </motion.span>
                  </span>
                  <motion.span
                     className="inline-block mx-4 text-[#1463fd]"
                     animate={{
                        rotateY: [0, 180, 360],
                        scale: [1, 1.2, 1],
                     }}
                     transition={{
                        duration: 2,
                        repeat: Number.POSITIVE_INFINITY,
                        ease: "easeInOut",
                     }}
                  >
                     0
                  </motion.span>
                  <span className="relative inline-block">
                     4
                     <motion.span
                        className="absolute inset-0 text-[#1463fd]"
                        animate={{
                           x: [0, -2, 2, 0],
                           opacity: [0, 0.7, 0],
                        }}
                        transition={{
                           duration: 0.2,
                           repeat: Number.POSITIVE_INFINITY,
                           repeatDelay: 2.5,
                        }}
                     >
                        4
                     </motion.span>
                  </span>
               </motion.h1>

               {/* Glitch Lines */}
               <motion.div
                  className="absolute inset-0 pointer-events-none"
                  animate={{
                     opacity: [0, 1, 0],
                  }}
                  transition={{
                     duration: 0.1,
                     repeat: Number.POSITIVE_INFINITY,
                     repeatDelay: 4,
                  }}
               >
                  <div className="absolute top-1/3 left-0 right-0 h-0.5 bg-[#1463fd]" />
                  <div className="absolute top-2/3 left-0 right-0 h-0.5 bg-white" />
               </motion.div>
            </motion.div>

            {/* Animated Subtitle */}
            <motion.div
               className="text-center mb-12"
               initial={{ opacity: 0, y: 50 }}
               animate={{ opacity: 1, y: 0 }}
               transition={{ delay: 0.5, duration: 0.8 }}
            >
               <motion.h2
                  className="text-2xl md:text-3xl font-bold mb-4 bg-gradient-to-r from-white via-[#1463fd] to-white bg-clip-text text-transparent"
                  animate={{
                     backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
                  }}
                  transition={{
                     duration: 3,
                     repeat: Number.POSITIVE_INFINITY,
                     ease: "linear",
                  }}
                  style={{
                     backgroundSize: "200% 200%",
                  }}
               >
                  Oops! Page Not Found
               </motion.h2>
               <motion.p
                  className="text-gray-400 text-lg max-w-md mx-auto"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1, duration: 0.8 }}
               >
                  The page you're looking for seems to have vanished into the
                  digital void.
               </motion.p>
            </motion.div>

            {/* Interactive Buttons */}
            <motion.div
               className="flex flex-col sm:flex-row gap-4"
               initial={{ opacity: 0, y: 30 }}
               animate={{ opacity: 1, y: 0 }}
               transition={{ delay: 1.2, duration: 0.8 }}
            >
               <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onHoverStart={() => setIsHovered(true)}
                  onHoverEnd={() => setIsHovered(false)}
               >
                  <Link
                     href="/"
                     className="group relative inline-flex items-center gap-2 px-8 py-4 bg-[#1463fd] text-white font-semibold rounded-full overflow-hidden transition-all duration-300 hover:shadow-lg hover:shadow-[#1463fd]/25"
                  >
                     <motion.div
                        className="absolute inset-0 bg-white"
                        initial={{ x: "-100%" }}
                        whileHover={{ x: 0 }}
                        transition={{ duration: 0.3 }}
                     />
                     {/* <Home
                        className="relative z-10 group-hover:text-black transition-colors duration-300"
                        size={20}
                     /> */}
                     <span className="relative z-10 group-hover:text-black transition-colors duration-300">
                        Go Home
                     </span>
                  </Link>
               </motion.div>

               <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
               >
                  <button
                     onClick={() => window.history.back()}
                     className="group relative inline-flex items-center gap-2 px-8 py-4 border-2 border-white text-white font-semibold rounded-full overflow-hidden transition-all duration-300 hover:bg-white hover:text-black"
                  >
                     {/* <ArrowLeft
                        className="transition-transform duration-300 group-hover:-translate-x-1"
                        size={20}
                     /> */}
                     <span>Go Back</span>
                  </button>
               </motion.div>
            </motion.div>

            {/* Animated Lightning Bolt */}
            <motion.div
               className="absolute top-1/4 right-1/4 text-[#1463fd]"
               animate={{
                  rotate: [0, 10, -10, 0],
                  scale: [1, 1.2, 1],
               }}
               transition={{
                  duration: 2,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "easeInOut",
               }}
            >
               {/* <Zap size={60} /> */}
            </motion.div>

            {/* Mouse Follower */}
            <motion.div
               className="fixed pointer-events-none z-50 mix-blend-difference"
               animate={{
                  x: mousePosition.x - 10,
                  y: mousePosition.y - 10,
               }}
               transition={{
                  type: "spring",
                  stiffness: 500,
                  damping: 28,
               }}
            >
               <motion.div
                  className="w-5 h-5 bg-[#1463fd] rounded-full"
                  animate={{
                     scale: isHovered ? 2 : 1,
                  }}
                  transition={{
                     duration: 0.2,
                  }}
               />
            </motion.div>
         </div>

         {/* Rotating Border Elements */}
         <motion.div
            className="absolute top-10 left-10 w-20 h-20 border-2 border-[#1463fd] rounded-full"
            animate={controls}
         />
         <motion.div
            className="absolute bottom-10 right-10 w-16 h-16 border-2 border-white"
            animate={{
               rotate: -360,
            }}
            transition={{
               duration: 15,
               repeat: Number.POSITIVE_INFINITY,
               ease: "linear",
            }}
         />
         <motion.div
            className="absolute top-1/2 left-10 w-12 h-12 border-2 border-[#1463fd]"
            animate={{
               rotate: [0, 45, 90, 135, 180, 225, 270, 315, 360],
               scale: [1, 1.1, 1],
            }}
            transition={{
               duration: 8,
               repeat: Number.POSITIVE_INFINITY,
               ease: "linear",
            }}
         />
      </div>
   );
}
