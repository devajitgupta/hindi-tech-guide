// app/[lang]/layout.tsx
import type { Metadata } from "next";
import { Poppins, Open_Sans } from "next/font/google";
import "../globals.css";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/effect-creative";
import Footer from "@/components/footer";
import Consultation from "@/components/Consultation";
import Navbar from "@/components/navbar";
import { CookieProvider } from "@/components/cookies/CookieContext";
import CookieBanner from "@/components/cookies/CookieBanner";
import CookieSettings from "@/components/cookies/CookieSettings";
import { Toaster } from "react-hot-toast";
import { LanguageProvider } from "@/context/LanguageProvider";
import { i18n, TLocale } from "../../i18n-config";
import { getDictionary } from "../../get-dictionary";
import { UIProviders } from "../ui-providers";

const poppins_init = Poppins({
   subsets: ["latin"],
   weight: ["100", "200", "300", "400", "500", "600", "700", "800", "900"],
   variable: "--font-poppins",
});

const inter_init = Open_Sans({
   subsets: ["latin"],
   weight: ["300", "400", "500", "600", "700", "800"],
   variable: "--font-inter",
});

type Props = {
   children: React.ReactNode;
   params: { lang: TLocale };
};

export async function generateStaticParams() {
   return i18n.locales.map((lang) => ({ lang }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
   const { lang } = params;

   return {
      title:
         lang === "es"
            ? "ByteScrum Technologies - Soluciones IT"
            : "ByteScrum Technologies - IT Solutions",
      description:
         lang === "es"
            ? "Empresa líder en TI para soluciones web, móviles y blockchain"
            : "Top IT Company for Web, Mobile & Blockchain Solutions",
      alternates: {
         canonical: lang === "en" ? "/" : `/${lang}`,
         languages: {
            en: "/",
            es: "/es",
         },
      },
   };
}

export default async function RootLayout({ children, params }: Props) {
   const { lang } = params;

   const dictionary = await getDictionary(lang);
   const langText = dictionary.homeDataPage;
   const langTextconsultationForm = dictionary.consultationForm;

   const jsonLd = {
      "@context": "https://schema.org",
      "@type": "Organization",
      name: "ByteScrum Technologies",
      url: "https://www.bytescrum.com/",
      logo: "https://yourwebsite.com/logo.png",
      description:
         "Top IT Company for Web, Mobile & Blockchain Solutions in USA, Canada, Netherlands.",
      serviceType: "Software Development Services",
      areaServed: {
         "@type": "Place",
         name: "Global",
      },
      address: {
         "@type": "PostalAddress",
         streetAddress: "B-50 2nd Floor, Vibhuti Khand, Gomti Nagar",
         addressLocality: "Lucknow",
         addressRegion: "Utter Pradesh",
         postalCode: "226010",
         addressCountry: "India",
      },
      contactPoint: {
         "@type": "ContactPoint",
         telephone: "+91 7607815580",
         contactType: "Customer Support",
         areaServed: "Worldwide",
         email: "support@bytescrum.com",
         availableLanguage: ["English", "Spanish"],
      },
      sameAs: [
         "https://www.instagram.com/bytescrum/",
         "https://x.com/bytescrum",
         "https://www.linkedin.com/company/bytescrum/posts/?feedView=all",
         "https://www.facebook.com/bytescrum",
      ],
   };

   return (
      <html lang={lang} suppressHydrationWarning className="scrollbar-hide">
         <head>
            <script
               type="application/ld+json"
               dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
            />
         </head>
         <body
            className={`${poppins_init.variable} ${inter_init.variable} overflow-x-hidden`}
         >
            <LanguageProvider>
               <UIProviders>
                  <Consultation langText={langTextconsultationForm} />
                  <Navbar lang={lang} langText={langText} />
                  <main>{children}</main>
                  <Footer langText={langText} />
               </UIProviders>
               <Toaster position="top-center" reverseOrder={false} />
               <CookieProvider>
                  <CookieBanner />
                  <CookieSettings />
               </CookieProvider>
            </LanguageProvider>
         </body>
      </html>
   );
}
