import Connect from "@/components/connectSection/Connect";
import ConnectForm from "@/components/contactUs/ConnectForm";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import DevelopmentExpertise from "@/components/service/webDevelopment/DevelopmentExpertise";
import EffectiveTeamSection from "@/components/service/webDevelopment/EffectiveTeamSection";
import WebDevOverViewSection from "@/components/service/webDevelopment/WebDevOverViewSection";
import WebDevPageBanner from "@/components/service/webDevelopment/WebDevPageBanner";
import TurstedMarquee from "@/components/TurstedMarquee";
import OverviewSection from "@/components/ui/OverviewSection";
import ProcessSection from "@/components/ui/ProcessSection";
import ServiceSection from "@/components/ui/ServiceSection";
import { Divider } from "@nextui-org/react";
import clsx from "clsx";
import React from "react";
import { Metadata } from "next";
import { TLocale } from "@/i18n-config";
import { getDictionary } from "@/get-dictionary";

export const metadata: Metadata = {
   title: "Python Development Services | ByteScrum Technologies",
   description:
      "Build secure and scalable apps with ByteScrum's Python development services. From web apps to data science and machine learning, we deliver tailored solutions using Django, Flask, and more.",
};


type Props = {
   params: { lang: TLocale };
};
export default async function WebDevelopment({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const langTextContactForm = dictionary.contactPage.contactFormSection;
   const countUpData = dictionary.homeDataPage
   const webDevelopmentPage= dictionary.webDevelopmentPage

   const langText = dictionary.WebDevelopmentPage;
    const sectionStyle =
      " px-5 md:px-[40px] py-[60px] md:py-[60px]  gap-[40px] bg-[#000000] overflow-hidden";
   const jsonLd = {
      "@context": "https://schema.org",
      "@type": "Service",
      name: "Python Development Services | ByteScrum Technologies",
      url: "https://www.bytescrum.com/python-development",
      about: {
         "@type": "CreativeWork",
         name: "Custom Python Development Solutions",
         description:
            "ByteScrum Technologies offers expert Python development services including web development, data analytics, machine learning, automation, and custom software solutions. Leverage powerful Python frameworks for scalable, efficient, and secure applications.",
      },
   };

   return (
      <>
         {" "}
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fafafa]  ">
            <WebDevPageBanner data= {webDevelopmentPage} />
            <OverviewSection
               className={clsx(sectionStyle, "py-5 md:py-0")}
               data={webDevelopmentPage.Overview} countUpData={countUpData} />
            {/* <WebDevOverViewSection
            className={clsx(sectionStyle, "py-5 md:py-0")}
         /> */}

            <DevelopmentExpertise data={webDevelopmentPage}
               className={clsx(sectionStyle, "md:py-[0px] md:pb-[60px]")}
            />
            <div className="pt-[74px] grid items-center gap-[40px] md:gap-[40px] relative overflow-hidden bg-gradient-to-b lg:bg-gradient-to-r from-[#0D0D0D]/50 to-[#2A2A2A]/50">
               <SectionTitle>{langText.homePageData.trustedBy}</SectionTitle>
               <SectionSubtitle className="max-w-[341px] md:max-w-[800px] m-auto">
                {langText.homePageData.trustedBySubtitle}
               </SectionSubtitle>
               <TurstedMarquee data={countUpData} />
            </div>
            {/* <TechShowCase className={clsx(sectionStyle)} /> */}
            <ServiceSection
               className={clsx(sectionStyle)}
               serviceSection={langText.serviceSection}
               data={langText.services}
            />
            <ProcessSection
               data={langText.processSection}
               className={clsx(sectionStyle)}
               steps={langText.steps}
            />
            <EffectiveTeamSection data={webDevelopmentPage} className={clsx(sectionStyle)} />
            {/* <Connect /> */}
            <Divider className="bg-[#262626] my-5" />
            <ConnectForm langText={langTextContactForm} className="py-10" />
         </div>
      </>
   );
};


// const services = [
//    {
//       icon: "lineicons:react",
//       title: "React Development",
//       description:
//          "Build dynamic user interfaces with React's component-based architecture.",
//    },
//    {
//       icon: "arcticons:my-supermarket-simulator-3d",
//       title: "E-Commerce Development",
//       description:
//          "Create robust online stores with seamless shopping experiences.",
//    },
//    {
//       icon: "bi:filetype-php",
//       title: "PHP Development",
//       description:
//          "Develop server-side applications efficiently using PHP scripting.",
//    },
//    {
//       icon: "simple-icons:laravel",
//       title: "Laravel Development",
//       description:
//          "Leverage Laravel for elegant and powerful web applications.",
//    },
//    {
//       icon: "bxl:nodejs",
//       title: "Node JS Development",
//       description: "Build scalable network applications with Node.js runtime.",
//    },
//    {
//       icon: "fluent:window-dev-tools-20-regular",
//       title: "Full Stack Development",
//       description:
//          "Deliver complete solutions with expertise in both front and back end.",
//    },
//    {
//       icon: "simple-icons:opensourcehardware",
//       title: "Open Source Development",
//       description:
//          "Contribute to and build projects using open source technologies.",
//    },
//    {
//       icon: "teenyicons:angular-outline",
//       title: "Angular Development",
//       description:
//          "Create dynamic web applications using Angular's powerful framework.",
//    },
// ];

// const steps = [
//    {
//       icon: "mdi:clipboard-text",
//       title: "Collection of Information",
//       text: "Understanding business objectives, user needs, and defining key software features is crucial for the success of any project. This phase involves gathering detailed requirements to ensure that the final product meets the expectations of all stakeholders involved.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:draw",
//       title: "UI/UX Design",
//       text: "Crafting intuitive and engaging user interfaces for seamless experiences is essential in today's digital landscape. Our design process focuses on creating visually appealing layouts that enhance user interaction and satisfaction, ensuring a positive experience across all devices.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:code-braces",
//       title: "Web Development",
//       text: "Building robust, scalable, and high-performance web applications tailored to your needs is our specialty. We utilize the latest technologies and best practices to ensure that your application is not only functional but also efficient and user-friendly.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:test-tube",
//       title: "Testing & Quality Assurance",
//       text: "Ensuring web application reliability through rigorous testing and debugging is a critical step in our development process. We conduct comprehensive tests to identify and resolve any issues, guaranteeing that the final product is stable and performs as expected.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:cloud-upload",
//       title: "Deployment & Support",
//       text: "Launching the web application with continuous monitoring and post-launch support is vital for its success. We provide ongoing assistance to address any issues that may arise after deployment, ensuring that your application remains functional and up-to-date.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
// ];
