import Connect from "@/components/connectSection/Connect";
import ConnectForm from "@/components/contactUs/ConnectForm";
import AnalyticsReporting from "@/components/service/digitalMarketing/AnalyticsReporting";
import ContentMarketing from "@/components/service/digitalMarketing/ContentMarketing";
import DigitalMarketingHero from "@/components/service/digitalMarketing/DigitalMarketingHero";
import DigitalMarketingService from "@/components/service/digitalMarketing/DigitalMarketingService";
import DigitalPlatformsSection from "@/components/service/digitalMarketing/DigitalPlatformsSection";
import MarketingStrategies from "@/components/service/digitalMarketing/MarketingStrategies";
import OtherServiceSection from "@/components/service/digitalMarketing/OtherServiceSection";
import SeoServices from "@/components/service/digitalMarketing/SeoServices";
import SocialMediaMarketing from "@/components/service/digitalMarketing/SocialMediaMarketing";
import SuccesStories from "@/components/service/digitalMarketing/SuccesStories";
import FAQSection from "@/components/ui/FaqSection/FAQSection";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";
import { Divider } from "@nextui-org/react";
import clsx from "clsx";
import { Metadata } from "next";
import React from "react";
import { twMerge } from "tailwind-merge";

export const metadata: Metadata = {
  title: "Digital Marketing Services | ByteScrum Technologies",
  description:
    "Boost your brand’s online presence with ByteScrum Technologies' comprehensive digital marketing services including SEO, content marketing, social media, PPC, email campaigns, and analytics.",
};

type Props = {
  params: { lang: TLocale };
};
export default async function DigitalMarketingPage({
  params: { lang },
}: Props) {
  const dictionary = await getDictionary(lang);
  const langTextContactForm = dictionary.contactPage.contactFormSection;

  const langText = dictionary.DigitalMarketingPage;
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 10,
      },
    },
  };

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: "Digital Marketing Services | ByteScrum Technologies",
    url: "https://www.bytescrum.com/digital-marketing",

    about: {
      "@type": "CreativeWork",
      name: "Data-Driven Digital Marketing Solutions",
      description:
        "ByteScrum Technologies offers result-oriented digital marketing services including SEO, social media marketing, content creation, PPC, email campaigns, and performance analytics to help brands grow online effectively.",
    },
  };

  const sectionStyle =
    "  md:px-[40px] py-[60px] md:py-[60px]  gap-[40px] bg-[#000000] overflow-hidden";
  return (
    <>
      {" "}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <div className="max-w-[1728px]  m-auto bg-[#000000] inter text-[#fff] ">
        <DigitalMarketingHero langText={langText} />
        <DigitalMarketingService
          containerVariants={containerVariants}
          itemVariants={itemVariants}
          langText={langText}
          className={twMerge(clsx(sectionStyle))}
        />
        <MarketingStrategies
          data={langText.MarketingStrategies}
          strategies={langText.strategies}
          className={twMerge(clsx(sectionStyle))}
        />
        <SocialMediaMarketing
          socialMediaMarketing={langText.socialMediaMarketing}
          className={twMerge(clsx(sectionStyle))}
          data={langText.SocialMediaMarketing}
        />
        <SeoServices
          className={twMerge(clsx(sectionStyle))}
          seoServices={langText.seoServices}
          data={langText.seoservices}
          socialMediaServices={langText.socialMediaServices}
          contentServices={langText.contentServices}
          analyticsServices={langText.analyticsServices}
        />
        <ContentMarketing
          className={twMerge(clsx(sectionStyle, "bg-black/0"))}
          contentMarketing={langText.contentMarketing}
        />
        <AnalyticsReporting
              className={twMerge(clsx(sectionStyle))}
              analyticsReporting={langText.analyticsReporting} data={langText.AnalyticsReporting}        />
        <SuccesStories
          className={twMerge(clsx(sectionStyle))}
          caseStudies={langText.caseStudies}
          data={langText.SuccesStories}
        />
        <DigitalPlatformsSection data= {langText.DigitalPlatformsSection}
          className={twMerge(clsx(sectionStyle))}
          platforms={langText.platforms}
        />
        <FAQSection
          className={twMerge(clsx(sectionStyle, "border-t border-[#262626]"))}
          data={langText.faqs}
          header={langText.faqSectionHeader}
        />
        <OtherServiceSection
          className={twMerge(clsx(sectionStyle))}
          otherServices={langText.otherServices}
          data={langText.OtherServiceSection}
        />
        {/* <Connect
            title="Ready to Grow Your Business?"
            text="Let's discuss how our digital marketing strategies can help you achieve your business goals and drive measurable results."
         /> */}
        <Divider className="bg-[#262626] my-5" />
        <ConnectForm langText={langTextContactForm} className="py-10" />
      </div>
    </>
  );
}

// const services = [
//    {
//       title: "Search Engine Optimization",
//       icon: "material-symbols:search-rounded",

//       description:
//          "Boost your website's visibility in search engine results and drive organic traffic.",
//       link: "/digital-marketing/seo",
//    },
//    {
//       title: "Social Media Marketing",
//       icon: "line-md:hash",

//       description:
//          "Engage with your audience and build brand awareness across social media platforms.",
//       link: "/digital-marketing/social-media",
//    },
//    {
//       title: "Content Marketing",
//       icon: "mdi:pencil-outline",

//       description:
//          "Create valuable content that attracts and retains your target audience.",
//       link: "/digital-marketing/content",
//    },
//    {
//       title: "Email Marketing",
//       icon: "mdi:email",

//       description:
//          "Nurture leads and drive conversions with targeted email campaigns.",
//       link: "/digital-marketing/email",
//    },
//    {
//       title: "Pay-Per-Click Advertising",
//       icon: "cryptocurrency:appc",

//       description:
//          "Generate immediate traffic and conversions with strategic paid advertising.",
//       link: "/digital-marketing/ppc",
//    },
//    {
//       title: "Analytics & Reporting",
//       icon: "uil:analytics",

//       description:
//          "Measure performance and gain insights to optimize your marketing strategies.",
//       link: "/digital-marketing/analytics",
//    },
// ];

// const strategies = [
//    {
//       title: "Brand Awareness",
//       description:
//          "Increase visibility and recognition of your brand among your target audience.",
//       color: "blue",
//    },
//    {
//       title: "Lead Generation",
//       description:
//          "Attract and convert high-quality prospects into leads for your business.",
//       color: "purple",
//    },
//    {
//       title: "Conversion Optimization",
//       description:
//          "Improve your website's ability to convert visitors into customers.",
//       color: "pink",
//    },
//    {
//       title: "Customer Retention",
//       description:
//          "Develop strategies to keep customers engaged and coming back for more.",
//       color: "green",
//    },
// ];

// const socialMediaMarketing = {
//    platformDescription: [
//       {
//          title: "Platform Selection",
//          description:
//             "We identify the most relevant platforms for your business based on your target audience and goals.",
//       },
//       {
//          title: "Content Strategy",
//          description:
//             "We develop a content strategy that resonates with your audience and aligns with your brand voice.",
//       },
//       {
//          title: "Community Building",
//          description:
//             "We help you build and nurture an engaged community around your brand.",
//       },
//       {
//          title: "Paid Advertising",
//          description:
//             "We create targeted ad campaigns to reach your ideal customers and drive specific actions.",
//       },
//    ],
//    platforms: [
//       {
//          title: "Facebook",
//          icon: "logos:facebook",
//       },
//       {
//          title: "Instagram",
//          icon: "skill-icons:instagram",
//       },
//       {
//          title: "X",
//          icon: "prime:twitter",
//       },
//       {
//          title: "Linkedin",
//          icon: "skill-icons:linkedin",
//       },
//       {
//          title: "TikTok",
//          icon: "iconoir:tiktok-solid",
//       },
//       {
//          title: "Youtube",
//          icon: "logos:youtube-icon",
//       },
//       {
//          title: "Pinterest",
//          icon: "logos:pinterest",
//       },
//       {
//          title: "Snapchat",
//          icon: "akar-icons:snapchat-fill",
//       },
//    ],
// };

// const seoServices = [
//    {
//       title: "Keyword Research",
//       description:
//          "Identify high-value keywords that your target audience is searching for.",
//       icon: "carbon:search",
//    },
//    {
//       title: "On-Page SEO",
//       description:
//          "Optimize your website's content and structure to improve search engine rankings.",
//       icon: "carbon:document",
//    },
//    {
//       title: "Off-Page SEO",
//       description:
//          "Build high-quality backlinks and improve your website's authority.",
//       icon: "icon-park-twotone:connection-point-two",
//    },
//    {
//       title: "Technical SEO",
//       description:
//          "Ensure your website is technically optimized for search engine crawling and indexing.",
//       icon: "carbon:code",
//    },
//    {
//       title: "Local SEO",
//       description:
//          "Improve visibility for local searches and attract customers in your area.",
//       icon: "carbon:location",
//    },
//    {
//       title: "SEO Audit",
//       description:
//          "Comprehensive analysis of your website's SEO performance and opportunities.",
//       icon: "carbon:report",
//    },
// ];

// const socialMediaServices = [
//    {
//       title: "Social Media Strategy",
//       description:
//          "Develop a comprehensive strategy aligned with your business goals.",
//       icon: "line-md:hash",
//    },
//    {
//       title: "Content Creation",
//       description:
//          "Create engaging content tailored to each social media platform.",
//       icon: "carbon:pen",
//    },
//    {
//       title: "Community Management",
//       description:
//          "Build and nurture relationships with your audience through active engagement.",
//       icon: "carbon:group",
//    },
//    {
//       title: "Social Media Advertising",
//       description:
//          "Create targeted ad campaigns to reach your ideal customers.",
//       icon: "cryptocurrency:appc",
//    },
//    {
//       title: "Influencer Marketing",
//       description:
//          "Collaborate with influencers to expand your reach and credibility.",
//       icon: "carbon:star",
//    },
//    {
//       title: "Social Listening",
//       description:
//          "Monitor conversations about your brand and industry to gain insights.",
//       icon: "carbon:hearing",
//    },
// ];

// const contentServices = [
//    {
//       title: "Content Strategy",
//       description:
//          "Develop a content plan aligned with your business goals and audience needs.",
//       icon: "line-md:hash",
//    },
//    {
//       title: "Blog Writing",
//       description:
//          "Create informative and engaging blog posts that attract and educate your audience.",
//       icon: "carbon:blog",
//    },
//    {
//       title: "Copywriting",
//       description: "Craft compelling copy that drives action and conversions.",
//       icon: "ic:sharp-copyright",
//    },
//    {
//       title: "Video Content",
//       description:
//          "Produce engaging video content that tells your brand story.",
//       icon: "carbon:video",
//    },
//    {
//       title: "Infographics",
//       description: "Create visual content that simplifies complex information.",
//       icon: "carbon:chart-line-data",
//    },
//    {
//       title: "Content Distribution",
//       description:
//          "Ensure your content reaches your target audience through multiple channels.",
//       icon: "carbon:share",
//    },
// ];

// const analyticsServices = [
//    {
//       title: "Performance Tracking",
//       description:
//          "Monitor key metrics to measure the success of your marketing campaigns.",
//       icon: "carbon:chart-line",
//    },
//    {
//       title: "Conversion Analysis",
//       description:
//          "Identify what drives conversions and optimize your marketing funnel.",
//       icon: "tabler:chart-scatter-3d",
//    },
//    {
//       title: "Audience Insights",
//       description:
//          "Gain a deeper understanding of your audience's behavior and preferences.",
//       icon: "carbon:user-profile",
//    },
//    {
//       title: "Competitive Analysis",
//       description:
//          "Benchmark your performance against competitors and identify opportunities.",
//       icon: "hugeicons:market-analysis",
//    },
//    {
//       title: "Custom Reporting",
//       description:
//          "Receive tailored reports that focus on the metrics that matter to your business.",
//       icon: "carbon:report-data",
//    },
//    {
//       title: "Data Visualization",
//       description:
//          "Transform complex data into clear, actionable insights through visual representations.",
//       icon: "carbon:chart-pie",
//    },
// ];
// const contentMarketing = {
//    services: [
//       {
//          title: "Blog Posts",
//          description:
//             "Informative articles that establish your expertise and improve SEO.",
//          icon: "carbon:blog",
//          color: "pink",
//       },
//       {
//          title: "Infographics",
//          description:
//             "Visual content that simplifies complex information and increases shareability.",
//          icon: "carbon:chart-line-data",
//          color: "blue",
//       },
//       {
//          title: "Videos",
//          description:
//             "Engaging video content that tells your brand story and demonstrates products.",
//          icon: "carbon:video",
//          color: "purple",
//       },
//       {
//          title: "Ebooks & Whitepapers",
//          description:
//             "In-depth resources that generate leads and showcase your expertise.",
//          icon: "carbon:document",
//          color: "green",
//       },
//    ],
//    benfit: [
//       {
//          title: "Increased Website Traffic",
//          icon: "carbon:chart-line",
//          color: "blue",
//       },
//       {
//          title: "Higher Conversion Rates",
//          icon: "carbon:chart-3d",
//          color: "green",
//       },
//       {
//          title: "Improved Brand Awareness",
//          icon: "carbon:improve-relevance",
//          color: "purple",
//       },
//       {
//          title: "Better Customer Engagement",
//          icon: "carbon:user-profile",
//          color: "pink",
//       },
//       {
//          title: "Enhanced SEO Performance",
//          icon: "carbon:search",
//          color: "amber",
//       },
//       {
//          title: "Established Industry Authority",
//          icon: "carbon:certificate",
//          color: "indigo",
//       },
//    ],
// };

// const analyticsReporting = {
//    metrics: [
//       {
//          label: "Organic Traffic",
//          value: "12,458",
//          growth: "+24%",
//          color: "blue",
//       },
//       {
//          label: "Conversion Rate",
//          value: "3.8%",
//          growth: "+1.2%",
//          color: "green",
//       },
//       {
//          label: "Bounce Rate",
//          value: "42%",
//          growth: "-5%",
//          color: "pink",
//       },
//       {
//          label: "Avg. Session Duration",
//          value: "2:45",
//          growth: "+0:35",
//          color: "purple",
//       },
//    ],
//    benefits: [
//       "Real-time performance monitoring",
//       "Custom reporting dashboards",
//       "Actionable insights and recommendations",
//       "ROI tracking for all marketing channels",
//       "Competitor benchmarking",
//    ],
//    whatMatters: [
//       {
//          title: "Comprehensive Tracking",
//          description:
//             "We track all relevant metrics across your marketing channels to provide a complete picture of your performance.",
//          icon: "carbon:chart-multitype",
//          color: "blue",
//       },
//       {
//          title: "Custom Dashboards",
//          description:
//             "We create tailored dashboards that focus on the metrics that matter most to your business goals.",
//          icon: "carbon:dashboard",
//          color: "purple",
//       },
//       {
//          title: "Regular Reporting",
//          description:
//             "Receive detailed reports with actionable insights and recommendations for optimization.",
//          icon: "carbon:report",
//          color: "green",
//       },
//       {
//          title: "Continuous Optimization",
//          description:
//             "We use data-driven insights to continuously refine and improve your marketing strategies.",
//          icon: "icon-park-outline:smart-optimization",
//          color: "pink",
//       },
//    ],
// };

// const caseStudies = [
//    {
//       title: "E-commerce Revenue Growth",
//       description:
//          "Increased online sales by 150% through integrated SEO and PPC strategies.",
//       industry: "Retail",
//       results: [
//          "150% increase in revenue",
//          "200% ROI on ad spend",
//          "45% increase in organic traffic",
//       ],
//       image: "/E-commerceRevenueGrowth.webp",
//    },
//    {
//       title: "B2B Lead Generation",
//       description:
//          "Generated 300+ qualified leads per month for a SaaS company through content marketing.",
//       industry: "Technology",
//       results: [
//          "300+ monthly leads",
//          "35% conversion rate",
//          "65% reduction in cost per lead",
//       ],
//       image: "/b2b.webp",
//    },
//    {
//       title: "Local Business Visibility",
//       description:
//          "Boosted local search visibility and in-store visits for a retail chain.",
//       industry: "Local Business",
//       results: [
//          "400% increase in local search visibility",
//          "250% increase in store visits",
//          "125% increase in revenue",
//       ],
//       image: "/localBusiness.webp",
//    },
// ];

// const platforms = [
//    { name: "Google", icon: "logos:google", category: "search" },
//    { name: "Facebook", icon: "logos:facebook", category: "social" },
//    { name: "Instagram", icon: "skill-icons:instagram", category: "social" },
//    { name: "LinkedIn", icon: "logos:linkedin-icon", category: "social" },
//    { name: "X", icon: "prime:twitter", category: "social" },
//    { name: "YouTube", icon: "logos:youtube-icon", category: "social" },
//    { name: "Pinterest", icon: "logos:pinterest", category: "social" },
//    { name: "TikTok", icon: "logos:tiktok-icon", category: "social" },
//    { name: "Google Ads", icon: "logos:google-ads", category: "advertising" },
//    { name: "Facebook Ads", icon: "logos:facebook", category: "advertising" },
//    { name: "Mailchimp", icon: "logos:mailchimp-freddie", category: "email" },
//    { name: "HubSpot", icon: "logos:hubspot", category: "marketing" },
//    { name: "Semrush", icon: "simple-icons:semrush", category: "seo" },
//    { name: "Hootsuit", icon: "logos:hootsuite-icon", category: "advertising" },
//    {
//       name: "Google Analytics",
//       icon: "logos:google-analytics",
//       category: "analytics",
//    },
// ];

// const faqs = [
//    {
//       question: "What is digital marketing?",
//       answer:
//          "Digital marketing encompasses all marketing efforts that use electronic devices or the internet. Businesses leverage digital channels such as search engines, social media, email, and websites to connect with current and prospective customers.",
//    },
//    {
//       question: "How long does it take to see results from digital marketing?",
//       answer:
//          "The timeline for seeing results varies depending on the strategies implemented. Some tactics like PPC advertising can yield immediate results, while others like SEO and content marketing are long-term strategies that typically show significant results after 3-6 months of consistent effort.",
//    },
//    {
//       question: "How much should I budget for digital marketing?",
//       answer:
//          "Your digital marketing budget depends on your business goals, industry, and the competitive landscape. As a general guideline, businesses typically allocate 7-10% of their revenue to marketing, with a growing portion dedicated to digital channels. We offer customized strategies to fit various budget levels.",
//    },
//    {
//       question: "Do I need to be on all social media platforms?",
//       answer:
//          "No, it's more effective to focus on the platforms where your target audience is most active rather than spreading yourself thin across all platforms. We help identify the most relevant channels for your business and develop strategies to maximize your presence there.",
//    },
//    {
//       question:
//          "How do you measure the success of digital marketing campaigns?",
//       answer:
//          "We track key performance indicators (KPIs) aligned with your business goals, such as website traffic, conversion rates, lead generation, engagement metrics, and return on investment (ROI). We provide regular reports with actionable insights to continuously optimize your campaigns.",
//    },
//    {
//       question: "Can digital marketing work for my small business?",
//       answer:
//          "Digital marketing offers scalable solutions for businesses of all sizes. For small businesses, it provides cost-effective ways to reach targeted audiences and compete with larger companies. We develop strategies tailored to your specific needs and budget constraints.",
//    },
// ];

// const otherServices = [
//    {
//       title: "Web Development",
//       description:
//          "Create responsive, high-performance websites and web applications.",
//       link: "/custom-software-development",
//       color: "blue",
//    },
//    {
//       title: "E-commerce Development",
//       description:
//          "Build powerful online stores that drive sales and enhance customer experiences.",
//       link: "/ecommerce-development",
//       color: "pink",
//    },
//    {
//       title: "Mobile App Development",
//       description:
//          "Develop custom mobile applications for iOS and Android platforms.",
//       link: "/mobile-app-development",
//       color: "green",
//    },
//    {
//       title: "UI/UX Design",
//       description:
//          "Create intuitive, engaging user interfaces that enhance user satisfaction.",
//       link: "/ui-ux-designer",
//       color: "purple",
//    },
//    {
//       title: "Blockchain Development",
//       description:
//          "Leverage blockchain technology for secure, transparent applications.",
//       link: "/block-chain-development",
//       color: "indigo",
//    },
//    {
//       title: "Explore More Services",
//       description:
//          "Explore our full range of services designed to elevate your business in the digital landscape.",
//       link: "/services",
//       color: "pink",
//    },
// ];
