import React from "react";
import dynamic from "next/dynamic";
import ServiceSection from "@/components/ui/ServiceSection";
import clsx from "clsx";
import TurstedMarquee from "@/components/TurstedMarquee";
import ProcessSection from "@/components/ui/ProcessSection";
import EffectiveTeamSection from "@/components/ui/EffectiveTeamSection";
import DevExpertiseSection from "@/components/ui/DevExpertiseSection";
import TeamSwipper from "@/components/career/teamSection/TeamSwipper";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import SectionSubtitle from "@/components/SectionSubtitle";
import ConnectForm from "@/components/contactUs/ConnectForm";
import { Divider } from "@nextui-org/react";
import CustomSoftBusiness from "@/components/customSoftware/CustomSoftBusiness";
import OverviewSection from "@/components/ui/OverviewSection";
import { Metadata } from "next";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";

const CustomSoftHeroSection = dynamic(
   () => import("@/components/customSoftware/CustomSoftHeroSection"),
   {
      ssr: false,
   }
);

export const metadata: Metadata = {
   title: "Custom Software Development | ByteScrum Technologies",
   description:
      "Discover ByteScrum Technologies' custom software development expertise—from planning to deployment—delivering scalable web, mobile, AI/ML, and enterprise solutions built for business success.",
};


type Props = {
   params: { lang: TLocale };
};
export default async function CustomSoftwareDevelopmentPage({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const countUpData = dictionary.homeDataPage
   const langTextContactForm = dictionary.contactPage.contactFormSection;

   const langText = dictionary.CustomSoftwareDevelopmentPage; const sectionStyle =
      " px-5 md:px-[40px] py-[40px] md:py-[60px]  gap-[40px] bg-[#000000] overflow-hidden";
   const jsonLd = {
      "@context": "https://schema.org",
      "@type": "Service",
      name: "Custom Software Development | ByteScrum Technologies",
      url: "https://www.bytescrum.com/custom-software-development",

      about: {
         "@type": "CreativeWork",
         name: "Tailored Software Solutions for Business Success",
         description:
            "ByteScrum Technologies offers end-to-end custom software development services, including web, mobile, AI/ML, cloud, enterprise software, and more, tailored to meet unique business needs and accelerate growth.",
      },
   };

   return (
      <>
         {" "}
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] page-customSoftDev ">
            <CustomSoftHeroSection data={langText.CustomSoftHeroSection} />
            <OverviewSection
               countUpData={countUpData}

               className={clsx(sectionStyle, "py-5 md:py-0")}
               data={langText.overViewSection}
            />

            <CustomSoftBusiness data={langText.CustomSoftBusiness} />
            <DevExpertiseSection
               className={clsx(sectionStyle)}
               skills={langText}
            />
            <div className="pt-[74px]  grid items-center gap-[10px] md:gap-[10px] relative overflow-hidden   bg-gradient-to-b lg:bg-gradient-to-r  from-[#0D0D0D]/50 to-[#2A2A2A]/50">
               {" "}
               <SectionTitle>{langText.homePageData.trustedBy}</SectionTitle>
               <SectionSubtitle className="max-w-[341px] md:max-w-[800px] m-auto">
                  {" "}{langText.homePageData.trustedBySubtitle}
               </SectionSubtitle>
               <TurstedMarquee data={countUpData} className="mt-5" />
            </div>
            <ServiceSection
               className={clsx(sectionStyle)}
               serviceSection={langText.serviceSection}
               data={langText.services}
            />
            <ProcessSection className={clsx(sectionStyle)} steps={langText.steps} data={langText.processSection}
            />

            <EffectiveTeamSection
               langText={langText.effectiveTeamSection}
               data={langText.teamData}
               className={clsx(sectionStyle)}
            />
            <div>
               <SectionTitle className="max-w-3xl m-auto">
                  {langText.homePageData.sectionTitle}
               </SectionTitle>
               <Text className=" m-auto">
            {langText.homePageData.sectionSubtitle}
              </Text>
            </div>
            {/* <NewTeamSwipper
            className={clsx(sectionStyle)}
            swipperData={teamSection}
         /> */}
            <TeamSwipper
               className={clsx(sectionStyle)}
               swipperData={langText.teamSection}
            />

            {/* <Connect /> */}
            <Divider className="bg-[#262626] my-5" />
            <ConnectForm langText={langTextContactForm} className="py-10" />
         </div>
      </>
   );
};


// const overViewSection = {
//    descriptionOne:
//       "Custom software development focuses on scalability, integration, security, user-centric design, and tailored deployment solutions. These elements empower businesses with efficient workflows, seamless system communication, robust data protection, intuitive interfaces, and optimized development processes to deliver innovative, purpose-built applications.",
//    descriptionTwo:
//       "Advanced technologies like AI, cloud computing, and microservices architecture are revolutionizing the custom software landscape. They enable smarter automation, real-time decision-making, and scalable infrastructure. As businesses seek agility and innovation, custom software becomes a strategic asset—delivering competitive advantages and long-term value.",
// };

// const services = [
//    {
//       icon: "mdi:code-braces",
//       title: "Custom Software Development",
//       description:
//          "Tailored software solutions to meet your business needs with scalability and efficiency.",
//    },
//    {
//       icon: "mdi:web",
//       title: "Web Application Development",
//       description:
//          "Build responsive, high-performance web applications with the latest technologies.",
//    },
//    {
//       icon: "mdi:cellphone",
//       title: "Mobile App Development",
//       description:
//          "Develop user-friendly iOS and Android apps with a seamless experience.",
//    },
//    {
//       icon: "mdi:cloud",
//       title: "Cloud Solutions",
//       description:
//          "Leverage cloud computing for scalable, secure, and cost-effective business applications.",
//    },
//    {
//       icon: "mdi:server",
//       title: "Enterprise Software Solutions",
//       description:
//          "Develop robust enterprise applications to streamline business operations.",
//    },
//    {
//       icon: "mdi:security",
//       title: "Software Security & Compliance",
//       description:
//          "Ensure top-level security and compliance for your software applications.",
//    },
//    {
//       icon: "mdi:robot",
//       title: "AI & Machine Learning Solutions",
//       description:
//          "Integrate AI and machine learning to automate processes and enhance decision-making.",
//    },
//    {
//       icon: "mdi:database",
//       title: "Database Design & Management",
//       description:
//          "Optimize data storage, retrieval, and security with custom database solutions.",
//    },
// ];

// const skills = [
//    { name: "Software Development", level: 99 },
//    { name: "System Architecture", level: 98 },
//    { name: "Database Management", level: 97 },
//    { name: "API Development & Integration", level: 96 },
// ];

// const steps = [
//    {
//       icon: "mdi:clipboard-text",
//       title: "Requirement Gathering",
//       text: "Understanding business objectives, user needs, and defining key software features.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:draw",
//       title: "UI/UX Design",
//       text: "Crafting intuitive and engaging user interfaces for seamless experiences.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:code-braces",
//       title: "Software Development",
//       text: "Building robust, scalable, and high-performance software tailored to your needs.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:test-tube",
//       title: "Testing & Quality Assurance",
//       text: "Ensuring software reliability through rigorous testing and debugging.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:cloud-upload",
//       title: "Deployment & Support",
//       text: "Launching the software with continuous monitoring and post-launch support.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
// ];

// const teamData = [
//    {
//       title: "Software Engineer",
//       description:
//          "Design and develop high-performance software applications tailored to business needs.",
//    },
//    {
//       title: "Software Architect",
//       description:
//          "Define the overall structure and ensure the scalability, security, and efficiency of software solutions.",
//    },
//    {
//       title: "Full Stack Developer",
//       description:
//          "Build and maintain both front-end and back-end software systems for seamless user experiences.",
//    },
// ];

// const teamSection = [
//    {
//       _id: 1,
//       src: "/careers/divyank.png",
//       name: "Divyank Singh",
//    },
//    {
//       _id: 2,
//       src: "/careers/shashank.png",
//       name: "Shashank Dubey",
//    },
//    {
//       _id: 3,
//       src: "/careers/rishi.png",
//       name: "Rishi Singh",
//    },
//    {
//       _id: 4,
//       src: "/careers/ajay.png",
//       name: "Ajay Nishad",
//    },
//    {
//       _id: 5,
//       src: "/careers/divyank.png",
//       name: "Divyank Singh",
//    },
//    {
//       _id: 6,
//       src: "/careers/shashank.png",
//       name: "Shashank Dubey",
//    },
//    {
//       _id: 7,
//       src: "/careers/rishi.png",
//       name: "Rishi Singh",
//    },
//    {
//       _id: 8,
//       src: "/careers/ajay.png",
//       name: "Ajay Nishad",
//    },
// ];
