import ConnectForm from "@/components/contactUs/ConnectForm";
import LaravelAppSection from "@/components/laravelDev/LaravelAppSection";
import LaravelHeroSection from "@/components/laravelDev/LaravelHeroSection";
import WhyUsSection from "@/components/laravelDev/WhyUsSection";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import TurstedMarquee from "@/components/TurstedMarquee";
import DevExpertiseSection from "@/components/ui/DevExpertiseSection";
import EffectiveTeamSection from "@/components/ui/EffectiveTeamSection";
import OverviewSection from "@/components/ui/OverviewSection";
import ProcessSection from "@/components/ui/ProcessSection";
import ServiceSection from "@/components/ui/ServiceSection";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";
import { Divider } from "@nextui-org/react";
import clsx from "clsx";
import { Metadata } from "next";

export const metadata: Metadata = {
   title: "Laravel Web Development | ByteScrum Technologies",
   description:
      "Build scalable, secure Laravel web applications with ByteScrum Technologies. Get custom Laravel development, RESTful API integration, CRM solutions, and more.",
};


type Props = {
   params: { lang: TLocale };
};
export default async function LaravelWebDevelopmentPage({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang); const countUpData = dictionary.homeDataPage

   const langTextContactForm = dictionary.contactPage.contactFormSection;

   const langText = dictionary.LaravelWebDevelopmentPage; 
   const sectionStyle =
      " px-5 md:px-[40px] py-[40px]  md:py-[60px]  gap-[40px] bg-[#000000] overflow-hidden";
   const jsonLd = {
      "@context": "https://schema.org",
      "@type": "Service",
      name: "Laravel Web Development | ByteScrum Technologies",
      url: "https://www.bytescrum.com/laravel-web-development",

      about: {
         "@type": "CreativeWork",
         name: "Custom Laravel Web Application Development",
         description:
            "ByteScrum Technologies builds robust Laravel-based web solutions including custom development, RESTful APIs, CRM integration, performance optimization, and secure web apps. Partner with us for scalable, secure, and feature-rich Laravel applications.",
      },
   };

   return (
      <>
         {" "}
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fafafa]  ">
            <LaravelHeroSection data={langText.LaravelHeroSection} />
            <OverviewSection
               className={clsx(sectionStyle, "py-5 md:py-0")}
               data={langText.overViewSection} countUpData={countUpData} />

            <LaravelAppSection data= {langText.laravelAppSection} />
            <DevExpertiseSection
               className={clsx(sectionStyle, "md:py-[0px] md:pb-[60px]")}
               skills={langText}
            />
            <div className="pt-[74px]  grid items-center gap-[10px] md:gap-[10px] relative overflow-hidden   bg-gradient-to-b lg:bg-gradient-to-r  from-[#0D0D0D]/50 to-[#2A2A2A]/50">
               {" "}
               <SectionTitle>{langText.homePageData.trustedBy}</SectionTitle>
               <SectionSubtitle className="max-w-[341px] md:max-w-[800px] m-auto">
                  {langText.homePageData.trustedBySubtitle}
               </SectionSubtitle>
               <TurstedMarquee data={countUpData} className="mt-5" />
            </div>
            <ServiceSection
               className={clsx(sectionStyle)}
               data={langText.services}
               serviceSection={langText.serviceSection}

            />
            <WhyUsSection data={langText.whyUsSection} />
            <ProcessSection
               className={clsx(sectionStyle)}
               data={langText.processSection}
               steps={langText.steps}
            />
            <EffectiveTeamSection
               langText={langText.effectiveTeamSection}
               data={langText.teamData}
               className={clsx(sectionStyle)}
            />

            {/* <LaravelDevProcess /> */}
            {/* <Connect /> */}
            <Divider className="bg-[#262626] my-5" />
            <ConnectForm langText={langTextContactForm} className="py-10" />
         </div>
      </>
   );
};


// const overViewSection = {
//    descriptionOne:
//       "Laravel development focuses on building secure, scalable, and maintainable web applications using elegant syntax and powerful features. With built-in tools for routing, authentication, and database management, Laravel streamlines backend development, ensuring faster deployment and consistent code quality.",
//    descriptionTwo:
//       "Leveraging Laravel’s modular structure and ecosystem—such as Eloquent ORM, Blade templating, and Laravel Mix—developers can create robust APIs and dynamic web solutions. Its emphasis on developer productivity, security, and modern best practices makes Laravel ideal for delivering high-performance web applications across industries.",
// };

// const services = [
//    {
//       icon: "mdi:code-tags",
//       title: "Custom Laravel Development",
//       description:
//          "Tailored Laravel applications built from scratch to meet your specific business requirements and objectives.",
//    },
//    {
//       icon: "mdi:api",
//       title: "API Development",
//       description:
//          "Create robust APIs that integrate seamlessly with your Laravel applications.",
//    },
//    {
//       icon: "mdi:security",
//       title: "Web Application Security",
//       description:
//          "Implement high-level security measures to protect your Laravel applications from vulnerabilities.",
//    },
//    {
//       icon: "mdi:database",
//       title: "Database Management",
//       description:
//          "Efficiently manage and optimize databases for your Laravel applications.",
//    },
//    {
//       icon: "mdi:cloud-upload",
//       title: "Cloud Deployment",
//       description:
//          "Deploy your Laravel applications on cloud platforms for scalability and performance.",
//    },
//    {
//       icon: "mdi:monitor-dashboard",
//       title: "Real-time Data Handling",
//       description:
//          "Implement real-time features in your Laravel applications for enhanced user experience.",
//    },
//    {
//       icon: "mdi:package-variant",
//       title: "Laravel Package Development",
//       description:
//          "Create custom packages to extend the functionality of your Laravel applications.",
//    },
//    {
//       icon: "mdi:chart-line",
//       title: "Performance Optimization",
//       description:
//          "Optimize your Laravel applications for speed and efficiency.",
//    },
// ];

// const skills = [
//    { name: "Laravel Development", level: 99 },
//    { name: "API Development", level: 98 },
//    { name: "Database Management", level: 96 },
//    { name: "Web Application Security", level: 97 },
//    { name: "Eloquent ORM", level: 95 },
// ];

// const steps = [
//    {
//       icon: "mdi:clipboard-text",
//       title: "Requirement Analysis",
//       text: "We thoroughly analyze business needs to define comprehensive requirements for the Laravel application, ensuring that all essential functionalities are identified and documented to meet user expectations and project goals effectively throughout the development process.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:hexagon-multiple",
//       title: "Laravel Architecture Design",
//       text: "We select optimal Laravel architecture, focusing on database design and scalability to ensure efficiency, future enhancements, and high performance throughout the application lifecycle.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:code-tags",
//       title: "Feature Development",
//       text: "Our team writes and rigorously tests features to ensure they function correctly and perform optimally. This phase involves implementing best practices in coding, ensuring that each feature aligns with the defined requirements and enhances user experience.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:shield-check",
//       title: "Testing & Security Audit",
//       text: "We conduct thorough testing and security audits to ensure the application is secure and functions as intended. This includes identifying vulnerabilities, performing code reviews, and ensuring compliance with industry standards for security and performance.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:rocket-launch",
//       title: "Deployment & Maintenance",
//       text: "After successful testing, we deploy the Laravel application to the production environment. We also provide ongoing maintenance and support, ensuring the application remains up-to-date, secure, and responsive to user feedback and evolving requirements.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
// ];

// const teamData = [
//    {
//       title: "Laravel Developer",
//       description:
//          "Build and maintain robust web applications using the Laravel framework, ensuring high performance and responsiveness.",
//    },
//    {
//       title: "API Developer",
//       description:
//          "Design and implement RESTful APIs for seamless integration with front-end applications and third-party services.",
//    },
//    {
//       title: "Database Administrator",
//       description:
//          "Manage and optimize database systems to ensure data integrity, security, and performance for Laravel applications.",
//    },
// ];
