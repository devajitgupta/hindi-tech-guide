import React from "react";
import PythonHeroSection from "../../../../components/pythonDevelopment/PythonHeroSection";
import VersatileSolutions from "@/components/pythonDevelopment/VersatileSolutions";
import PythonFrameWorkSection from "@/components/pythonDevelopment/PythonFrameWorkSection";
import TurstedMarquee from "@/components/TurstedMarquee";
import clsx from "clsx";
import DevExpertiseSection from "@/components/ui/DevExpertiseSection";
import SectionTitle from "@/components/SectionTitle";
import SectionSubtitle from "@/components/SectionSubtitle";
import ServiceSection from "@/components/ui/ServiceSection";
import ProcessSection from "@/components/ui/ProcessSection";
import EffectiveTeamSection from "@/components/ui/EffectiveTeamSection";
import { Divider } from "@nextui-org/react";
import ConnectForm from "@/components/contactUs/ConnectForm";
import OverviewSection from "@/components/ui/OverviewSection";
import { Metadata } from "next";
import { TLocale } from "@/i18n-config";
import { getDictionary } from "@/get-dictionary";

export const metadata: Metadata = {
   title: "Python Development | ByteScrum Technologies",
   description:
      "Unlock powerful, scalable, and secure Python development with ByteScrum. From web apps to data science and machine learning, our expert team builds advanced Python solutions tailored to your business.",
};


type Props = {
   params: { lang: TLocale };
};
export default async function PythonDevelopmentPage({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const langTextContactForm = dictionary.contactPage.contactFormSection;
   const langText = dictionary.PythonDevelopmentPage;
   const countUpData = dictionary.homeDataPage

   const sectionStyle =
      " px-5 md:px-[40px] py-[60px] md:py-[60px]  gap-[40px] bg-[#000000] overflow-hidden";

   const jsonLd = {
      "@context": "https://schema.org",
      "@type": "Service",
      name: "Python Development | ByteScrum Technologies",
      url: "https://www.bytescrum.com/python-development",
      about: {
         "@type": "CreativeWork",
         name: "Versatile Python Development Services",
         description:
            "ByteScrum Technologies delivers powerful Python development solutions for web applications, data science, automation, APIs, and machine learning. We offer scalable, secure, and high-performance services to solve real-world challenges across industries.",
      },
   };

   return (
      <>
         {" "}
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] ">
            {" "}
            <PythonHeroSection langText={langText.PythonHeroSection} />
            <OverviewSection
               countUpData={countUpData}

               className={clsx(sectionStyle, "py-5 md:py-0")}
               data={langText.overViewSection}
            />
            <VersatileSolutions data={langText.VersatileSolutions} />
            <DevExpertiseSection

               className={clsx(sectionStyle, "md:py-[0px] md:pb-[60px]")}
               skills={langText}
            />
            <div className="pt-[74px]  grid items-center gap-[10px] md:gap-[10px] relative overflow-hidden   bg-gradient-to-b lg:bg-gradient-to-r  from-[#0D0D0D]/50 to-[#2A2A2A]/50">
               {" "}
               <SectionTitle>{langText.homePageData.trustedBy}</SectionTitle>
               <SectionSubtitle className="max-w-[341px] md:max-w-[800px] m-auto">
                  {langText.homePageData.trustedBySubtitle}
               </SectionSubtitle>
               <TurstedMarquee data={countUpData} className="mt-5" />
            </div>
            <ServiceSection
               className={clsx(sectionStyle)}
               serviceSection={langText.serviceSection}
               data={langText.services}
            />
            <PythonFrameWorkSection data={langText.PythonFrameWorkSection}
               className={clsx(sectionStyle)}
               libraries={langText.libraries}
            />
            <ProcessSection
               className={clsx(sectionStyle)}
               data={langText.processSection}
               steps={langText.steps}
            />
            <EffectiveTeamSection
               langText={langText.effectiveTeamSection}
               data={langText.teamData}
               className={clsx(sectionStyle)}
            />
            {/* <PythonDevProcess /> */}
            {/* <Connect /> */}
            <Divider className="bg-[#262626] my-5" />
            <ConnectForm langText={langTextContactForm} className="py-10" />
         </div>
      </>
   );
};


// const overViewSection = {
//    descriptionOne:
//       "Python development excels in creating versatile, scalable, and maintainable applications across web, data science, automation, and AI domains. With its clean syntax and vast ecosystem of libraries and frameworks, Python enables rapid development while maintaining code readability and performance.",
//    descriptionTwo:
//       "From building robust backend systems and APIs with frameworks like Django and Flask to driving machine learning and data analysis with Pandas, NumPy, and TensorFlow, Python empowers developers to deliver reliable, efficient, and innovative software solutions across industries.",
// };

// const services = [
//    {
//       icon: "mdi:code-braces",
//       title: "Web Development with Python",
//       description:
//          "Build robust web applications using popular Python frameworks like Django and Flask.",
//    },
//    {
//       icon: "mdi:database",
//       title: "Data Science & Analytics",
//       description:
//          "Leverage Python's powerful libraries for data analysis, visualization, and machine learning.",
//    },
//    {
//       icon: "mdi:security",
//       title: "API Development",
//       description:
//          "Create secure and scalable RESTful APIs using Python for various applications.",
//    },
//    {
//       icon: "mdi:cloud",
//       title: "Cloud Computing Solutions",
//       description:
//          "Develop cloud-based applications and services using Python on platforms like AWS and Azure.",
//    },
//    {
//       icon: "mdi:robot",
//       title: "Machine Learning & AI",
//       description:
//          "Implement machine learning algorithms and AI solutions using Python's extensive libraries.",
//    },
//    {
//       icon: "mdi:chart-line",
//       title: "Automation & Scripting",
//       description:
//          "Automate repetitive tasks and processes using Python scripts.",
//    },
//    {
//       icon: "mdi:package-variant",
//       title: "Software Development",
//       description:
//          "Design and develop software applications tailored to your business needs using Python.",
//    },
//    {
//       icon: "mdi:cloud-sync",
//       title: "DevOps & CI/CD",
//       description:
//          "Integrate Python into your DevOps pipeline for continuous integration and deployment.",
//    },
// ];

// const skills = [
//    { name: "Web Development with Python", level: 95 },
//    { name: "Data Science & Analytics", level: 90 },
//    { name: "API Development with Python", level: 92 },
//    { name: "Machine Learning & AI with Python", level: 88 },
// ];

// const steps = [
//    {
//       icon: "mdi:clipboard-text",
//       title: "Requirement Analysis",
//       text: "Understanding business needs and defining project requirements.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:hexagon-multiple",
//       title: "System Design",
//       text: "Designing the architecture and components of the application.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:code-tags",
//       title: "Development",
//       text: "Writing and testing code to build the application.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:shield-check",
//       title: "Testing & Quality Assurance",
//       text: "Ensuring application quality through rigorous testing.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:rocket-launch",
//       title: "Deployment & Maintenance",
//       text: "Deploying the application and providing ongoing support.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
// ];

// const teamData = [
//    {
//       title: "Python Developer",
//       description:
//          "Expert in building scalable applications and services using Python.",
//    },
//    {
//       title: "Data Scientist",
//       description:
//          "Specializes in data analysis and machine learning using Python.",
//    },
//    {
//       title: "DevOps Engineer",
//       description:
//          "Focuses on automating and optimizing deployment processes with Python.",
//    },
// ];

const libraries = [
   {
      title: "Django",
      description:
         "High-level web framework for rapid development and clean, pragmatic design.",
      icon: "mdi:django",
   },
   {
      title: "Flask",
      description:
         "Lightweight WSGI web application framework for building APIs and microservices.",
      icon: "mdi:flask",
   },
   {
      title: "TensorFlow",
      description:
         "Open-source library for machine learning and artificial intelligence.",
      icon: "mdi:tensorflow",
   },
   {
      title: "PyTorch",
      description:
         "Deep learning framework for research and production applications.",
      icon: "mdi:pytorch",
   },
   {
      title: "NumPy",
      description: "Fundamental package for scientific computing with Python.",
      icon: "mdi:numpy",
   },
   {
      title: "Scikit-learn",
      description:
         "Machine learning library for classification, regression, and clustering.",
      icon: "mdi:scikit-learn",
   },
   {
      title: "FastAPI",
      description:
         "Modern, fast web framework for building APIs with Python 3.7+",
      icon: "mdi:fastapi",
   },
   {
      title: "Pandas",
      description:
         "Powerful data manipulation and analysis library for Python.",
      icon: "mdi:pandas",
   },
];
