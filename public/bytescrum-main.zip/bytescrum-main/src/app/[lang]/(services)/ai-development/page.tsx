// import AIHeroSection from "@/components/aiDev/AIHeroSection";
import ConnectForm from "@/components/contactUs/ConnectForm";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import TurstedMarquee from "@/components/TurstedMarquee";
import DevExpertiseSection from "@/components/ui/DevExpertiseSection";
import EffectiveTeamSection from "@/components/ui/EffectiveTeamSection";
import OverviewSection from "@/components/ui/OverviewSection";
import ProcessSection from "@/components/ui/ProcessSection";
import ServiceSection from "@/components/ui/ServiceSection";
import { Divider } from "@nextui-org/react";
import clsx from "clsx";
import React from "react";
import { Metadata } from "next";
import AIHeroSection from "@/components/aiDevelopment/aiHeroSection";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";

const jsonLd = {
   "@context": "https://schema.org",
   "@type": "Service",
   name: "AI Development | ByteScrum Technologies",
   url: "https://www.bytescrum.com/ai-development",
   about: {
      "@type": "CreativeWork",
      name: "AI-Powered Business Solutions",
      description:
         "ByteScrum Technologies offers AI development services including machine learning models, computer vision, NLP, AI chatbots, and custom AI tools to automate, analyze, and accelerate your business.",
   },
};

export const metadata: Metadata = {
   title: "AI Development | ByteScrum Technologies",
   description:
      "Explore ByteScrum Technologies' AI development services such as machine learning, NLP, chatbots, computer vision, and intelligent automation tailored to drive business innovation.",
};

type Props = {
   params: { lang: TLocale };
};
export default async function AIDevelopmentPage({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const countUpData = dictionary.homeDataPage
   const langTextContactForm = dictionary.contactPage.contactFormSection;

   const langText = dictionary.aiServicesPage;
   const sectionStyle =
      " px-4 md:px-[40px] py-[40px] md:py-[60px] gap-[40px] bg-[#000000] overflow-hidden";

   return (
      <>
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fafafa]">
            <AIHeroSection data={langText.aiHeroSection} />
            <OverviewSection
               countUpData={countUpData}
               className={clsx(sectionStyle, "py-5 md:py-0")}
               data={langText.overViewSection}
            />
            <DevExpertiseSection
               className={clsx(sectionStyle, "md:py-[0px] md:pb-[60px]")}
               skills={langText}
            />
            <div className="pt-[74px] grid items-center gap-[10px] md:gap-[10px] relative overflow-hidden bg-gradient-to-b lg:bg-gradient-to-r from-[#0D0D0D]/50 to-[#2A2A2A]/50">
               <SectionTitle>{langText.homePageData.trustedBy}</SectionTitle>
               <SectionSubtitle className="max-w-[341px] md:max-w-[800px] m-auto">
                  {langText.homePageData.trustedBySubtitle}
               </SectionSubtitle>
               <TurstedMarquee data={countUpData} className="mt-5" />
            </div>
            <ServiceSection
               className={clsx(sectionStyle)}
               data={langText.services}
               serviceSection={langText.serviceSection}
            />
            <ProcessSection
               className={clsx(sectionStyle)}
               data={langText.processSection}
               steps={langText.steps}
            />
            <EffectiveTeamSection
               langText={langText.effectiveTeamSection}
               data={langText.teamData}

               className={clsx(sectionStyle)}
            />
            <Divider className="bg-[#262626] my-5" />
            <ConnectForm langText={langTextContactForm} className="py-10" />
         </div>
      </>
   );
};


// Overview Section Data
// const overViewSection = {
//    descriptionOne:
//       "AI development leverages machine learning, natural language processing, computer vision, and deep learning to build smart systems. These technologies enable businesses to analyze large data sets, automate tasks, and create more personalized user experiences.",
//    descriptionTwo:
//       "AI-driven solutions are reshaping industries by enhancing decision-making, boosting productivity, and reducing costs. With advancements in generative AI, edge AI, and ethical AI frameworks, organizations can now deploy intelligent tools that are transparent, secure, and impactful.",
// };

// Services Offered
// const services = [
//    {
//       icon: "mdi:robot",
//       title: "AI Chatbot Development",
//       description:
//          "Create intelligent conversational agents powered by NLP and machine learning.",
//    },
//    {
//       icon: "mdi:brain",
//       title: "Machine Learning Solutions",
//       description:
//          "Build predictive and classification models to drive data-driven decisions.",
//    },
//    {
//       icon: "mdi:face-recognition",
//       title: "Computer Vision",
//       description:
//          "Implement image and video analysis systems using object detection and recognition.",
//    },
//    {
//       icon: "mdi:google-translate",
//       title: "Natural Language Processing (NLP)",
//       description:
//          "Analyze and process human language with text classification, entity recognition, and sentiment analysis.",
//    },
//    {
//       icon: "mdi:cloud-sync",
//       title: "AI Integration Services",
//       description:
//          "Integrate AI models into existing systems for automation and intelligence.",
//    },
//    {
//       icon: "mdi:gesture-tap-button",
//       title: "Recommendation Engines",
//       description:
//          "Build real-time recommendation systems for e-commerce, media, and content platforms.",
//    },
//    {
//       icon: "mdi:chart-bubble",
//       title: "Predictive Analytics",
//       description:
//          "Forecast trends and behaviors using historical and real-time data.",
//    },
//    {
//       icon: "mdi:lightbulb-on",
//       title: "Custom AI Tools",
//       description:
//          "Develop tailor-made AI tools for your specific business case or workflow.",
//    },
// ];

// // Skills
// const skills = [
//    { name: "Machine Learning", level: 98 },
//    { name: "NLP & Chatbots", level: 97 },
//    { name: "Computer Vision", level: 95 },
//    { name: "Predictive Analytics", level: 96 },
// ];

// // Process Steps
// const steps = [
//    {
//       icon: "mdi:lightbulb-outline",
//       title: "Problem Identification",
//       text: "Understanding your goals and determining how AI can solve the problem.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:database-search",
//       title: "Data Collection & Preprocessing",
//       text: "Collecting, cleaning, and transforming data for model training.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:robot-industrial",
//       title: "Model Development",
//       text: "Building machine learning or deep learning models suited to your use case.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:test-tube",
//       title: "Testing & Optimization",
//       text: "Evaluating model accuracy and tuning performance for optimal results.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:cloud-upload",
//       title: "Deployment & Monitoring",
//       text: "Deploying the AI model into production with continuous monitoring.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
// ];

// // Team Roles
// const teamData = [
//    {
//       title: "AI/ML Engineer",
//       description:
//          "Design and develop machine learning models tailored to business needs.",
//    },
//    {
//       title: "NLP Specialist",
//       description:
//          "Work on language understanding, entity recognition, sentiment analysis, and AI-powered chatbots.",
//    },
//    {
//       title: "Computer Vision Engineer",
//       description:
//          "Build and deploy image/video-based recognition and analysis systems.",
//    },
//    {
//       title: "AI Product Architect",
//       description:
//          "Design scalable architectures and oversee the integration of AI into core systems.",
//    },
// ];
