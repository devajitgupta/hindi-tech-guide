import { TrustedCard } from "@/components/home";
import React from "react";
import { twMerge } from "tailwind-merge";
import clsx from "clsx";
import DeveloperPageBanner from "@/components/service/hireDeveloper/pageBanner/DeveloperPageBanner";
import ExperienceSection from "@/components/service/hireDeveloper/experienceSection/ExperienceSection";
import ByteScrumValueSection from "@/components/service/hireDeveloper/ByteScrumValue";
import DevelopmentSection from "@/components/service/hireDeveloper/developmentSection/DevelopmentSection";
import SkillSection from "@/components/service/hireDeveloper/skillSection/SkillSection";
import SectionTitle from "@/components/SectionTitle";
import dynamic from "next/dynamic";
import { Divider } from "@nextui-org/react";
import ConnectForm from "@/components/contactUs/ConnectForm";
import { Metadata } from "next";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";

const TeamSwipper = dynamic(
   () => import("@/components/career/teamSection/TeamSwipper"),
   {
      ssr: false,
   }
);

export const metadata: Metadata = {
   title: "Hire Dedicated Developers | ByteScrum Technologies",
   description:
      "Hire expert developers from ByteScrum Technologies. Access top talent in React, Node.js, WordPress, Flutter, and more for scalable, cost-effective software development.",
};


type Props = {
   params: { lang: TLocale };
};
export default async function HireDeveloper({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const langTextContactForm = dictionary.contactPage.contactFormSection;
   const countUpData = dictionary.homeDataPage
   const langText = dictionary.hireDeveloperPage; 
   const trustedSection = countUpData.trustedSection;
   const careerData= dictionary.careerData
   const sectionStyle =
      " px-5 md:px-[40px] py-[30px]  md:py-[60px] gap-[40px] bg-[#000000]";
   const jsonLd = {
      "@context": "https://schema.org",
      "@type": "Service",
      name: "Hire Dedicated Developers | ByteScrum Technologies",
      url: "https://www.bytescrum.com/hire-dedicated-developers",

      about: {
         "@type": "CreativeWork",
         name: "Top-Notch Dedicated Developers for Hire",
         description:
            "ByteScrum Technologies offers skilled, dedicated developers across multiple technologies like React, Node.js, WordPress, Flutter, Python, and more. Hire expert developers for cost-effective, risk-free, and scalable software solutions tailored to your business needs.",
      },
   };

   return (
      <>
         {" "}
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] page-hireDeveloper ">
            <DeveloperPageBanner
               countUpData={countUpData}
               data={langText.hireBannerData}
               className={sectionStyle}
            />

            <ExperienceSection
               className={twMerge(clsx(sectionStyle, "px-0"))}
               data={langText.experienceSection}
            />

            <SkillSection
               className={twMerge(clsx(sectionStyle))}
               data={langText.skillSection}
            />

            <div className="pt-[74px]  grid items-center gap-[40px] md:gap-[40px] relative overflow-hidden   bg-gradient-to-b lg:bg-gradient-to-r from-[#0D0D0D]/50 to-[#2A2A2A]/50">
               <div className="grid place-items-center gap-[10px]">
                  <h3
                     className="text-[25px] md:text-[45px] text-center font-poppins text-[#ffffff] poppins"
                     data-aos="fade-up"
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     {trustedSection.title}
                  </h3>
                  <p
                     className="text-[14px] md:text-[18px] text-[#f5f5f5] max-w-[341px] md:max-w-[800px] text-center leading-[24px] md:leading-[28px]  inter"
                     data-aos="fade-up"
                     data-aos-easing="ease-out-cubic"
                     data-aos-delay={300}
                     data-aos-anchor-placement="top-bottom"
                  >
                     {trustedSection.text}
                  </p>
               </div>
               <div className="trustSection  pb-[180px] md:pb-[180px]   grid items-center gap-[72px] md:gap-[92px] relative overflow-hidden bg-gradient-to-b lg:bg-gradient-to-r from-[#0D0D0D]/50 to-[#2A2A2A]/50">
                  {trustedSection.trustedCardData.map((item:any, index:number) => (
                     <div
                        key={item._id}
                        className="grid gap-[0px] md:gap-[20px]  item-center justify-center overflow-hidden w-5/12  "
                     >
                        <div className=" flex gap-[10px] md:gap-[20px] animate-[marqueRight_linear_15s_infinite]  md:animate-[marqueRight_linear_25s_infinite] absolute   overflow-x-hidden ">
                           {" "}
                           {item.lineOne &&
                              item.lineOne.map((logo:any, logoIndex:number) => (
                                 <TrustedCard
                                    logo={logo.logo}
                                    width={logo.width}
                                    height={logo.height}
                                    key={logo._id}
                                 />
                              ))}
                           {item.lineOne &&
                              item.lineOne.map((logo:any, logoIndex:number) => (
                                 <TrustedCard
                                    logo={logo.logo}
                                    width={logo.width}
                                    height={logo.height}
                                    // key={`${logoIndex}-1st_row`}
                                    key={logo._id}
                                 />
                              ))}
                        </div>
                        <div className=" flex gap-[10px] md:gap-[20px] animate-[marqueLeft_linear_20s_infinite]  md:animate-[marqueLeft_linear_30s_infinite] absolute overflow-x-hidden ">
                           {item.lineTwo &&
                              item.lineTwo.map((logo:any, logoIndex:number) => (
                                 <TrustedCard
                                    logo={logo.logo}
                                    width={logo.width}
                                    height={logo.height}
                                    // key={`${logoIndex}-2nd_row`}
                                    key={logo._id}
                                 />
                              ))}
                           {item.lineTwo &&
                              item.lineTwo.map((logo:any, logoIndex:number) => (
                                 <TrustedCard
                                    logo={logo.logo}
                                    width={logo.width}
                                    height={logo.height}
                                    // key={`${logoIndex}-2nd_row`}
                                    key={logo._id}
                                 />
                              ))}
                        </div>

                        <div className=" flex gap-[10px] md:gap-[20px] animate-[marqueRight_linear_15s_infinite]  md:animate-[marqueRight_linear_25s_infinite] bottom-12 absolute   overflow-x-hidden md:hidden ">
                           {item.lineOne &&
                              item.lineOne.map((logo:any, logoIndex:number) => (
                                 <TrustedCard
                                    logo={logo.logo}
                                    width={logo.width}
                                    height={logo.height}
                                    // key={`${logoIndex}-1st_row`}
                                    key={logo._id}
                                 />
                              ))}

                           {item.lineOne &&
                              item.lineOne.map((logo:any, logoIndex:number) => (
                                 <TrustedCard
                                    logo={logo.logo}
                                    width={logo.width}
                                    height={logo.height}
                                    // key={`${logoIndex}-1st_row`}
                                    key={logo._id}
                                 />
                              ))}
                        </div>
                     </div>
                  ))}
               </div>
            </div>

            <DevelopmentSection
               className={twMerge(clsx(sectionStyle))}
               data={langText.developmentSection}
            />

            <div
               className={twMerge(
                  clsx(
                     sectionStyle,
                     "space-y-[30px]   md:space-y-[40px] px-0 md:px-0"
                  )
               )}
            >
               <div
                  className={twMerge(
                     clsx("grid items-center gap-24 px-4 md:px-[40px] ")
                  )}
               >
                  <div className="m-auto space-y-3">
                     <SectionTitle
                        className="poppins flex flex-col md:flex-row items-center justify-center text-[25px] md:text-[45px] leading-[30px] md:leading-[60px] text-center gap-[5px] md:gap-3"
                        data-aos="fade-up"
                        data-aos-easing="ease-out-cubic"
                        data-aos-anchor-placement="top-bottom"
                     >
                        {langText.developerSection.titleOne}{" "}
                        <span className="text-[#909090]">
                           {" "}
                           {langText.developerSection.titleTwo}
                        </span>
                     </SectionTitle>
                     <p
                        className="inter max-w-[347px] md:max-w-[759px] text-center text-[12px] md:text-[16px]  leading-normal md:leading-[28px] text-[#f5f5f5] font-normal"
                        data-aos="fade-up"
                        data-aos-easing="ease-out-cubic"
                        data-aos-delay={300}
                        data-aos-anchor-placement="top-bottom"
                     >
                        {careerData.teamSection.text}{" "}
                     </p>
                  </div>
               </div>
               <TeamSwipper swipperData={careerData.teamSection.teams} />
            </div>

            <ByteScrumValueSection
               className={twMerge(clsx(sectionStyle))}
               data={langText.byteScrumValueSection}
            />

            {/* <Connect /> */}
            <Divider className="bg-[#262626] my-5" />
            <ConnectForm langText={langTextContactForm} className="py-10" />
         </div>
      </>
   );
};

