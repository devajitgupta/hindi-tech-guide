import BlockHeroSection from "@/components/blockChainDev/BlockHeroSection";
import ConnectForm from "@/components/contactUs/ConnectForm";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import TurstedMarquee from "@/components/TurstedMarquee";
import DevExpertiseSection from "@/components/ui/DevExpertiseSection";
import EffectiveTeamSection from "@/components/ui/EffectiveTeamSection";
import OverviewSection from "@/components/ui/OverviewSection";
import ProcessSection from "@/components/ui/ProcessSection";
import ServiceSection from "@/components/ui/ServiceSection";
import { Divider } from "@nextui-org/react";
import clsx from "clsx";
import React from "react";
import { Metadata } from "next";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";

const jsonLd = {
   "@context": "https://schema.org",
   "@type": "Service",
   name: "Blockchain Development | ByteScrum Technologies",
   url: "https://www.bytescrum.com/block-chain-development",

   about: {
      "@type": "CreativeWork",
      name: "Secure & Scalable Blockchain Solutions",
      description:
         "ByteScrum Technologies provides expert blockchain development services including smart contract development, dApps, DeFi, NFT/token creation, and enterprise blockchain solutions to help businesses innovate and grow securely.",
   },
};

export const metadata: Metadata = {
   title: "Blockchain Development | ByteScrum Technologies",
   description:
      "Explore ByteScrum Technologies’ blockchain development services, including smart contracts, dApps, DeFi, NFTs, and secure enterprise blockchain solutions tailored to drive innovation and growth.",
};

type Props = {
   params: { lang: TLocale };
};
export default async function BlockChainDevelopmentPage({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const langText = dictionary.blockChainServicesPage
   const countUpData = dictionary.homeDataPage

   const langTextContactForm = dictionary.contactPage.contactFormSection;

   const sectionStyle =
      " px-4 md:px-[40px] py-[40px] md:py-[60px]  gap-[40px] bg-[#000000] overflow-hidden";
   return (
      <>
         {" "}
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fafafa]  ">
            <BlockHeroSection data={langText.BlockHeroSection} />
            <OverviewSection
               countUpData={countUpData}
               className={clsx(sectionStyle, "py-5 md:py-0")}
               data={langText.overViewSection}
            />

            {/* <BlockChainOverview className={clsx(sectionStyle, "py-5 md:py-0")} /> */}

            <DevExpertiseSection
               className={clsx(sectionStyle, "md:py-[0px] md:pb-[60px]")}
               skills={langText}
            />
            <div className="pt-[74px]  grid items-center gap-[10px] md:gap-[10px] relative overflow-hidden   bg-gradient-to-b lg:bg-gradient-to-r  from-[#0D0D0D]/50 to-[#2A2A2A]/50">
               {" "}
               <SectionTitle>{langText.homePageData.trustedBy}</SectionTitle>
               <SectionSubtitle className="max-w-[341px] md:max-w-[800px] m-auto">
                  {" "}
                  {langText.homePageData.trustedBySubtitle}
               </SectionSubtitle>
               <TurstedMarquee data={countUpData} className="mt-5" />
            </div>
            <ServiceSection
               className={clsx(sectionStyle)}
               serviceSection={langText.serviceSection}
               data={langText.services}
            />
            <ProcessSection
               className={clsx(sectionStyle)}
               data={langText.processSection}
               steps={langText.steps}
            />
            <EffectiveTeamSection
               langText={langText.effectiveTeamSection}
               data={langText.teamData}
               className={clsx(sectionStyle)}
            />
            {/* <BlockChainDevProcess /> */}

            {/* <Connect /> */}
            <Divider className="bg-[#262626] my-5" />
            <ConnectForm langText={langTextContactForm} className="py-10" />
         </div>
      </>
   );
};


// const overViewSection = {
//    descriptionOne:
//       "  Blockchain development encompasses scalability, interoperability, privacy, governance, and Blockchain as a Service (BaaS). These elements enhance decentralized   technologies, facilitating efficient transactions,   seamless blockchain communication, data security,   informed decision-making, and streamlined development   and deployment processes for innovative solutions.",
//    descriptionTwo:
//       "  Smart contracts enhance automation and trust, while    decentralized identity solutions empower users over    their data. Emerging technologies like layer-2 solutions    and cross-chain bridges will transform blockchain    interactions, fostering innovation and unlocking new    opportunities for a more transparent and equitable    digital economy..",
// };

// const services = [
//    {
//       icon: "mdi:ethereum",
//       title: "Smart Contract Development",
//       description:
//          "Build secure and efficient smart contracts on Ethereum and other blockchains.",
//    },
//    {
//       icon: "mdi:bitcoin",
//       title: "Decentralized Applications (dApps)",
//       description:
//          "Create Web3 applications that run on decentralized networks.",
//    },
//    {
//       icon: "mdi:security",
//       title: "Blockchain Security",
//       description:
//          "Ensure high-level security in your blockchain applications.",
//    },
//    {
//       icon: "mdi:nfc-variant",
//       title: "NFT & Token Development",
//       description:
//          "Develop custom tokens and NFT solutions tailored to your needs.",
//    },
//    {
//       icon: "mdi:database-lock",
//       title: "DeFi Solutions",
//       description:
//          "Develop decentralized finance applications with transparency and security.",
//    },
//    {
//       icon: "mdi:chart-bar",
//       title: "Crypto Trading Bots",
//       description: "Automate cryptocurrency trading with AI-powered bots.",
//    },
//    {
//       icon: "mdi:wallet",
//       title: "Crypto Wallet Integration",
//       description:
//          "Securely integrate cryptocurrency wallets into your applications.",
//    },
//    {
//       icon: "hugeicons:blockchain-02",
//       title: "Enterprise Blockchain Solutions",
//       description:
//          "Custom blockchain solutions for businesses and enterprises.",
//    },
// ];

// const skills = [
//    { name: "Smart Contract Development", level: 99 },
//    { name: "Decentralized Applications (dApps)", level: 98 },
//    { name: "Blockchain Security", level: 96 },
//    { name: "NFT & Token Development", level: 97 },
// ];

// const steps = [
//    {
//       icon: "mdi:clipboard-text",
//       title: "Requirement Analysis",
//       text: "Understanding business needs and defining blockchain use cases.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:hexagon-multiple",
//       title: "Blockchain Architecture Design",
//       text: "Choosing the right blockchain platform, consensus mechanism, and smart contract structure.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:code-tags",
//       title: "Smart Contract Development",
//       text: "Writing and testing smart contracts for security and efficiency.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:shield-check",
//       title: "Testing & Security Audit",
//       text: "Ensuring contract security through rigorous audits and penetration testing.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:rocket-launch",
//       title: "Deployment & Maintenance",
//       text: "Deploying the blockchain network and providing ongoing support.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
// ];

// const teamData = [
//    {
//       title: "Smart Contract Developer",
//       description:
//          "Design and develop secure, efficient smart contracts on Ethereum and other blockchains.",
//    },
//    {
//       title: "Blockchain Architect",
//       description:
//          "Create scalable and secure blockchain infrastructures for decentralized applications.",
//    },
//    {
//       title: "DeFi Engineer",
//       description:
//          "Develop decentralized finance applications with robust security and transparency.",
//    },
// ];
