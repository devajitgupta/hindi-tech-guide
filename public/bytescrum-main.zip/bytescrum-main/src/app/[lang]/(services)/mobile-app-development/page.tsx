import ConnectForm from "@/components/contactUs/ConnectForm";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import MasterSection from "@/components/service/mobileAppDevelopment/MasterSection";
import MobileAppHeroSection from "@/components/service/mobileAppDevelopment/MobileAppHeroSection";
import TurstedMarquee from "@/components/TurstedMarquee";
import DevExpertiseSection from "@/components/ui/DevExpertiseSection";
import EffectiveTeamSection from "@/components/ui/EffectiveTeamSection";
import OverviewSection from "@/components/ui/OverviewSection";
import ProcessSection from "@/components/ui/ProcessSection";
import ServiceSection from "@/components/ui/ServiceSection";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";
import { Divider } from "@nextui-org/react";
import clsx from "clsx";
import { Metadata } from "next";
import React from "react";
import { twMerge } from "tailwind-merge";

export const metadata: Metadata = {
   title: "Mobile App Development | ByteScrum Technologies",
   description:
      "Transform your app idea into reality with ByteScrum Technologies. We provide custom mobile app development services for iOS, Android, and cross-platform with secure, high-performance features.",
};


type Props = {
   params: { lang: TLocale };
};
export default async function MobileAppDevelopmentPage({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);  
    const countUpData = dictionary.homeDataPage

   const langTextContactForm = dictionary.contactPage.contactFormSection;

   const langText = dictionary.MobileAppDevelopmentPage; const jsonLd = {
      "@context": "https://schema.org",
      "@type": "Service",
      name: "Mobile App Development | ByteScrum Technologies",
      url: "https://www.bytescrum.com/mobile-app-development",
      about: {
         "@type": "CreativeWork",
         name: "End-to-End Mobile App Development Services",
         description:
            "ByteScrum Technologies delivers scalable and user-friendly mobile apps for iOS, Android, and cross-platform environments. Our services include UI/UX design, in-app purchases, mobile security, analytics integration, and full-cycle app development with performance optimization.",
      },
   };

   const sectionStyle =
      " px-5 md:px-[40px] py-[60px]  md:py-[80px] gap-[40px] bg-[#000000]";

   return (
      <>
         {" "}
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] page-mobileApp ">
            <MobileAppHeroSection data={langText.mobileAppHeroSection} />
            {/* <MobileAppDevBanner /> */}

            <OverviewSection
               className={clsx(sectionStyle, "py-5 md:py-0")}
               data={langText.overViewSection} countUpData={countUpData}            />

            <MasterSection data= {langText.MasterSection}
               className={twMerge(clsx(sectionStyle, "py-0 md:py-0 "))}
            />
            <DevExpertiseSection
               className={clsx(sectionStyle)}
               skills={langText}
            />

            <div className="pt-[74px]  grid items-center gap-[10px] md:gap-[10px] relative overflow-hidden   bg-gradient-to-b lg:bg-gradient-to-r  from-[#0D0D0D]/50 to-[#2A2A2A]/50">
               <SectionTitle>{langText.homePageData.trustedBy}</SectionTitle>
               <SectionSubtitle className="max-w-[341px] md:max-w-[800px] m-auto">
                  {langText.homePageData.trustedBySubtitle}
               </SectionSubtitle>
               <TurstedMarquee data={countUpData}  className="mt-5" />
            </div>
            <ServiceSection
               className={clsx(sectionStyle)}
               data={langText.services}
               serviceSection={langText.serviceSection}

            />
            <ProcessSection
               className={clsx("lg:hidden", sectionStyle)}
               data={langText.processSection}
               steps={langText.steps}
            />
            {/* <MobileDevWorkProcess
            className={twMerge(clsx("hidden lg:block", sectionStyle))}
         /> */}
            {/* <MobileAppWorkProcessNew /> */}
            <ProcessSection
               className={clsx(sectionStyle)}
               data={langText.processSection}
               steps={langText.steps}
            />
            <EffectiveTeamSection
               langText={langText.effectiveTeamSection}
               data={langText.teamData}
               className={clsx(sectionStyle)}
            />
            {/* <Connect /> */}
            <Divider className="bg-[#262626] my-5" />
            <ConnectForm langText={langTextContactForm} className="py-10" />
         </div>
      </>
   );
};


// const overViewSection = {
//    descriptionOne:
//       "  Mobile app development focuses on creating                        user-friendly, secure, and scalable applications for                        both iOS and Android platforms. Our approach emphasizes                        innovative design, seamless functionality, and                        exceptional user experiences, ensuring that each app                        meets the specific needs of ts users while leveraging                        the latest technologies.",
//    descriptionTwo:
//       "  Mobile app development focuses on creating                        user-friendly, secure, and scalable applications for                        both iOS and Android platforms. Our approach emphasizes                        innovative design, seamless functionality, and                        exceptional user experiences, ensuring that each app                        meets the specific needs of ts users while leveraging                        the latest technologies.",
// };

// const services = [
//    {
//       icon: "mdi:apple",
//       title: "iOS Development",
//       description:
//          "Create native applications for iOS devices using Swift or Objective-C, delivering exceptional user experiences on iPhones and iPads.",
//    },
//    {
//       icon: "mdi:android",
//       title: "Android Development",
//       description:
//          "Develop applications for Android devices using Java or Kotlin, targeting a diverse user base on the popular platform.",
//    },
//    {
//       icon: "mdi:crosshairs-gps",
//       title: "Location-Based Services",
//       description:
//          "Implement GPS and location-based features to enhance user engagement and functionality.",
//    },
//    {
//       icon: "mdi:cloud-upload",
//       title: "Cloud Integration",
//       description:
//          "Integrate cloud services for data storage and synchronization, ensuring seamless user experiences across devices.",
//    },
//    {
//       icon: "mdi:security",
//       title: "Mobile App Security",
//       description:
//          "Ensure high-level security in your mobile applications to protect user data and privacy.",
//    },
//    {
//       icon: "mdi:chart-line",
//       title: "Analytics & Performance Tracking",
//       description:
//          "Incorporate analytics to monitor app performance and user engagement.",
//    },
//    {
//       icon: "mdi:wallet",
//       title: "In-App Purchases",
//       description:
//          "Implement secure in-app purchase systems to enhance monetization strategies.",
//    },
//    {
//       icon: "mdi:responsive",
//       title: "Cross-Platform Development",
//       description:
//          "Develop applications that work seamlessly across multiple platforms, maximizing reach and user engagement.",
//    },
// ];

// const skills = [
//    { name: "iOS Development", level: 95 },
//    { name: "Android Development", level: 94 },
//    { name: "Cross-Platform Development", level: 90 },
//    { name: "Mobile UI/UX Design", level: 92 },
//    { name: "Mobile App Security", level: 93 },
// ];

// const steps = [
//    {
//       icon: "mdi:clipboard-text",
//       title: "Requirement Analysis",
//       text: "We begin by thoroughly understanding user needs, gathering requirements, and defining the essential functionalities for the mobile application to ensure it meets the expectations and goals of the target audience effectively and efficiently.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mynaui:pen",
//       title: "UI/UX Design",
//       text: "Our design team focuses on creating intuitive and engaging user interfaces, ensuring that the user experience is seamless and enjoyable, while also aligning with the overall vision and functionality of the mobile application being developed.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:code-tags",
//       title: "App Development",
//       text: "During the development phase, our skilled developers write and rigorously test code for mobile applications, ensuring compatibility across various platforms while adhering to best practices and maintaining high standards of quality throughout the process.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:shield-check",
//       title: "Testing & Quality Assurance",
//       text: "We conduct comprehensive testing and quality assurance to ensure that the mobile application performs optimally, is user-friendly, and meets security standards, identifying and resolving any issues before the app is launched to the public.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:rocket-launch",
//       title: "Deployment & Maintenance",
//       text: "After successful testing, we launch the mobile application and provide ongoing support and maintenance, ensuring that it remains up-to-date, functional, and responsive to user feedback and evolving market demands over time.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
// ];

// const teamData = [
//    {
//       title: "Mobile App Developer",
//       description:
//          "Design and develop user-friendly mobile applications for iOS and Android platforms.",
//    },
//    {
//       title: "UI/UX Designer",
//       description:
//          "Create engaging and intuitive user interfaces and experiences tailored for mobile devices.",
//    },
//    {
//       title: "Mobile App Tester",
//       description:
//          "Conduct thorough testing to ensure performance, usability, and security of mobile applications.",
//    },
// ];
