import ConnectForm from "@/components/contactUs/ConnectForm";
import EmergencyRecovery from "@/components/service/recoverHackedWesite/EmergencyRecovery";
import FutureHacking from "@/components/service/recoverHackedWesite/FutureHacking";
import KeyFeatureSection from "@/components/service/recoverHackedWesite/KeyFeatureSection";
import OfferSection from "@/components/service/recoverHackedWesite/OfferSection";
import RecoveredWebsites from "@/components/service/recoverHackedWesite/RecoveredWebsites";
import RecoverHeroSection from "@/components/service/recoverHackedWesite/RecoverHeroSection";
import RecoverySteps from "@/components/service/recoverHackedWesite/RecoverySteps";
import SecuritySection from "@/components/service/recoverHackedWesite/SecuritySection";
import OverviewSection from "@/components/ui/OverviewSection";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";
import { Divider } from "@nextui-org/react";
import clsx from "clsx";
import { Metadata } from "next";
import React from "react";
import { twMerge } from "tailwind-merge";

export const metadata: Metadata = {
   title: "Recover Hacked Website | ByteScrum Technologies",
   description:
      "Is your website hacked? ByteScrum offers emergency hack recovery services to restore and secure your website quickly. Remove malware, fix SEO blacklists, and protect against future attacks.",
};


type Props = {
   params: { lang: TLocale };
};
export default async function RecoverHackedWebsitePage({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const countUpData = dictionary.homeDataPage

   const langTextContactForm = dictionary.contactPage.contactFormSection;

   const langText = dictionary.RecoverHackedWebsitePage;
   const sectionStyle =
      " px-5 md:px-[40px] py-[60px]  md:py-[80px] gap-[40px] bg-[#000000] ";

   const jsonLd = {
      "@context": "https://schema.org",
      "@type": "Service",
      name: "Recover Hacked Website | ByteScrum Technologies",
      url: "https://www.bytescrum.com/recover-hacked-website",
      about: {
         "@type": "CreativeWork",
         name: "Emergency Website Hack Recovery Services",
         description:
            "ByteScrum Technologies provides fast and reliable hacked website recovery services. We detect, clean, and secure your website from all types of cyberattacks including malware, phishing, and blacklisting. Get back online with confidence.",
      },
   };

   return (
      <>
         {" "}
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] recover-hacked-page">
            {/* <RecoverPageBanner /> */}
            <RecoverHeroSection data={langText.recoverHeroSection} />
            <OverviewSection
               className={clsx(sectionStyle, "py-5 md:py-0 ")}
               data={langText.overViewSection}
               countUpData={countUpData}
            />
            <FutureHacking data={langText.futureHacking} className={twMerge(clsx(sectionStyle))} />
            <KeyFeatureSection data={langText.keyFeatureSection} className={twMerge(clsx(sectionStyle))} />
            <SecuritySection data={langText} className={twMerge(clsx(sectionStyle))} />
            <OfferSection data={langText.offerSection}
               className={twMerge(clsx(sectionStyle, "xl:px-32 "))}
            />
            <RecoverySteps data={langText.recoverySteps} className={twMerge(clsx(sectionStyle))} />
            <EmergencyRecovery data={langText.emergencyRecovery} className={twMerge(clsx(sectionStyle))} />
            <RecoveredWebsites data={langText.recoveredWebsites} />
            <Divider className="bg-[#262626] my-5" />
            <ConnectForm langText={langTextContactForm} className="py-10" />
         </div>
      </>
   );
};

// const overViewSection = {
//    descriptionOne:
//       "Recovering a hacked website involves identifying security breaches, removing malicious code, and restoring full functionality without data loss. Our process ensures a thorough audit of your site, patching vulnerabilities, strengthening access controls, and implementing robust security protocols to prevent future attacks.",
//    descriptionTwo:
//       "With rapid response and expert analysis, we help restore your website's integrity and reputation. From malware removal and blacklist cleanup to firewall configuration and continuous monitoring, our goal is to provide a secure, stable environment—so you can confidently get back online and protect your digital presence.",
// };
