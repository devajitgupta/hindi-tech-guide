import ConnectForm from "@/components/contactUs/ConnectForm";
import EcomHeroSection from "@/components/ecommerceDevelopment/EcomHeroSection";
import EComPlatform from "@/components/ecommerceDevelopment/EComPlatform";
import EComShopping from "@/components/ecommerceDevelopment/EComShopping";
import SectionSubtitle from "@/components/SectionSubtitle";
import SectionTitle from "@/components/SectionTitle";
import TurstedMarquee from "@/components/TurstedMarquee";
import DevExpertiseSection from "@/components/ui/DevExpertiseSection";
import EffectiveTeamSection from "@/components/ui/EffectiveTeamSection";
import OverviewSection from "@/components/ui/OverviewSection";
import ProcessSection from "@/components/ui/ProcessSection";
import ServiceSection from "@/components/ui/ServiceSection";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";
import { Divider } from "@nextui-org/react";
import clsx from "clsx";
import { Metadata } from "next";

export const metadata: Metadata = {
   title: "E-commerce Development | ByteScrum Technologies",
   description:
      "Drive online growth with ByteScrum Technologies' e-commerce development services, from custom store development and payment integration to analytics, inventory systems, and platform optimization.",
};


type Props = {
   params: { lang: TLocale };
};
export default async function EcommerceDevelopment({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const countUpData = dictionary.homeDataPage
   const langTextContactForm = dictionary.contactPage.contactFormSection;

   const langText = dictionary.EcommerceDevPage; const sectionStyle =
      " px-5 md:px-[40px] py-[40px] md:py-[60px]  gap-[40px] bg-[#000000] overflow-hidden";

   const jsonLd = {
      "@context": "https://schema.org",
      "@type": "Service",
      name: "E-commerce Development | ByteScrum Technologies",
      url: "https://www.bytescrum.com/ecommerce-development",

      about: {
         "@type": "CreativeWork",
         name: "Custom & Scalable E-commerce Solutions",
         description:
            "ByteScrum Technologies delivers tailored e-commerce development solutions, including custom store creation, payment gateway integration, analytics, inventory management, and platform optimization to help businesses thrive online.",
      },
   };

   return (
      <>
         {" "}
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] ">
            <EcomHeroSection langText={langText.EcomHeroSec} />

            <OverviewSection
               countUpData={countUpData}
               className={clsx(sectionStyle, "py-5 md:py-0")}
               data={langText.overViewSection}
            />
            <EComShopping langText={langText.ecomSection} />
            <DevExpertiseSection
               skills={langText}
               className={clsx(sectionStyle, "md:py-[0px] md:pb-[60px]")}
            />

            <div className="pt-[74px]  grid items-center gap-[10px] md:gap-[10px] relative overflow-hidden   bg-gradient-to-b lg:bg-gradient-to-r  from-[#0D0D0D]/50 to-[#2A2A2A]/50">

               <SectionTitle>{langText.homePage.dataOne}</SectionTitle>
               <SectionSubtitle className="max-w-[341px] md:max-w-[800px] m-auto">

                  {langText.homePage.dataTwo}
               </SectionSubtitle>{" "}
               <TurstedMarquee  data={countUpData} className="mt-5" />
            </div>
            <ServiceSection
               className={clsx(sectionStyle)}
               data={langText.services}
               serviceSection={langText.serviceSection}
            />
            <EComPlatform langText={langText.eComPlatform} />
            <ProcessSection
               className={clsx(sectionStyle)}
               data={langText.processSection}
               steps={langText.steps}
            />
            <EffectiveTeamSection
               langText={langText.effectiveTeamSection}
               data={langText.teamData}
               className={clsx(sectionStyle)}
            />
            {/* <EComDevProcess /> */}
            <Divider className="bg-[#262626]" />
            <ConnectForm langText={langTextContactForm} className={clsx(sectionStyle)} />
         </div>
      </>
   );
};


// const overViewSection = {
//    descriptionOne:
//       "E-commerce development focuses on building secure, scalable, and high-performing online stores tailored to your business goals. Our approach emphasizes intuitive user interfaces, seamless shopping experiences, and robust backend systems that support everything from product management to secure payments.",
//    descriptionTwo:
//       "We leverage the latest technologies to ensure your e-commerce platform delivers fast load times, mobile responsiveness, and powerful integrations. Whether it’s a custom storefront or a multi-vendor marketplace, we craft solutions that drive conversions and customer satisfaction.",
// };

// const skills = [
//    { name: "E-commerce Platform Development", level: 99 },
//    { name: "Payment Gateway Integration", level: 98 },
//    { name: "User Experience (UX) Design", level: 96 },
//    { name: "Inventory Management Systems", level: 97 },
// ];

// const services = [
//    {
//       icon: "mdi:store",
//       title: "E-commerce Platform Development",
//       description:
//          "Create robust and scalable e-commerce platforms tailored to your business needs.",
//    },
//    {
//       icon: "mdi:credit-card",
//       title: "Payment Gateway Integration",
//       description:
//          "Seamlessly integrate secure payment gateways for a smooth transaction experience.",
//    },
//    {
//       icon: "mdi:cart",
//       title: "Shopping Cart Solutions",
//       description:
//          "Develop user-friendly shopping cart systems that enhance customer experience.",
//    },
//    {
//       icon: "mdi:account-circle",
//       title: "User Account Management",
//       description:
//          "Implement secure user account systems for personalized shopping experiences.",
//    },
//    {
//       icon: "mdi:analytics",
//       title: "E-commerce Analytics",
//       description:
//          "Utilize data analytics to optimize sales strategies and improve customer engagement.",
//    },
//    {
//       icon: "mdi:shield-check",
//       title: "E-commerce Security Solutions",
//       description:
//          "Ensure high-level security for your e-commerce applications to protect customer data.",
//    },
//    {
//       icon: "mdi:cloud-upload",
//       title: "Inventory Management Systems",
//       description:
//          "Develop efficient inventory management systems to streamline operations.",
//    },
//    {
//       icon: "mdi:star",
//       title: "Customer Loyalty Programs",
//       description:
//          "Create engaging loyalty programs to retain customers and boost sales.",
//    },
// ];

// const steps = [
//    {
//       icon: "mdi:clipboard-text",
//       title: "Requirement Analysis",
//       text: "Understanding business needs and defining e-commerce requirements.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:hexagon-multiple",
//       title: "E-commerce Platform Design",
//       text: "Choosing the right technology stack and architecture for the e-commerce platform.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:code-tags",
//       title: "Feature Development",
//       text: "Implementing essential e-commerce features such as product listings, shopping cart, and checkout.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:shield-check",
//       title: "Testing & Quality Assurance",
//       text: "Ensuring platform functionality and security through comprehensive testing.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
//    {
//       icon: "mdi:rocket-launch",
//       title: "Deployment & Maintenance",
//       text: "Launching the e-commerce platform and providing ongoing support and updates.",
//       srcOne: "/service/webDev/processOne.png",
//       srcTwo: "/service/webDev/processTwo.png",
//    },
// ];

// const teamData = [
//    {
//       title: "E-commerce Developer",
//       description:
//          "Build and maintain robust e-commerce platforms with a focus on user experience.",
//    },
//    {
//       title: "UI/UX Designer",
//       description:
//          "Design intuitive and engaging user interfaces for e-commerce applications.",
//    },
//    {
//       title: "E-commerce Marketing Specialist",
//       description:
//          "Develop and implement marketing strategies to drive traffic and sales.",
//    },
// ];
