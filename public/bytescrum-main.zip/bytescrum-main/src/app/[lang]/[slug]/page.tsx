// import "./loaderStyle.css";
import React from "react";
import Link from "next/link";
import { Divider } from "@nextui-org/react";
import ConnectForm from "@/components/contactUs/ConnectForm";
import {
   NewProjectBanner,
   NewProjectSection,
} from "@/components/portfolio/project";
import { TLocale } from "@/i18n-config";
import { getDictionary } from "@/get-dictionary";

const services = ["block-chain-development", "custom-software-development"];

type Props = {
   params: { lang: TLocale; slug: string };
};

export default async function Project({ params: { lang, slug } }: Props) {
   const dictionary = await getDictionary(lang);
   const langText = dictionary.projectsPage;
   const portfolioData = dictionary.homeDataPage;
   const langTextContactForm = dictionary.contactPage.contactFormSection;

   const sectionStyle =
      " px-5 md:px-[40px] py-[60px]  md:py-[80px] gap-[40px] bg-[#000000]";

   if (services.includes(slug)) {
      return <div>hello</div>;
   }

   const project = langText.find((proj: any) => proj.id === slug);

   if (!project)
      return (
         <div className="min-h-[92vh] flex items-center justify-center flex-col">
            <div className=" max-h-[40vh] grid place-items-center relative ">
               <p className="text-[8rem] top-[-9rem] md:text-[12rem] md:top-[-12rem] font-bold absolute z-[999999] text-[#616161] ">
                  404
               </p>
               <div className="loader top-[-5rem]  md:top-[-4rem] ">
                  <div className="box">
                     <div className="logo">
                        <svg
                           width="310"
                           height="169"
                           viewBox="0 0 310 169"
                           fill="none"
                           xmlns="http://www.w3.org/2000/svg"
                        >
                           <path
                              d="M22 56.5001C22 59.0118 19.9575 61 17.5 61C15.0426 61 13 59.0118 13 56.5001C13 53.9882 15.0426 52 17.5 52C19.9575 52 22 53.9882 22 56.5001Z"
                              stroke="white"
                              strokeWidth="0.5"
                           />
                           <path
                              d="M20.6357 53.5558L42.3324 30.043H162.87"
                              stroke="white"
                           />
                           <path
                              d="M32 68.5001C32 71.0118 29.9574 73 27.5 73C25.0425 73 23 71.0118 23 68.5001C23 65.9882 25.0425 64 27.5 64C29.9574 64 32 65.9882 32 68.5001Z"
                              stroke="white"
                              strokeWidth="0.5"
                           />
                           <path
                              d="M30.2783 65.3137L51.9751 41.8008H162.869"
                              stroke="white"
                           />
                           <path
                              d="M41 81.4999C41 84.0118 38.9575 86 36.5 86C34.0426 86 32 84.0118 32 81.4999C32 78.9882 34.0426 77 36.5 77C38.9575 77 41 78.9882 41 81.4999Z"
                              stroke="white"
                              strokeWidth="0.5"
                           />
                           <path
                              d="M39.9219 78.3743L61.6187 54.8613H162.87"
                              stroke="white"
                           />
                           <path
                              d="M19.2002 100.5C19.2002 103.012 17.1576 105 14.7002 105C12.2427 105 10.2002 103.012 10.2002 100.5C10.2002 97.9881 12.2427 96 14.7002 96C17.1576 96 19.2002 97.9881 19.2002 100.5Z"
                              stroke="white"
                              strokeWidth="0.5"
                           />
                           <path
                              d="M19.4307 100.582H36.3058L70.0562 65.3125H162.87"
                              stroke="white"
                           />
                           <path
                              d="M10 111.5C10 114.012 7.95746 116 5.49999 116C3.04254 116 1 114.012 1 111.5C1 108.988 3.04254 107 5.49999 107C7.95746 107 10 108.988 10 111.5Z"
                              stroke="white"
                              strokeWidth="0.5"
                           />
                           <path
                              d="M9.78809 111.031H42.3332L77.2891 74.4551H162.871"
                              stroke="white"
                           />
                           <path
                              d="M17 134.5C17 137.012 14.9574 139 12.5 139C10.0425 139 8 137.012 8 134.5C8 131.988 10.0425 130 12.5 130C14.9574 130 17 131.988 17 134.5Z"
                              stroke="white"
                              strokeWidth="0.5"
                           />
                           <path
                              d="M17.0195 134.546H39.9216L82.1097 88.8262H161.664"
                              stroke="white"
                           />
                           <path
                              d="M72.7998 120.5C72.7998 123.012 70.7572 125 68.2998 125C65.8424 125 63.7998 123.012 63.7998 120.5C63.7998 117.988 65.8424 116 68.2998 116C70.7572 116 72.7998 117.988 72.7998 120.5Z"
                              stroke="white"
                              strokeWidth="0.5"
                           />
                           <path
                              d="M72.4658 120.176H97.7786V99.2754H162.87"
                              stroke="white"
                           />
                           <path
                              d="M64 134.5C64 137.012 61.9574 139 59.5001 139C57.0426 139 55 137.012 55 134.5C55 131.988 57.0426 130 59.5001 130C61.9574 130 64 131.988 64 134.5Z"
                              stroke="white"
                              strokeWidth="0.5"
                           />
                           <path
                              d="M64.0293 134.546H106.736L121.887 117.564H162.871"
                              stroke="white"
                           />
                           <path
                              d="M57 148.5C57 151.013 54.9574 153 52.5 153C50.0425 153 48 151.013 48 148.5C48 145.988 50.0425 144 52.5 144C54.9574 144 57 145.988 57 148.5Z"
                              stroke="white"
                              strokeWidth="0.5"
                           />
                           <path
                              d="M56.7969 148.912H108.628L124.298 130.625H162.87"
                              stroke="white"
                           />
                           <path
                              d="M46 163.5C46 166.011 43.9574 168 41.5 168C39.0425 168 37 166.011 37 163.5C37 160.989 39.0425 159 41.5 159C43.9574 159 46 160.989 46 163.5Z"
                              stroke="white"
                              strokeWidth="0.5"
                           />
                           <path
                              d="M45.9492 163.282L115.861 161.976L130.325 146.301H162.87"
                              stroke="white"
                           />
                           <path
                              d="M138.762 27.4316V30.0442V60.0884H189.387C196.62 65.3136 196.62 70.5385 189.387 75.7636H138.762V108.42L189.387 109.727C196.62 114.952 196.62 118.871 189.387 122.789H138.762V155.446L199.03 154.139C238.808 141.077 224.343 95.3576 218.316 90.1327C223.138 83.6012 226.754 71.8448 225.549 60.0884H241.218C237.602 83.1658 229.165 139.771 229.165 139.771C226.754 152.833 237.602 160.671 249.657 160.671C270.147 160.671 274.969 137.158 274.969 137.158C258.094 141.077 259.3 131.933 260.504 125.402L273.763 60.0884H309.925V28.7379H278.586L285.817 0L254.477 5.22508L248.451 27.4316H138.762Z"
                              fill="white"
                           />
                        </svg>
                     </div>
                  </div>
                  <div className="box"></div>
                  <div className="box"></div>
                  <div className="box"></div>
                  <div className="box"></div>
               </div>
               <div className="absolute bottom-[1rem] md:bottom-[-2rem] z-[999999]">
                  <p className="text-[2.4rem]  leading-[4rem] md:leading-[6rem]  md:text-[3.8rem] text-center flex flex-col font-bold   text-[#616161] uppercase">
                     <span className="text-[6rem] md:text-[9.5rem] text-center">
                        Page
                     </span>{" "}
                     Not Found
                     <span className="w-full bottom-0  absolute h-[2px] bg-gradient-to-r from-transparent via-white to-transparent md:mt-4"></span>
                  </p>
               </div>
               <Link
                  href="/"
                  className=" absolute -bottom-[5rem] md:-bottom-[6rem] rounded-full bg-primary px-4 py-2 hover:text-black text-white hover:bg-white"
               >
                  Go back to Home
               </Link>
            </div>
         </div>
      );

   return (
      <section className="max-w-[1728px] m-auto  inter text-[#fff] page-Project ">
         {/* NOTE: Page Banner */}
         {/* <ProjectBanner data={project} /> */}

         {/* NOTE: Connect Section */}
         {/* <ProjectSection sectionStyle={sectionStyle} data={project} /> */}
         <NewProjectBanner data={project} />
         <NewProjectSection data={project} portfolioSection={portfolioData} />

         {/* NOTE: Connect Section */}
         {/* <Connect /> */}
         <Divider className="bg-[#262626] my-5" />
         <ConnectForm className="py-10" langText={langTextContactForm} />
      </section>
   );
}
