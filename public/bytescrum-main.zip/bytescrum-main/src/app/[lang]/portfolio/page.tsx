import PortfolioBanner from "@/components/portfolio/PortfolioBanner";
import OurPortfolio from "@/components/home/PortfolioSection";
import ConnectForm from "@/components/contactUs/ConnectForm";
import { Divider } from "@nextui-org/react";
import { Metadata } from "next";
import { TLocale } from "@/i18n-config";
import { getDictionary } from "@/get-dictionary";

export const metadata: Metadata = {
   title: "Portfolio | ByteScrum Technologies",
   description:
      "Explore ByteScrum Technologies portfolio showcasing our web development, mobile app, and software projects across various industries.",
};
type Props = {
   params: { lang: TLocale };
};
export default async function Portfolio({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const langText = dictionary.projectsPage;
   const bannerLangText = dictionary.portfolioPage;
   const portfolioDataLang = dictionary.homeDataPage;
   const langTextContactForm = dictionary.contactPage.contactFormSection;

   const jsonLd = {
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      name: "Portfolio | ByteScrum Technologies",
      url: "https://www.bytescrum.com/portfolio",

      about: {
         "@type": "CreativeWork",
         name: "Our Portfolio",
         description:
            "Showcase of ByteScrum Technologies projects including web development, mobile apps, and digital solutions.",
      },
   };

   return (
      <>
         {" "}
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] transition-all duration-1000 ease-in-out  ">
            <PortfolioBanner langText={bannerLangText} />

            <OurPortfolio lang={lang} langText={portfolioDataLang} />
            {/* <Connect /> */}
            <Divider className="bg-[#262626] my-5" />
            <ConnectForm className="py-10" langText={langTextContactForm} />
         </div>
      </>
   );
}
