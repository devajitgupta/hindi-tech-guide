// app/[lang]/page.tsx
import { HomeBanner } from "@/components/home";
import BlogButton from "@/components/home/blogSection/BlogButton";
import ChampionCards from "@/components/home/championSection/ChampionCards";
import SkillCards from "@/components/home/skillSection/SkillCards";
import MobileWorkProcessAnimation from "@/components/home/workProcess/MobileWorkProcessAnimation";
import MobileChampionCards from "@/components/home/championSection/MobileChampionCards";
import ScrollButton from "@/components/home/ScrollButton";
import SectionTitle from "@/components/SectionTitle";
import SectionSubtitle from "@/components/SectionSubtitle";
import TurstedMarquee from "@/components/TurstedMarquee";
import OurPortfolio from "@/components/home/PortfolioSection";
import PortfolioFooter from "@/components/home/PortfolioSection/PortfolioFooter";
import dynamic from "next/dynamic";
import { Button, Divider } from "@nextui-org/react";
import ConnectForm from "@/components/contactUs/ConnectForm";
import { TLocale } from "@/i18n-config";
import { getDictionary } from "@/get-dictionary";

const WorkProcessDesktopSvg = dynamic(
   () => import("@/components/home/workProcess/WorkProcessDesktopSvg"),
   {
      ssr: false,
   }
);

const BlogSwipper = dynamic(
   () => import("@/components/home/blogSection/BlogSwipper"),
   {
      ssr: false,
   }
);

const TestimonialCard = dynamic(
   () =>
      import("@/components/home/testimonial").then(
         (mod) => mod.TestimonialCard
      ),
   {
      ssr: false,
   }
);

const StatsCountUp = dynamic(
   () => import("@/components/home/stats/StatsCountUp"),
   {
      ssr: false,
   }
);

type Props = {
   params: { lang: TLocale };
};

export default async function Home({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const langText = dictionary.homeDataPage;
   const langTextContactForm = dictionary.contactPage.contactFormSection;

   return (
      <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fafafa] space-y-[30px] page-home">
         {/* NOTE: Hero Section */}
         <div className="relative -top-20 min-h-[100dvh] md:min-h-[65dvh] lg:min-h-[85dvh] overflow-hidden xl:min-h-[100dvh]">
            <div className="absolute top-0">
               <HomeBanner lang={lang} langText={langText} />
            </div>
            <div className="absolute bottom-[1.5%] md:bottom-[20%] left-[50%] downArrow transform -translate-x-1/2 -translate-y-1/2 md:translate-x-60 md:translate-y-1/2 z-20">
               <ScrollButton
                  img={langText.heroSection.scrollDownBtn.img}
                  link={langText.heroSection.scrollDownBtn.link}
                  icon={langText.heroSection.scrollDownBtn.icon}
               />
            </div>
         </div>

         {/* NOTE: Real Value Section */}
         <div
            id="realValue"
            className="md:px-16 xl:px-32 pt-[60px] pb-[15px] md:pb-[30px] md:pt-[60px] px-4"
         >
            <SectionTitle>
               <span className="text-[#565656]">
                  {langText.realvalueSection.title.textOne}{" "}
               </span>
               {langText.realvalueSection.title.textTwo}
            </SectionTitle>
            <StatsCountUp langText={langText} />
         </div>

         {/* NOTE: Service Section */}
         <div className="pb-[60px] md:py-[20px] pt-[15px] grid place-items-center gap-[40px] md:gap-[80px]">
            <div className="grid place-items-center px-4 gap-[20px]">
               <SectionTitle>
                  <span className="text-[#565656]">
                     {langText.chanmpionSection.title.textOne}
                  </span>{" "}
                  <br className="md:hidden" />
                  {langText.chanmpionSection.title.textTwo}
               </SectionTitle>
               <SectionSubtitle>
                  {langText.chanmpionSection.text}
               </SectionSubtitle>
            </div>
            <ChampionCards
               data={langText.chanmpionSection}
               className="hidden"
            />
            <MobileChampionCards className="md:hidden" />
         </div>

         {/* NOTE: Work Process Section */}
         <div className="grid place-items-center py-[20px] md:py-[100px] gap-[60px] md:gap-[82px]">
            <div className="grid place-items-center md:px-16 xl:px-32 px-4 gap-[20px]">
               <SectionTitle>
                  <span className="text-[#565656]">
                     {langText.workProcessSection.title.textOne}
                  </span>{" "}
                  {langText.workProcessSection.title.textTwo}
               </SectionTitle>
               <SectionSubtitle>
                  {langText.workProcessSection.text}
               </SectionSubtitle>
            </div>
            <div className="grid gap-[26px]">
               <div className="relative">
                  <div className="hidden md:block relative z-100">
                     <WorkProcessDesktopSvg />
                  </div>
                  <div className="md:hidden relative z-100 px-4 grid place-items-center">
                     <MobileWorkProcessAnimation />
                  </div>
               </div>
            </div>
         </div>

         <div>
            {/* NOTE: Portfolio Section */}
            <OurPortfolio langText={langText} lang={""} />

            {/* NOTE: PortfolioFooter Section */}
            <div className="md:px-[20px] xl:px-[40px] py-[60px] md:py-[80px] px-4 grid items-center gap-[92px] bg-[#1a1a1a]">
               <PortfolioFooter
                  footerText={langText.portfolioSection.footerText}
                  btnText={langText.portfolioSection.btnText}
                  icon={langText.portfolioSection.icon}
               />
            </div>
         </div>

         {/* NOTE: Trusted Section */}
         <div className="mt-[60px] grid items-center gap-[72px] md:gap-[92px] relative overflow-hidden">
            <div className="grid place-items-center gap-[10px]">
               <SectionTitle>{langText.trustedSection.title}</SectionTitle>
               <SectionSubtitle className="max-w-[341px] md:max-w-[800px]">
                  {langText.trustedSection.text}
               </SectionSubtitle>
            </div>
            <TurstedMarquee data={langText} />
         </div>

         {/* NOTE: Skill Section */}
         <div className="md:px-[20px] xl:px-24 py-[60px] md:py-[60px] px-4 grid items-center gap-[40px] bg-gradient-to-b lg:bg-gradient-to-r from-[#0D0D0D] to-[#2A2A2A]">
            <div className="grid lg:grid-cols-2 items-center gap-[60px] md:gap-[60px]">
               <div
                  className="grid gap-[20px]"
                  data-aos={"fade-right"}
                  data-aos-duration="500"
                  data-aos-delay="150"
               >
                  <SectionTitle className="text-center lg:text-start">
                     {langText.skillSection.title}
                  </SectionTitle>
                  <SectionSubtitle className="text-center lg:text-start max-w-full">
                     {langText.skillSection.text}
                  </SectionSubtitle>
               </div>
               <div className="grid justify-center lg:justify-end">
                  <SkillCards />
               </div>
            </div>
         </div>

         {/* NOTE: Testimonial Section */}
         <div className="md:px-[20px] xl:px-[40px] py-[60px] md:py-[80px] px-[26px] grid items-center md:gap-[10px] bg-[#000000] border-b border-[#2f2f2f]">
            <div>
               <SectionTitle>
                  {langText.clientSection.titleOne.textOne}{" "}
                  <span className="text-[#a4a4a4]">
                     {langText.clientSection.titleOne.textTwo}
                  </span>{" "}
                  <br /> {langText.clientSection.titleTwo.textOne}
                  <span className="text-[#a4a4a4]">
                     {langText.clientSection.titleTwo.textTwo}
                  </span>
               </SectionTitle>
            </div>
            <TestimonialCard langText={langText.clientSection.clientData} />
         </div>

         {/* NOTE: Blog Section */}
         <div className="grid items-center py-[60px] md:py-[60px] gap-[40px] md:gap-[80px] bg-[#000000]">
            <div className="md:px-[20px] xl:px-[40px] px-[26px] flex items-center justify-between w-screen xl:w-auto">
               <SectionTitle className="text-start">
                  {langText.blogSection.title.textOne}
                  <br className="md:hidden" />{" "}
                  {langText.blogSection.title.textTwo}{" "}
                  <span className="text-[#a4a4a4]">
                     {langText.blogSection.title.textThree}
                  </span>
               </SectionTitle>
               <BlogButton
                  title={langText.blogSection.btnText}
                  href={langText.blogSection.href}
               />
            </div>
            <div className="grid place-items-center m-auto ">
               <BlogSwipper />
            </div>
         </div>

         <Divider className="bg-[#262626]" />
         <ConnectForm className="pb-10 pt-2.5" langText={langTextContactForm} />
      </div>
   );
}
