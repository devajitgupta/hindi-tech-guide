import React from "react";

const Blogs = () => {
   return <div className="text-white">Blogs Page </div>;
};

export default Blogs;
