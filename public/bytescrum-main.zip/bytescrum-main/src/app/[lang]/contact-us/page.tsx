import ContactBanner from "@/components/contactUs/ContactBanner";
import AddressSection from "@/components/contactUs/AddressSection";
import CareerSection from "@/components/contactUs/CareerSection";
import ConnectForm from "@/components/contactUs/ConnectForm";
import Map from "@/components/contactUs/Map";
import clsx from "clsx";
import { twMerge } from "tailwind-merge";
import { Metadata } from "next";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";

export const metadata: Metadata = {
   title: "Contact Us | ByteScrum Technologies",
   description:
      "Contact ByteScrum Technologies for your web development and software needs. Get in touch to discuss your project requirements.",
};

type Props = {
   params: { lang: TLocale };
};

export default async function ContactUs({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const langText = dictionary.contactPage;
   const langTextContactForm = dictionary.contactPage.contactFormSection;

   const sectionStyle =
      " px-5 md:px-[40px] py-[60px]  md:py-[80px] gap-[40px] bg-[#000000]";
   const jsonLd = {
      "@context": "https://schema.org",
      "@type": "ContactPage",
      name: "Contact Us | ByteScrum Technologies",
      url: "https://www.bytescrum.com/contact-us",

      about: {
         "@type": "CreativeWork",
         name: "Contact ByteScrum Technologies",
         description:
            "Get in touch with ByteScrum Technologies for web development, software solutions, and digital services.",
      },
   };

   return (
      <>
         {" "}
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] ">
            <ContactBanner langText={langText.contact} />
            <ConnectForm
               className={twMerge(clsx("lg:hidden", sectionStyle))}
               langText={langTextContactForm}
            />
            <AddressSection
               className={twMerge(clsx(sectionStyle))}
               langText={langText.officeAddressData}
            />
            <CareerSection
               className={twMerge(
                  clsx(sectionStyle, "bg-[#090909] grid item-center ")
               )}
               langText={langText.careerSection}
            />
            <ConnectForm
               className={twMerge(clsx("hidden lg:flex ", sectionStyle))}
               langText={langTextContactForm}
            />
            <Map />
         </div>
      </>
   );
}
