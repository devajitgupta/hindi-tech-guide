import ConnectForm from "@/components/contactUs/ConnectForm";
import Service from "@/components/service/Service";
import FAQSection from "@/components/ui/FaqSection/FAQSection";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";
import { Divider } from "@nextui-org/react";
import { Metadata } from "next";

export const metadata: Metadata = {
   title: "Software Development Services | ByteScrum",
   description:
      "ByteScrum offers expert software development services including web, mobile, blockchain, QA, and more. Get tailored solutions for your business.",
};

type Props = {
   params: { lang: TLocale };
};

export default async function ({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);

   const langText = dictionary.servicesPage;
   const langTextShared = dictionary.homeDataPage;
   const langTextContactForm = dictionary.contactPage.contactFormSection;
   const sectionStyle =
      " px-5 md:px-[40px] py-[30px]  md:py-[60px] gap-[40px] bg-[#000000]";
   const jsonLd = {
      "@context": "https://schema.org",
      "@type": "Service",
      provider: {
         "@type": "Organization",
         name: "ByteScrum",
         url: "https://bytescrum.vercel.app",
      },
      serviceType: "Software Development Services",
      areaServed: {
         "@type": "Place",
         name: "Global",
      },
      hasOfferCatalog: {
         "@type": "OfferCatalog",
         name: "Service Offerings",
         itemListElement: [
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "Mobile App Development",
                  description:
                     "iOS & Android native/hybrid apps with secure backend integration.",
               },
            },
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "Blockchain Development",
                  description:
                     "Smart contract & decentralized application development.",
               },
            },
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "Custom Software Solutions",
                  description: "Tailored software to meet your business needs.",
               },
            },
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "Web Development",
                  description:
                     "Modern, scalable web applications and websites.",
               },
            },
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "E-commerce Development",
                  description:
                     "Full-featured online stores with secure checkout & admin panels.",
               },
            },
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "QA & Testing",
                  description:
                     "Robust manual and automated testing to ensure product quality.",
               },
            },
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "Python Developer Hiring",
                  description:
                     "Dedicated Python developers for scalable solutions.",
               },
            },
            {
               "@type": "Offer",
               itemOffered: {
                  "@type": "Service",
                  name: "Recover Hacked Website",
                  description:
                     "Immediate malware cleanup and security hardening services.",
               },
            },
         ],
      },
   };
   return (
      <>
         {" "}
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fafafa]">
            <Service langText={langText} langTextShared={langTextShared} />
            <FAQSection
               className={sectionStyle}
               header={langText.faqSectionHeader}
               data={langText.faqs}
            />
            <Divider className="bg-[#262626] my-5" />
            <ConnectForm className="py-10" langText={langTextContactForm} />
         </div>
      </>
   );
}

// const faqs = [
//    {
//       question: "What is your development process?",
//       answer:
//          "Our development process includes discovery, planning, design, development, testing, deployment, and ongoing maintenance. We follow agile methodologies to ensure flexibility and regular client feedback throughout the project.",
//    },
//    {
//       question: "How long does it take to complete a project?",
//       answer:
//          "Project timelines vary depending on complexity and scope. A simple website might take 4-6 weeks, while a complex application could take 3-6 months. We provide detailed timelines during the planning phase.",
//    },
//    {
//       question: "Do you provide ongoing support after project completion?",
//       answer:
//          "Yes, we offer various maintenance and support packages to ensure your solution continues to perform optimally. Our support includes bug fixes, security updates, and feature enhancements.",
//    },
//    {
//       question: "How do you ensure the security of applications?",
//       answer:
//          "We implement industry best practices for security, including secure coding standards, regular security audits, penetration testing, and compliance with relevant regulations like GDPR and CCPA.",
//    },
//    {
//       question: "Can you work with our existing team?",
//       answer:
//          "We offer flexible engagement models and can seamlessly integrate with your existing team, providing the specific expertise you need to complement your internal resources.",
//    },
// ];
