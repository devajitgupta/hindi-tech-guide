import AboutBanner from "@/components/aboutUs/AboutBanner";
import AboutmeSection from "@/components/aboutUs/AboutmeSection";
import clsx from "clsx";
import FunSection from "@/components/aboutUs/FunSection";
import ChooseSection from "@/components/aboutUs/ChooseSection";
import MissionSection from "@/components/aboutUs/MissionSection";
import ValueSection from "@/components/aboutUs/ValueSection";
import ConnectForm from "@/components/contactUs/ConnectForm";
import { Divider } from "@nextui-org/react";
import { Metadata } from "next";
import { TLocale } from "@/i18n-config";
import { getDictionary } from "@/get-dictionary";

export const metadata: Metadata = {
   title: "About Us | ByteScrum Technologies",
   description:
      "Learn about ByteScrum Technologies, our mission, values, and the passionate team behind our innovative digital solutions.",
};

type Props = {
   params: { lang: TLocale };
};
export default async function AboutUs({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const langText = dictionary.aboutUsPage;
   const langTextStartUpcount = dictionary.homeDataPage;
   const langTextContactForm = dictionary.contactPage.contactFormSection;
   const sectionStyle = " px-5 md:px-[40px]  bg-[#000000] overflow-hidden";

   const jsonLd = {
      "@context": "https://schema.org",
      "@type": "AboutPage",
      name: "About Us | ByteScrum Technologies",
      url: "https://www.bytescrum.com/about-us",

      about: {
         "@type": "CreativeWork",
         name: "Empowering Tech, Simplifying Lives",
         description:
            "ByteScrum Technologies is dedicated to driving innovation and delivering exceptional web and software development services.",
      },
   };
   return (
      <>
         {" "}
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] ">
            <AboutBanner langText={langText.aboutBannerData} />
            <AboutmeSection
               className={clsx(sectionStyle)}
               langText={langText.aboutMeSection}
            />
            <FunSection
               className={clsx(sectionStyle)}
               langText={langText.funSection}
               langTextStartUpcount={langTextStartUpcount}
            />
            <ChooseSection
               lang={lang}
               langText={langText}
               className={clsx("md:py-[0px]  mb-0 ", sectionStyle)}
            />

            <MissionSection
               className={clsx(
                  sectionStyle,
                  "pb-[60px] md:pb -[80px] border-b border-[#262626] mb-0"
               )}
               langText={langText.missionSection}
            />
            <Divider className="bg-[#262626]" />
            <ConnectForm className="py-20 " langText={langTextContactForm} />
         </div>
      </>
   );
}
