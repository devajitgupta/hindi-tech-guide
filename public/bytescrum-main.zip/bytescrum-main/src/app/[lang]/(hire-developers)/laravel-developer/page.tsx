import Developers from "@/components/hireDevelopers/Developers";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";
import clsx from "clsx";
import React from "react";
import { twMerge } from "tailwind-merge";
type Props = {
   params: { lang: TLocale };
};

export default async function LaraveldeveloperPage({
   params: { lang },
}: Props) {
   const dictionary = await getDictionary(lang);
   const langText = dictionary.developerDataPage;
   const langTextContactForm = dictionary.contactPage.contactFormSection;
   const sectionStyle = "  bg-[#000000]";
   return (
      <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] ">
         {/* <FullStackHeroSection /> */}
         <Developers
            {...langText["laravel-developer"]}
            langText={langTextContactForm}
            className={twMerge(clsx(sectionStyle, "px:0 md:px-0"))}
         />
      </div>
   );
}
