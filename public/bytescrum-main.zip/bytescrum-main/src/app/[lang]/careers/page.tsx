import CareerBanner from "@/components/career/CareerBanner";
import BenefitSection from "@/components/career/benefitSection/BenefitSection";
import clsx from "clsx";
import WorkSection from "@/components/career/workSection/WorkSection";
import OpportunitySection from "@/components/career/opportunitySection/OpportunitySection";
import TeamSection from "@/components/career/teamSection/TeamSection";
import Connect from "@/components/connectSection/Connect";
import { twMerge } from "tailwind-merge";
import BenefitSwipper from "@/components/career/benefitSection/BenefitSwipper";

import TestGallery from "@/components/career/TestGallery";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";
import { Metadata } from "next";

export const metadata: Metadata = {
   title: "Careers | ByteScrum Technologies",
   description:
      "Explore exciting career opportunities at ByteScrum Technologies and join our passionate team.",
};

type Props = {
   params: { lang: TLocale };
};
export default async function Careers({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);

   const langText = dictionary.careerData;
   const sectionStyle =
      " px-5 md:px-[40px] py-[60px] md:py-[60px] bg-[#000000] overflow-hidden page-career";
   return (
      <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] ">
         <CareerBanner data={langText.pageBanner} />

         <BenefitSection
            className={clsx(sectionStyle, "md:pb-[180px]")}
            data={langText.benefitSection}
         />
         <BenefitSwipper
            className={clsx(sectionStyle, "px-0  lg:hidden")}
            swipperData={langText.benefitSection.cardData}
         />
         {/* <PhotoGallery data={langText.imgGallery} /> */}
         {/* <div className="max-h-screen overflow-hidden">
            <GallerySection />
         </div> */}

         <TestGallery workspaceHeader={langText.workspaceHeader} />

         <WorkSection
            className={twMerge(clsx(sectionStyle, "px-0 md:py-[30px]  "))}
            data={langText.workSection}
         />
         <OpportunitySection
            className={twMerge(clsx(sectionStyle, "md:py-[60px] "))}
            data={langText.opportunity}
         />
         <TeamSection className={sectionStyle} data={langText.teamSection} />
         {/* <Connect /> */}
      </div>
   );
}
