// import PageBanner from "@/components/PageBanner";
// import SectionTitle from "@/components/SectionTitle";
// import Text from "@/components/Text";
// import clsx from "clsx";
// import { Metadata } from "next";
// import Link from "next/link";
// import React from "react";
// import { twMerge } from "tailwind-merge";

// export const metadata: Metadata = {
//    title: "Privacy Policy | ByteScrum Technologies",
//    description:
//       "Read ByteScrum Technologies privacy policy to understand how we protect and handle your personal information and data.",
// };

// const PrivacyPolicyPage = () => {
//    const sectionTitleStyle = "!text-xl md:!text-2xl font-semibold text-start  ";
//    const textStyle =
//       " mb-3 lg:max-w-full w-full text-start md:!text-lg md:!leading-[32px] ";
//    const jsonLd = {
//       "@context": "https://schema.org",
//       "@type": "WebPage",
//       name: "Privacy Policy | ByteScrum Technologies",
//       url: "https://www.bytescrum.com/privacy-policy",

//       about: {
//          "@type": "CreativeWork",
//          name: "Privacy Policy",
//          description:
//             "ByteScrum Technologies privacy policy explaining how we collect, use, and safeguard user information.",
//       },
//    };

//    return (
//       <>
//          {" "}
//          <script
//             type="application/ld+json"
//             dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
//          />
//          <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] ">
//             {" "}
//             <PageBanner bgPath="/contactBanner.png">
//                <div className="grid place-items-center md:gap-[10px]">
//                   <h1
//                      className="text-[35px] md:text-[70px] md:leading-[80px]   poppins text-center font-bold"
//                      data-aos="zoom-in"
//                      data-aos-easing="ease-out-cubic"
//                      data-aos-anchor-placement="top-bottom"
//                   >
//                      Privacy Policy
//                   </h1>
//                   <p
//                      className="poppins text-[#b7b7b7] text-[14px] md:text-[18px]"
//                      data-aos="zoom-in"
//                      data-aos-easing="ease-out-cubic"
//                      data-aos-delay={500}
//                      data-aos-anchor-placement="top-bottom"
//                   >
//                      {" "}
//                      Home | Privacy-Policy
//                   </p>
//                </div>
//             </PageBanner>
//             <div className="px-5 md:px-[80px] py-[30px]  md:py-[40px] gap-[40px] bg-[#000000]">
//                <div className=" m-auto">
//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      Effective Date: 01-02-2017
//                   </SectionTitle>

//                   <Text className={twMerge(clsx(textStyle))}>
//                      At ByteScrum Technologies, we are dedicated to protecting
//                      the privacy and confidentiality of our users' personal
//                      information. This Privacy Policy explains how we collect,
//                      use, and safeguard the information we receive when
//                      providing our services as an IT web and app-based service
//                      provider. By using our services, you agree to the terms
//                      described in this policy.
//                   </Text>

//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      1. Information We Collect
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      As an IT web and app-based service provider, we do not
//                      collect personal information from our clients' users unless
//                      explicitly provided to us for the purpose of providing our
//                      services. We only collect and process information that is
//                      necessary and relevant to deliver our services effectively.
//                   </Text>

//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      2. How We Use Your Information{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      We use the information provided by our clients to deliver
//                      the requested services, including development, maintenance,
//                      and support.
//                   </Text>

//                   <SectionTitle
//                      useAs="h4"
//                      className={twMerge(
//                         clsx(sectionTitleStyle, "!text-lg md:!text-xl")
//                      )}
//                   >
//                      2.1 Service Delivery:{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      We use the information provided by our clients to deliver
//                      the requested services, including development, maintenance,
//                      and support.
//                   </Text>

//                   <SectionTitle
//                      useAs="h4"
//                      className={twMerge(
//                         clsx(sectionTitleStyle, "!text-lg md:!text-xl")
//                      )}
//                   >
//                      2.2 Communication:{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      We may use the provided contact information to communicate
//                      with our clients regarding service-related updates,
//                      inquiries, and support.
//                   </Text>

//                   <SectionTitle
//                      useAs="h4"
//                      className={twMerge(
//                         clsx(sectionTitleStyle, "!text-lg md:!text-xl")
//                      )}
//                   >
//                      Information Sharing and Disclosure{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      We use the information provided by our clients to deliver
//                      the requested services, including development, maintenance,
//                      and support.
//                   </Text>

//                   <SectionTitle
//                      useAs="h4"
//                      className={twMerge(
//                         clsx(sectionTitleStyle, "!text-lg md:!text-xl")
//                      )}
//                   >
//                      2.1 Communication:{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      We may use the provided contact information to communicate
//                      with our clients regarding service-related updates,
//                      inquiries, and support.
//                   </Text>

//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      3. Information Sharing and Disclosure{" "}
//                   </SectionTitle>
//                   <SectionTitle
//                      useAs="h4"
//                      className={twMerge(
//                         clsx(sectionTitleStyle, "!text-lg md:!text-xl")
//                      )}
//                   >
//                      3.1 Third-Party Services:{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      In the course of providing our services, we may engage
//                      trusted third-party service providers to assist us. These
//                      providers may have access to certain information, but they
//                      are bound by confidentiality agreements and are authorized
//                      to use it only to the extent necessary to perform their
//                      services on our behalf.
//                   </Text>

//                   <SectionTitle
//                      useAs="h4"
//                      className={twMerge(
//                         clsx(sectionTitleStyle, "!text-lg md:!text-xl")
//                      )}
//                   >
//                      3.2 Legal Compliance:{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      We may disclose client information if required by law,
//                      court order, or government request. We may also share
//                      information to protect our rights, safety, or property, or
//                      that of our clients or the public.
//                   </Text>

//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      4. Data Security{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      We take appropriate measures to ensure the security and
//                      confidentiality of client information. We implement
//                      industry-standard security practices and procedures to
//                      protect against unauthorized access, disclosure,
//                      alteration, or destruction of data.
//                   </Text>

//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      5. Your Rights and Choices{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      As a user of our services, you may not have direct control
//                      over personal information collected by our clients. If you
//                      have any concerns or requests regarding your personal
//                      information, please reach out to the relevant client
//                      directly.
//                   </Text>

//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      6. Third-Party Links and Services{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      Our services may contain links to third-party websites or
//                      services that are not operated by us. We are not
//                      responsible for the privacy practices or content of those
//                      third parties. We encourage you to review the privacy
//                      policies of any third-party sites or services you interact
//                      with.
//                   </Text>

//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      7. Changes to this Privacy Policy{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      We reserve the right to update or modify this Privacy
//                      Policy at any time. Any changes will be effective
//                      immediately upon posting the revised policy on our website
//                      or notifying our clients through other means. We encourage
//                      you to review this policy periodically for any updates. If
//                      you have any questions or concerns regarding this Privacy
//                      Policy, please contact us using the link below.
//                   </Text>

//                   <Text className={twMerge(clsx(textStyle))}>
//                      <Link
//                         href="/contact-us"
//                         className="text-blue-500 underline underline-offset-2 "
//                      >
//                         Contact Us
//                      </Link>
//                   </Text>
//                </div>
//             </div>
//          </div>
//       </>
//    );
// };

// export default PrivacyPolicyPage;

import PageBanner from "@/components/PageBanner";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";
import clsx from "clsx";
import { Metadata } from "next";
import Link from "next/link";
import React from "react";
import { twMerge } from "tailwind-merge";

export const metadata: Metadata = {
   title: "Privacy Policy | ByteScrum Technologies",
   description:
      "Read ByteScrum Technologies privacy policy to understand how we protect and handle your personal information and data.",
};

type Props = {
   params: { lang: TLocale };
};
export default async function PrivacyPolicyPage({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const langText = dictionary.privacyPolicyPage;
   const sectionTitleStyle = "!text-xl md:!text-2xl font-semibold text-start";
   const textStyle =
      "mb-3 lg:max-w-full w-full text-start md:!text-lg md:!leading-[32px]";

   const jsonLd = {
      "@context": "https://schema.org",
      "@type": "WebPage",
      name: metadata.title,
      url: "https://www.bytescrum.com/privacy-policy",
      about: {
         "@type": "CreativeWork",
         name: langText.pageTitle,
         description: metadata.description,
      },
   };

   return (
      <>
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff]">
            <PageBanner bgPath="/contactBanner.png">
               <div className="grid place-items-center md:gap-[10px]">
                  <h1
                     className="text-[35px] md:text-[70px] md:leading-[80px] poppins text-center font-bold"
                     data-aos="zoom-in"
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     {langText.pageTitle}
                  </h1>
                  <p
                     className="poppins text-[#b7b7b7] text-[14px] md:text-[18px]"
                     data-aos="zoom-in"
                     data-aos-delay={500}
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     {langText.breadcrumb}
                  </p>
               </div>
            </PageBanner>

            <div className="px-5 md:px-[80px] py-[30px] md:py-[40px] gap-[40px] bg-[#000000]">
               <div className="m-auto">
                  <SectionTitle
                     useAs="h3"
                     className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
                  >
                     {`${langText.effectiveDateLabel}: ${langText.effectiveDate}`}
                  </SectionTitle>

                  <Text className={twMerge(clsx(textStyle))}>
                     {langText.intro}
                  </Text>

                  {langText.sections.map((section: any, index: any) => (
                     <React.Fragment key={index}>
                        <SectionTitle
                           useAs="h3"
                           className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
                        >
                           {section.title}
                        </SectionTitle>

                        {section.content && (
                           <Text className={twMerge(clsx(textStyle))}>
                              {section.content}
                           </Text>
                        )}

                        {section.subsections?.map((sub: any, index: any) => (
                           <React.Fragment key={index}>
                              <SectionTitle
                                 useAs="h4"
                                 className={twMerge(
                                    clsx(
                                       sectionTitleStyle,
                                       "!text-lg md:!text-xl"
                                    )
                                 )}
                              >
                                 {sub.title}
                              </SectionTitle>
                              <Text className={twMerge(clsx(textStyle))}>
                                 {sub.content}
                              </Text>
                           </React.Fragment>
                        ))}

                        {section.hasContactLink && (
                           <Text className={twMerge(clsx(textStyle))}>
                              <Link
                                 href="/contact-us"
                                 className="text-blue-500 underline underline-offset-2"
                              >
                                 {section.contactText}
                              </Link>
                           </Text>
                        )}
                     </React.Fragment>
                  ))}
               </div>
            </div>
         </div>
      </>
   );
}
