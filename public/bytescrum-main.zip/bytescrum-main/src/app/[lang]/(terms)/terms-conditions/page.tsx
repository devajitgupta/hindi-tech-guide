// import PageBanner from "@/components/PageBanner";
// import SectionTitle from "@/components/SectionTitle";
// import Text from "@/components/Text";
// import clsx from "clsx";
// import { Metadata } from "next";
// import Link from "next/link";
// import React from "react";
// import { twMerge } from "tailwind-merge";

// export const metadata: Metadata = {
//    title: "Terms & Conditions | ByteScrum Technologies",
//    description:
//       "Read ByteScrum Technologies terms and conditions to understand the rules and regulations for using our website and services.",
// };

// const PrivacyPolicyPage = () => {
//    const sectionTitleStyle = "!text-xl md:!text-2xl font-semibold text-start  ";
//    const textStyle =
//       " mb-3 lg:max-w-full w-full text-start md:!text-lg md:!leading-[32px] ";
//    const listStyle =
//       " mb-1 lg:max-w-full w-full text-start md:!text-lg md:!leading-[28px] ml-5 pe-5 ";
//    const jsonLd = {
//       "@context": "https://schema.org",
//       "@type": "WebPage",
//       name: "Terms & Conditions | ByteScrum Technologies",
//       url: "https://www.bytescrum.com/terms-conditions",

//       about: {
//          "@type": "CreativeWork",
//          name: "Terms & Conditions",
//          description:
//             "ByteScrum Technologies terms and conditions outlining the rules and regulations for website use and services.",
//       },
//    };
//    return (
//       <>
//          {" "}
//          <script
//             type="application/ld+json"
//             dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
//          />
//          <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] ">
//             {" "}
//             <PageBanner bgPath="/contactBanner.png">
//                <div className="grid place-items-center md:gap-[10px]">
//                   <h1
//                      className="text-[35px] md:text-[70px] md:leading-[80px]   poppins text-center font-bold"
//                      data-aos="zoom-in"
//                      data-aos-easing="ease-out-cubic"
//                      data-aos-anchor-placement="top-bottom"
//                   >
//                      Terms & Conditions
//                   </h1>
//                   <p
//                      className="poppins text-[#b7b7b7] text-[14px] md:text-[18px]"
//                      data-aos="zoom-in"
//                      data-aos-easing="ease-out-cubic"
//                      data-aos-delay={500}
//                      data-aos-anchor-placement="top-bottom"
//                   >
//                      {" "}
//                      Home | Terms-Conditions
//                   </p>
//                </div>
//             </PageBanner>
//             <div className="px-5 md:px-[80px] py-[30px]  md:py-[40px] gap-[40px] bg-[#000000]">
//                {" "}
//                <div className="container">
//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      Welcome to ByteScrum Technologies Private Limited{" "}
//                   </SectionTitle>

//                   <Text className={twMerge(clsx(textStyle))}>
//                      These terms of service outline the rules and regulations
//                      for the use of ByteScrum Technologies Private Limited's
//                      Website.
//                   </Text>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      ByteScrum Technologies Private Limited is located at:
//                      <br />
//                      B-50 Second Floor Vibuhti Khand, <br /> Gomti Nagar,
//                      Lucknow 226010 <br />
//                      UTTAR PRADESH , INDIA
//                   </Text>

//                   <Text className={twMerge(clsx(textStyle))}>
//                      By accessing this website we assume you accept these terms
//                      of service in full. Do not continue to use ByteScrum
//                      Technologies Private Limited's website if you do not accept
//                      all of the terms of service stated on this page.
//                   </Text>

//                   <Text className={twMerge(clsx(textStyle))}>
//                      The following terminology applies to these Terms of
//                      Service, Privacy Statement and Disclaimer Notice and any or
//                      all Agreements: "Client", "You" and "Your" refers to you,
//                      the person accessing this website and accepting the
//                      Company's terms of service. "The Company", "Ourselves",
//                      "We", "Our" and "Us", refers to our Company. "Party",
//                      "Parties", or "Us", refers to both the Client and
//                      ourselves, or either the Client or ourselves. All terms
//                      refer to the offer, acceptance and consideration of payment
//                      necessary to undertake the process of our assistance to the
//                      Client in the most appropriate manner, whether by formal
//                      meetings of a fixed duration, or any other means, for the
//                      express purpose of meeting the Client's needs in respect of
//                      provision of the Company's stated services/products, in
//                      accordance with and subject to, prevailing law of India.
//                      Any use of the above terminology or other words in the
//                      singular, plural, capitalisation and/or he/she or they, are
//                      taken as interchangeable and therefore as referring to the
//                      same.
//                   </Text>

//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      Cookies{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      We employ the use of cookies. By using ByteScrum
//                      Technologies Private Limited's website you consent to the
//                      use of cookies in accordance with ByteScrum Technologies
//                      Private Limited's privacy policy. Most of the modern day
//                      interactive websites use cookies to enable us to retrieve
//                      user details for each visit. Cookies are used in some areas
//                      of our site to enable the functionality of this area and
//                      ease of use for those people visiting. Some of our
//                      affiliate / advertising partners may also use cookies. To
//                      know more in detail, please click here{" "}
//                      <Link href="/cookies">Cookies</Link>
//                   </Text>

//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      License{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      Unless otherwise stated, ByteScrum Technologies Private
//                      Limited and/or it's licensors own the intellectual property
//                      rights for all material on ByteScrum Technologies Private
//                      Limited. All intellectual property rights are reserved. You
//                      may view and/or print pages from bytescrum.com for your own
//                      personal use subject to restrictions set in these terms of
//                      service.
//                   </Text>

//                   <Text className={twMerge(clsx(textStyle))}>
//                      You must not:
//                   </Text>
//                   <ul className=" list-disc">
//                      <li className={twMerge(clsx(listStyle))}>
//                         Republish material from bytescrum.com
//                      </li>
//                      <li className={twMerge(clsx(listStyle))}>
//                         Sell, rent or sub-license material from bytescrum.com/
//                      </li>
//                      <li className={twMerge(clsx(listStyle))}>
//                         Reproduce, duplicate or copy material from bytescrum.com
//                      </li>
//                   </ul>

//                   <Text className={twMerge(clsx(textStyle))}>
//                      Redistribute content from ByteScrum Technologies Private
//                      Limited &#x28;unless content is specifically made for
//                      redistribution&#x29;.
//                   </Text>

//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      User Comments{" "}
//                   </SectionTitle>

//                   <Text className={twMerge(clsx(textStyle))}>
//                      You must not:
//                   </Text>
//                   <ul className=" list-decimal">
//                      <li className={twMerge(clsx(listStyle))}>
//                         This Agreement shall begin on the date hereof.
//                      </li>
//                      <li className={twMerge(clsx(listStyle))}>
//                         Certain parts of this website offer the opportunity for
//                         users to post and exchange opinions, information,
//                         material and data &#x28;'Comments'&#x29; in areas of the
//                         website. ByteScrum Technologies Private Limited does not
//                         screen, edit, publish or review Comments prior to their
//                         appearance on the website and Comments do not reflect
//                         the views or opinions of ByteScrum Technologies Private
//                         Limited, its agents or affiliates. Comments reflect the
//                         view and opinion of the person who posts such a view or
//                         opinion. To the extent permitted by applicable laws
//                         ByteScrum Technologies Private Limited shall not be
//                         responsible or liable for the Comments or for any loss
//                         cost, liability, damages or expenses caused and or
//                         suffered as a result of any use of and/or posting of
//                         and/or appearance of the Comments on this website.
//                      </li>
//                      <li className={twMerge(clsx(listStyle))}>
//                         ByteScrum Technologies Private Limited reserves the
//                         right to monitor all Comments and to remove any Comments
//                         which it considers in its absolute discretion to be
//                         inappropriate, offensive or otherwise in breach of these
//                         Terms of Service.
//                      </li>
//                      <li className={twMerge(clsx(listStyle))}>
//                         You warrant and represent that:
//                         <ul className=" list-disc">
//                            <li className={twMerge(clsx(listStyle))}>
//                               You are entitled to post the Comments on our
//                               website and have all necessary licenses and
//                               consents to do so;
//                            </li>
//                            <li className={twMerge(clsx(listStyle))}>
//                               The Comments do not infringe any intellectual
//                               property right, including without limitation
//                               copyright, patent or trademark, or other
//                               proprietary right of any third party;
//                            </li>
//                            <li className={twMerge(clsx(listStyle))}>
//                               The Comments do not contain any defamatory,
//                               libelous, offensive, indecent or otherwise
//                               unlawful material or material which is an invasion
//                               of privacy
//                            </li>
//                            <li className={twMerge(clsx(listStyle))}>
//                               The Comments will not be used to solicit or
//                               promote business or custom or present commercial
//                               activities or unlawful activity.
//                            </li>
//                         </ul>
//                      </li>
//                      <li className={twMerge(clsx(listStyle))}>
//                         You hereby grant to{" "}
//                         <strong>ByteScrum Technologies Private Limited</strong>{" "}
//                         a non-exclusive royalty-free license to use, reproduce,
//                         edit and authorize others to use, reproduce and edit any
//                         of your Comments in any and all forms, formats or media.
//                      </li>
//                   </ul>
//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      Hyperlinking to our Content{" "}
//                   </SectionTitle>
//                   <ul className=" list-decimal">
//                      <li className={twMerge(clsx(listStyle))}>
//                         The following organizations may link to our Web site
//                         without prior written approval:
//                         <ul className=" list-disc">
//                            <li className={twMerge(clsx(listStyle))}>
//                               Government agencies;
//                            </li>
//                            <li className={twMerge(clsx(listStyle))}>
//                               Search engines;
//                            </li>
//                            <li className={twMerge(clsx(listStyle))}>
//                               News organizations;
//                            </li>
//                            <li className={twMerge(clsx(listStyle))}>
//                               Online directory distributors when they list us in
//                               the directory may link to our Web site in the same
//                               manner as they hyperlink to the Web sites of other
//                               listed businesses; and
//                            </li>
//                            <li className={twMerge(clsx(listStyle))}>
//                               Systemwide Accredited Businesses except soliciting
//                               non-profit organizations, charity shopping malls,
//                               and charity fundraising groups which may not
//                               hyperlink to our Web site.
//                            </li>
//                         </ul>
//                      </li>
//                      <li className={twMerge(clsx(listStyle))}>
//                         These organizations may link to our home page, to
//                         publications or to other Web site information so long as
//                         the link: &#x28;a&#x29; is not in any way misleading;
//                         &#x28;b&#x29; does not falsely imply sponsorship,
//                         endorsement or approval of the linking party and its
//                         products or services; and &#x28;c&#x29; fits within the
//                         context of the linking party's site.
//                      </li>
//                      <li className={twMerge(clsx(listStyle))}>
//                         We may consider and approve in our sole discretion other
//                         link requests from the following types of organizations:
//                         <ul className=" list-disc">
//                            <li className={twMerge(clsx(listStyle))}>
//                               Commonly-known consumer and/or business
//                               information sources such as Chambers of Commerce,
//                               American Automobile Association, AARP and
//                               Consumers Union;
//                            </li>
//                            <li className={twMerge(clsx(listStyle))}>
//                               Dot.com community sites;
//                            </li>
//                            <li className={twMerge(clsx(listStyle))}>
//                               Associations or other groups representing
//                               charities, including charity giving sites,
//                            </li>
//                            <li className={twMerge(clsx(listStyle))}>
//                               Online directory distributors;
//                            </li>
//                            <li className={twMerge(clsx(listStyle))}>
//                               Internet portals;
//                            </li>
//                            <li className={twMerge(clsx(listStyle))}>
//                               Accounting, law and consulting firms whose primary
//                               clients are businesses; and
//                            </li>
//                            <li className={twMerge(clsx(listStyle))}>
//                               Educational institutions and trade associations.
//                            </li>
//                         </ul>
//                      </li>
//                   </ul>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      We will approve link requests from these organizations if
//                      we determine that: &#x28;a&#x29; the link would not reflect
//                      unfavorably on us or our accredited businesses &#x28;for
//                      example, trade associations or other organizations
//                      representing inherently suspect types of business, such as
//                      work-at-home opportunities, shall not be allowed to
//                      link&#x29;; &#x28;b&#x29;the organization does not have an
//                      unsatisfactory record with us; &#x28;c&#x29; the benefit to
//                      us from the visibility associated with the hyperlink
//                      outweighs the absence of ByteScrum Technologies Private
//                      Limited; and &#x28;d&#x29; where the link is in the context
//                      of general resource information or is otherwise consistent
//                      with editorial content in a newsletter or similar product
//                      furthering the mission of the organization.
//                   </Text>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      These organizations may link to our home page, to
//                      publications or to other Web site information so long as
//                      the link: &#x28;a&#x29; is not in any way misleading;
//                      &#x28;b&#x29; does not falsely imply sponsorship,
//                      endorsement or approval of the linking party and it
//                      products or services; and &#x28;c&#x29; fits within the
//                      context of the linking party's site.
//                   </Text>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      If you are among the organizations listed in paragraph 2
//                      above and are interested in linking to our website, you
//                      must notify us by sending an e-mail to{" "}
//                      <a href="mailto:info@bytescrum.com">info@bytescrum.com</a>.
//                      Please include your name, your organization name, contact
//                      information &#x28;such as a phone number and/or e-mail
//                      address&#x29; as well as the URL of your site, a list of
//                      any URLs from which you intend to link to our Web site, and
//                      a list of the URL&#x28;s&#x29; on our site to which you
//                      would like to link. Allow 2-3 weeks for a response.
//                      <br />
//                      Approved organizations may hyperlink to our Web site as
//                      follows:
//                   </Text>
//                   <ul className=" list-disc">
//                      <li className={twMerge(clsx(listStyle))}>
//                         By use of our corporate name; or
//                      </li>
//                      <li className={twMerge(clsx(listStyle))}>
//                         By use of the uniform resource locator &#x28;Web
//                         address&#x29; being linked to; or
//                      </li>
//                      <li className={twMerge(clsx(listStyle))}>
//                         By use of any other description of our Web site or
//                         material being linked to that makes sense within the
//                         context and format of content on the linking party's
//                         site.
//                      </li>
//                   </ul>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      No use of ByteScrum Technologies Private Limited's logo or
//                      other artwork will be allowed for linking absent a
//                      trademark license agreement.
//                   </Text>
//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      Iframes{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      Without prior approval and express written permission, you
//                      may not create frames around our Web pages or use other
//                      techniques that alter in any way the visual presentation or
//                      appearance of our Web site.
//                   </Text>
//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      Content Liability{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      We shall have no responsibility or liability for any
//                      content appearing on your Web site. You agree to indemnify
//                      and defend us against all claims arising out of or based
//                      upon your Website. No link&#x28;s&#x29; may appear on any
//                      page on your Web site or within any context containing
//                      content or materials that may be interpreted as libelous,
//                      obscene or criminal, or which infringes, otherwise
//                      violates, or advocates the infringement or other violation
//                      of, any third party rights.
//                   </Text>
//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      Reservation of Rights{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      We reserve the right at any time and in its sole discretion
//                      to request that you remove all links or any particular link
//                      to our Web site. You agree to immediately remove all links
//                      to our Web site upon such request. We also reserve the
//                      right to amend these terms of service and its linking
//                      policy at any time. By continuing to link to our Web site,
//                      you agree to be bound to and abide by these linking terms
//                      of service.
//                   </Text>
//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      Removal of links from our website{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      If you find any link on our Web site or any linked web site
//                      objectionable for any reason, you may contact us about
//                      this. We will consider requests to remove links but will
//                      have no obligation to do so or to respond directly to you.
//                      <br />
//                      Whilst we endeavour to ensure that the information on this
//                      website is correct, we do not warrant its completeness or
//                      accuracy; nor do we commit to ensuring that the website
//                      remains available or that the material on the website is
//                      kept up to date.
//                   </Text>
//                   <SectionTitle
//                      useAs="h3"
//                      className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
//                   >
//                      Disclaimer{" "}
//                   </SectionTitle>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      To the maximum extent permitted by applicable law, we
//                      exclude all representations, warranties and conditions
//                      relating to our website and the use of this website
//                      &#x28;including, without limitation, any warranties implied
//                      by law in respect of satisfactory quality, fitness for
//                      purpose and/or the use of reasonable care and skill&#x29;.
//                      Nothing in this disclaimer will:
//                   </Text>
//                   <ul className=" list-disc">
//                      <li className={twMerge(clsx(listStyle))}>
//                         Limit or exclude our or your liability for death or
//                         personal injury resulting from negligence;
//                      </li>
//                      <li className={twMerge(clsx(listStyle))}>
//                         Limit or exclude our or your liability for fraud or
//                         fraudulent misrepresentation;
//                      </li>
//                      <li className={twMerge(clsx(listStyle))}>
//                         Limit any of our or your liabilities in any way that is
//                         not permitted under applicable law; or
//                      </li>
//                      <li className={twMerge(clsx(listStyle))}>
//                         Exclude any of our or your liabilities that may not be
//                         excluded under applicable law.
//                      </li>
//                   </ul>
//                   <Text className={twMerge(clsx(textStyle))}>
//                      The limitations and exclusions of liability set out in this
//                      Section and elsewhere in this disclaimer: &#x28;a&#x29; are
//                      subject to the preceding paragraph; and &#x28;b&#x29;
//                      govern all liabilities arising under the disclaimer or in
//                      relation to the subject matter of this disclaimer,
//                      including liabilities arising in contract, in tort
//                      &#x28;including negligence&#x29; and for breach of
//                      statutory duty.
//                      <br />
//                      To the extent that the website and the information and
//                      services on the website are provided free of charge, we
//                      will not be liable for any loss or damage of any nature.
//                   </Text>
//                </div>
//             </div>
//          </div>
//       </>
//    );
// };

// export default PrivacyPolicyPage;

import PageBanner from "@/components/PageBanner";
import SectionTitle from "@/components/SectionTitle";
import Text from "@/components/Text";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";
import clsx from "clsx";
import { Metadata } from "next";
import Link from "next/link";
import React from "react";
import { twMerge } from "tailwind-merge";

export const metadata: Metadata = {
   title: "Terms & Conditions | ByteScrum Technologies",
   description:
      "Read ByteScrum Technologies terms and conditions to understand the rules and regulations for using our website and services.",
};

type Props = {
   params: { lang: TLocale };
};

// Helper component to render content with lists
const ContentRenderer = ({ content, textStyle, listStyle }: any) => {
   return content.map((item: any, index: number) => {
      if (typeof item === "string") {
         return (
            <Text key={index} className={twMerge(clsx(textStyle))}>
               {item}
            </Text>
         );
      }

      if (item.type === "list") {
         return (
            <ul
               key={index}
               className={item.style === "disc" ? "list-disc" : "list-decimal"}
            >
               {item.items.map((listItem: any, listIndex: number) => (
                  <li key={listIndex} className={twMerge(clsx(listStyle))}>
                     {typeof listItem === "string" ? listItem : listItem.text}
                     {listItem.subList && (
                        <ul
                           className={
                              listItem.subList.type === "disc"
                                 ? "list-disc"
                                 : "list-decimal"
                           }
                        >
                           {listItem.subList.items.map(
                              (subItem: string, subIndex: number) => (
                                 <li
                                    key={subIndex}
                                    className={twMerge(clsx(listStyle))}
                                 >
                                    {subItem}
                                 </li>
                              )
                           )}
                        </ul>
                     )}
                  </li>
               ))}
            </ul>
         );
      }

      if (item.address) {
         return (
            <Text key={index} className={twMerge(clsx(textStyle))}>
               {item.text}
               <br />
               {item.address.map((line: string, lineIndex: number) => (
                  <React.Fragment key={lineIndex}>
                     {line} <br />
                  </React.Fragment>
               ))}
            </Text>
         );
      }

      if (item.link) {
         return (
            <Text key={index} className={twMerge(clsx(textStyle))}>
               {item.text} <Link href={item.link.href}>{item.link.text}</Link>
            </Text>
         );
      }

      if (item.email) {
         return (
            <Text key={index} className={twMerge(clsx(textStyle))}>
               {item.text} <a href={`mailto:${item.email}`}>{item.email}</a>
               {item.additionalText}
               <br />
               {item.followUpText}
            </Text>
         );
      }

      return null;
   });
};

export default async function PrivacyPolicyPage({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const langText = dictionary.termsConditions;

   const sectionTitleStyle = "!text-xl md:!text-2xl font-semibold text-start  ";
   const textStyle =
      " mb-3 lg:max-w-full w-full text-start md:!text-lg md:!leading-[32px] ";
   const listStyle =
      " mb-1 lg:max-w-full w-full text-start md:!text-lg md:!leading-[28px] ml-5 pe-5 ";

    const jsonLd = {
      "@context": "https://schema.org",
      "@type": "WebPage",
      name: "Terms & Conditions | ByteScrum Technologies",
      url: "https://www.bytescrum.com/terms-conditions",

      about: {
         "@type": "CreativeWork",
         name: "Terms & Conditions",
         description:
            "ByteScrum Technologies terms and conditions outlining the rules and regulations for website use and services.",
      },
   };

   return (
      <>
          <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         /> 
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] ">
            <PageBanner bgPath={"/contactBanner.png"}>
               <div className="grid place-items-center md:gap-[10px]">
                  <h1
                     className="text-[35px] md:text-[70px] md:leading-[80px]   poppins text-center font-bold"
                     data-aos="zoom-in"
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     {langText.title}
                  </h1>
                  <p
                     className="poppins text-[#b7b7b7] text-[14px] md:text-[18px]"
                     data-aos="zoom-in"
                     data-aos-easing="ease-out-cubic"
                     data-aos-delay={500}
                     data-aos-anchor-placement="top-bottom"
                  >
                     {langText.breadcrumb}
                  </p>
               </div>
            </PageBanner>

            <div className="px-5 md:px-[80px] py-[30px]  md:py-[40px] gap-[40px] bg-[#000000]">
               <div className="container">
                  {/* Welcome Section */}
                  <SectionTitle
                     useAs="h3"
                     className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
                  >
                     {langText.content.welcome.title}
                  </SectionTitle>

                  {langText.content.welcome.paragraphs.map(
                     (paragraph: any, index: number) => {
                        if (typeof paragraph === "string") {
                           return (
                              <Text
                                 key={index}
                                 className={twMerge(clsx(textStyle))}
                              >
                                 {paragraph}
                              </Text>
                           );
                        }

                        if (paragraph.address) {
                           return (
                              <Text
                                 key={index}
                                 className={twMerge(clsx(textStyle))}
                              >
                                 {paragraph.text}
                                 <br />
                                 {paragraph.address.map(
                                    (line: string, lineIndex: number) => (
                                       <React.Fragment key={lineIndex}>
                                          {line} <br />
                                       </React.Fragment>
                                    )
                                 )}
                              </Text>
                           );
                        }

                        return null;
                     }
                  )}

                  {/* Cookies Section */}
                  <SectionTitle
                     useAs="h3"
                     className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
                  >
                     {langText.content.cookies.title}
                  </SectionTitle>
                  <ContentRenderer
                     content={langText.content.cookies.content}
                     textStyle={textStyle}
                     listStyle={listStyle}
                  />

                  {/* License Section */}
                  <SectionTitle
                     useAs="h3"
                     className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
                  >
                     {langText.content.license.title}
                  </SectionTitle>
                  <ContentRenderer
                     content={langText.content.license.content}
                     textStyle={textStyle}
                     listStyle={listStyle}
                  />

                  {/* User Comments Section */}
                  <SectionTitle
                     useAs="h3"
                     className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
                  >
                     {langText.content.userComments.title}
                  </SectionTitle>
                  <ContentRenderer
                     content={langText.content.userComments.content}
                     textStyle={textStyle}
                     listStyle={listStyle}
                  />

                  {/* Hyperlinking Section */}
                  <SectionTitle
                     useAs="h3"
                     className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
                  >
                     {langText.content.hyperlinking.title}
                  </SectionTitle>
                  <ContentRenderer
                     content={langText.content.hyperlinking.content}
                     textStyle={textStyle}
                     listStyle={listStyle}
                  />

                  {/* Iframes Section */}
                  <SectionTitle
                     useAs="h3"
                     className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
                  >
                     {langText.content.iframes.title}
                  </SectionTitle>
                  <ContentRenderer
                     content={langText.content.iframes.content}
                     textStyle={textStyle}
                     listStyle={listStyle}
                  />

                  {/* Content Liability Section */}
                  <SectionTitle
                     useAs="h3"
                     className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
                  >
                     {langText.content.contentLiability.title}
                  </SectionTitle>
                  <ContentRenderer
                     content={langText.content.contentLiability.content}
                     textStyle={textStyle}
                     listStyle={listStyle}
                  />

                  {/* Reservation of Rights Section */}
                  <SectionTitle
                     useAs="h3"
                     className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
                  >
                     {langText.content.reservationOfRights.title}
                  </SectionTitle>
                  <ContentRenderer
                     content={langText.content.reservationOfRights.content}
                     textStyle={textStyle}
                     listStyle={listStyle}
                  />

                  {/* Removal of Links Section */}
                  <SectionTitle
                     useAs="h3"
                     className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
                  >
                     {langText.content.removalOfLinks.title}
                  </SectionTitle>
                  <ContentRenderer
                     content={langText.content.removalOfLinks.content}
                     textStyle={textStyle}
                     listStyle={listStyle}
                  />

                  {/* Disclaimer Section */}
                  <SectionTitle
                     useAs="h3"
                     className={twMerge(clsx(sectionTitleStyle, "mb-2"))}
                  >
                     {langText.content.disclaimer.title}
                  </SectionTitle>
                  <ContentRenderer
                     content={langText.content.disclaimer.content}
                     textStyle={textStyle}
                     listStyle={listStyle}
                  />
               </div>
            </div>
         </div>
      </>
   );
}
