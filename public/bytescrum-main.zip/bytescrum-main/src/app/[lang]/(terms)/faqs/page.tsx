import PageBanner from "@/components/PageBanner";
import FAQSection from "@/components/ui/FaqSection/FAQSection";
import { getDictionary } from "@/get-dictionary";
import { TLocale } from "@/i18n-config";
import clsx from "clsx";
import { Metadata } from "next";
import React from "react";
import { twMerge } from "tailwind-merge";

export const metadata: Metadata = {
   title: "Frequently Asked Questions | ByteScrum Technologies",
   description:
      "Find answers to common questions about ByteScrum Technologies services, development process, pricing, and project timelines.",
};

type Props = {
   params: { lang: TLocale };
};

export default async function FAQ({ params: { lang } }: Props) {
   const dictionary = await getDictionary(lang);
   const langText = dictionary.faqsPage;

   const jsonLd = {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      name: "Frequently Asked Questions | ByteScrum Technologies",
      url: "https://www.bytescrum.com/faq",

      about: {
         "@type": "CreativeWork",
         name: "ByteScrum FAQ",
         description:
            "Common questions about ByteScrum Technologies services, development process, and how to get started.",
      },
   };

   return (
      <>
         {" "}
         <script
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
         />
         <div className="max-w-[1728px] m-auto bg-[#000000] inter text-[#fff] ">
            <PageBanner
               bgPath={"/aboutUs/banner.png"}
               bannerHeight={"h-[28vh ] md:h-[55vh]"}
               className={twMerge(
                  clsx(
                     "relative overflow-hidden px-[22px] md:px-[54px]  items-center justify-normal "
                  )
               )}
            >
               {" "}
               <div className="space-y-[10px]">
                  <h1
                     className="text-[35px] md:text-[70px] md:leading-[80px] font-light  poppins text-center "
                     data-aos="fade-up"
                     data-aos-delay={300}
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     <span className="font-bold ">{langText.title}</span>
                  </h1>
                  <p
                     className="max-w-[609px] text-[16px] leading-[28px]  text-center m-auto mt-2"
                     data-aos="fade-up"
                     data-aos-delay={500}
                     data-aos-easing="ease-out-cubic"
                     data-aos-anchor-placement="top-bottom"
                  >
                     {langText.routeTitle}
                  </p>
               </div>
            </PageBanner>
            <div className="mx-auto  md:px-[40px] py-10 md:py-20">
               <FAQSection data={langText.faqs} showTitle={false} />
            </div>
         </div>
      </>
   );
}

// const faqs = [
//    {
//       question: "What services does Bytescrum offer?",
//       answer:
//          "Bytescrum offers a comprehensive range of digital services including custom software development, blockchain development, e-commerce solutions, Laravel development, Python development, and website recovery services. We also provide specialized developer hiring services for full-stack, UI/UX, Laravel, PHP, and Shopify development needs.",
//    },
//    {
//       question: "How does your development process work?",
//       answer:
//          "Our development process typically follows these steps: initial consultation, requirements gathering, planning and design, development, testing and quality assurance, deployment, and ongoing support and maintenance. We maintain transparent communication throughout the project lifecycle and adapt our approach based on your specific needs.",
//    },
//    {
//       question: "What technologies do you specialize in?",
//       answer:
//          "We specialize in a wide range of technologies including React, Node.js, Python, Flutter, AWS, Laravel, Angular, Vue.js, MongoDB, Firebase, Ethereum, and Docker. Our team stays updated with the latest technological advancements to provide cutting-edge solutions for your business needs.",
//    },
//    {
//       question: "How much does a typical project cost?",
//       answer:
//          "Project costs vary depending on the scope, complexity, and specific requirements. We provide detailed quotes after understanding your project needs during the initial consultation. We offer flexible pricing models including fixed-price, time and materials, and dedicated team arrangements to suit different project types and budgets.",
//    },
//    {
//       question: "How long does it take to complete a project?",
//       answer:
//          "Project timelines depend on the complexity and scope of work. Simple websites might take 2-4 weeks, while complex custom software applications can take several months. During our initial consultation, we'll provide a more accurate timeline based on your specific requirements and project goals.",
//    },
//    {
//       question: "Do you provide ongoing support after project completion?",
//       answer:
//          "Yes, we offer ongoing support and maintenance services to ensure your application continues to run smoothly after launch. We provide different support packages tailored to your needs, including regular updates, bug fixes, performance optimization, and feature enhancements.",
//    },
//    {
//       question: "How do you ensure the quality of your deliverables?",
//       answer:
//          "We implement rigorous quality assurance processes including code reviews, automated testing, manual testing, and performance testing. Our development follows industry best practices and coding standards. We also maintain regular communication with clients to ensure the final product meets all requirements and expectations.",
//    },
//    {
//       question:
//          "Can you help with an existing project or do you only work on new ones?",
//       answer:
//          "We can definitely help with existing projects. Our team is experienced in code review, refactoring, and taking over maintenance and development of existing applications. We'll assess your current codebase and provide recommendations for improvements or extensions based on your goals.",
//    },
//    {
//       question: "How do I get started with Bytescrum?",
//       answer:
//          "Getting started is easy! Simply reach out to us through our contact form, email, or phone. We'll schedule an initial consultation to discuss your project requirements, goals, and expectations. Based on this discussion, we'll provide you with a proposal including timeline, cost estimates, and a project plan.",
//    },
//    {
//       question: "Do you sign NDAs to protect my business idea?",
//       answer:
//          "Yes, we understand the importance of confidentiality. We're happy to sign Non-Disclosure Agreements (NDAs) before discussing your project details to ensure your business ideas and information remain protected. Client confidentiality is a core value at Bytescrum.",
//    },
// ];
