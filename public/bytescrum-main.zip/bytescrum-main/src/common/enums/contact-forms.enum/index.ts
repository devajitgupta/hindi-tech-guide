export enum EContactFormTypes {
  FREE_CONSULTANCY = "Free consultancy",
  CAREERS = "Careers",
  CONTACT_US = "CONTACT US",
  NEWSLETTER = "Newsletter",
  ADMIN = "admin",
  RECOVER_HACKED_WEBSITE = "Recover Hacked Website"
}
