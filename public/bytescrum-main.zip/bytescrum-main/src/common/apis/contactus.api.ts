const base = "/contact-forms";
const ContactUsApi = {
  base,
  create: base // For POST request
  //   blockResults: base + "/block-results",
  //   unBlockResults: base + "/unblock-results",
  //   removeMany: base + "/remove/many",
  //   removebyQuery: base + "/remove-by-query"
};

export default ContactUsApi;
