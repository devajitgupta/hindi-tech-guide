export type {
  IBaseAPI,
  IDeleteAPI,
  IGetAPI,
  IPatchAPI,
  IPostAPI,
  IAPIResponse
} from "./main.api.interface";
