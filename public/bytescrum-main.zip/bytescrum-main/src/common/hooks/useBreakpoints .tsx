import { useEffect, useState } from "react";

const useBreakpoints = () => {
   const [screenWidth, setScreenWidth] = useState<number>(0);
   const [screenHeight, setScreenHeight] = useState<number>(0);
   const [availScreenWidth, setAvailScreenWidth] = useState<number>(0);
   const [availScreenHeight, setAvailScreenHeight] = useState<number>(0);

   useEffect(() => {
      const updateScreenDimensions = () => {
         setScreenWidth(window.screen.width);
         setScreenHeight(window.screen.height);
         setAvailScreenWidth(window.screen.availWidth);
         setAvailScreenHeight(window.screen.availHeight);
      };

      updateScreenDimensions();

      window.addEventListener("resize", updateScreenDimensions);

      return () => {
         window.removeEventListener("resize", updateScreenDimensions);
      };
   }, []);

   return {
      screenWidth,
      screenHeight,
      availScreenWidth,
      availScreenHeight,
   };
};

export default useBreakpoints;
