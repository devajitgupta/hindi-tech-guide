import { useState, useEffect } from "react";

const useRandomNumber = (length: number, time: number = 3000) => {
   const [randomNumber, setRandomNumber] = useState<number>(0);

   useEffect(() => {
      const interval = setInterval(() => {
         setRandomNumber((prevNumber) => {
            const newRandomNumber = prevNumber + 1;
            return newRandomNumber >= length ? 0 : newRandomNumber;
         });
      }, time);

      return () => clearInterval(interval);
   }, [length, time]);

   return randomNumber;
};

export default useRandomNumber;
