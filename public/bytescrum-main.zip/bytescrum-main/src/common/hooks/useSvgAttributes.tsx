import { useMediaQueries } from "@react-hook/media-query";

interface SvgAttributes {
   svgWidth: string;
   svgHeight: string;
   border: string;
}

const useSvgAttributes = (): SvgAttributes => {
   const { matches } = useMediaQueries({
      md: "only screen and (min-width: 768px) and (max-width: 1023.99px)",
      lg: "only screen and (min-width: 1024px) and (max-width: 1279.99px)",
      xl: "only screen and (min-width: 1280px) ",
   });

   const activeQuery = matches.md
      ? "md"
      : matches.lg
      ? "lg"
      : matches.xl
      ? "xl"
      : //   : matches.xxl
        //   ? "2xl"
        "default";

   const getSvgAttributes = (query: typeof activeQuery): SvgAttributes => {
      switch (activeQuery) {
         case "md":
            return {
               svgWidth: "800",
               svgHeight: "630",
               border: "border border-red-500",
            };

         case "lg":
            return {
               svgWidth: "975",
               svgHeight: "767",
               border: "border border-green-500",
            };

         case "xl":
            return {
               svgWidth: "1170",
               svgHeight: "916",
               border: "border border-blue-500",
            };
         //  case "2xl":
         //     return {
         //        svgWidth: "1152",
         //        svgHeight: "901",
         //        border: "border border-pink-500",
         //     };
         default:
            return {
               svgWidth: "1170",
               svgHeight: "916",
               border: "border border-white-500",
            };
      }
   };

   return getSvgAttributes(activeQuery);
};

export default useSvgAttributes;
