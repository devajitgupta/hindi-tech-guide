"use cliet";
import { useAnimation } from "framer-motion";
import { useEffect } from "react";

const icon = {
   hidden: {
      opacity: 0,
      pathLength: 0,
   },
   visible: {
      opacity: 1,
      pathLength: 1,
   },
};

const useAnimatedLine = (
   delay: number,
   repeatDelay: number,
   duration: number
) => {
   const controls = useAnimation();

   useEffect(() => {
      controls.start({
         opacity: 1,
         transition: {
            repeat: Infinity,
            repeatType: "loop",
            repeatDelay: repeatDelay,
            delay: delay,
            duration: duration,
            ease: "easeInOut",
         },
      });
   }, [controls, delay, repeatDelay, duration]);

   return controls;
};

export default useAnimatedLine;
