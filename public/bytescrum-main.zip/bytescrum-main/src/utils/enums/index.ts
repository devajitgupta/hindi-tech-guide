import { TLocale } from "@/i18n-config";

export enum EContactFormTypes {
  FREE_CONSULTANCY = "Free consultancy",
  CAREERS = "Careers",
  CONTACT_US = "CONTACT US",
  NEWSLETTER = "Newsletter",
  ADMIN = "admin",
  RECOVER_HACKED_WEBSITE = "Recover Hacked Website"
}
export const genLinkServer = (link: string, lang: TLocale) => {
   if (lang === "en") return link;

   return `/${lang}${link}`;
};
