// // import { withHydrationOverlay } from "@builder.io/react-hydration-overlay/next";

// // /** @type {import('next').NextConfig} */
// const nextConfig = {
//    trailingSlash: true,
//    async headers() {
//       return [
//          {
//             source: "/(.*)",
//             headers: [
//                {
//                   key: "Content-Security-Policy",
//                   value:
//                      "default-src 'self'; " +
//                      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://fonts.googleapis.com; " +
//                      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
//                      "font-src 'self' data: https://fonts.gstatic.com; " +
//                      "connect-src 'self' https://fonts.googleapis.com https://fonts.gstatic.com;",
//                },
//             ],
//          },
//       ];
//    },
// };

// // export default withHydrationOverlay({
// //    /**
// //     * Optional: `appRootSelector` is the selector for the root element of your app. By default, it is `#__next` which works
// //     * for Next.js apps with pages directory. If you are using the app directory, you should change this to `main`.
// //     */
// //    appRootSelector: "main",
// // })(nextConfig);

// import { withHydrationOverlay } from "@builder.io/react-hydration-overlay/next";

// /** @type {import('next').NextConfig} */
// const nextConfig = {
//    trailingSlash: true,

//    async headers() {
//       return [
//          {
//             source: "/(.*)",
//             headers: [
//                {
//                   key: "Content-Security-Policy",
//                   value:
//                      "default-src 'self'; " +
//                      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://fonts.googleapis.com; " +
//                      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
//                      "font-src 'self' data: https://fonts.gstatic.com; " +
//                      "connect-src 'self' https://fonts.googleapis.com https://fonts.gstatic.com;",
//                },
//             ],
//          },
//       ];
//    },
// };

// export default nextConfig;

/** @type {import('next').NextConfig} */
const nextConfig = {
   trailingSlash: true,

   async headers() {
      return [
         {
            source: "/(.*)",
            headers: [
               {
                  key: "Content-Security-Policy",
                  value:
                     "default-src 'self'; " +
                     "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://fonts.googleapis.com https://code.iconify.design; " +
                     "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
                     "font-src 'self' data: https://fonts.gstatic.com; " +
                     "img-src 'self' data: https://api.iconify.design https://code.iconify.design; " +
                     "frame-src https://www.google.com https://maps.googleapis.com; " +
                     "connect-src 'self' https://fonts.googleapis.com https://fonts.gstatic.com https://api.iconify.design https://code.iconify.design;",
               },
            ],
         },
      ];
   },
};

export default nextConfig;
