import type { Config } from "tailwindcss";
const defaultTheme = require("tailwindcss/defaultTheme");
import { nextui } from "@nextui-org/react";
const config: Config = {
   content: [
      "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
      "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
      "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
      "./node_modules/@nextui-org/theme/dist/**/*.{js,ts,jsx,tsx}",
   ],
   theme: {
      extend: {
         backgroundImage: {
            "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
            "gradient-conic":
               "conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))",
         },
         keyframes: {
            marqueRight: {
               "0%": { left: "-100%" },
               "100%": { left: "0" },
            },
            marqueLeft: {
               "0%": { right: "-100%" },
               "100%": { right: "0" },
            },
            marqueTop: {
               "0%": { bottom: "-100%" },
               "100%": { bottom: "0" },
            },
         },

         screens: {
            xs: "391px",
            ...defaultTheme.screens,
         },
      },
   },
   plugins: [nextui(), require("tailwindcss-animated")],
};
export default config;
